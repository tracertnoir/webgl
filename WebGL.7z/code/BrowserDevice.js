/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.up)throw new Error("The unit file 'BrowserDevice.js' included twice!"
);EmWiApp.up=(function(){var A=EmWiApp;var E={};

E.Bn={Gh:function(){var sraw=A.tA(20,A.hm,null);var iraw=A.tA(100,0,null);var I;for(
I=0;I<20;I=I+1)sraw.Set(I,A.hm);for(I=0;I<100;I=I+1)iraw.Set(I,0);{doSend("GET_DATA..."
);if(Object.keys(jsonDatas).length>0){console.log("JsonCount = "+Object.keys(jsonDatas
).length);sraw[0]=jsonDatas.LOTID;sraw[1]=jsonDatas.STEP_CODE;sraw[2]=jsonDatas.
RECIPE_NAME.trimEnd();sraw[3]=jsonDatas.JOB_TIME;sraw[4]=jsonDatas.EVENT_TIME;sraw[
5]=jsonDatas.HOLD_TIME;sraw[6]=jsonDatas.TOTAL_TIME;iraw[0]=parseFloat(jsonDatas.
TEMP_SV_01)*10;iraw[1]=parseFloat(jsonDatas.TEMP_SV_02)*10;iraw[2]=parseFloat(jsonDatas.
TEMP_SV_03)*10;iraw[3]=parseFloat(jsonDatas.TEMP_SV_04)*10;iraw[10]=parseFloat(jsonDatas.
TEMP_FFC_01)*10;iraw[11]=parseFloat(jsonDatas.TEMP_FFC_02)*10;iraw[12]=parseFloat(
jsonDatas.TEMP_FFC_03)*10;iraw[13]=parseFloat(jsonDatas.TEMP_FFC_04)*10;iraw[14]=
parseFloat(jsonDatas.TEMP_FFC_05)*10;iraw[15]=parseFloat(jsonDatas.TEMP_FFC_06)*
10;iraw[16]=parseFloat(jsonDatas.TEMP_FFC_07)*10;iraw[17]=parseFloat(jsonDatas.TEMP_FFC_08
)*10;iraw[20]=parseFloat(jsonDatas.TEMP_DDC_01)*10;iraw[21]=parseFloat(jsonDatas.
TEMP_DDC_02)*10;iraw[22]=parseFloat(jsonDatas.TEMP_DDC_03)*10;iraw[23]=parseFloat(
jsonDatas.TEMP_DDC_04)*10;iraw[24]=parseFloat(jsonDatas.TEMP_DDC_05)*10;iraw[25]=
parseFloat(jsonDatas.TEMP_DDC_06)*10;iraw[26]=parseFloat(jsonDatas.TEMP_DDC_07)*
10;iraw[27]=parseFloat(jsonDatas.TEMP_DDC_08)*10;iraw[30]=parseFloat(jsonDatas.TEMP_DEV_01
)*10;iraw[31]=parseFloat(jsonDatas.TEMP_DEV_02)*10;iraw[32]=parseFloat(jsonDatas.
TEMP_DEV_03)*10;iraw[33]=parseFloat(jsonDatas.TEMP_DEV_04)*10;iraw[34]=parseFloat(
jsonDatas.TEMP_CAL_01)*10;iraw[35]=parseFloat(jsonDatas.TEMP_CAL_02)*10;iraw[36]=
parseFloat(jsonDatas.TEMP_CAL_03)*10;iraw[37]=parseFloat(jsonDatas.TEMP_CAL_04)*
10;iraw[40]=parseFloat(jsonDatas.GAS_SV_01)*1000;iraw[41]=parseFloat(jsonDatas.GAS_SV_02
)*1000;iraw[42]=parseFloat(jsonDatas.GAS_SV_03)*1000;iraw[43]=parseFloat(jsonDatas.
GAS_SV_04)*1000;iraw[44]=parseFloat(jsonDatas.GAS_SV_05)*1000;iraw[45]=parseFloat(
jsonDatas.GAS_SV_06)*1000;iraw[46]=parseFloat(jsonDatas.GAS_SV_07)*1000;iraw[47]=
parseFloat(jsonDatas.GAS_SV_08)*1000;iraw[50]=parseFloat(jsonDatas.GAS_PV_01)*1000;
iraw[51]=parseFloat(jsonDatas.GAS_PV_02)*1000;iraw[52]=parseFloat(jsonDatas.GAS_PV_03
)*1000;iraw[53]=parseFloat(jsonDatas.GAS_PV_04)*1000;iraw[54]=parseFloat(jsonDatas.
GAS_PV_05)*1000;iraw[55]=parseFloat(jsonDatas.GAS_PV_06)*1000;iraw[56]=parseFloat(
jsonDatas.GAS_PV_07)*1000;iraw[57]=parseFloat(jsonDatas.GAS_PV_08)*1000;iraw[60]=
parseFloat(jsonDatas.GAS_PV_11)*1000;iraw[61]=parseFloat(jsonDatas.GAS_PV_12)*1000;
iraw[62]=parseFloat(jsonDatas.GAS_PV_13)*1000;iraw[63]=parseFloat(jsonDatas.GAS_PV_14
)*1000;iraw[64]=parseFloat(jsonDatas.GAS_PV_15)*1000;iraw[65]=parseFloat(jsonDatas.
GAS_PV_16)*1000;iraw[66]=parseFloat(jsonDatas.GAS_PV_17)*1000;iraw[67]=parseFloat(
jsonDatas.GAS_PV_18)*1000;iraw[70]=parseFloat(jsonDatas.TEMP_BURN_01)*10;iraw[71
]=parseFloat(jsonDatas.TEMP_BURN_02)*10;iraw[72]=parseFloat(jsonDatas.TEMP_BURN_03
)*10;iraw[73]=parseFloat(jsonDatas.TEMP_BURN_04)*10;iraw[74]=parseFloat(jsonDatas.
TEMP_BURN_LAMP)*1;iraw[75]=parseFloat(jsonDatas.TEMP_BURN_FRAME)*1;iraw[76]=parseFloat(
jsonDatas.TEMP_BURN_07)*10;iraw[77]=parseFloat(jsonDatas.TEMP_BURN_08)*10;iraw[80
]=parseFloat(jsonDatas.APC_01)*10;iraw[81]=parseFloat(jsonDatas.APC_02)*10;iraw[
82]=parseFloat(jsonDatas.APC_03)*10;iraw[83]=parseFloat(jsonDatas.APC_04)*10;iraw[
84]=parseFloat(jsonDatas.APC_01)*10;iraw[85]=parseFloat(jsonDatas.APC_02)*10;iraw[
86]=parseFloat(jsonDatas.APC_03)*10;iraw[87]=parseFloat(jsonDatas.APC_04)*10;iraw[
90]=parseFloat(jsonDatas.LEAK_01)*10;iraw[91]=parseFloat(jsonDatas.LEAK_02)*10;iraw[
92]=parseFloat(jsonDatas.LEAK_03)*10;iraw[93]=parseFloat(jsonDatas.LEAK_04)*10;iraw[
94]=parseFloat(jsonDatas.LEAK_01)*10;iraw[95]=parseFloat(jsonDatas.LEAK_02)*10;iraw[
96]=parseFloat(jsonDatas.LEAK_03)*10;iraw[97]=parseFloat(jsonDatas.LEAK_04)*10;}
}this.Ey(sraw.Get(0));this.EA(sraw.Get(1));this.Ez(sraw.Get(2));this.Ex(sraw.Get(
3));this.Ew(sraw.Get(4));this.Ea(sraw.Get(5));this.EG(sraw.Get(6));this.EC(iraw.
Get(0));this.ED(iraw.Get(1));this.EE(iraw.Get(2));this.EF(iraw.Get(3));this.Eb(iraw.
Get(10));this.Ec(iraw.Get(11));this.Ed(iraw.Get(12));this.Ee(iraw.Get(13));this.
D8(iraw.Get(20));this.D9(iraw.Get(21));this.D_(iraw.Get(22));this.D$(iraw.Get(23
));this.Eo(iraw.Get(40));this.Ep(iraw.Get(41));this.Eq(iraw.Get(42));this.Er(iraw.
Get(43));this.Es(iraw.Get(44));this.Et(iraw.Get(45));this.Eu(iraw.Get(46));this.
Ev(iraw.Get(47));this.Eg(iraw.Get(50));this.Eh(iraw.Get(51));this.Ei(iraw.Get(52
));this.Ej(iraw.Get(53));this.Ek(iraw.Get(54));this.El(iraw.Get(55));this.Em(iraw.
Get(56));this.En(iraw.Get(57));A.uf("%s",this.EI);},Gi:function(){init_websocket(
);},EA:function(C){if(this.EI===C)return;this.EI=C;A.tG([this,this.ID,this.EA],0
);},Ey:function(C){if(this.Fb===C)return;this.Fb=C;A.tG([this,this.IB,this.Ey],0
);},Ez:function(C){if(this.Ff===C)return;this.Ff=C;A.tG([this,this.IC,this.Ez],0
);},Ex:function(C){if(this.Fa===C)return;this.Fa=C;A.tG([this,this.IA,this.Ex],0
);},Ea:function(C){if(this.E5===C)return;this.E5=C;A.tG([this,this.Ig,this.Ea],0
);},Ew:function(C){if(this.E_===C)return;this.E_=C;A.tG([this,this.Iz,this.Ew],0
);},EG:function(C){if(this.Fl===C)return;this.Fl=C;A.tG([this,this.II,this.EG],0
);},Eb:function(C){if(this.DQ===C)return;this.DQ=C;A.tG([this,this.Ih,this.Eb],0
);},D8:function(C){if(this.DN===C)return;this.DN=C;A.tG([this,this.Id,this.D8],0
);},Ec:function(C){if(this.CG===C)return;this.CG=C;A.tG([this,this.Ii,this.Ec],0
);},D9:function(C){if(this.CF===C)return;this.CF=C;A.tG([this,this.Ie,this.D9],0
);},Ed:function(C){if(this.H5===C)return;this.H5=C;A.tG([this,this.G7,this.Ed],0
);},EC:function(C){if(this.EJ===C)return;this.EJ=C;A.tG([this,this.IE,this.EC],0
);},ED:function(C){if(this.EK===C)return;this.EK=C;A.tG([this,this.IF,this.ED],0
);},EE:function(C){if(this.EL===C)return;this.EL=C;A.tG([this,this.IG,this.EE],0
);},EF:function(C){if(this.EM===C)return;this.EM=C;A.tG([this,this.IH,this.EF],0
);},Eo:function(C){if(this.Do===C)return;this.Do=C;A.tG([this,this.Is,this.Eo],0
);},Ep:function(C){if(this.D0===C)return;this.D0=C;A.tG([this,this.It,this.Ep],0
);},Eq:function(C){if(this.D1===C)return;this.D1=C;A.tG([this,this.Iu,this.Eq],0
);},Er:function(C){if(this.D2===C)return;this.D2=C;A.tG([this,this.Iv,this.Er],0
);},Es:function(C){if(this.D3===C)return;this.D3=C;A.tG([this,this.Iw,this.Es],0
);},Et:function(C){if(this.D4===C)return;this.D4=C;A.tG([this,this.Ix,this.Et],0
);},Eu:function(C){if(this.D5===C)return;this.D5=C;A.tG([this,this.Iy,this.Eu],0
);},Ev:function(C){if(this.FW===C)return;this.FW=C;A.tG([this,this.G8,this.Ev],0
);},Eg:function(C){if(this.DS===C)return;this.DS=C;A.tG([this,this.Ik,this.Eg],0
);},Eh:function(C){if(this.DT===C)return;this.DT=C;A.tG([this,this.Il,this.Eh],0
);},Ei:function(C){if(this.DU===C)return;this.DU=C;A.tG([this,this.Im,this.Ei],0
);},Ej:function(C){if(this.DV===C)return;this.DV=C;A.tG([this,this.In,this.Ej],0
);},Ek:function(C){if(this.DW===C)return;this.DW=C;A.tG([this,this.Io,this.Ek],0
);},El:function(C){if(this.DX===C)return;this.DX=C;A.tG([this,this.Ip,this.El],0
);},Em:function(C){if(this.DY===C)return;this.DY=C;A.tG([this,this.Iq,this.Em],0
);},En:function(C){if(this.DZ===C)return;this.DZ=C;A.tG([this,this.Ir,this.En],0
);},D_:function(C){if(this.H3===C)return;this.H3=C;A.tG([this,this.G6,this.D_],0
);},Ee:function(C){if(this.DR===C)return;this.DR=C;A.tG([this,this.Ij,this.Ee],0
);},D$:function(C){if(this.DO===C)return;this.DO=C;A.tG([this,this.If,this.D$],0
);},_Init:function(aArg){var H=this.H;H.__proto__=E.Bn;A.gv++;},_Done:function(){
var H=this.H;H.__proto__=null;A.gv--;},_ReInit:function(){},_Mark:function(D){},
_variants:function(){return this;},_className:"BrowserDevice::DeviceClass"};var eqDatas;
var jsonDatas;function init_websocket(){var wsUri="ws://"+location.hostname+":5080/";
websocket=new WebSocket(wsUri);websocket.onopen=function(evt){onOpen(evt)};websocket.
onclose=function(evt){onClose(evt)};websocket.onmessage=function(evt){onMessage(
evt)};websocket.onerror=function(evt){onError(evt)};}function onOpen(evt){console.
log("onOpen");}function onClose(evt){console.log("onClose");}function onMessage(
evt){console.log(evt.data);jsonDatas=JSON.parse(evt.data);}function onError(evt){
console.log("onError");}function doSend(message){console.log("doSend");if(websocket.
readyState==1){websocket.send(message);}console.log(websocket.readyState);}
E._Init=function(){};E.Av=function(D){};return E;})();

/* Embedded Wizard */