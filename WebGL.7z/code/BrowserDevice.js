/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.up)throw new Error("The unit file 'BrowserDevice.js' included twice!"
);EmWiApp.up=(function(){var A=EmWiApp;var E={};

E.Bn={Fy:function(){var sraw=A.tA(20,A.hm,null);var iraw=A.tA(100,0,null);var H;for(
H=0;H<20;H=H+1)sraw.Set(H,A.hm);for(H=0;H<100;H=H+1)iraw.Set(H,0);{doSend("GET_DATA..."
);if(Object.keys(jsonDatas).length>0){console.log("JsonCount = "+Object.keys(jsonDatas
).length);sraw[0]=jsonDatas.LOTID;sraw[1]=jsonDatas.STEP_CODE;sraw[2]=jsonDatas.
RECIPE_NAME.trimEnd();sraw[3]=jsonDatas.JOB_TIME;sraw[4]=jsonDatas.EVENT_TIME;sraw[
5]=jsonDatas.HOLD_TIME;sraw[6]=jsonDatas.TOTAL_TIME;sraw[7]=jsonDatas.EQ_NAME;iraw[
0]=parseFloat(jsonDatas.TEMP_SV_01)*10;iraw[1]=parseFloat(jsonDatas.TEMP_SV_02)*
10;iraw[2]=parseFloat(jsonDatas.TEMP_SV_03)*10;iraw[3]=parseFloat(jsonDatas.TEMP_SV_04
)*10;iraw[10]=parseFloat(jsonDatas.TEMP_FFC_01)*10;iraw[11]=parseFloat(jsonDatas.
TEMP_FFC_02)*10;iraw[12]=parseFloat(jsonDatas.TEMP_FFC_03)*10;iraw[13]=parseFloat(
jsonDatas.TEMP_FFC_04)*10;iraw[14]=parseFloat(jsonDatas.TEMP_FFC_05)*10;iraw[15]=
parseFloat(jsonDatas.TEMP_FFC_06)*10;iraw[16]=parseFloat(jsonDatas.TEMP_FFC_07)*
10;iraw[17]=parseFloat(jsonDatas.TEMP_FFC_08)*10;iraw[20]=parseFloat(jsonDatas.TEMP_DDC_01
)*10;iraw[21]=parseFloat(jsonDatas.TEMP_DDC_02)*10;iraw[22]=parseFloat(jsonDatas.
TEMP_DDC_03)*10;iraw[23]=parseFloat(jsonDatas.TEMP_DDC_04)*10;iraw[24]=parseFloat(
jsonDatas.TEMP_DDC_05)*10;iraw[25]=parseFloat(jsonDatas.TEMP_DDC_06)*10;iraw[26]=
parseFloat(jsonDatas.TEMP_DDC_07)*10;iraw[27]=parseFloat(jsonDatas.TEMP_DDC_08)*
10;iraw[30]=parseFloat(jsonDatas.TEMP_DEV_01)*10;iraw[31]=parseFloat(jsonDatas.TEMP_DEV_02
)*10;iraw[32]=parseFloat(jsonDatas.TEMP_DEV_03)*10;iraw[33]=parseFloat(jsonDatas.
TEMP_DEV_04)*10;iraw[34]=parseFloat(jsonDatas.TEMP_CAL_01)*10;iraw[35]=parseFloat(
jsonDatas.TEMP_CAL_02)*10;iraw[36]=parseFloat(jsonDatas.TEMP_CAL_03)*10;iraw[37]=
parseFloat(jsonDatas.TEMP_CAL_04)*10;iraw[40]=parseFloat(jsonDatas.GAS_SV_01)*1000;
iraw[41]=parseFloat(jsonDatas.GAS_SV_02)*1000;iraw[42]=parseFloat(jsonDatas.GAS_SV_03
)*1000;iraw[43]=parseFloat(jsonDatas.GAS_SV_04)*1000;iraw[44]=parseFloat(jsonDatas.
GAS_SV_05)*1000;iraw[45]=parseFloat(jsonDatas.GAS_SV_06)*1000;iraw[46]=parseFloat(
jsonDatas.GAS_SV_07)*1000;iraw[47]=parseFloat(jsonDatas.GAS_SV_08)*1000;iraw[50]=
parseFloat(jsonDatas.GAS_PV_01)*1000;iraw[51]=parseFloat(jsonDatas.GAS_PV_02)*1000;
iraw[52]=parseFloat(jsonDatas.GAS_PV_03)*1000;iraw[53]=parseFloat(jsonDatas.GAS_PV_04
)*1000;iraw[54]=parseFloat(jsonDatas.GAS_PV_05)*1000;iraw[55]=parseFloat(jsonDatas.
GAS_PV_06)*1000;iraw[56]=parseFloat(jsonDatas.GAS_PV_07)*1000;iraw[57]=parseFloat(
jsonDatas.GAS_PV_08)*1000;iraw[60]=parseFloat(jsonDatas.GAS_PV_11)*1000;iraw[61]=
parseFloat(jsonDatas.GAS_PV_12)*1000;iraw[62]=parseFloat(jsonDatas.GAS_PV_13)*1000;
iraw[63]=parseFloat(jsonDatas.GAS_PV_14)*1000;iraw[64]=parseFloat(jsonDatas.GAS_PV_15
)*1000;iraw[65]=parseFloat(jsonDatas.GAS_PV_16)*1000;iraw[66]=parseFloat(jsonDatas.
GAS_PV_17)*1000;iraw[67]=parseFloat(jsonDatas.GAS_PV_18)*1000;iraw[70]=parseFloat(
jsonDatas.TEMP_BURN_01)*10;iraw[71]=parseFloat(jsonDatas.TEMP_BURN_02)*10;iraw[72
]=parseFloat(jsonDatas.TEMP_BURN_03)*10;iraw[73]=parseFloat(jsonDatas.TEMP_BURN_04
)*10;iraw[74]=parseFloat(jsonDatas.TEMP_BURN_LAMP)*1;iraw[75]=parseFloat(jsonDatas.
TEMP_BURN_FRAME)*1;iraw[76]=parseFloat(jsonDatas.TEMP_BURN_07)*10;iraw[77]=parseFloat(
jsonDatas.TEMP_BURN_08)*10;iraw[80]=parseFloat(jsonDatas.APC_01)*10;iraw[81]=parseFloat(
jsonDatas.APC_02)*10;iraw[82]=parseFloat(jsonDatas.APC_03)*10;iraw[83]=parseFloat(
jsonDatas.APC_04)*10;iraw[84]=parseFloat(jsonDatas.APC_01)*10;iraw[85]=parseFloat(
jsonDatas.APC_02)*10;iraw[86]=parseFloat(jsonDatas.APC_03)*10;iraw[87]=parseFloat(
jsonDatas.APC_04)*10;iraw[90]=parseFloat(jsonDatas.LEAK_01)*10;iraw[91]=parseFloat(
jsonDatas.LEAK_02)*10;iraw[92]=parseFloat(jsonDatas.LEAK_03)*10;iraw[93]=parseFloat(
jsonDatas.LEAK_04)*10;iraw[94]=parseFloat(jsonDatas.LEAK_01)*10;iraw[95]=parseFloat(
jsonDatas.LEAK_02)*10;iraw[96]=parseFloat(jsonDatas.LEAK_03)*10;iraw[97]=parseFloat(
jsonDatas.LEAK_04)*10;}}this.G2(sraw.Get(0));this.G4(sraw.Get(1));this.G3(sraw.Get(
2));this.G1(sraw.Get(3));this.G0(sraw.Get(4));this.GE(sraw.Get(5));this.G9(sraw.
Get(6));this.GD(sraw.Get(7));this.G5(iraw.Get(0));this.G6(iraw.Get(1));this.G7(iraw.
Get(2));this.G8(iraw.Get(3));this.GF(iraw.Get(10));this.GG(iraw.Get(11));this.GH(
iraw.Get(12));this.GI(iraw.Get(13));this.Gz(iraw.Get(20));this.GA(iraw.Get(21));
this.GB(iraw.Get(22));this.GC(iraw.Get(23));this.GS(iraw.Get(40));this.GT(iraw.Get(
41));this.GU(iraw.Get(42));this.GV(iraw.Get(43));this.GW(iraw.Get(44));this.GX(iraw.
Get(45));this.GY(iraw.Get(46));this.GZ(iraw.Get(47));this.GK(iraw.Get(50));this.
GL(iraw.Get(51));this.GM(iraw.Get(52));this.GN(iraw.Get(53));this.GO(iraw.Get(54
));this.GP(iraw.Get(55));this.GQ(iraw.Get(56));this.GR(iraw.Get(57));A.uf("%i",iraw.
Get(47));},Fz:function(){init_websocket();},_Init:function(aArg){var AW=this.AW;
AW.__proto__=E.Bn;A.gv++;},_Done:function(){var AW=this.AW;AW.__proto__=null;A.gv--;
},_ReInit:function(){},_Mark:function(D){},_variants:function(){return this;},_className:
"BrowserDevice::DeviceClass"};var eqDatas;var jsonDatas;function init_websocket(
){var wsUri="ws://"+location.hostname+":5080/";websocket=new WebSocket(wsUri);websocket.
onopen=function(evt){onOpen(evt)};websocket.onclose=function(evt){onClose(evt)};
websocket.onmessage=function(evt){onMessage(evt)};websocket.onerror=function(evt
){onError(evt)};}function onOpen(evt){console.log("onOpen");}function onClose(evt
){console.log("onClose");}function onMessage(evt){console.log(evt.data);jsonDatas=
JSON.parse(evt.data);}function onError(evt){console.log("onError");}function doSend(
message){console.log("doSend");if(websocket.readyState==1){websocket.send(message
);}console.log(websocket.readyState);}
E._Init=function(){};E.Au=function(D){};return E;})();

/* Embedded Wizard */