/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.up)throw new Error("The unit file 'BrowserDevice.js' included twice!"
);EmWiApp.up=(function(){var A=EmWiApp;var E={};

E.Bl={Gh:function(){var sraw=A.tA(20,A.hm,null);var iraw=A.tA(100,0,null);var I;for(
I=0;I<20;I=I+1)sraw.Set(I,A.hm);for(I=0;I<100;I=I+1)iraw.Set(I,0);{doSend("GET_DATA..."
);if(Object.keys(jsonDatas).length>0){console.log("JsonCount = "+Object.keys(jsonDatas
).length);sraw[0]=jsonDatas.LOTID;sraw[1]=jsonDatas.STEP_CODE;sraw[2]=jsonDatas.
RECIPE_NAME.trimEnd();sraw[3]=jsonDatas.JOB_TIME;sraw[4]=jsonDatas.EVENT_TIME;sraw[
5]=jsonDatas.HOLD_TIME;sraw[6]=jsonDatas.TOTAL_TIME;iraw[0]=parseFloat(jsonDatas.
TEMP_SV_01)*10;iraw[1]=parseFloat(jsonDatas.TEMP_SV_02)*10;iraw[2]=parseFloat(jsonDatas.
TEMP_SV_03)*10;iraw[3]=parseFloat(jsonDatas.TEMP_SV_04)*10;iraw[10]=parseFloat(jsonDatas.
TEMP_FFC_01)*10;iraw[11]=parseFloat(jsonDatas.TEMP_FFC_02)*10;iraw[12]=parseFloat(
jsonDatas.TEMP_FFC_03)*10;iraw[13]=parseFloat(jsonDatas.TEMP_FFC_04)*10;iraw[14]=
parseFloat(jsonDatas.TEMP_FFC_05)*10;iraw[15]=parseFloat(jsonDatas.TEMP_FFC_06)*
10;iraw[16]=parseFloat(jsonDatas.TEMP_FFC_07)*10;iraw[17]=parseFloat(jsonDatas.TEMP_FFC_08
)*10;iraw[20]=parseFloat(jsonDatas.TEMP_DDC_01)*10;iraw[21]=parseFloat(jsonDatas.
TEMP_DDC_02)*10;iraw[22]=parseFloat(jsonDatas.TEMP_DDC_03)*10;iraw[23]=parseFloat(
jsonDatas.TEMP_DDC_04)*10;iraw[24]=parseFloat(jsonDatas.TEMP_DDC_05)*10;iraw[25]=
parseFloat(jsonDatas.TEMP_DDC_06)*10;iraw[26]=parseFloat(jsonDatas.TEMP_DDC_07)*
10;iraw[27]=parseFloat(jsonDatas.TEMP_DDC_08)*10;iraw[30]=parseFloat(jsonDatas.TEMP_DEV_01
)*10;iraw[31]=parseFloat(jsonDatas.TEMP_DEV_02)*10;iraw[32]=parseFloat(jsonDatas.
TEMP_DEV_03)*10;iraw[33]=parseFloat(jsonDatas.TEMP_DEV_04)*10;iraw[34]=parseFloat(
jsonDatas.TEMP_CAL_01)*10;iraw[35]=parseFloat(jsonDatas.TEMP_CAL_02)*10;iraw[36]=
parseFloat(jsonDatas.TEMP_CAL_03)*10;iraw[37]=parseFloat(jsonDatas.TEMP_CAL_04)*
10;iraw[40]=parseFloat(jsonDatas.GAS_SV_01)*1000;iraw[41]=parseFloat(jsonDatas.GAS_SV_02
)*1000;iraw[42]=parseFloat(jsonDatas.GAS_SV_03)*1000;iraw[43]=parseFloat(jsonDatas.
GAS_SV_04)*1000;iraw[44]=parseFloat(jsonDatas.GAS_SV_05)*1000;iraw[45]=parseFloat(
jsonDatas.GAS_SV_06)*1000;iraw[46]=parseFloat(jsonDatas.GAS_SV_07)*1000;iraw[47]=
parseFloat(jsonDatas.GAS_SV_08)*1000;iraw[50]=parseFloat(jsonDatas.GAS_PV_01)*1000;
iraw[51]=parseFloat(jsonDatas.GAS_PV_02)*1000;iraw[52]=parseFloat(jsonDatas.GAS_PV_03
)*1000;iraw[53]=parseFloat(jsonDatas.GAS_PV_04)*1000;iraw[54]=parseFloat(jsonDatas.
GAS_PV_05)*1000;iraw[55]=parseFloat(jsonDatas.GAS_PV_06)*1000;iraw[56]=parseFloat(
jsonDatas.GAS_PV_07)*1000;iraw[57]=parseFloat(jsonDatas.GAS_PV_08)*1000;iraw[60]=
parseFloat(jsonDatas.GAS_PV_11)*1000;iraw[61]=parseFloat(jsonDatas.GAS_PV_12)*1000;
iraw[62]=parseFloat(jsonDatas.GAS_PV_13)*1000;iraw[63]=parseFloat(jsonDatas.GAS_PV_14
)*1000;iraw[64]=parseFloat(jsonDatas.GAS_PV_15)*1000;iraw[65]=parseFloat(jsonDatas.
GAS_PV_16)*1000;iraw[66]=parseFloat(jsonDatas.GAS_PV_17)*1000;iraw[67]=parseFloat(
jsonDatas.GAS_PV_18)*1000;iraw[70]=parseFloat(jsonDatas.TEMP_BURN_01)*10;iraw[71
]=parseFloat(jsonDatas.TEMP_BURN_02)*10;iraw[72]=parseFloat(jsonDatas.TEMP_BURN_03
)*10;iraw[73]=parseFloat(jsonDatas.TEMP_BURN_04)*10;iraw[74]=parseFloat(jsonDatas.
TEMP_BURN_LAMP)*1;iraw[75]=parseFloat(jsonDatas.TEMP_BURN_FRAME)*1;iraw[76]=parseFloat(
jsonDatas.TEMP_BURN_07)*10;iraw[77]=parseFloat(jsonDatas.TEMP_BURN_08)*10;iraw[80
]=parseFloat(jsonDatas.APC_01)*10;iraw[81]=parseFloat(jsonDatas.APC_02)*10;iraw[
82]=parseFloat(jsonDatas.APC_03)*10;iraw[83]=parseFloat(jsonDatas.APC_04)*10;iraw[
84]=parseFloat(jsonDatas.APC_01)*10;iraw[85]=parseFloat(jsonDatas.APC_02)*10;iraw[
86]=parseFloat(jsonDatas.APC_03)*10;iraw[87]=parseFloat(jsonDatas.APC_04)*10;iraw[
90]=parseFloat(jsonDatas.LEAK_01)*10;iraw[91]=parseFloat(jsonDatas.LEAK_02)*10;iraw[
92]=parseFloat(jsonDatas.LEAK_03)*10;iraw[93]=parseFloat(jsonDatas.LEAK_04)*10;iraw[
94]=parseFloat(jsonDatas.LEAK_01)*10;iraw[95]=parseFloat(jsonDatas.LEAK_02)*10;iraw[
96]=parseFloat(jsonDatas.LEAK_03)*10;iraw[97]=parseFloat(jsonDatas.LEAK_04)*10;}
}this.Eh(sraw.Get(0));this.Ej(sraw.Get(1));this.Ei(sraw.Get(2));this.Eg(sraw.Get(
3));this.Ef(sraw.Get(4));this.D$(sraw.Get(5));this.Ep(sraw.Get(6));this.El(iraw.
Get(0));this.Em(iraw.Get(1));this.En(iraw.Get(2));this.Eo(iraw.Get(3));this.Ea(iraw.
Get(10));this.Eb(iraw.Get(11));this.Ec(iraw.Get(12));this.Ed(iraw.Get(13));this.
D7(iraw.Get(20));this.D8(iraw.Get(21));this.D9(iraw.Get(22));this.D_(iraw.Get(23
));A.uf("%s",this.Er);},Gi:function(){init_websocket();},Ej:function(C){if(this.
Er===C)return;this.Er=C;A.tG([this,this.ID,this.Ej],0);},Eh:function(C){if(this.
EV===C)return;this.EV=C;A.tG([this,this.IB,this.Eh],0);},Ei:function(C){if(this.
Fd===C)return;this.Fd=C;A.tG([this,this.IC,this.Ei],0);},Eg:function(C){if(this.
EU===C)return;this.EU=C;A.tG([this,this.IA,this.Eg],0);},D$:function(C){if(this.
EN===C)return;this.EN=C;A.tG([this,this.Ig,this.D$],0);},Ef:function(C){if(this.
ES===C)return;this.ES=C;A.tG([this,this.Iz,this.Ef],0);},Ep:function(C){if(this.
Fj===C)return;this.Fj=C;A.tG([this,this.II,this.Ep],0);},Ea:function(C){if(this.
DQ===C)return;this.DQ=C;A.tG([this,this.Ih,this.Ea],0);},D7:function(C){if(this.
DN===C)return;this.DN=C;A.tG([this,this.Id,this.D7],0);},Eb:function(C){if(this.
CG===C)return;this.CG=C;A.tG([this,this.Ii,this.Eb],0);},D8:function(C){if(this.
CF===C)return;this.CF=C;A.tG([this,this.Ie,this.D8],0);},Ec:function(C){if(this.
H5===C)return;this.H5=C;A.tG([this,this.G7,this.Ec],0);},El:function(C){if(this.
Es===C)return;this.Es=C;A.tG([this,this.IE,this.El],0);},Em:function(C){if(this.
Et===C)return;this.Et=C;A.tG([this,this.IF,this.Em],0);},En:function(C){if(this.
Eu===C)return;this.Eu=C;A.tG([this,this.IG,this.En],0);},Eo:function(C){if(this.
Ev===C)return;this.Ev=C;A.tG([this,this.IH,this.Eo],0);},E4:function(C){if(this.
Dp===C)return;this.Dp=C;A.tG([this,this.Is,this.E4],0);},E5:function(C){if(this.
D0===C)return;this.D0=C;A.tG([this,this.It,this.E5],0);},E6:function(C){if(this.
D1===C)return;this.D1=C;A.tG([this,this.Iu,this.E6],0);},E7:function(C){if(this.
D2===C)return;this.D2=C;A.tG([this,this.Iv,this.E7],0);},E8:function(C){if(this.
D3===C)return;this.D3=C;A.tG([this,this.Iw,this.E8],0);},E9:function(C){if(this.
D4===C)return;this.D4=C;A.tG([this,this.Ix,this.E9],0);},E_:function(C){if(this.
D5===C)return;this.D5=C;A.tG([this,this.Iy,this.E_],0);},E$:function(C){if(this.
FV===C)return;this.FV=C;A.tG([this,this.G8,this.E$],0);},EW:function(C){if(this.
DS===C)return;this.DS=C;A.tG([this,this.Ik,this.EW],0);},EX:function(C){if(this.
DT===C)return;this.DT=C;A.tG([this,this.Il,this.EX],0);},EY:function(C){if(this.
DU===C)return;this.DU=C;A.tG([this,this.Im,this.EY],0);},EZ:function(C){if(this.
DV===C)return;this.DV=C;A.tG([this,this.In,this.EZ],0);},E0:function(C){if(this.
DW===C)return;this.DW=C;A.tG([this,this.Io,this.E0],0);},E1:function(C){if(this.
DX===C)return;this.DX=C;A.tG([this,this.Ip,this.E1],0);},E2:function(C){if(this.
DY===C)return;this.DY=C;A.tG([this,this.Iq,this.E2],0);},E3:function(C){if(this.
DZ===C)return;this.DZ=C;A.tG([this,this.Ir,this.E3],0);},D9:function(C){if(this.
H3===C)return;this.H3=C;A.tG([this,this.G6,this.D9],0);},Ed:function(C){if(this.
DR===C)return;this.DR=C;A.tG([this,this.Ij,this.Ed],0);},D_:function(C){if(this.
DO===C)return;this.DO=C;A.tG([this,this.If,this.D_],0);},_Init:function(aArg){var
H=this.H;H.__proto__=E.Bl;A.gv++;},_Done:function(){var H=this.H;H.__proto__=null;
A.gv--;},_ReInit:function(){},_Mark:function(D){},_variants:function(){return this;
},_className:"BrowserDevice::DeviceClass"};var eqDatas;var jsonDatas;function init_websocket(
){var wsUri="ws://"+location.hostname+":5080/";websocket=new WebSocket(wsUri);websocket.
onopen=function(evt){onOpen(evt)};websocket.onclose=function(evt){onClose(evt)};
websocket.onmessage=function(evt){onMessage(evt)};websocket.onerror=function(evt
){onError(evt)};}function onOpen(evt){console.log("onOpen");}function onClose(evt
){console.log("onClose");}function onMessage(evt){console.log(evt.data);jsonDatas=
JSON.parse(evt.data);}function onError(evt){console.log("onError");}function doSend(
message){console.log("doSend");if(websocket.readyState==1){websocket.send(message
);}console.log(websocket.readyState);}
E._Init=function(){};E.Au=function(D){};return E;})();

/* Embedded Wizard */