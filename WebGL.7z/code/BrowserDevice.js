/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.uo)throw new Error("The unit file 'BrowserDevice.js' included twice!"
);EmWiApp.uo=(function(){var B=EmWiApp;var D={};

D.A$={EP:function(){init_websocket();},DT:function(C){if(this.D4===C)return;this.
D4=C;B.tG([this,this.GV,this.DT],0);},DR:function(C){if(this.DF===C)return;this.
DF=C;B.tG([this,this.GT,this.DR],0);},DS:function(C){if(this.D1===C)return;this.
D1=C;B.tG([this,this.GU,this.DS],0);},DQ:function(C){if(this.DE===C)return;this.
DE=C;B.tG([this,this.GS,this.DQ],0);},DK:function(C){if(this.Dv===C)return;this.
Dv=C;B.tG([this,this.GM,this.DK],0);},DP:function(C){if(this.DC===C)return;this.
DC=C;B.tG([this,this.GR,this.DP],0);},DY:function(C){if(this.D9===C)return;this.
D9=C;B.tG([this,this.G0,this.DY],0);},DL:function(C){if(this.Dw===C)return;this.
Dw=C;B.tG([this,this.GN,this.DL],0);},DG:function(C){if(this.Dt===C)return;this.
Dt=C;B.tG([this,this.GI,this.DG],0);},DM:function(C){if(this.Ck===C)return;this.
Ck=C;B.tG([this,this.GO,this.DM],0);},DH:function(C){if(this.Cj===C)return;this.
Cj=C;B.tG([this,this.GJ,this.DH],0);},DN:function(C){if(this.Gy===C)return;this.
Gy=C;B.tG([this,this.GP,this.DN],0);},DU:function(C){if(this.D5===C)return;this.
D5=C;B.tG([this,this.GW,this.DU],0);},DV:function(C){if(this.D6===C)return;this.
D6=C;B.tG([this,this.GX,this.DV],0);},DW:function(C){if(this.D7===C)return;this.
D7=C;B.tG([this,this.GY,this.DW],0);},DX:function(C){if(this.D8===C)return;this.
D8=C;B.tG([this,this.GZ,this.DX],0);},DI:function(C){if(this.Gw===C)return;this.
Gw=C;B.tG([this,this.GK,this.DI],0);},DO:function(C){if(this.Dx===C)return;this.
Dx=C;B.tG([this,this.GQ,this.DO],0);},DJ:function(C){if(this.Du===C)return;this.
Du=C;B.tG([this,this.GL,this.DJ],0);},_Init:function(aArg){var J=this.J;J.__proto__=
D.A$;B.gv++;},_Done:function(){var J=this.J;J.__proto__=null;B.gv--;},_ReInit:function(
){},_Mark:function(E){},_variants:function(){return this;},_className:"BrowserDevice::DeviceClass"
};var eqDatas;var jsonDatas;function init_websocket(){var wsUri="ws://"+location.
hostname+":5080/";websocket=new WebSocket(wsUri);websocket.onopen=function(evt){
onOpen(evt)};websocket.onclose=function(evt){onClose(evt)};websocket.onmessage=function(
evt){onMessage(evt)};websocket.onerror=function(evt){onError(evt)};}function onOpen(
evt){console.log("onOpen");}function onClose(evt){console.log("onClose");}function
onMessage(evt){console.log(evt.data);jsonDatas=JSON.parse(evt.data);}function onError(
evt){console.log("onError");}function doSend(message){console.log("doSend");if(websocket.
readyState==1){websocket.send(message);}console.log(websocket.readyState);}
D._Init=function(){};D.Am=function(E){};return D;})();

/* Embedded Wizard */