/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.ui)throw new Error("The unit file 'EnStyle.js' included twice!");EmWiApp.
ui=(function(){var B=EmWiApp;var D={};

D.F$={_class:function(){return B.ul.Az;},0:{Data:function(){return B.ut;},Cache:[
],_this:null}};D.F_={_class:function(){return B.ul.Az;},0:{Data:function(){return B.
us;},Cache:[],_this:null}};D.Gj=0xFF3FE4BC;D.Gk=0xFF34FDFD;D.Gl=0xFF2BC1FE;D.Gi=
0xFF6CA567;
D._Init=function(){};D.Ao=function(E){var A;if((A=D.F$[0]._this)&&(A._cycle!=E))A.
_Done(D.F$[0]._this=null);if((A=D.F_[0]._this)&&(A._cycle!=E))A._Done(D.F_[0]._this=
null);};return D;})();

/* Embedded Wizard */