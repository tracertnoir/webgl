/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.ui)throw new Error("The unit file 'WidgetSet.js' included twice!");
EmWiApp.ui=(function(){var B=EmWiApp;var D={};
var Ac=".";var Ax="-";var BV=[0,0,200,30];
D.J1={JZ:0,Jh:1,Jg:2,Jj:3,Ji:4};D.FM={Ea:null,D_:null,GB:B.hm,GA:Ac,Hz:Ax,HA:B.hm
,H0:0,H2:0,H1:0,FN:0,FK:0xFF000000,FL:0xFF000000,FJ:0x12,HY:0,FI:0,FH:0,HZ:0,FF:
0xFF000000,FG:0xFF000000,FE:0x12,De:B.qx,ER:B.qx,AA:0,HS:function(C){if(this.FN===
C)return;this.FN=C;B.lq([this,this.Bw],this);},HP:function(C){if(this.FK===C)return;
this.FK=C;B.lq([this,this.Bw],this);},HQ:function(C){if(this.FL===C)return;this.
FL=C;B.lq([this,this.Bw],this);},HO:function(C){if(this.FJ===C)return;this.FJ=C;
B.lq([this,this.Bw],this);},HR:function(C){if(this.Ea===C)return;this.Ea=C;B.lq([
this,this.Bw],this);},HN:function(C){if(this.FI===C)return;this.FI=C;B.lq([this,
this.Bw],this);},HM:function(C){if(this.FH===C)return;this.FH=C;B.lq([this,this.
Bw],this);},HJ:function(C){if(this.FF===C)return;this.FF=C;B.lq([this,this.Bw],this
);},HK:function(C){if(this.FG===C)return;this.FG=C;B.lq([this,this.Bw],this);},HI:
function(C){if(this.FE===C)return;this.FE=C;B.lq([this,this.Bw],this);},HL:function(
C){if(this.D_===C)return;this.D_=C;B.lq([this,this.Bw],this);},EK:function(C){if(
this.AA===C)return;this.AA=C;B.lq([this,this.Bw],this);},_Init:function(aArg){D.
EQ._Init.call(this,aArg);this.__proto__=D.FM;},_Mark:function(E){var A;D.EQ._Mark.
call(this,E);if((A=this.Ea)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.D_)&&(
A._cycle!=E))A._Mark(A._cycle=E);},_className:"WidgetSet::ValueDisplayConfig"};D.
EQ={Bw:function(B9){B.qw(this,0);},_Init:function(aArg){this.__proto__=D.EQ;B.gv++;
},_Done:function(){this.__proto__=null;B.gv--;},_ReInit:function(){},_Mark:function(
E){var A;if((A=this.P)&&(A._cycle!=E))A._Mark(A._cycle=E);},P:null,_cycle:0,_observers:
null,_className:"WidgetSet::WidgetConfig"};D.T={AJ:null,AR:null,N:null,A6:null,Do:
B.hm,EN:B.hm,EM:0,HE:0,Ht:0,Hu:1.000000,Fj:0,Gj:false,S:function(C){var A;if(!!this.
N){var He=[C[2]-C[0],C[3]-C[1]];var A9=He;if(A9[0]<this.N.ER[0])A9=[this.N.ER[0]
,A9[1]];if(A9[1]<this.N.ER[1])A9=[A9[0],this.N.ER[1]];if((this.N.De[0]>0)&&(A9[0
]>this.N.De[0]))A9=[this.N.De[0],A9[1]];if((this.N.De[1]>0)&&(A9[1]>this.N.De[1]
))A9=[A9[0],this.N.De[1]];var B6=B.tw(A9,He);if(!!B6[0]){var BX=((this.AA&0x4)===
0x4);var BY=((this.AA&0x8)===0x8);if(BX&&!BY)C=B.t1(C,C[2]+B6[0]);else if(!BX&&BY
)C=[].concat(C[0]-B6[0],C.slice(1,4));else{C=[].concat(C[0]-((B6[0]/2)|0),C.slice(
1,4));C=B.t1(C,C[0]+A9[0]);}}if(!!B6[1]){var BZ=((this.AA&0x10)===0x10);var BW=((
this.AA&0x20)===0x20);if(BZ&&!BW)C=[].concat(C.slice(0,3),C[3]+B6[1]);else if(!BZ&&
BW)C=B.t3(C,C[1]-B6[1]);else{C=B.t3(C,C[1]-((B6[1]/2)|0));C=[].concat(C.slice(0,
3),C[1]+A9[1]);}}}B.Core.Ab.S.call(this,C);},D$:function(EU){var A;B.Core.Ab.D$.
call(this,EU);var Hj=!!this.N&&!!this.N.Ea;var Hi=!!this.N&&!!this.N.D_;var Q=[0
,0,(A=this.M)[2]-A[0],A[3]-A[1]];if(Hj&&!this.AR){this.AR=B._NewObject(B.um.Text
,0);this.Av(this.AR,0);}else if(!Hj&&!!this.AR){this.G4(this.AR);this.AR=null;}if(
Hi&&!this.AJ){this.AJ=B._NewObject(B.um.Text,0);this.Av(this.AJ,0);this.AJ.HG(true
);}else if(!Hi&&!!this.AJ){this.G4(this.AJ);this.AJ=null;}if(!!this.AR){var CV=0xFFFFFFFF;
var A1=Q;if(this.Gj)CV=this.N.FK;else CV=this.N.FL;if((this.N.AA===2)||(this.N.AA===
1))this.AR.EL([this,this.Hl]);else this.AR.EL(null);if((!!this.AJ&&(this.EN!==B.
hm))&&!(((A=this.AJ.CL())[0]>=A[2])||(A[1]>=A[3]))){if(this.N.AA===4)A1=B.t1(A1,
this.AJ.CL()[0]);if(this.N.AA===3)A1=[].concat(this.AJ.CL()[2],A1.slice(1,4));}this.
AR.S([A1[0]+this.N.FN,A1[1]+this.N.H2,A1[2]-this.N.H1,A1[3]-this.N.H0]);this.AR.
EJ(this.N.Ea);this.AR.EH(this.N.FJ);this.AR.Dc(this.Do);this.AR.EI(CV);}if(!!this.
AJ){var CV=0xFFFFFFFF;var A1=Q;if(this.Gj)CV=this.N.FF;else CV=this.N.FG;if((this.
N.AA===4)||(this.N.AA===3))this.AJ.EL([this,this.Hl]);else this.AJ.EL(null);if(!
!this.AR&&(this.Do!==B.hm)){if(this.N.AA===2)A1=B.t1(A1,this.AR.CL()[0]);if(this.
N.AA===1)A1=[].concat(this.AR.CL()[2],A1.slice(1,4));}this.AJ.S([A1[0]+this.N.HZ
,A1[1]+this.N.FI,A1[2]-this.N.FH,A1[3]-this.N.HY]);this.AJ.EJ(this.N.D_);this.AJ.
EH(this.N.FE);this.AJ.Dc(this.EN);this.AJ.EI(CV);}},Hl:function(B9){if(!!this.N&&
!!this.N.AA)this.Da();},Gn:function(B9){if(!!this.N){var Ey=(this.Fj*this.Hu)+this.
Ht;var Eo=this.HE;if(this.EM>0)Eo=Eo+1;if(Ey<0.000000)Eo=Eo+1;var A4=B.tC(Ey,Eo,
this.EM);var AX=A4.indexOf(String.fromCharCode(0x2E),0);if((AX>=0)&&(this.N.GA!==
Ac))A4=(B.t8(A4,AX)+this.N.GA)+B.ub(A4,0,AX+1);if(Ey<0.000000){A4=B.ub(A4,0,1);AX=
AX-1;}if(this.N.GB!==B.hm){if(AX<0)AX=A4.length;for(;AX>3;AX=AX-3)A4=(B.t8(A4,AX-
3)+this.N.GB)+B.ub(A4,0,AX-3);}if(Ey>=0.000000)A4=this.N.HA+A4;else A4=this.N.Hz+
A4;if(A4!==this.Do){this.Do=A4;this.Gj=Ey<0.000000;this.Da();}}else if(this.Do!==
B.hm){this.Do=B.hm;this.Da();}},Gm:function(B9){if(!!this.N)this.S(this.M);B.lq([
this,this.Gn],this);this.Da();},C2:function(B9){var A;if(!!this.A6)this.HF((A=this.
A6,A[1].call(A[0])));},AG:function(C){if(B.tn(this.A6,C))return;if(!!this.A6)B.sO([
this,this.C2],this.A6,0);this.A6=C;if(!!C)B.sB([this,this.C2],C,0);if(!!C)B.lq([
this,this.C2],this);},Bq:function(C){if(this.EN===C)return;this.EN=C;this.Da();}
,Bp:function(C){if(this.EM===C)return;this.EM=C;B.lq([this,this.Gn],this);},HF:function(
C){if(this.Fj===C)return;this.Fj=C;B.lq([this,this.Gn],this);},Bo:function(C){if(
this.N===C)return;if(!!this.N)B.sM([this,this.Gm],this.N,0);this.N=C;if(!!C)B.sz([
this,this.Gm],C,0);B.lq([this,this.Gm],this);},_Init:function(aArg){B.Core.Ab._Init.
call(this,aArg);this.__proto__=D.T;this.F=0x1B;this.S(BV);},_Mark:function(E){var
A;B.Core.Ab._Mark.call(this,E);if((A=this.AJ)&&(A._cycle!=E))A._Mark(A._cycle=E);
if((A=this.AR)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.N)&&(A._cycle!=E))A.
_Mark(A._cycle=E);if((A=this.A6)&&((A=A[0])._cycle!=E))A._Mark(A._cycle=E);},_className:
"WidgetSet::ValueDisplay"};
D._Init=function(){D.FM.__proto__=D.EQ;D.T.__proto__=B.Core.Ab;};D.Am=function(E){
};return D;})();

/* Embedded Wizard */