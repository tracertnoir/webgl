/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.uj)throw new Error("The unit file 'WidgetSet.js' included twice!");
EmWiApp.uj=(function(){var A=EmWiApp;var E={};
var Ac=".";var At="-";var Cr=[0,0,200,30];
E.MI={MG:0,LW:1,LV:2,LY:3,LX:4};E.Gg={Fm:null,Fk:null,H8:A.hm,H7:Ac,Jy:At,Jz:A.hm
,JX:0,JZ:0,JY:0,Hk:0,Hi:0xFF000000,Hj:0xFF000000,Hh:0x12,JU:0,Hg:0,Hf:0,JV:0,Hd:
0xFF000000,He:0xFF000000,Hc:0x12,Ew:A.qx,Gk:A.qx,AJ:0,JL:function(C){if(this.Hk===
C)return;this.Hk=C;A.lq([this,this.BP],this);},IT:function(C){if(this.Hi===C)return;
this.Hi=C;A.lq([this,this.BP],this);},IU:function(C){if(this.Hj===C)return;this.
Hj=C;A.lq([this,this.BP],this);},IS:function(C){if(this.Hh===C)return;this.Hh=C;
A.lq([this,this.BP],this);},IV:function(C){if(this.Fm===C)return;this.Fm=C;A.lq([
this,this.BP],this);},JK:function(C){if(this.Hg===C)return;this.Hg=C;A.lq([this,
this.BP],this);},JJ:function(C){if(this.Hf===C)return;this.Hf=C;A.lq([this,this.
BP],this);},IP:function(C){if(this.Hd===C)return;this.Hd=C;A.lq([this,this.BP],this
);},IQ:function(C){if(this.He===C)return;this.He=C;A.lq([this,this.BP],this);},IO:
function(C){if(this.Hc===C)return;this.Hc=C;A.lq([this,this.BP],this);},IR:function(
C){if(this.Fk===C)return;this.Fk=C;A.lq([this,this.BP],this);},Fa:function(C){if(
this.AJ===C)return;this.AJ=C;A.lq([this,this.BP],this);},_Init:function(aArg){E.
Gj._Init.call(this,aArg);this.__proto__=E.Gg;},_Mark:function(D){var B;E.Gj._Mark.
call(this,D);if((B=this.Fm)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.Fk)&&(
B._cycle!=D))B._Mark(B._cycle=D);},_className:"WidgetSet::ValueDisplayConfig"};E.
Gj={BP:function(B_){A.qw(this,0);},_Init:function(aArg){this.__proto__=E.Gj;A.gv++;
},_Done:function(){this.__proto__=null;A.gv--;},_ReInit:function(){},_Mark:function(
D){var B;if((B=this.M)&&(B._cycle!=D))B._Mark(B._cycle=D);},M:null,_cycle:0,_observers:
null,_className:"WidgetSet::WidgetConfig"};E.Q={AS:null,A1:null,R:null,Bf:null,EH:
A.hm,Ge:A.hm,Gd:0,JE:0,GR:0,GS:1.000000,GT:0,HL:false,O:function(C){var B;if(!!this.
R){var Jc=[C[2]-C[0],C[3]-C[1]];var Bi=Jc;if(Bi[0]<this.R.Gk[0])Bi=[this.R.Gk[0]
,Bi[1]];if(Bi[1]<this.R.Gk[1])Bi=[Bi[0],this.R.Gk[1]];if((this.R.Ew[0]>0)&&(Bi[0
]>this.R.Ew[0]))Bi=[this.R.Ew[0],Bi[1]];if((this.R.Ew[1]>0)&&(Bi[1]>this.R.Ew[1]
))Bi=[Bi[0],this.R.Ew[1]];var A4=A.tw(Bi,Jc);if(!!A4[0]){var Ct=((this.AJ&0x4)===
0x4);var Cu=((this.AJ&0x8)===0x8);if(Ct&&!Cu)C=A.t1(C,C[2]+A4[0]);else if(!Ct&&Cu
)C=[].concat(C[0]-A4[0],C.slice(1,4));else{C=[].concat(C[0]-((A4[0]/2)|0),C.slice(
1,4));C=A.t1(C,C[0]+Bi[0]);}}if(!!A4[1]){var Cv=((this.AJ&0x10)===0x10);var Cs=((
this.AJ&0x20)===0x20);if(Cv&&!Cs)C=[].concat(C.slice(0,3),C[3]+A4[1]);else if(!Cv&&
Cs)C=A.t3(C,C[1]-A4[1]);else{C=A.t3(C,C[1]-((A4[1]/2)|0));C=[].concat(C.slice(0,
3),C[1]+Bi[1]);}}}A.Core.Z.O.call(this,C);},Fl:function(Gn){var B;A.Core.Z.Fl.call(
this,Gn);var Jh=!!this.R&&!!this.R.Fm;var Jg=!!this.R&&!!this.R.Fk;var T=[0,0,(B=
this.N)[2]-B[0],B[3]-B[1]];if(Jh&&!this.A1){this.A1=A._NewObject(A.un.Text,0);this.
V(this.A1,0);}else if(!Jh&&!!this.A1){this.IW(this.A1);this.A1=null;}if(Jg&&!this.
AS){this.AS=A._NewObject(A.un.Text,0);this.V(this.AS,0);this.AS.JG(true);}else if(
!Jg&&!!this.AS){this.IW(this.AS);this.AS=null;}if(!!this.A1){var DA=0xFFFFFFFF;var
A9=T;if(this.HL)DA=this.R.Hi;else DA=this.R.Hj;if((this.R.AJ===2)||(this.R.AJ===
1))this.A1.Ga([this,this.Jj]);else this.A1.Ga(null);if((!!this.AS&&(this.Ge!==A.
hm))&&!(((B=this.AS.Dq())[0]>=B[2])||(B[1]>=B[3]))){if(this.R.AJ===4)A9=A.t1(A9,
this.AS.Dq()[0]);if(this.R.AJ===3)A9=[].concat(this.AS.Dq()[2],A9.slice(1,4));}this.
A1.O([A9[0]+this.R.Hk,A9[1]+this.R.JZ,A9[2]-this.R.JY,A9[3]-this.R.JX]);this.A1.
F$(this.R.Fm);this.A1.FZ(this.R.Hh);this.A1.Ek(this.EH);this.A1.D6(DA);}if(!!this.
AS){var DA=0xFFFFFFFF;var A9=T;if(this.HL)DA=this.R.Hd;else DA=this.R.He;if((this.
R.AJ===4)||(this.R.AJ===3))this.AS.Ga([this,this.Jj]);else this.AS.Ga(null);if(!
!this.A1&&(this.EH!==A.hm)){if(this.R.AJ===2)A9=A.t1(A9,this.A1.Dq()[0]);if(this.
R.AJ===1)A9=[].concat(this.A1.Dq()[2],A9.slice(1,4));}this.AS.O([A9[0]+this.R.JV
,A9[1]+this.R.Hg,A9[2]-this.R.Hf,A9[3]-this.R.JU]);this.AS.F$(this.R.Fk);this.AS.
FZ(this.R.Hc);this.AS.Ek(this.Ge);this.AS.D6(DA);}},Jj:function(B_){if(!!this.R&&
!!this.R.AJ)this.Dr();},FF:function(B_){if(!!this.R){var FM=(this.GT*this.GS)+this.
GR;var FC=this.JE;if(this.Gd>0)FC=FC+1;if(FM<0.000000)FC=FC+1;var Bc=A.tC(FM,FC,
this.Gd);var A6=Bc.indexOf(String.fromCharCode(0x2E),0);if((A6>=0)&&(this.R.H7!==
Ac))Bc=(A.t8(Bc,A6)+this.R.H7)+A.ub(Bc,0,A6+1);if(FM<0.000000){Bc=A.ub(Bc,0,1);A6=
A6-1;}if(this.R.H8!==A.hm){if(A6<0)A6=Bc.length;for(;A6>3;A6=A6-3)Bc=(A.t8(Bc,A6-
3)+this.R.H8)+A.ub(Bc,0,A6-3);}if(FM>=0.000000)Bc=this.R.Jz+Bc;else Bc=this.R.Jy+
Bc;if(Bc!==this.EH){this.EH=Bc;this.HL=FM<0.000000;this.Dr();}}else if(this.EH!==
A.hm){this.EH=A.hm;this.Dr();}},HO:function(B_){if(!!this.R)this.O(this.N);A.lq([
this,this.FF],this);this.Dr();},DH:function(B_){var B;if(!!this.Bf)this.F0((B=this.
Bf,B[1].call(B[0])));},Aa:function(C){if(A.tn(this.Bf,C))return;if(!!this.Bf)A.sO([
this,this.DH],this.Bf,0);this.Bf=C;if(!!C)A.sB([this,this.DH],C,0);if(!!C)A.lq([
this,this.DH],this);},Ao:function(C){if(this.Ge===C)return;this.Ge=C;this.Dr();}
,An:function(C){if(this.Gd===C)return;this.Gd=C;A.lq([this,this.FF],this);},JF:function(
C){if(this.GR===C)return;this.GR=C;A.lq([this,this.FF],this);},BE:function(C){if(
this.GS===C)return;this.GS=C;A.lq([this,this.FF],this);},F0:function(C){if(this.
GT===C)return;this.GT=C;A.lq([this,this.FF],this);},Am:function(C){if(this.R===C
)return;if(!!this.R)A.sM([this,this.HO],this.R,0);this.R=C;if(!!C)A.sz([this,this.
HO],C,0);A.lq([this,this.HO],this);},_Init:function(aArg){A.Core.Z._Init.call(this
,aArg);this.__proto__=E.Q;this.F=0x1B;this.O(Cr);},_Mark:function(D){var B;A.Core.
Z._Mark.call(this,D);if((B=this.AS)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.
A1)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.R)&&(B._cycle!=D))B._Mark(B._cycle=
D);if((B=this.Bf)&&((B=B[0])._cycle!=D))B._Mark(B._cycle=D);},_className:"WidgetSet::ValueDisplay"
};
E._Init=function(){E.Gg.__proto__=E.Gj;E.Q.__proto__=A.Core.Z;};E.Au=function(D){
};return E;})();

/* Embedded Wizard */