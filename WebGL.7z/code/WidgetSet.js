/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.uj)throw new Error("The unit file 'WidgetSet.js' included twice!");
EmWiApp.uj=(function(){var A=EmWiApp;var E={};
var Ac=".";var Au="-";var Cr=[0,0,200,30];
E.MI={MG:0,LW:1,LV:2,LY:3,LX:4};E.Gg={Fo:null,Fm:null,H8:A.hm,H7:Ac,Jz:Au,JA:A.hm
,JY:0,J0:0,JZ:0,Hk:0,Hi:0xFF000000,Hj:0xFF000000,Hh:0x12,JV:0,Hg:0,Hf:0,JW:0,Hd:
0xFF000000,He:0xFF000000,Hc:0x12,EN:A.qx,Gk:A.qx,AK:0,JM:function(C){if(this.Hk===
C)return;this.Hk=C;A.lq([this,this.BP],this);},IU:function(C){if(this.Hi===C)return;
this.Hi=C;A.lq([this,this.BP],this);},IV:function(C){if(this.Hj===C)return;this.
Hj=C;A.lq([this,this.BP],this);},IT:function(C){if(this.Hh===C)return;this.Hh=C;
A.lq([this,this.BP],this);},IW:function(C){if(this.Fo===C)return;this.Fo=C;A.lq([
this,this.BP],this);},JL:function(C){if(this.Hg===C)return;this.Hg=C;A.lq([this,
this.BP],this);},JK:function(C){if(this.Hf===C)return;this.Hf=C;A.lq([this,this.
BP],this);},IQ:function(C){if(this.Hd===C)return;this.Hd=C;A.lq([this,this.BP],this
);},IR:function(C){if(this.He===C)return;this.He=C;A.lq([this,this.BP],this);},IP:
function(C){if(this.Hc===C)return;this.Hc=C;A.lq([this,this.BP],this);},IS:function(
C){if(this.Fm===C)return;this.Fm=C;A.lq([this,this.BP],this);},Fc:function(C){if(
this.AK===C)return;this.AK=C;A.lq([this,this.BP],this);},_Init:function(aArg){E.
Gj._Init.call(this,aArg);this.__proto__=E.Gg;},_Mark:function(D){var B;E.Gj._Mark.
call(this,D);if((B=this.Fo)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.Fm)&&(
B._cycle!=D))B._Mark(B._cycle=D);},_className:"WidgetSet::ValueDisplayConfig"};E.
Gj={BP:function(Cn){A.qw(this,0);},_Init:function(aArg){this.__proto__=E.Gj;A.gv++;
},_Done:function(){this.__proto__=null;A.gv--;},_ReInit:function(){},_Mark:function(
D){var B;if((B=this.M)&&(B._cycle!=D))B._Mark(B._cycle=D);},M:null,_cycle:0,_observers:
null,_className:"WidgetSet::WidgetConfig"};E.Q={AT:null,A2:null,R:null,Bg:null,EZ:
A.hm,Ge:A.hm,Gd:0,JF:0,GR:0,GS:1.000000,GT:0,HL:false,O:function(C){var B;if(!!this.
R){var Jd=[C[2]-C[0],C[3]-C[1]];var Bj=Jd;if(Bj[0]<this.R.Gk[0])Bj=[this.R.Gk[0]
,Bj[1]];if(Bj[1]<this.R.Gk[1])Bj=[Bj[0],this.R.Gk[1]];if((this.R.EN[0]>0)&&(Bj[0
]>this.R.EN[0]))Bj=[this.R.EN[0],Bj[1]];if((this.R.EN[1]>0)&&(Bj[1]>this.R.EN[1]
))Bj=[Bj[0],this.R.EN[1]];var A5=A.tw(Bj,Jd);if(!!A5[0]){var Ct=((this.AK&0x4)===
0x4);var Cu=((this.AK&0x8)===0x8);if(Ct&&!Cu)C=A.t1(C,C[2]+A5[0]);else if(!Ct&&Cu
)C=[].concat(C[0]-A5[0],C.slice(1,4));else{C=[].concat(C[0]-((A5[0]/2)|0),C.slice(
1,4));C=A.t1(C,C[0]+Bj[0]);}}if(!!A5[1]){var Cv=((this.AK&0x10)===0x10);var Cs=((
this.AK&0x20)===0x20);if(Cv&&!Cs)C=[].concat(C.slice(0,3),C[3]+A5[1]);else if(!Cv&&
Cs)C=A.t3(C,C[1]-A5[1]);else{C=A.t3(C,C[1]-((A5[1]/2)|0));C=[].concat(C.slice(0,
3),C[1]+Bj[1]);}}}A.Core.Z.O.call(this,C);},Fn:function(Gn){var B;A.Core.Z.Fn.call(
this,Gn);var Ji=!!this.R&&!!this.R.Fo;var Jh=!!this.R&&!!this.R.Fm;var T=[0,0,(B=
this.N)[2]-B[0],B[3]-B[1]];if(Ji&&!this.A2){this.A2=A._NewObject(A.un.Text,0);this.
V(this.A2,0);}else if(!Ji&&!!this.A2){this.IX(this.A2);this.A2=null;}if(Jh&&!this.
AT){this.AT=A._NewObject(A.un.Text,0);this.V(this.AT,0);this.AT.JH(true);}else if(
!Jh&&!!this.AT){this.IX(this.AT);this.AT=null;}if(!!this.A2){var DA=0xFFFFFFFF;var
A_=T;if(this.HL)DA=this.R.Hi;else DA=this.R.Hj;if((this.R.AK===2)||(this.R.AK===
1))this.A2.Ga([this,this.Jk]);else this.A2.Ga(null);if((!!this.AT&&(this.Ge!==A.
hm))&&!(((B=this.AT.Dp())[0]>=B[2])||(B[1]>=B[3]))){if(this.R.AK===4)A_=A.t1(A_,
this.AT.Dp()[0]);if(this.R.AK===3)A_=[].concat(this.AT.Dp()[2],A_.slice(1,4));}this.
A2.O([A_[0]+this.R.Hk,A_[1]+this.R.J0,A_[2]-this.R.JZ,A_[3]-this.R.JY]);this.A2.
F$(this.R.Fo);this.A2.FZ(this.R.Hh);this.A2.EB(this.EZ);this.A2.D7(DA);}if(!!this.
AT){var DA=0xFFFFFFFF;var A_=T;if(this.HL)DA=this.R.Hd;else DA=this.R.He;if((this.
R.AK===4)||(this.R.AK===3))this.AT.Ga([this,this.Jk]);else this.AT.Ga(null);if(!
!this.A2&&(this.EZ!==A.hm)){if(this.R.AK===2)A_=A.t1(A_,this.A2.Dp()[0]);if(this.
R.AK===1)A_=[].concat(this.A2.Dp()[2],A_.slice(1,4));}this.AT.O([A_[0]+this.R.JW
,A_[1]+this.R.Hg,A_[2]-this.R.Hf,A_[3]-this.R.JV]);this.AT.F$(this.R.Fm);this.AT.
FZ(this.R.Hc);this.AT.EB(this.Ge);this.AT.D7(DA);}},Jk:function(Cn){if(!!this.R&&
!!this.R.AK)this.Dq();},FG:function(Cn){if(!!this.R){var FN=(this.GT*this.GS)+this.
GR;var FD=this.JF;if(this.Gd>0)FD=FD+1;if(FN<0.000000)FD=FD+1;var Bd=A.tC(FN,FD,
this.Gd);var A7=Bd.indexOf(String.fromCharCode(0x2E),0);if((A7>=0)&&(this.R.H7!==
Ac))Bd=(A.t8(Bd,A7)+this.R.H7)+A.ub(Bd,0,A7+1);if(FN<0.000000){Bd=A.ub(Bd,0,1);A7=
A7-1;}if(this.R.H8!==A.hm){if(A7<0)A7=Bd.length;for(;A7>3;A7=A7-3)Bd=(A.t8(Bd,A7-
3)+this.R.H8)+A.ub(Bd,0,A7-3);}if(FN>=0.000000)Bd=this.R.JA+Bd;else Bd=this.R.Jz+
Bd;if(Bd!==this.EZ){this.EZ=Bd;this.HL=FN<0.000000;this.Dq();}}else if(this.EZ!==
A.hm){this.EZ=A.hm;this.Dq();}},HO:function(Cn){if(!!this.R)this.O(this.N);A.lq([
this,this.FG],this);this.Dq();},DH:function(Cn){var B;if(!!this.Bg)this.F0((B=this.
Bg,B[1].call(B[0])));},Aa:function(C){if(A.tn(this.Bg,C))return;if(!!this.Bg)A.sO([
this,this.DH],this.Bg,0);this.Bg=C;if(!!C)A.sB([this,this.DH],C,0);if(!!C)A.lq([
this,this.DH],this);},Ap:function(C){if(this.Ge===C)return;this.Ge=C;this.Dq();}
,Ao:function(C){if(this.Gd===C)return;this.Gd=C;A.lq([this,this.FG],this);},JG:function(
C){if(this.GR===C)return;this.GR=C;A.lq([this,this.FG],this);},An:function(C){if(
this.GS===C)return;this.GS=C;A.lq([this,this.FG],this);},F0:function(C){if(this.
GT===C)return;this.GT=C;A.lq([this,this.FG],this);},Am:function(C){if(this.R===C
)return;if(!!this.R)A.sM([this,this.HO],this.R,0);this.R=C;if(!!C)A.sz([this,this.
HO],C,0);A.lq([this,this.HO],this);},_Init:function(aArg){A.Core.Z._Init.call(this
,aArg);this.__proto__=E.Q;this.F=0x1B;this.O(Cr);},_Mark:function(D){var B;A.Core.
Z._Mark.call(this,D);if((B=this.AT)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.
A2)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.R)&&(B._cycle!=D))B._Mark(B._cycle=
D);if((B=this.Bg)&&((B=B[0])._cycle!=D))B._Mark(B._cycle=D);},_className:"WidgetSet::ValueDisplay"
};
E._Init=function(){E.Gg.__proto__=E.Gj;E.Q.__proto__=A.Core.Z;};E.Av=function(D){
};return E;})();

/* Embedded Wizard */