/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.uj)throw new Error("The unit file 'WidgetSet.js' included twice!");
EmWiApp.uj=(function(){var A=EmWiApp;var E={};
var Ab=".";var At="-";var Cr=[0,0,200,30];
E.L$={L9:0,Ln:1,Lm:2,Lp:3,Lo:4};E.Fv={El:null,Ej:null,H5:A.hm,H4:Ab,Jz:At,JA:A.hm
,JY:0,J0:0,JZ:0,Hj:0,Hh:0xFF000000,Hi:0xFF000000,Hg:0x12,JV:0,Hf:0,He:0,JW:0,Hc:
0xFF000000,Hd:0xFF000000,Hb:0x12,DQ:A.qx,Fz:A.qx,AJ:0,JM:function(C){if(this.Hj===
C)return;this.Hj=C;A.lq([this,this.BP],this);},IU:function(C){if(this.Hh===C)return;
this.Hh=C;A.lq([this,this.BP],this);},IV:function(C){if(this.Hi===C)return;this.
Hi=C;A.lq([this,this.BP],this);},IT:function(C){if(this.Hg===C)return;this.Hg=C;
A.lq([this,this.BP],this);},IW:function(C){if(this.El===C)return;this.El=C;A.lq([
this,this.BP],this);},JL:function(C){if(this.Hf===C)return;this.Hf=C;A.lq([this,
this.BP],this);},JK:function(C){if(this.He===C)return;this.He=C;A.lq([this,this.
BP],this);},IQ:function(C){if(this.Hc===C)return;this.Hc=C;A.lq([this,this.BP],this
);},IR:function(C){if(this.Hd===C)return;this.Hd=C;A.lq([this,this.BP],this);},IP:
function(C){if(this.Hb===C)return;this.Hb=C;A.lq([this,this.BP],this);},IS:function(
C){if(this.Ej===C)return;this.Ej=C;A.lq([this,this.BP],this);},Eb:function(C){if(
this.AJ===C)return;this.AJ=C;A.lq([this,this.BP],this);},_Init:function(aArg){E.
Fy._Init.call(this,aArg);this.__proto__=E.Fv;},_Mark:function(D){var B;E.Fy._Mark.
call(this,D);if((B=this.El)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.Ej)&&(
B._cycle!=D))B._Mark(B._cycle=D);},_className:"WidgetSet::ValueDisplayConfig"};E.
Fy={BP:function(Cn){A.qw(this,0);},_Init:function(aArg){this.__proto__=E.Fy;A.gv++;
},_Done:function(){this.__proto__=null;A.gv--;},_ReInit:function(){},_Mark:function(
D){var B;if((B=this.L)&&(B._cycle!=D))B._Mark(B._cycle=D);},L:null,_cycle:0,_observers:
null,_className:"WidgetSet::WidgetConfig"};E.P={AS:null,A2:null,Q:null,Bg:null,D2:
A.hm,Ft:A.hm,Fo:0,JF:0,Gd:0,Ge:1.000000,Gf:0,HK:false,N:function(C){var B;if(!!this.
Q){var Jd=[C[2]-C[0],C[3]-C[1]];var Bj=Jd;if(Bj[0]<this.Q.Fz[0])Bj=[this.Q.Fz[0]
,Bj[1]];if(Bj[1]<this.Q.Fz[1])Bj=[Bj[0],this.Q.Fz[1]];if((this.Q.DQ[0]>0)&&(Bj[0
]>this.Q.DQ[0]))Bj=[this.Q.DQ[0],Bj[1]];if((this.Q.DQ[1]>0)&&(Bj[1]>this.Q.DQ[1]
))Bj=[Bj[0],this.Q.DQ[1]];var A5=A.tw(Bj,Jd);if(!!A5[0]){var Ct=((this.AJ&0x4)===
0x4);var Cu=((this.AJ&0x8)===0x8);if(Ct&&!Cu)C=A.t1(C,C[2]+A5[0]);else if(!Ct&&Cu
)C=[].concat(C[0]-A5[0],C.slice(1,4));else{C=[].concat(C[0]-((A5[0]/2)|0),C.slice(
1,4));C=A.t1(C,C[0]+Bj[0]);}}if(!!A5[1]){var Cv=((this.AJ&0x10)===0x10);var Cs=((
this.AJ&0x20)===0x20);if(Cv&&!Cs)C=[].concat(C.slice(0,3),C[3]+A5[1]);else if(!Cv&&
Cs)C=A.t3(C,C[1]-A5[1]);else{C=A.t3(C,C[1]-((A5[1]/2)|0));C=[].concat(C.slice(0,
3),C[1]+Bj[1]);}}}A.Core.Y.N.call(this,C);},Ek:function(FC){var B;A.Core.Y.Ek.call(
this,FC);var Ji=!!this.Q&&!!this.Q.El;var Jh=!!this.Q&&!!this.Q.Ej;var S=[0,0,(B=
this.M)[2]-B[0],B[3]-B[1]];if(Ji&&!this.A2){this.A2=A._NewObject(A.un.Text,0);this.
U(this.A2,0);}else if(!Ji&&!!this.A2){this.IX(this.A2);this.A2=null;}if(Jh&&!this.
AS){this.AS=A._NewObject(A.un.Text,0);this.U(this.AS,0);this.AS.JH(true);}else if(
!Jh&&!!this.AS){this.IX(this.AS);this.AS=null;}if(!!this.A2){var Dx=0xFFFFFFFF;var
A_=S;if(this.HK)Dx=this.Q.Hh;else Dx=this.Q.Hi;if((this.Q.AJ===2)||(this.Q.AJ===
1))this.A2.Fl([this,this.Jk]);else this.A2.Fl(null);if((!!this.AS&&(this.Ft!==A.
hm))&&!(((B=this.AS.Dm())[0]>=B[2])||(B[1]>=B[3]))){if(this.Q.AJ===4)A_=A.t1(A_,
this.AS.Dm()[0]);if(this.Q.AJ===3)A_=[].concat(this.AS.Dm()[2],A_.slice(1,4));}this.
A2.N([A_[0]+this.Q.Hj,A_[1]+this.Q.J0,A_[2]-this.Q.JZ,A_[3]-this.Q.JY]);this.A2.
Fk(this.Q.El);this.A2.Fh(this.Q.Hg);this.A2.DO(this.D2);this.A2.DM(Dx);}if(!!this.
AS){var Dx=0xFFFFFFFF;var A_=S;if(this.HK)Dx=this.Q.Hc;else Dx=this.Q.Hd;if((this.
Q.AJ===4)||(this.Q.AJ===3))this.AS.Fl([this,this.Jk]);else this.AS.Fl(null);if(!
!this.A2&&(this.D2!==A.hm)){if(this.Q.AJ===2)A_=A.t1(A_,this.A2.Dm()[0]);if(this.
Q.AJ===1)A_=[].concat(this.A2.Dm()[2],A_.slice(1,4));}this.AS.N([A_[0]+this.Q.JW
,A_[1]+this.Q.Hf,A_[2]-this.Q.He,A_[3]-this.Q.JV]);this.AS.Fk(this.Q.Ej);this.AS.
Fh(this.Q.Hb);this.AS.DO(this.Ft);this.AS.DM(Dx);}},Jk:function(Cn){if(!!this.Q&&
!!this.Q.AJ)this.Dn();},ED:function(Cn){if(!!this.Q){var EK=(this.Gf*this.Ge)+this.
Gd;var EA=this.JF;if(this.Fo>0)EA=EA+1;if(EK<0.000000)EA=EA+1;var Bd=A.tC(EK,EA,
this.Fo);var A7=Bd.indexOf(String.fromCharCode(0x2E),0);if((A7>=0)&&(this.Q.H4!==
Ab))Bd=(A.t8(Bd,A7)+this.Q.H4)+A.ub(Bd,0,A7+1);if(EK<0.000000){Bd=A.ub(Bd,0,1);A7=
A7-1;}if(this.Q.H5!==A.hm){if(A7<0)A7=Bd.length;for(;A7>3;A7=A7-3)Bd=(A.t8(Bd,A7-
3)+this.Q.H5)+A.ub(Bd,0,A7-3);}if(EK>=0.000000)Bd=this.Q.JA+Bd;else Bd=this.Q.Jz+
Bd;if(Bd!==this.D2){this.D2=Bd;this.HK=EK<0.000000;this.Dn();}}else if(this.D2!==
A.hm){this.D2=A.hm;this.Dn();}},HN:function(Cn){if(!!this.Q)this.N(this.M);A.lq([
this,this.ED],this);this.Dn();},DE:function(Cn){var B;if(!!this.Bg)this.Fi((B=this.
Bg,B[1].call(B[0])));},Z:function(C){if(A.tn(this.Bg,C))return;if(!!this.Bg)A.sO([
this,this.DE],this.Bg,0);this.Bg=C;if(!!C)A.sB([this,this.DE],C,0);if(!!C)A.lq([
this,this.DE],this);},Ao:function(C){if(this.Ft===C)return;this.Ft=C;this.Dn();}
,An:function(C){if(this.Fo===C)return;this.Fo=C;A.lq([this,this.ED],this);},JG:function(
C){if(this.Gd===C)return;this.Gd=C;A.lq([this,this.ED],this);},Am:function(C){if(
this.Ge===C)return;this.Ge=C;A.lq([this,this.ED],this);},Fi:function(C){if(this.
Gf===C)return;this.Gf=C;A.lq([this,this.ED],this);},Al:function(C){if(this.Q===C
)return;if(!!this.Q)A.sM([this,this.HN],this.Q,0);this.Q=C;if(!!C)A.sz([this,this.
HN],C,0);A.lq([this,this.HN],this);},_Init:function(aArg){A.Core.Y._Init.call(this
,aArg);this.__proto__=E.P;this.F=0x1B;this.N(Cr);},_Mark:function(D){var B;A.Core.
Y._Mark.call(this,D);if((B=this.AS)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.
A2)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.Q)&&(B._cycle!=D))B._Mark(B._cycle=
D);if((B=this.Bg)&&((B=B[0])._cycle!=D))B._Mark(B._cycle=D);},_className:"WidgetSet::ValueDisplay"
};
E._Init=function(){E.Fv.__proto__=E.Fy;E.P.__proto__=A.Core.Y;};E.Au=function(D){
};return E;})();

/* Embedded Wizard */