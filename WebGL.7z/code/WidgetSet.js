/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.uj)throw new Error("The unit file 'WidgetSet.js' included twice!");
EmWiApp.uj=(function(){var A=EmWiApp;var E={};
var Ab=".";var At="-";var Cr=[0,0,200,30];
E.Mf={Md:0,Lt:1,Ls:2,Lv:3,Lu:4};E.Fx={Em:null,Ek:null,H8:A.hm,H7:Ab,JD:At,JE:A.hm
,J2:0,J4:0,J3:0,Hm:0,Hk:0xFF000000,Hl:0xFF000000,Hj:0x12,JZ:0,Hi:0,Hh:0,J0:0,Hf:
0xFF000000,Hg:0xFF000000,He:0x12,DS:A.qx,FB:A.qx,AJ:0,JQ:function(C){if(this.Hm===
C)return;this.Hm=C;A.lq([this,this.BP],this);},IY:function(C){if(this.Hk===C)return;
this.Hk=C;A.lq([this,this.BP],this);},IZ:function(C){if(this.Hl===C)return;this.
Hl=C;A.lq([this,this.BP],this);},IX:function(C){if(this.Hj===C)return;this.Hj=C;
A.lq([this,this.BP],this);},I0:function(C){if(this.Em===C)return;this.Em=C;A.lq([
this,this.BP],this);},JP:function(C){if(this.Hi===C)return;this.Hi=C;A.lq([this,
this.BP],this);},JO:function(C){if(this.Hh===C)return;this.Hh=C;A.lq([this,this.
BP],this);},IU:function(C){if(this.Hf===C)return;this.Hf=C;A.lq([this,this.BP],this
);},IV:function(C){if(this.Hg===C)return;this.Hg=C;A.lq([this,this.BP],this);},IT:
function(C){if(this.He===C)return;this.He=C;A.lq([this,this.BP],this);},IW:function(
C){if(this.Ek===C)return;this.Ek=C;A.lq([this,this.BP],this);},Ec:function(C){if(
this.AJ===C)return;this.AJ=C;A.lq([this,this.BP],this);},_Init:function(aArg){E.
FA._Init.call(this,aArg);this.__proto__=E.Fx;},_Mark:function(D){var B;E.FA._Mark.
call(this,D);if((B=this.Em)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.Ek)&&(
B._cycle!=D))B._Mark(B._cycle=D);},_className:"WidgetSet::ValueDisplayConfig"};E.
FA={BP:function(Cn){A.qw(this,0);},_Init:function(aArg){this.__proto__=E.FA;A.gv++;
},_Done:function(){this.__proto__=null;A.gv--;},_ReInit:function(){},_Mark:function(
D){var B;if((B=this.L)&&(B._cycle!=D))B._Mark(B._cycle=D);},L:null,_cycle:0,_observers:
null,_className:"WidgetSet::WidgetConfig"};E.P={AT:null,A2:null,Q:null,Bg:null,D3:
A.hm,Fv:A.hm,Fq:0,JJ:0,Gf:0,Gg:1.000000,Gh:0,HN:false,N:function(C){var B;if(!!this.
Q){var Jh=[C[2]-C[0],C[3]-C[1]];var Bj=Jh;if(Bj[0]<this.Q.FB[0])Bj=[this.Q.FB[0]
,Bj[1]];if(Bj[1]<this.Q.FB[1])Bj=[Bj[0],this.Q.FB[1]];if((this.Q.DS[0]>0)&&(Bj[0
]>this.Q.DS[0]))Bj=[this.Q.DS[0],Bj[1]];if((this.Q.DS[1]>0)&&(Bj[1]>this.Q.DS[1]
))Bj=[Bj[0],this.Q.DS[1]];var A5=A.tw(Bj,Jh);if(!!A5[0]){var Ct=((this.AJ&0x4)===
0x4);var Cu=((this.AJ&0x8)===0x8);if(Ct&&!Cu)C=A.t1(C,C[2]+A5[0]);else if(!Ct&&Cu
)C=[].concat(C[0]-A5[0],C.slice(1,4));else{C=[].concat(C[0]-((A5[0]/2)|0),C.slice(
1,4));C=A.t1(C,C[0]+Bj[0]);}}if(!!A5[1]){var Cv=((this.AJ&0x10)===0x10);var Cs=((
this.AJ&0x20)===0x20);if(Cv&&!Cs)C=[].concat(C.slice(0,3),C[3]+A5[1]);else if(!Cv&&
Cs)C=A.t3(C,C[1]-A5[1]);else{C=A.t3(C,C[1]-((A5[1]/2)|0));C=[].concat(C.slice(0,
3),C[1]+Bj[1]);}}}A.Core.Y.N.call(this,C);},El:function(FE){var B;A.Core.Y.El.call(
this,FE);var Jm=!!this.Q&&!!this.Q.Em;var Jl=!!this.Q&&!!this.Q.Ek;var S=[0,0,(B=
this.M)[2]-B[0],B[3]-B[1]];if(Jm&&!this.A2){this.A2=A._NewObject(A.un.Text,0);this.
U(this.A2,0);}else if(!Jm&&!!this.A2){this.I1(this.A2);this.A2=null;}if(Jl&&!this.
AT){this.AT=A._NewObject(A.un.Text,0);this.U(this.AT,0);this.AT.JL(true);}else if(
!Jl&&!!this.AT){this.I1(this.AT);this.AT=null;}if(!!this.A2){var Dz=0xFFFFFFFF;var
A_=S;if(this.HN)Dz=this.Q.Hk;else Dz=this.Q.Hl;if((this.Q.AJ===2)||(this.Q.AJ===
1))this.A2.Fm([this,this.Jo]);else this.A2.Fm(null);if((!!this.AT&&(this.Fv!==A.
hm))&&!(((B=this.AT.Do())[0]>=B[2])||(B[1]>=B[3]))){if(this.Q.AJ===4)A_=A.t1(A_,
this.AT.Do()[0]);if(this.Q.AJ===3)A_=[].concat(this.AT.Do()[2],A_.slice(1,4));}this.
A2.N([A_[0]+this.Q.Hm,A_[1]+this.Q.J4,A_[2]-this.Q.J3,A_[3]-this.Q.J2]);this.A2.
Fl(this.Q.Em);this.A2.Fi(this.Q.Hj);this.A2.DQ(this.D3);this.A2.DO(Dz);}if(!!this.
AT){var Dz=0xFFFFFFFF;var A_=S;if(this.HN)Dz=this.Q.Hf;else Dz=this.Q.Hg;if((this.
Q.AJ===4)||(this.Q.AJ===3))this.AT.Fm([this,this.Jo]);else this.AT.Fm(null);if(!
!this.A2&&(this.D3!==A.hm)){if(this.Q.AJ===2)A_=A.t1(A_,this.A2.Do()[0]);if(this.
Q.AJ===1)A_=[].concat(this.A2.Do()[2],A_.slice(1,4));}this.AT.N([A_[0]+this.Q.J0
,A_[1]+this.Q.Hi,A_[2]-this.Q.Hh,A_[3]-this.Q.JZ]);this.AT.Fl(this.Q.Ek);this.AT.
Fi(this.Q.He);this.AT.DQ(this.Fv);this.AT.DO(Dz);}},Jo:function(Cn){if(!!this.Q&&
!!this.Q.AJ)this.Dp();},EE:function(Cn){if(!!this.Q){var EL=(this.Gh*this.Gg)+this.
Gf;var EB=this.JJ;if(this.Fq>0)EB=EB+1;if(EL<0.000000)EB=EB+1;var Bd=A.tC(EL,EB,
this.Fq);var A7=Bd.indexOf(String.fromCharCode(0x2E),0);if((A7>=0)&&(this.Q.H7!==
Ab))Bd=(A.t8(Bd,A7)+this.Q.H7)+A.ub(Bd,0,A7+1);if(EL<0.000000){Bd=A.ub(Bd,0,1);A7=
A7-1;}if(this.Q.H8!==A.hm){if(A7<0)A7=Bd.length;for(;A7>3;A7=A7-3)Bd=(A.t8(Bd,A7-
3)+this.Q.H8)+A.ub(Bd,0,A7-3);}if(EL>=0.000000)Bd=this.Q.JE+Bd;else Bd=this.Q.JD+
Bd;if(Bd!==this.D3){this.D3=Bd;this.HN=EL<0.000000;this.Dp();}}else if(this.D3!==
A.hm){this.D3=A.hm;this.Dp();}},HQ:function(Cn){if(!!this.Q)this.N(this.M);A.lq([
this,this.EE],this);this.Dp();},DG:function(Cn){var B;if(!!this.Bg)this.Fj((B=this.
Bg,B[1].call(B[0])));},Z:function(C){if(A.tn(this.Bg,C))return;if(!!this.Bg)A.sO([
this,this.DG],this.Bg,0);this.Bg=C;if(!!C)A.sB([this,this.DG],C,0);if(!!C)A.lq([
this,this.DG],this);},Ao:function(C){if(this.Fv===C)return;this.Fv=C;this.Dp();}
,An:function(C){if(this.Fq===C)return;this.Fq=C;A.lq([this,this.EE],this);},JK:function(
C){if(this.Gf===C)return;this.Gf=C;A.lq([this,this.EE],this);},Am:function(C){if(
this.Gg===C)return;this.Gg=C;A.lq([this,this.EE],this);},Fj:function(C){if(this.
Gh===C)return;this.Gh=C;A.lq([this,this.EE],this);},Al:function(C){if(this.Q===C
)return;if(!!this.Q)A.sM([this,this.HQ],this.Q,0);this.Q=C;if(!!C)A.sz([this,this.
HQ],C,0);A.lq([this,this.HQ],this);},_Init:function(aArg){A.Core.Y._Init.call(this
,aArg);this.__proto__=E.P;this.F=0x1B;this.N(Cr);},_Mark:function(D){var B;A.Core.
Y._Mark.call(this,D);if((B=this.AT)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.
A2)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.Q)&&(B._cycle!=D))B._Mark(B._cycle=
D);if((B=this.Bg)&&((B=B[0])._cycle!=D))B._Mark(B._cycle=D);},_className:"WidgetSet::ValueDisplay"
};
E._Init=function(){E.Fx.__proto__=E.FA;E.P.__proto__=A.Core.Y;};E.Au=function(D){
};return E;})();

/* Embedded Wizard */