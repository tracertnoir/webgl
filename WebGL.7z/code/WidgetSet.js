/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.uj)throw new Error("The unit file 'WidgetSet.js' included twice!");
EmWiApp.uj=(function(){var B=EmWiApp;var D={};
var Z=".";var An="-";var Ca=[0,0,200,30];
D.KY={KW:0,Ka:1,J$:2,Kc:3,Kb:4};D.Gv={Ew:null,Eu:null,Hh:B.hm,Hg:Z,Ih:An,Ii:B.hm,
IQ:0,IS:0,IR:0,Gw:0,Gt:0xFF000000,Gu:0xFF000000,Gs:0x12,IN:0,Gr:0,Gq:0,IO:0,Go:0xFF000000
,Gp:0xFF000000,Gn:0x12,D0:B.qx,Fj:B.qx,AE:0,IE:function(C){if(this.Gw===C)return;
this.Gw=C;B.lq([this,this.BN],this);},IB:function(C){if(this.Gt===C)return;this.
Gt=C;B.lq([this,this.BN],this);},IC:function(C){if(this.Gu===C)return;this.Gu=C;
B.lq([this,this.BN],this);},IA:function(C){if(this.Gs===C)return;this.Gs=C;B.lq([
this,this.BN],this);},ID:function(C){if(this.Ew===C)return;this.Ew=C;B.lq([this,
this.BN],this);},Iz:function(C){if(this.Gr===C)return;this.Gr=C;B.lq([this,this.
BN],this);},Iy:function(C){if(this.Gq===C)return;this.Gq=C;B.lq([this,this.BN],this
);},Iv:function(C){if(this.Go===C)return;this.Go=C;B.lq([this,this.BN],this);},Iw:
function(C){if(this.Gp===C)return;this.Gp=C;B.lq([this,this.BN],this);},Iu:function(
C){if(this.Gn===C)return;this.Gn=C;B.lq([this,this.BN],this);},Ix:function(C){if(
this.Eu===C)return;this.Eu=C;B.lq([this,this.BN],this);},Eo:function(C){if(this.
AE===C)return;this.AE=C;B.lq([this,this.BN],this);},_Init:function(aArg){D.Fi._Init.
call(this,aArg);this.__proto__=D.Gv;},_Mark:function(E){var A;D.Fi._Mark.call(this
,E);if((A=this.Ew)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.Eu)&&(A._cycle!=
E))A._Mark(A._cycle=E);},_className:"WidgetSet::ValueDisplayConfig"};D.Fi={BN:function(
B8){B.qw(this,0);},_Init:function(aArg){this.__proto__=D.Fi;B.gv++;},_Done:function(
){this.__proto__=null;B.gv--;},_ReInit:function(){},_Mark:function(E){var A;if((
A=this.O)&&(A._cycle!=E))A._Mark(A._cycle=E);},O:null,_cycle:0,_observers:null,_className:
"WidgetSet::WidgetConfig"};D.Ai={AN:null,AV:null,P:null,A$:null,D$:B.hm,Fe:B.hm,
Fd:0,In:0,FQ:0,FR:1.000000,FS:0,GX:false,T:function(C){var A;if(!!this.P){var HW=[
C[2]-C[0],C[3]-C[1]];var Bc=HW;if(Bc[0]<this.P.Fj[0])Bc=[this.P.Fj[0],Bc[1]];if(
Bc[1]<this.P.Fj[1])Bc=[Bc[0],this.P.Fj[1]];if((this.P.D0[0]>0)&&(Bc[0]>this.P.D0[
0]))Bc=[this.P.D0[0],Bc[1]];if((this.P.D0[1]>0)&&(Bc[1]>this.P.D0[1]))Bc=[Bc[0],
this.P.D0[1]];var AY=B.tw(Bc,HW);if(!!AY[0]){var Cc=((this.AE&0x4)===0x4);var Cd=((
this.AE&0x8)===0x8);if(Cc&&!Cd)C=B.t1(C,C[2]+AY[0]);else if(!Cc&&Cd)C=[].concat(
C[0]-AY[0],C.slice(1,4));else{C=[].concat(C[0]-((AY[0]/2)|0),C.slice(1,4));C=B.t1(
C,C[0]+Bc[0]);}}if(!!AY[1]){var Ce=((this.AE&0x10)===0x10);var Cb=((this.AE&0x20
)===0x20);if(Ce&&!Cb)C=[].concat(C.slice(0,3),C[3]+AY[1]);else if(!Ce&&Cb)C=B.t3(
C,C[1]-AY[1]);else{C=B.t3(C,C[1]-((AY[1]/2)|0));C=[].concat(C.slice(0,3),C[1]+Bc[
1]);}}}B.Core.X.T.call(this,C);},Ev:function(Fm){var A;B.Core.X.Ev.call(this,Fm);
var H1=!!this.P&&!!this.P.Ew;var H0=!!this.P&&!!this.P.Eu;var R=[0,0,(A=this.M)[
2]-A[0],A[3]-A[1]];if(H1&&!this.AV){this.AV=B._NewObject(B.un.Text,0);this.As(this.
AV,0);}else if(!H1&&!!this.AV){this.HI(this.AV);this.AV=null;}if(H0&&!this.AN){this.
AN=B._NewObject(B.un.Text,0);this.As(this.AN,0);this.AN.Ip(true);}else if(!H0&&!
!this.AN){this.HI(this.AN);this.AN=null;}if(!!this.AV){var Dg=0xFFFFFFFF;var A3=
R;if(this.GX)Dg=this.P.Gt;else Dg=this.P.Gu;if((this.P.AE===2)||(this.P.AE===1))
this.AV.Fa([this,this.H3]);else this.AV.Fa(null);if((!!this.AN&&(this.Fe!==B.hm)
)&&!(((A=this.AN.C8())[0]>=A[2])||(A[1]>=A[3]))){if(this.P.AE===4)A3=B.t1(A3,this.
AN.C8()[0]);if(this.P.AE===3)A3=[].concat(this.AN.C8()[2],A3.slice(1,4));}this.AV.
T([A3[0]+this.P.Gw,A3[1]+this.P.IS,A3[2]-this.P.IR,A3[3]-this.P.IQ]);this.AV.E$(
this.P.Ew);this.AV.E8(this.P.Gs);this.AV.DO(this.D$);this.AV.Dy(Dg);}if(!!this.AN
){var Dg=0xFFFFFFFF;var A3=R;if(this.GX)Dg=this.P.Go;else Dg=this.P.Gp;if((this.
P.AE===4)||(this.P.AE===3))this.AN.Fa([this,this.H3]);else this.AN.Fa(null);if(!
!this.AV&&(this.D$!==B.hm)){if(this.P.AE===2)A3=B.t1(A3,this.AV.C8()[0]);if(this.
P.AE===1)A3=[].concat(this.AV.C8()[2],A3.slice(1,4));}this.AN.T([A3[0]+this.P.IO
,A3[1]+this.P.Gr,A3[2]-this.P.Gq,A3[3]-this.P.IN]);this.AN.E$(this.P.Eu);this.AN.
E8(this.P.Gn);this.AN.DO(this.Fe);this.AN.Dy(Dg);}},H3:function(B8){if(!!this.P&&
!!this.P.AE)this.C9();},EP:function(B8){if(!!this.P){var EW=(this.FS*this.FR)+this.
FQ;var EM=this.In;if(this.Fd>0)EM=EM+1;if(EW<0.000000)EM=EM+1;var A8=B.tC(EW,EM,
this.Fd);var A0=A8.indexOf(String.fromCharCode(0x2E),0);if((A0>=0)&&(this.P.Hg!==
Z))A8=(B.t8(A8,A0)+this.P.Hg)+B.ub(A8,0,A0+1);if(EW<0.000000){A8=B.ub(A8,0,1);A0=
A0-1;}if(this.P.Hh!==B.hm){if(A0<0)A0=A8.length;for(;A0>3;A0=A0-3)A8=(B.t8(A8,A0-
3)+this.P.Hh)+B.ub(A8,0,A0-3);}if(EW>=0.000000)A8=this.P.Ii+A8;else A8=this.P.Ih+
A8;if(A8!==this.D$){this.D$=A8;this.GX=EW<0.000000;this.C9();}}else if(this.D$!==
B.hm){this.D$=B.hm;this.C9();}},G0:function(B8){if(!!this.P)this.T(this.M);B.lq([
this,this.EP],this);this.C9();},Dn:function(B8){var A;if(!!this.A$)this.E9((A=this.
A$,A[1].call(A[0])));},AJ:function(C){if(B.tn(this.A$,C))return;if(!!this.A$)B.sO([
this,this.Dn],this.A$,0);this.A$=C;if(!!C)B.sB([this,this.Dn],C,0);if(!!C)B.lq([
this,this.Dn],this);},BC:function(C){if(this.Fe===C)return;this.Fe=C;this.C9();}
,BB:function(C){if(this.Fd===C)return;this.Fd=C;B.lq([this,this.EP],this);},Io:function(
C){if(this.FQ===C)return;this.FQ=C;B.lq([this,this.EP],this);},BA:function(C){if(
this.FR===C)return;this.FR=C;B.lq([this,this.EP],this);},E9:function(C){if(this.
FS===C)return;this.FS=C;B.lq([this,this.EP],this);},Bz:function(C){if(this.P===C
)return;if(!!this.P)B.sM([this,this.G0],this.P,0);this.P=C;if(!!C)B.sz([this,this.
G0],C,0);B.lq([this,this.G0],this);},_Init:function(aArg){B.Core.X._Init.call(this
,aArg);this.__proto__=D.Ai;this.F=0x1B;this.T(Ca);},_Mark:function(E){var A;B.Core.
X._Mark.call(this,E);if((A=this.AN)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.
AV)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.P)&&(A._cycle!=E))A._Mark(A._cycle=
E);if((A=this.A$)&&((A=A[0])._cycle!=E))A._Mark(A._cycle=E);},_className:"WidgetSet::ValueDisplay"
};
D._Init=function(){D.Gv.__proto__=D.Fi;D.Ai.__proto__=B.Core.X;};D.Ao=function(E){
};return D;})();

/* Embedded Wizard */