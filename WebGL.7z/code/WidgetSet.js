/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.ui)throw new Error("The unit file 'WidgetSet.js' included twice!");
EmWiApp.ui=(function(){var B=EmWiApp;var D={};
var Y=".";var Ax="-";var BX=[0,0,200,30];
D.J6={J4:0,Jm:1,Jl:2,Jo:3,Jn:4};D.FO={Eb:null,D$:null,GD:B.hm,GC:Y,HB:Ax,HC:B.hm,
H3:0,H5:0,H4:0,FP:0,FM:0xFF000000,FN:0xFF000000,FL:0x12,H1:0,FK:0,FJ:0,H2:0,FH:0xFF000000
,FI:0xFF000000,FG:0x12,Dt:B.qx,EV:B.qx,AA:0,HU:function(C){if(this.FP===C)return;
this.FP=C;B.lq([this,this.Bw],this);},HR:function(C){if(this.FM===C)return;this.
FM=C;B.lq([this,this.Bw],this);},HS:function(C){if(this.FN===C)return;this.FN=C;
B.lq([this,this.Bw],this);},HQ:function(C){if(this.FL===C)return;this.FL=C;B.lq([
this,this.Bw],this);},HT:function(C){if(this.Eb===C)return;this.Eb=C;B.lq([this,
this.Bw],this);},HP:function(C){if(this.FK===C)return;this.FK=C;B.lq([this,this.
Bw],this);},HO:function(C){if(this.FJ===C)return;this.FJ=C;B.lq([this,this.Bw],this
);},HL:function(C){if(this.FH===C)return;this.FH=C;B.lq([this,this.Bw],this);},HM:
function(C){if(this.FI===C)return;this.FI=C;B.lq([this,this.Bw],this);},HK:function(
C){if(this.FG===C)return;this.FG=C;B.lq([this,this.Bw],this);},HN:function(C){if(
this.D$===C)return;this.D$=C;B.lq([this,this.Bw],this);},EM:function(C){if(this.
AA===C)return;this.AA=C;B.lq([this,this.Bw],this);},_Init:function(aArg){D.EU._Init.
call(this,aArg);this.__proto__=D.FO;},_Mark:function(E){var A;D.EU._Mark.call(this
,E);if((A=this.Eb)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.D$)&&(A._cycle!=
E))A._Mark(A._cycle=E);},_className:"WidgetSet::ValueDisplayConfig"};D.EU={Bw:function(
BH){B.qw(this,0);},_Init:function(aArg){this.__proto__=D.EU;B.gv++;},_Done:function(
){this.__proto__=null;B.gv--;},_ReInit:function(){},_Mark:function(E){var A;if((
A=this.O)&&(A._cycle!=E))A._Mark(A._cycle=E);},O:null,_cycle:0,_observers:null,_className:
"WidgetSet::WidgetConfig"};D.Ah={AJ:null,AR:null,N:null,A6:null,DD:B.hm,EQ:B.hm,
EP:0,HG:0,Hv:0,Hw:1.000000,Fn:0,Gl:false,S:function(C){var A;if(!!this.N){var Hg=[
C[2]-C[0],C[3]-C[1]];var A9=Hg;if(A9[0]<this.N.EV[0])A9=[this.N.EV[0],A9[1]];if(
A9[1]<this.N.EV[1])A9=[A9[0],this.N.EV[1]];if((this.N.Dt[0]>0)&&(A9[0]>this.N.Dt[
0]))A9=[this.N.Dt[0],A9[1]];if((this.N.Dt[1]>0)&&(A9[1]>this.N.Dt[1]))A9=[A9[0],
this.N.Dt[1]];var B8=B.tw(A9,Hg);if(!!B8[0]){var BZ=((this.AA&0x4)===0x4);var B0=((
this.AA&0x8)===0x8);if(BZ&&!B0)C=B.t1(C,C[2]+B8[0]);else if(!BZ&&B0)C=[].concat(
C[0]-B8[0],C.slice(1,4));else{C=[].concat(C[0]-((B8[0]/2)|0),C.slice(1,4));C=B.t1(
C,C[0]+A9[0]);}}if(!!B8[1]){var B1=((this.AA&0x10)===0x10);var BY=((this.AA&0x20
)===0x20);if(B1&&!BY)C=[].concat(C.slice(0,3),C[3]+B8[1]);else if(!B1&&BY)C=B.t3(
C,C[1]-B8[1]);else{C=B.t3(C,C[1]-((B8[1]/2)|0));C=[].concat(C.slice(0,3),C[1]+A9[
1]);}}}B.Core.Ab.S.call(this,C);},Ea:function(EY){var A;B.Core.Ab.Ea.call(this,EY
);var Hl=!!this.N&&!!this.N.Eb;var Hk=!!this.N&&!!this.N.D$;var Q=[0,0,(A=this.M
)[2]-A[0],A[3]-A[1]];if(Hl&&!this.AR){this.AR=B._NewObject(B.um.Text,0);this.Av(
this.AR,0);}else if(!Hl&&!!this.AR){this.G6(this.AR);this.AR=null;}if(Hk&&!this.
AJ){this.AJ=B._NewObject(B.um.Text,0);this.Av(this.AJ,0);this.AJ.HI(true);}else if(
!Hk&&!!this.AJ){this.G6(this.AJ);this.AJ=null;}if(!!this.AR){var CW=0xFFFFFFFF;var
A1=Q;if(this.Gl)CW=this.N.FM;else CW=this.N.FN;if((this.N.AA===2)||(this.N.AA===
1))this.AR.EN([this,this.Hn]);else this.AR.EN(null);if((!!this.AJ&&(this.EQ!==B.
hm))&&!(((A=this.AJ.CM())[0]>=A[2])||(A[1]>=A[3]))){if(this.N.AA===4)A1=B.t1(A1,
this.AJ.CM()[0]);if(this.N.AA===3)A1=[].concat(this.AJ.CM()[2],A1.slice(1,4));}this.
AR.S([A1[0]+this.N.FP,A1[1]+this.N.H5,A1[2]-this.N.H4,A1[3]-this.N.H3]);this.AR.
EL(this.N.Eb);this.AR.EI(this.N.FL);this.AR.Dp(this.DD);this.AR.EJ(CW);}if(!!this.
AJ){var CW=0xFFFFFFFF;var A1=Q;if(this.Gl)CW=this.N.FH;else CW=this.N.FI;if((this.
N.AA===4)||(this.N.AA===3))this.AJ.EN([this,this.Hn]);else this.AJ.EN(null);if(!
!this.AR&&(this.DD!==B.hm)){if(this.N.AA===2)A1=B.t1(A1,this.AR.CM()[0]);if(this.
N.AA===1)A1=[].concat(this.AR.CM()[2],A1.slice(1,4));}this.AJ.S([A1[0]+this.N.H2
,A1[1]+this.N.FK,A1[2]-this.N.FJ,A1[3]-this.N.H1]);this.AJ.EL(this.N.D$);this.AJ.
EI(this.N.FG);this.AJ.Dp(this.EQ);this.AJ.EJ(CW);}},Hn:function(BH){if(!!this.N&&
!!this.N.AA)this.Db();},Gp:function(BH){if(!!this.N){var Ez=(this.Fn*this.Hw)+this.
Hv;var Ep=this.HG;if(this.EP>0)Ep=Ep+1;if(Ez<0.000000)Ep=Ep+1;var A4=B.tC(Ez,Ep,
this.EP);var AX=A4.indexOf(String.fromCharCode(0x2E),0);if((AX>=0)&&(this.N.GC!==
Y))A4=(B.t8(A4,AX)+this.N.GC)+B.ub(A4,0,AX+1);if(Ez<0.000000){A4=B.ub(A4,0,1);AX=
AX-1;}if(this.N.GD!==B.hm){if(AX<0)AX=A4.length;for(;AX>3;AX=AX-3)A4=(B.t8(A4,AX-
3)+this.N.GD)+B.ub(A4,0,AX-3);}if(Ez>=0.000000)A4=this.N.HC+A4;else A4=this.N.HB+
A4;if(A4!==this.DD){this.DD=A4;this.Gl=Ez<0.000000;this.Db();}}else if(this.DD!==
B.hm){this.DD=B.hm;this.Db();}},Go:function(BH){if(!!this.N)this.S(this.M);B.lq([
this,this.Gp],this);this.Db();},C3:function(BH){var A;if(!!this.A6)this.HH((A=this.
A6,A[1].call(A[0])));},AG:function(C){if(B.tn(this.A6,C))return;if(!!this.A6)B.sO([
this,this.C3],this.A6,0);this.A6=C;if(!!C)B.sB([this,this.C3],C,0);if(!!C)B.lq([
this,this.C3],this);},Bq:function(C){if(this.EQ===C)return;this.EQ=C;this.Db();}
,Bp:function(C){if(this.EP===C)return;this.EP=C;B.lq([this,this.Gp],this);},HH:function(
C){if(this.Fn===C)return;this.Fn=C;B.lq([this,this.Gp],this);},Bo:function(C){if(
this.N===C)return;if(!!this.N)B.sM([this,this.Go],this.N,0);this.N=C;if(!!C)B.sz([
this,this.Go],C,0);B.lq([this,this.Go],this);},_Init:function(aArg){B.Core.Ab._Init.
call(this,aArg);this.__proto__=D.Ah;this.F=0x1B;this.S(BX);},_Mark:function(E){var
A;B.Core.Ab._Mark.call(this,E);if((A=this.AJ)&&(A._cycle!=E))A._Mark(A._cycle=E);
if((A=this.AR)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.N)&&(A._cycle!=E))A.
_Mark(A._cycle=E);if((A=this.A6)&&((A=A[0])._cycle!=E))A._Mark(A._cycle=E);},_className:
"WidgetSet::ValueDisplay"};
D._Init=function(){D.FO.__proto__=D.EU;D.Ah.__proto__=B.Core.Ab;};D.Am=function(E
){};return D;})();

/* Embedded Wizard */