/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.ui)throw new Error("The unit file 'WidgetSet.js' included twice!");
EmWiApp.ui=(function(){var B=EmWiApp;var D={};
var Z=".";var Ay="-";var B1=[0,0,200,30];
D.Ka={J_:0,Js:1,Jr:2,Ju:3,Jt:4};D.FU={Ef:null,Ed:null,GJ:B.hm,GI:Z,HG:Ay,HH:B.hm,
H_:0,Ia:0,H$:0,FV:0,FS:0xFF000000,FT:0xFF000000,FR:0x12,H8:0,FQ:0,FP:0,H9:0,FN:0xFF000000
,FO:0xFF000000,FM:0x12,DF:B.qx,E0:B.qx,AC:0,H0:function(C){if(this.FV===C)return;
this.FV=C;B.lq([this,this.BB],this);},HX:function(C){if(this.FS===C)return;this.
FS=C;B.lq([this,this.BB],this);},HY:function(C){if(this.FT===C)return;this.FT=C;
B.lq([this,this.BB],this);},HW:function(C){if(this.FR===C)return;this.FR=C;B.lq([
this,this.BB],this);},HZ:function(C){if(this.Ef===C)return;this.Ef=C;B.lq([this,
this.BB],this);},HV:function(C){if(this.FQ===C)return;this.FQ=C;B.lq([this,this.
BB],this);},HU:function(C){if(this.FP===C)return;this.FP=C;B.lq([this,this.BB],this
);},HR:function(C){if(this.FN===C)return;this.FN=C;B.lq([this,this.BB],this);},HS:
function(C){if(this.FO===C)return;this.FO=C;B.lq([this,this.BB],this);},HQ:function(
C){if(this.FM===C)return;this.FM=C;B.lq([this,this.BB],this);},HT:function(C){if(
this.Ed===C)return;this.Ed=C;B.lq([this,this.BB],this);},ER:function(C){if(this.
AC===C)return;this.AC=C;B.lq([this,this.BB],this);},_Init:function(aArg){D.EZ._Init.
call(this,aArg);this.__proto__=D.FU;},_Mark:function(E){var A;D.EZ._Mark.call(this
,E);if((A=this.Ef)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.Ed)&&(A._cycle!=
E))A._Mark(A._cycle=E);},_className:"WidgetSet::ValueDisplayConfig"};D.EZ={BB:function(
BX){B.qw(this,0);},_Init:function(aArg){this.__proto__=D.EZ;B.gv++;},_Done:function(
){this.__proto__=null;B.gv--;},_ReInit:function(){},_Mark:function(E){var A;if((
A=this.P)&&(A._cycle!=E))A._Mark(A._cycle=E);},P:null,_cycle:0,_observers:null,_className:
"WidgetSet::WidgetConfig"};D.Ai={AL:null,AU:null,O:null,A8:null,DO:B.hm,EV:B.hm,
EU:0,HL:0,Fr:0,Fs:1.000000,Ft:0,Gs:false,U:function(C){var A;if(!!this.O){var Hn=[
C[2]-C[0],C[3]-C[1]];var A$=Hn;if(A$[0]<this.O.E0[0])A$=[this.O.E0[0],A$[1]];if(
A$[1]<this.O.E0[1])A$=[A$[0],this.O.E0[1]];if((this.O.DF[0]>0)&&(A$[0]>this.O.DF[
0]))A$=[this.O.DF[0],A$[1]];if((this.O.DF[1]>0)&&(A$[1]>this.O.DF[1]))A$=[A$[0],
this.O.DF[1]];var AX=B.tw(A$,Hn);if(!!AX[0]){var B3=((this.AC&0x4)===0x4);var B4=((
this.AC&0x8)===0x8);if(B3&&!B4)C=B.t1(C,C[2]+AX[0]);else if(!B3&&B4)C=[].concat(
C[0]-AX[0],C.slice(1,4));else{C=[].concat(C[0]-((AX[0]/2)|0),C.slice(1,4));C=B.t1(
C,C[0]+A$[0]);}}if(!!AX[1]){var B5=((this.AC&0x10)===0x10);var B2=((this.AC&0x20
)===0x20);if(B5&&!B2)C=[].concat(C.slice(0,3),C[3]+AX[1]);else if(!B5&&B2)C=B.t3(
C,C[1]-AX[1]);else{C=B.t3(C,C[1]-((AX[1]/2)|0));C=[].concat(C.slice(0,3),C[1]+A$[
1]);}}}B.Core.Ac.U.call(this,C);},Ee:function(E3){var A;B.Core.Ac.Ee.call(this,E3
);var Hs=!!this.O&&!!this.O.Ef;var Hr=!!this.O&&!!this.O.Ed;var R=[0,0,(A=this.M
)[2]-A[0],A[3]-A[1]];if(Hs&&!this.AU){this.AU=B._NewObject(B.um.Text,0);this.Aw(
this.AU,0);}else if(!Hs&&!!this.AU){this.Hb(this.AU);this.AU=null;}if(Hr&&!this.
AL){this.AL=B._NewObject(B.um.Text,0);this.Aw(this.AL,0);this.AL.HN(true);}else if(
!Hr&&!!this.AL){this.Hb(this.AL);this.AL=null;}if(!!this.AU){var C1=0xFFFFFFFF;var
A2=R;if(this.Gs)C1=this.O.FS;else C1=this.O.FT;if((this.O.AC===2)||(this.O.AC===
1))this.AU.ES([this,this.Hu]);else this.AU.ES(null);if((!!this.AL&&(this.EV!==B.
hm))&&!(((A=this.AL.CS())[0]>=A[2])||(A[1]>=A[3]))){if(this.O.AC===4)A2=B.t1(A2,
this.AL.CS()[0]);if(this.O.AC===3)A2=[].concat(this.AL.CS()[2],A2.slice(1,4));}this.
AU.U([A2[0]+this.O.FV,A2[1]+this.O.Ia,A2[2]-this.O.H$,A2[3]-this.O.H_]);this.AU.
EQ(this.O.Ef);this.AU.EN(this.O.FR);this.AU.Dx(this.DO);this.AU.EO(C1);}if(!!this.
AL){var C1=0xFFFFFFFF;var A2=R;if(this.Gs)C1=this.O.FN;else C1=this.O.FO;if((this.
O.AC===4)||(this.O.AC===3))this.AL.ES([this,this.Hu]);else this.AL.ES(null);if(!
!this.AU&&(this.DO!==B.hm)){if(this.O.AC===2)A2=B.t1(A2,this.AU.CS()[0]);if(this.
O.AC===1)A2=[].concat(this.AU.CS()[2],A2.slice(1,4));}this.AL.U([A2[0]+this.O.H9
,A2[1]+this.O.FQ,A2[2]-this.O.FP,A2[3]-this.O.H8]);this.AL.EQ(this.O.Ed);this.AL.
EN(this.O.FM);this.AL.Dx(this.EV);this.AL.EO(C1);}},Hu:function(BX){if(!!this.O&&
!!this.O.AC)this.Dh();},Ew:function(BX){if(!!this.O){var EE=(this.Ft*this.Fs)+this.
Fr;var Et=this.HL;if(this.EU>0)Et=Et+1;if(EE<0.000000)Et=Et+1;var A6=B.tC(EE,Et,
this.EU);var AZ=A6.indexOf(String.fromCharCode(0x2E),0);if((AZ>=0)&&(this.O.GI!==
Z))A6=(B.t8(A6,AZ)+this.O.GI)+B.ub(A6,0,AZ+1);if(EE<0.000000){A6=B.ub(A6,0,1);AZ=
AZ-1;}if(this.O.GJ!==B.hm){if(AZ<0)AZ=A6.length;for(;AZ>3;AZ=AZ-3)A6=(B.t8(A6,AZ-
3)+this.O.GJ)+B.ub(A6,0,AZ-3);}if(EE>=0.000000)A6=this.O.HH+A6;else A6=this.O.HG+
A6;if(A6!==this.DO){this.DO=A6;this.Gs=EE<0.000000;this.Dh();}}else if(this.DO!==
B.hm){this.DO=B.hm;this.Dh();}},Gv:function(BX){if(!!this.O)this.U(this.M);B.lq([
this,this.Ew],this);this.Dh();},C8:function(BX){var A;if(!!this.A8)this.Ha((A=this.
A8,A[1].call(A[0])));},AH:function(C){if(B.tn(this.A8,C))return;if(!!this.A8)B.sO([
this,this.C8],this.A8,0);this.A8=C;if(!!C)B.sB([this,this.C8],C,0);if(!!C)B.lq([
this,this.C8],this);},Bu:function(C){if(this.EV===C)return;this.EV=C;this.Dh();}
,Bt:function(C){if(this.EU===C)return;this.EU=C;B.lq([this,this.Ew],this);},HM:function(
C){if(this.Fr===C)return;this.Fr=C;B.lq([this,this.Ew],this);},Bs:function(C){if(
this.Fs===C)return;this.Fs=C;B.lq([this,this.Ew],this);},Ha:function(C){if(this.
Ft===C)return;this.Ft=C;B.lq([this,this.Ew],this);},Br:function(C){if(this.O===C
)return;if(!!this.O)B.sM([this,this.Gv],this.O,0);this.O=C;if(!!C)B.sz([this,this.
Gv],C,0);B.lq([this,this.Gv],this);},_Init:function(aArg){B.Core.Ac._Init.call(this
,aArg);this.__proto__=D.Ai;this.F=0x1B;this.U(B1);},_Mark:function(E){var A;B.Core.
Ac._Mark.call(this,E);if((A=this.AL)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.
AU)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.O)&&(A._cycle!=E))A._Mark(A._cycle=
E);if((A=this.A8)&&((A=A[0])._cycle!=E))A._Mark(A._cycle=E);},_className:"WidgetSet::ValueDisplay"
};
D._Init=function(){D.FU.__proto__=D.EZ;D.Ai.__proto__=B.Core.Ac;};D.An=function(E
){};return D;})();

/* Embedded Wizard */