/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.ul)throw new Error("The unit file 'Resources.js' included twice!");
EmWiApp.ul=(function(){var A=EmWiApp;var E={};
var Ab=[0,0];var At="The property \'FrameSize\' is READ ONLY.";
E.Dm={bitmap:null,FrameDelay:0,NoOfFrames:1,FrameSize:A.qx,D5:false,Ib:false,BT:function(
){if(!this.bitmap)return;var handle=this.bitmap;A.sW(handle);this.bitmap=null;this.
FrameSize=Ab;this.FrameDelay=0;this.NoOfFrames=1;this.D5=false;},Bf:function(aArg
){if(!aArg)return;var handle=null;var noOfFrames=1;var frameSize=Ab;var frameDelay=
0;{var bmp=A.tp(aArg,this);if(bmp){noOfFrames=bmp.NoOfFrames;frameSize=bmp.FrameSize;
frameDelay=bmp.FrameDelay;}handle=bmp;}this.bitmap=handle;this.NoOfFrames=noOfFrames;
this.FrameSize=frameSize;this.FrameDelay=frameDelay;this.Ib=true;this.D5=(!!this.
bitmap&&(this.FrameDelay>0))&&(this.NoOfFrames>1);},GJ:function(C){throw new Error(
At);},Update:function(){},_Init:function(aArg){A.Core.CG._Init.call(this,aArg);this.
__proto__=E.Dm;this.Bf(aArg);},_Done:function(){this.BT();this.__proto__=A.Core.
CG;A.Core.CG._Done.call(this);},_className:"Resources::Bitmap"};E.AB={font:null,
Leading:0,Descent:0,Ascent:0,BT:function(){if(!this.font)return;var handle=this.
font;A.sX(handle);this.font=null;this.Ascent=0;this.Descent=0;this.Leading=0;},Bf:
function(aArg){if(!aArg)return;var handle=null;var ascent=0;var descent=0;var leading=
0;{var font=A.tr(aArg);if(font){ascent=font.Ascent;descent=font.Descent;leading=
font.Leading;}handle=font;}this.font=handle;this.Ascent=ascent;this.Descent=descent;
this.Leading=leading;},H9:function(aFlowString){if(!this.font)return 0;var handle=
this.font;var advance=0;advance=A.s2(handle,aFlowString);return advance;},JR:function(
aString,aOffset,aWidth,aMaxNoOfRows,aBidi){if(aOffset<0)aOffset=0;if(!this.font||((
aOffset>0)&&(aOffset>=aString.length)))return A.hm;var handle=this.font;var result=
A.hm;result=A.tM(handle,aString,aOffset,aWidth,aMaxNoOfRows,aBidi);return result;
},D9:function(aString,aOffset,aCount){if(aOffset<0)aOffset=0;if(!this.font||((aOffset>
0)&&(aOffset>=aString.length)))return 0;var handle=this.font;var advance=0;advance=
A.jJ(handle,aString,aOffset,aCount);return advance;},OnGetLeading:function(){return this.
Leading;},OnGetDescent:function(){return this.Descent;},OnGetAscent:function(){return this.
Ascent;},_Init:function(aArg){A.Core.CG._Init.call(this,aArg);this.__proto__=E.AB;
this.Bf(aArg);},_Done:function(){this.BT();this.__proto__=A.Core.CG;A.Core.CG._Done.
call(this);},_className:"Resources::Font"};E.E0={_class:function(){return E.AB;}
,0:{Data:function(){return A.uw;},Cache:[],_this:null}};E.Gq={_class:function(){
return E.AB;},0:{Data:function(){return A.uv;},Cache:[],_this:null}};
E._Init=function(){E.Dm.__proto__=A.Core.CG;E.AB.__proto__=A.Core.CG;};E.Au=function(
D){var B;if((B=E.E0[0]._this)&&(B._cycle!=D))B._Done(E.E0[0]._this=null);if((B=E.
Gq[0]._this)&&(B._cycle!=D))B._Done(E.Gq[0]._this=null);};return E;})();

/* Embedded Wizard */