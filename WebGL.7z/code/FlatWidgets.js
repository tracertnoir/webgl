/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.uk)throw new Error("The unit file 'FlatWidgets.js' included twice!"
);EmWiApp.uk=(function(){var A=EmWiApp;var E={};

E.CU=0xFF00BF7F;E.P={_Init:function(){A.uj.Fx._Init.call(this,0);this.JQ(60);this.
IY(E.CU);this.IZ(E.CU);this.IX(0x9);this.I0(A.s$(E.Gp));this.JP(7);this.JO(5);this.
IU(E.CU);this.IV(E.CU);this.IT(0xC);this.IW(A.s$(A.ul.E0));this.Ec(2);},_variants:
function(){return this;},_this:null};E.Gp={_class:function(){return A.ul.AB;},0:{
Data:function(){return A.uu;},Cache:[],_this:null}};E.A0={_Init:function(){A.uj.
Fx._Init.call(this,0);this.IY(E.CU);this.IZ(E.CU);this.IX(0x22);this.I0(A.s$(A.ul.
Gq));this.IU(E.CU);this.IV(E.CU);this.IT(0xA);this.IW(A.s$(A.ul.E0));},_variants:
function(){return this;},_this:null};
E._Init=function(){};E.Au=function(D){var B;if((B=E.P._this)&&(B._cycle!=D))B._Done(
E.P._this=null);if((B=E.Gp[0]._this)&&(B._cycle!=D))B._Done(E.Gp[0]._this=null);
if((B=E.A0._this)&&(B._cycle!=D))B._Done(E.A0._this=null);};return E;})();

/* Embedded Wizard */