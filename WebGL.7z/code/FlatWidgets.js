/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.uk)throw new Error("The unit file 'FlatWidgets.js' included twice!"
);EmWiApp.uk=(function(){var A=EmWiApp;var E={};

E.CV=0xFF00BF7F;E.Q={_Init:function(){A.uj.Gg._Init.call(this,0);this.JM(60);this.
IU(E.CV);this.IV(E.CV);this.IT(0x9);this.IW(A.s$(E.GZ));this.JL(7);this.JK(5);this.
IQ(E.CV);this.IR(E.CV);this.IP(0xC);this.IS(A.s$(A.ul.FU));this.Fc(2);},_variants:
function(){return this;},_this:null};E.GZ={_class:function(){return A.ul.AC;},0:{
Data:function(){return A.uu;},Cache:[],_this:null}};E.A0={_Init:function(){A.uj.
Gg._Init.call(this,0);this.IU(E.CV);this.IV(E.CV);this.IT(0x22);this.IW(A.s$(A.ul.
G0));this.IQ(E.CV);this.IR(E.CV);this.IP(0xA);this.IS(A.s$(A.ul.FU));},_variants:
function(){return this;},_this:null};
E._Init=function(){};E.Av=function(D){var B;if((B=E.Q._this)&&(B._cycle!=D))B._Done(
E.Q._this=null);if((B=E.GZ[0]._this)&&(B._cycle!=D))B._Done(E.GZ[0]._this=null);
if((B=E.A0._this)&&(B._cycle!=D))B._Done(E.A0._this=null);};return E;})();

/* Embedded Wizard */