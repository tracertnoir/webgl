/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.uk)throw new Error("The unit file 'FlatWidgets.js' included twice!"
);EmWiApp.uk=(function(){var A=EmWiApp;var E={};

E.CU=0xFF00BF7F;E.Q={_Init:function(){A.uj.Gg._Init.call(this,0);this.JL(60);this.
IT(E.CU);this.IU(E.CU);this.IS(0x9);this.IV(A.s$(E.GZ));this.JK(7);this.JJ(5);this.
IP(E.CU);this.IQ(E.CU);this.IO(0xC);this.IR(A.s$(A.ul.FT));this.Fa(2);},_variants:
function(){return this;},_this:null};E.GZ={_class:function(){return A.ul.AB;},0:{
Data:function(){return A.uu;},Cache:[],_this:null}};E.AZ={_Init:function(){A.uj.
Gg._Init.call(this,0);this.IT(E.CU);this.IU(E.CU);this.IS(0x22);this.IV(A.s$(A.ul.
G0));this.IP(E.CU);this.IQ(E.CU);this.IO(0xA);this.IR(A.s$(A.ul.FT));},_variants:
function(){return this;},_this:null};
E._Init=function(){};E.Au=function(D){var B;if((B=E.Q._this)&&(B._cycle!=D))B._Done(
E.Q._this=null);if((B=E.GZ[0]._this)&&(B._cycle!=D))B._Done(E.GZ[0]._this=null);
if((B=E.AZ._this)&&(B._cycle!=D))B._Done(E.AZ._this=null);};return E;})();

/* Embedded Wizard */