/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.uk)throw new Error("The unit file 'FlatWidgets.js' included twice!"
);EmWiApp.uk=(function(){var B=EmWiApp;var D={};

D.EZ=0xFF00BF7F;D.Ai={_Init:function(){B.uj.Gv._Init.call(this,0);this.IE(60);this.
IB(D.EZ);this.IC(D.EZ);this.IA(0x9);this.ID(B.s$(D.FY));this.Iz(7);this.Iy(5);this.
Iv(D.EZ);this.Iw(D.EZ);this.Iu(0xC);this.Ix(B.s$(B.ul.FZ));this.Eo(2);},_variants:
function(){return this;},_this:null};D.FY={_class:function(){return B.ul.Az;},0:{
Data:function(){return B.uu;},Cache:[],_this:null}};
D._Init=function(){};D.Ao=function(E){var A;if((A=D.Ai._this)&&(A._cycle!=E))A._Done(
D.Ai._this=null);if((A=D.FY[0]._this)&&(A._cycle!=E))A._Done(D.FY[0]._this=null);
};return D;})();

/* Embedded Wizard */