/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.uk)throw new Error("The unit file 'FlatWidgets.js' included twice!"
);EmWiApp.uk=(function(){var A=EmWiApp;var E={};

E.CT=0xFF00BF7F;E.P={_Init:function(){A.uj.Fv._Init.call(this,0);this.JM(60);this.
IU(E.CT);this.IV(E.CT);this.IT(0x9);this.IW(A.s$(E.Gm));this.JL(7);this.JK(5);this.
IQ(E.CT);this.IR(E.CT);this.IP(0xC);this.IS(A.s$(A.ul.EZ));this.Eb(2);},_variants:
function(){return this;},_this:null};E.Gm={_class:function(){return A.ul.AB;},0:{
Data:function(){return A.uu;},Cache:[],_this:null}};E.A0={_Init:function(){A.uj.
Fv._Init.call(this,0);this.IU(E.CT);this.IV(E.CT);this.IT(0x22);this.IW(A.s$(A.ul.
Gn));this.IQ(E.CT);this.IR(E.CT);this.IP(0xA);this.IS(A.s$(A.ul.EZ));},_variants:
function(){return this;},_this:null};
E._Init=function(){};E.Au=function(D){var B;if((B=E.P._this)&&(B._cycle!=D))B._Done(
E.P._this=null);if((B=E.Gm[0]._this)&&(B._cycle!=D))B._Done(E.Gm[0]._this=null);
if((B=E.A0._this)&&(B._cycle!=D))B._Done(E.A0._this=null);};return E;})();

/* Embedded Wizard */