/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.ia)throw new Error("The unit file 'Application.js' included twice!"
);EmWiApp.ia=(function(){var B=EmWiApp;var D={};
var Ac="init...";var Ax=[0,0,1024,768];var BV=[20,30,150,90];var CP="LOT-ID";var Eb=
"SK0012";var FO=[160,30,290,90];var FP="RECIPE";var FQ="P2500-4.75";var FR=[300,
30,430,90];var H3="STEP";var H4=[440,30,570,90];var H5="JOB TIME";var H6=[580,30
,710,90];var H7="EVENT TIME";var H8=[720,30,850,90];var H9="HOLD TIME";var H_=[860
,30,990,90];var H$="TOTAL TIME";var Ia=[40,140,210,200];var Ib="SV 1";var Ic=[40
,190,210,250];var Id="SV 2";var Ie=[40,240,210,300];var If="SV 3";var Ig=[40,290
,210,350];var Ih="SV 4";var Ii=[240,140,410,200];var Ij="FFC 1";var Ik=[240,190,
410,250];var Il="FFC 2";var Im=[240,240,410,300];var In="FFC 3";var Io=[240,290,
410,350];var Ip="FFC 4";var Iq=[430,140,600,200];var Ir="DDC 1";var Is=[430,190,
600,250];var It="DDC 2";var Iu=[430,240,600,300];var Iv="DDC 3";var Iw=[430,290,
600,350];var Ix="DDC 4";var Iy="Unit";var Iz="Name";var G6=[0,0,170,70];var IA=[
4,1,170,20];var IB=[0,10,170,70];
D.Fg={AM:null,Cc:null,Co:null,Cp:null,Cq:null,Cr:null,Cs:null,T:null,BK:null,BN:null
,BO:null,BP:null,BQ:null,BR:null,BS:null,BT:null,BU:null,BL:null,BM:null,A5:function(
aArg){B.uf("%s",Ac);B._GetAutoObject(B.Device.Device).EP();},_Init:function(aArg
){B.Core.Root._Init.call(this,aArg);D.AM._Init.call(this.AM={P:this},0);D.AM._Init.
call(this.Cc={P:this},0);D.AM._Init.call(this.Co={P:this},0);D.AM._Init.call(this.
Cp={P:this},0);D.AM._Init.call(this.Cq={P:this},0);D.AM._Init.call(this.Cr={P:this
},0);D.AM._Init.call(this.Cs={P:this},0);B.ui.T._Init.call(this.T={P:this},0);B.
ui.T._Init.call(this.BK={P:this},0);B.ui.T._Init.call(this.BN={P:this},0);B.ui.T.
_Init.call(this.BO={P:this},0);B.ui.T._Init.call(this.BP={P:this},0);B.ui.T._Init.
call(this.BQ={P:this},0);B.ui.T._Init.call(this.BR={P:this},0);B.ui.T._Init.call(
this.BS={P:this},0);B.ui.T._Init.call(this.BT={P:this},0);B.ui.T._Init.call(this.
BU={P:this},0);B.ui.T._Init.call(this.BL={P:this},0);B.ui.T._Init.call(this.BM={
P:this},0);this.__proto__=D.Fg;var A;this.S(Ax);this.AM.S(BV);this.AM.CM(CP);this.
AM.Fz(Eb);this.Cc.S(FO);this.Cc.CM(FP);this.Cc.Fz(FQ);this.Co.S(FR);this.Co.CM(H3
);this.Cp.S(H4);this.Cp.CM(H5);this.Cq.S(H6);this.Cq.CM(H7);this.Cr.S(H8);this.Cr.
CM(H9);this.Cs.S(H_);this.Cs.CM(H$);this.T.S(Ia);this.T.Bq(Ib);this.T.Bp(1);this.
BK.S(Ic);this.BK.Bq(Id);this.BK.Bp(1);this.BN.S(Ie);this.BN.Bq(If);this.BN.Bp(1);
this.BO.S(Ig);this.BO.Bq(Ih);this.BO.Bp(1);this.BP.S(Ii);this.BP.Bq(Ij);this.BP.
Bp(1);this.BQ.S(Ik);this.BQ.Bq(Il);this.BQ.Bp(1);this.BR.S(Im);this.BR.Bq(In);this.
BR.Bp(1);this.BS.S(Io);this.BS.Bq(Ip);this.BS.Bp(1);this.BT.S(Iq);this.BT.Bq(Ir);
this.BT.Bp(1);this.BU.S(Is);this.BU.Bq(It);this.BU.Bp(1);this.BL.S(Iu);this.BL.Bq(
Iv);this.BL.Bp(1);this.BM.S(Iw);this.BM.Bq(Ix);this.BM.Bp(1);this.Av(this.AM,0);
this.Av(this.Cc,0);this.Av(this.Co,0);this.Av(this.Cp,0);this.Av(this.Cq,0);this.
Av(this.Cr,0);this.Av(this.Cs,0);this.Av(this.T,0);this.Av(this.BK,0);this.Av(this.
BN,0);this.Av(this.BO,0);this.Av(this.BP,0);this.Av(this.BQ,0);this.Av(this.BR,0
);this.Av(this.BS,0);this.Av(this.BT,0);this.Av(this.BU,0);this.Av(this.BL,0);this.
Av(this.BM,0);this.AM.AG([A=B._GetAutoObject(B.Device.Device),A.GT,A.DR]);this.Cc.
AG([A=B._GetAutoObject(B.Device.Device),A.GU,A.DS]);this.Co.AG([A=B._GetAutoObject(
B.Device.Device),A.GV,A.DT]);this.Cp.AG([A=B._GetAutoObject(B.Device.Device),A.GS
,A.DQ]);this.Cq.AG([A=B._GetAutoObject(B.Device.Device),A.GM,A.DK]);this.Cr.AG([
A=B._GetAutoObject(B.Device.Device),A.GR,A.DP]);this.Cs.AG([A=B._GetAutoObject(B.
Device.Device),A.G0,A.DY]);this.T.AG([A=B._GetAutoObject(B.Device.Device),A.GW,A.
DU]);this.T.Bo(B._GetAutoObject(B.uj.T));this.BK.AG([A=B._GetAutoObject(B.Device.
Device),A.GX,A.DV]);this.BK.Bo(B._GetAutoObject(B.uj.T));this.BN.AG([A=B._GetAutoObject(
B.Device.Device),A.GY,A.DW]);this.BN.Bo(B._GetAutoObject(B.uj.T));this.BO.AG([A=
B._GetAutoObject(B.Device.Device),A.GZ,A.DX]);this.BO.Bo(B._GetAutoObject(B.uj.T
));this.BP.AG([A=B._GetAutoObject(B.Device.Device),A.GN,A.DL]);this.BP.Bo(B._GetAutoObject(
B.uj.T));this.BQ.AG([A=B._GetAutoObject(B.Device.Device),A.GO,A.DM]);this.BQ.Bo(
B._GetAutoObject(B.uj.T));this.BR.AG([A=B._GetAutoObject(B.Device.Device),A.GP,A.
DN]);this.BR.Bo(B._GetAutoObject(B.uj.T));this.BS.AG([A=B._GetAutoObject(B.Device.
Device),A.GQ,A.DO]);this.BS.Bo(B._GetAutoObject(B.uj.T));this.BT.AG([A=B._GetAutoObject(
B.Device.Device),A.GI,A.DG]);this.BT.Bo(B._GetAutoObject(B.uj.T));this.BU.AG([A=
B._GetAutoObject(B.Device.Device),A.GJ,A.DH]);this.BU.Bo(B._GetAutoObject(B.uj.T
));this.BL.AG([A=B._GetAutoObject(B.Device.Device),A.GK,A.DI]);this.BL.Bo(B._GetAutoObject(
B.uj.T));this.BM.AG([A=B._GetAutoObject(B.Device.Device),A.GL,A.DJ]);this.BM.Bo(
B._GetAutoObject(B.uj.T));this.A5(aArg);},_Done:function(){this.__proto__=B.Core.
Root;this.AM._Done();this.Cc._Done();this.Co._Done();this.Cp._Done();this.Cq._Done(
);this.Cr._Done();this.Cs._Done();this.T._Done();this.BK._Done();this.BN._Done();
this.BO._Done();this.BP._Done();this.BQ._Done();this.BR._Done();this.BS._Done();
this.BT._Done();this.BU._Done();this.BL._Done();this.BM._Done();B.Core.Root._Done.
call(this);},_ReInit:function(){B.Core.Root._ReInit.call(this);this.AM._ReInit();
this.Cc._ReInit();this.Co._ReInit();this.Cp._ReInit();this.Cq._ReInit();this.Cr.
_ReInit();this.Cs._ReInit();this.T._ReInit();this.BK._ReInit();this.BN._ReInit();
this.BO._ReInit();this.BP._ReInit();this.BQ._ReInit();this.BR._ReInit();this.BS.
_ReInit();this.BT._ReInit();this.BU._ReInit();this.BL._ReInit();this.BM._ReInit(
);},_Mark:function(E){var A;B.Core.Root._Mark.call(this,E);if((A=this.AM)._cycle
!=E)A._Mark(A._cycle=E);if((A=this.Cc)._cycle!=E)A._Mark(A._cycle=E);if((A=this.
Co)._cycle!=E)A._Mark(A._cycle=E);if((A=this.Cp)._cycle!=E)A._Mark(A._cycle=E);if((
A=this.Cq)._cycle!=E)A._Mark(A._cycle=E);if((A=this.Cr)._cycle!=E)A._Mark(A._cycle=
E);if((A=this.Cs)._cycle!=E)A._Mark(A._cycle=E);if((A=this.T)._cycle!=E)A._Mark(
A._cycle=E);if((A=this.BK)._cycle!=E)A._Mark(A._cycle=E);if((A=this.BN)._cycle!=
E)A._Mark(A._cycle=E);if((A=this.BO)._cycle!=E)A._Mark(A._cycle=E);if((A=this.BP
)._cycle!=E)A._Mark(A._cycle=E);if((A=this.BQ)._cycle!=E)A._Mark(A._cycle=E);if((
A=this.BR)._cycle!=E)A._Mark(A._cycle=E);if((A=this.BS)._cycle!=E)A._Mark(A._cycle=
E);if((A=this.BT)._cycle!=E)A._Mark(A._cycle=E);if((A=this.BU)._cycle!=E)A._Mark(
A._cycle=E);if((A=this.BL)._cycle!=E)A._Mark(A._cycle=E);if((A=this.BM)._cycle!=
E)A._Mark(A._cycle=E);},_className:"Application::Application"};D.AM={A6:null,BA:
null,BH:null,By:null,Gb:Iy,Gc:Iz,EO:function(aSize){B.Core.Ab.EO.call(this,aSize
);},D$:function(EU){B.Core.Ab.D$.call(this,EU);},CM:function(C){if(this.Gb===C)return;
this.Gb=C;this.BH.Dc(this.Gb);},Fz:function(C){if(this.Gc===C)return;this.Gc=C;this.
By.Dc(this.Gc);},AG:function(C){if(B.tn(this.A6,C))return;if(!!this.A6)B.sO([this
,this.C2],this.A6,0);this.A6=C;if(!!C)B.sB([this,this.C2],C,0);if(!!C)B.lq([this
,this.C2],this);},C2:function(B9){var A;if(!!this.A6)this.Fz((A=this.A6,A[1].call(
A[0])));},_Init:function(aArg){B.Core.Ab._Init.call(this,aArg);B.um.BA._Init.call(
this.BA={P:this},0);B.um.Text._Init.call(this.BH={P:this},0);B.um.Text._Init.call(
this.By={P:this},0);this.__proto__=D.AM;this.BA.EK(0x3F);this.BA.S(G6);this.S(G6
);this.BH.S(IA);this.BH.EH(0x11);this.BH.Dc(CP);this.BH.EI(0xFF636363);this.By.EK(
0x3F);this.By.S(IB);this.By.EH(0x12);this.By.Dc(CP);this.By.EI(0xFF636363);this.
Av(this.BA,0);this.Av(this.BH,0);this.Av(this.By,0);this.BH.EJ(B.s$(B.un.Fv));this.
By.EJ(B.s$(B.un.Fu));},_Done:function(){this.__proto__=B.Core.Ab;this.BA._Done();
this.BH._Done();this.By._Done();B.Core.Ab._Done.call(this);},_ReInit:function(){
B.Core.Ab._ReInit.call(this);this.BA._ReInit();this.BH._ReInit();this.By._ReInit(
);},_Mark:function(E){var A;B.Core.Ab._Mark.call(this,E);if((A=this.A6)&&((A=A[0
])._cycle!=E))A._Mark(A._cycle=E);if((A=this.BA)._cycle!=E)A._Mark(A._cycle=E);if((
A=this.BH)._cycle!=E)A._Mark(A._cycle=E);if((A=this.By)._cycle!=E)A._Mark(A._cycle=
E);},_className:"Application::StringRectDataBox"};
D._Init=function(){D.Fg.__proto__=B.Core.Root;D.AM.__proto__=B.Core.Ab;};D.Am=function(
E){};return D;})();

/* Embedded Wizard */