/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.ia)throw new Error("The unit file 'Application.js' included twice!"
);EmWiApp.ia=(function(){var A=EmWiApp;var E={};
var Ac="init...";var At="get data...";var Cr=[0,0,1200,768];var Fn=[20,30,320,90];
var C6="LOT-ID";var Hl="SK0012";var Hm=[340,30,470,90];var Hn="RECIPE";var Ho="P2500-4.75";
var Hp=[480,30,610,90];var J0="STEP";var J1=[620,30,750,90];var J2="JOB TIME";var
J3=[760,30,890,90];var J4="EVENT TIME";var J5=[900,30,1030,90];var J6="HOLD TIME";
var J7=[1040,30,1170,90];var J8="TOTAL TIME";var J9=[20,152,290,202];var J_="SV 1";
var J$=[20,202,290,252];var Ka="SV 2";var Kb=[20,252,290,302];var Kc="SV 3";var Kd=[
20,302,290,352];var Ke="SV 4";var Kf=[220,152,490,202];var Kg="FFC 1";var Kh=[220
,202,490,252];var Ki="FFC 2";var Kj=[220,252,490,302];var Kk="FFC 3";var Kl=[220
,302,490,352];var Km="FFC 4";var Kn=[420,152,690,202];var Ko="DDC 1";var Kp=[420
,202,690,252];var Kq="DDC 2";var Kr=[420,252,690,302];var Ks="DDC 3";var Kt=[420
,302,690,352];var Ku="DDC 4";var Kv=[630,162,1170,340];var Kw=[30,420,170,490];var
Kx="GAS 1";var Ky=[170,420,310,490];var Kz="GAS 2";var KA=[310,420,450,490];var KB=
"GAS 3";var KC=[450,420,590,490];var KD="GAS 4";var KE=[590,420,730,490];var KF=
"GAS 5";var KG=[730,420,870,490];var KH="GAS 6";var KI=[870,420,1010,490];var KJ=
"GAS 7";var KK=[1010,420,1150,490];var KL="GAS 8";var KM=[30,490,170,540];var KN=[
170,490,310,540];var KO=[310,490,450,540];var KP=[450,490,590,540];var KQ=[590,490
,730,540];var KR=[730,490,870,540];var KS=[870,490,1010,540];var KT=[1010,490,1150
,540];var KU=[30,550,1170,730];var KV="Unit";var KW="Name";var I3=[0,0,170,70];var
KX=[4,1,170,20];var KY=[0,10,170,70];
E.GN={AV:null,CI:null,C1:null,C2:null,C3:null,C4:null,C5:null,Timer:null,Bm:null,
BZ:null,B0:null,B1:null,BJ:null,B2:null,B3:null,BV:null,BI:null,BW:null,BX:null,
BY:null,AM:null,Bq:null,Q:null,Cc:null,Ci:null,Cd:null,Ce:null,Cf:null,Cg:null,Ch:
null,Cj:null,Ck:null,Cl:null,Cm:null,Cn:null,Co:null,Cp:null,Cq:null,CY:null,AL:
null,Be:function(aArg){A.uf("%s",Ac);A._GetAutoObject(A.Device.Device).Gi();},JO:
function(B_){A.uf("%s",At);A._GetAutoObject(A.Device.Device).Gh();this.JW();},JW:
function(){this.AM.H1();this.AM.Al(A._GetAutoObject(A.Device.Device).EI,A.ui.Ff);
this.AM.Al(A._GetAutoObject(A.Device.Device).EJ,A.ui.Fg);this.AM.Al(A._GetAutoObject(
A.Device.Device).EK,A.ui.Fh);this.AM.Al(A._GetAutoObject(A.Device.Device).EL,A.ui.
Fi);this.AM.Al(A._GetAutoObject(A.Device.Device).DQ,A.ui.Ff);this.AM.Al(A._GetAutoObject(
A.Device.Device).CG,A.ui.Fg);this.AM.Al(A._GetAutoObject(A.Device.Device).G7(),A.
ui.Fh);this.AM.Al(A._GetAutoObject(A.Device.Device).DR,A.ui.Fi);this.AM.Al(A._GetAutoObject(
A.Device.Device).DN,A.ui.Ff);this.AM.Al(A._GetAutoObject(A.Device.Device).CF,A.ui.
Fg);this.AM.Al(A._GetAutoObject(A.Device.Device).G6(),A.ui.Fh);this.AM.Al(A._GetAutoObject(
A.Device.Device).DO,A.ui.Fi);this.Bq.IN(this.AM);this.AL.H1();this.AL.Al(A._GetAutoObject(
A.Device.Device).Dp,A.ui.Ff);this.AL.Al(A._GetAutoObject(A.Device.Device).D0,A.ui.
Fg);this.AL.Al(A._GetAutoObject(A.Device.Device).D1,A.ui.Fh);this.AL.Al(A._GetAutoObject(
A.Device.Device).D2,A.ui.Fi);this.AL.Al(A._GetAutoObject(A.Device.Device).D3,A.ui.
IY);this.AL.Al(A._GetAutoObject(A.Device.Device).D4,A.ui.IZ);this.AL.Al(A._GetAutoObject(
A.Device.Device).D5,A.ui.I0);this.AL.Al(A._GetAutoObject(A.Device.Device).G8(),A.
ui.I1);this.AL.Al(A._GetAutoObject(A.Device.Device).DS,A.ui.Ff);this.AL.Al(A._GetAutoObject(
A.Device.Device).DT,A.ui.Fg);this.AL.Al(A._GetAutoObject(A.Device.Device).DU,A.ui.
Fh);this.AL.Al(A._GetAutoObject(A.Device.Device).DV,A.ui.Fi);this.AL.Al(A._GetAutoObject(
A.Device.Device).DW,A.ui.IY);this.AL.Al(A._GetAutoObject(A.Device.Device).DX,A.ui.
IZ);this.AL.Al(A._GetAutoObject(A.Device.Device).DY,A.ui.I0);this.AL.Al(A._GetAutoObject(
A.Device.Device).DZ,A.ui.I1);this.CY.IN(this.AL);},_Init:function(aArg){A.Core.Root.
_Init.call(this,aArg);E.AV._Init.call(this.AV={M:this},0);E.AV._Init.call(this.CI={
M:this},0);E.AV._Init.call(this.C1={M:this},0);E.AV._Init.call(this.C2={M:this},
0);E.AV._Init.call(this.C3={M:this},0);E.AV._Init.call(this.C4={M:this},0);E.AV.
_Init.call(this.C5={M:this},0);A.Core.Timer._Init.call(this.Timer={M:this},0);A.
uj.Q._Init.call(this.Bm={M:this},0);A.uj.Q._Init.call(this.BZ={M:this},0);A.uj.Q.
_Init.call(this.B0={M:this},0);A.uj.Q._Init.call(this.B1={M:this},0);A.uj.Q._Init.
call(this.BJ={M:this},0);A.uj.Q._Init.call(this.B2={M:this},0);A.uj.Q._Init.call(
this.B3={M:this},0);A.uj.Q._Init.call(this.BV={M:this},0);A.uj.Q._Init.call(this.
BI={M:this},0);A.uj.Q._Init.call(this.BW={M:this},0);A.uj.Q._Init.call(this.BX={
M:this},0);A.uj.Q._Init.call(this.BY={M:this},0);A.uo.AM._Init.call(this.AM={M:this
},0);A.uo.Bq._Init.call(this.Bq={M:this},0);A.uj.Q._Init.call(this.Q={M:this},0);
A.uj.Q._Init.call(this.Cc={M:this},0);A.uj.Q._Init.call(this.Ci={M:this},0);A.uj.
Q._Init.call(this.Cd={M:this},0);A.uj.Q._Init.call(this.Ce={M:this},0);A.uj.Q._Init.
call(this.Cf={M:this},0);A.uj.Q._Init.call(this.Cg={M:this},0);A.uj.Q._Init.call(
this.Ch={M:this},0);A.uj.Q._Init.call(this.Cj={M:this},0);A.uj.Q._Init.call(this.
Ck={M:this},0);A.uj.Q._Init.call(this.Cl={M:this},0);A.uj.Q._Init.call(this.Cm={
M:this},0);A.uj.Q._Init.call(this.Cn={M:this},0);A.uj.Q._Init.call(this.Co={M:this
},0);A.uj.Q._Init.call(this.Cp={M:this},0);A.uj.Q._Init.call(this.Cq={M:this},0);
A.uo.Bq._Init.call(this.CY={M:this},0);A.uo.AM._Init.call(this.AL={M:this},0);this.
__proto__=E.GN;var B;this.O(Cr);this.AV.O(Fn);this.AV.Ds(C6);this.AV.G_(Hl);this.
CI.O(Hm);this.CI.Ds(Hn);this.CI.G_(Ho);this.C1.O(Hp);this.C1.Ds(J0);this.C2.O(J1
);this.C2.Ds(J2);this.C3.O(J3);this.C3.Ds(J4);this.C4.O(J5);this.C4.Ds(J6);this.
C5.O(J7);this.C5.Ds(J8);this.Timer.F_(true);this.Bm.JI(0);this.Bm.O(J9);this.Bm.
Ao(J_);this.Bm.An(1);this.Bm.JF(0.000000);this.Bm.BE(0.100000);this.Bm.F0(8000);
this.BZ.O(J$);this.BZ.Ao(Ka);this.BZ.An(1);this.BZ.BE(0.100000);this.B0.O(Kb);this.
B0.Ao(Kc);this.B0.An(1);this.B0.BE(0.100000);this.B1.O(Kd);this.B1.Ao(Ke);this.B1.
An(1);this.B1.BE(0.100000);this.BJ.O(Kf);this.BJ.Ao(Kg);this.BJ.An(1);this.BJ.BE(
0.100000);this.BJ.F0(8000);this.B2.O(Kh);this.B2.Ao(Ki);this.B2.An(1);this.B2.BE(
0.100000);this.B3.O(Kj);this.B3.Ao(Kk);this.B3.An(1);this.B3.BE(0.100000);this.BV.
O(Kl);this.BV.Ao(Km);this.BV.An(1);this.BV.BE(0.100000);this.BI.O(Kn);this.BI.Ao(
Ko);this.BI.An(1);this.BI.BE(0.100000);this.BI.F0(8000);this.BW.O(Kp);this.BW.Ao(
Kq);this.BW.An(1);this.BW.BE(0.100000);this.BX.O(Kr);this.BX.Ao(Ks);this.BX.An(1
);this.BX.BE(0.100000);this.BY.O(Kt);this.BY.Ao(Ku);this.BY.An(1);this.BY.BE(0.100000
);this.Bq.O(Kv);this.Bq.IM(10000);this.Q.O(Kw);this.Q.Ao(Kx);this.Q.An(1);this.Cc.
O(Ky);this.Cc.Ao(Kz);this.Cc.An(1);this.Ci.O(KA);this.Ci.Ao(KB);this.Ci.An(1);this.
Cd.O(KC);this.Cd.Ao(KD);this.Cd.An(1);this.Ce.O(KE);this.Ce.Ao(KF);this.Ce.An(1);
this.Cf.O(KG);this.Cf.Ao(KH);this.Cf.An(1);this.Cg.O(KI);this.Cg.Ao(KJ);this.Cg.
An(1);this.Ch.O(KK);this.Ch.Ao(KL);this.Ch.An(1);this.Cj.O(KM);this.Cj.Ao(A.hm);
this.Cj.An(1);this.Ck.O(KN);this.Ck.Ao(A.hm);this.Ck.An(1);this.Cl.O(KO);this.Cl.
Ao(A.hm);this.Cl.An(1);this.Cm.O(KP);this.Cm.Ao(A.hm);this.Cm.An(1);this.Cn.O(KQ
);this.Cn.Ao(A.hm);this.Cn.An(1);this.Co.O(KR);this.Co.Ao(A.hm);this.Co.An(1);this.
Cp.O(KS);this.Cp.Ao(A.hm);this.Cp.An(1);this.Cq.O(KT);this.Cq.Ao(A.hm);this.Cq.An(
1);this.CY.O(KU);this.CY.IM(10000);this.V(this.AV,0);this.V(this.CI,0);this.V(this.
C1,0);this.V(this.C2,0);this.V(this.C3,0);this.V(this.C4,0);this.V(this.C5,0);this.
V(this.Bm,0);this.V(this.BZ,0);this.V(this.B0,0);this.V(this.B1,0);this.V(this.BJ
,0);this.V(this.B2,0);this.V(this.B3,0);this.V(this.BV,0);this.V(this.BI,0);this.
V(this.BW,0);this.V(this.BX,0);this.V(this.BY,0);this.V(this.Bq,0);this.V(this.Q
,0);this.V(this.Cc,0);this.V(this.Ci,0);this.V(this.Cd,0);this.V(this.Ce,0);this.
V(this.Cf,0);this.V(this.Cg,0);this.V(this.Ch,0);this.V(this.Cj,0);this.V(this.Ck
,0);this.V(this.Cl,0);this.V(this.Cm,0);this.V(this.Cn,0);this.V(this.Co,0);this.
V(this.Cp,0);this.V(this.Cq,0);this.V(this.CY,0);this.AV.Aa([B=A._GetAutoObject(
A.Device.Device),B.IB,B.Ex]);this.CI.Aa([B=A._GetAutoObject(A.Device.Device),B.IC
,B.Ey]);this.C1.Aa([B=A._GetAutoObject(A.Device.Device),B.ID,B.Ez]);this.C2.Aa([
B=A._GetAutoObject(A.Device.Device),B.IA,B.Ew]);this.C3.Aa([B=A._GetAutoObject(A.
Device.Device),B.Ig,B.D$]);this.C4.Aa([B=A._GetAutoObject(A.Device.Device),B.Iz,
B.Ev]);this.C5.Aa([B=A._GetAutoObject(A.Device.Device),B.II,B.EF]);this.Timer.Gb=[
this,this.JO];this.Bm.Aa([B=A._GetAutoObject(A.Device.Device),B.IE,B.EB]);this.Bm.
Am(A._GetAutoObject(A.uk.Q));this.BZ.Aa([B=A._GetAutoObject(A.Device.Device),B.IF
,B.EC]);this.BZ.Am(A._GetAutoObject(A.uk.Q));this.B0.Aa([B=A._GetAutoObject(A.Device.
Device),B.IG,B.ED]);this.B0.Am(A._GetAutoObject(A.uk.Q));this.B1.Aa([B=A._GetAutoObject(
A.Device.Device),B.IH,B.EE]);this.B1.Am(A._GetAutoObject(A.uk.Q));this.BJ.Aa([B=
A._GetAutoObject(A.Device.Device),B.Ih,B.Ea]);this.BJ.Am(A._GetAutoObject(A.uk.Q
));this.B2.Aa([B=A._GetAutoObject(A.Device.Device),B.Ii,B.Eb]);this.B2.Am(A._GetAutoObject(
A.uk.Q));this.B3.Aa([B=A._GetAutoObject(A.Device.Device),B.G7,B.Ec]);this.B3.Am(
A._GetAutoObject(A.uk.Q));this.BV.Aa([B=A._GetAutoObject(A.Device.Device),B.Ij,B.
Ed]);this.BV.Am(A._GetAutoObject(A.uk.Q));this.BI.Aa([B=A._GetAutoObject(A.Device.
Device),B.Id,B.D7]);this.BI.Am(A._GetAutoObject(A.uk.Q));this.BW.Aa([B=A._GetAutoObject(
A.Device.Device),B.Ie,B.D8]);this.BW.Am(A._GetAutoObject(A.uk.Q));this.BX.Aa([B=
A._GetAutoObject(A.Device.Device),B.G6,B.D9]);this.BX.Am(A._GetAutoObject(A.uk.Q
));this.BY.Aa([B=A._GetAutoObject(A.Device.Device),B.If,B.D_]);this.BY.Am(A._GetAutoObject(
A.uk.Q));this.Q.Aa([B=A._GetAutoObject(A.Device.Device),B.Is,B.En]);this.Q.Am(A.
_GetAutoObject(A.uk.AZ));this.Cc.Aa([B=A._GetAutoObject(A.Device.Device),B.It,B.
Eo]);this.Cc.Am(A._GetAutoObject(A.uk.AZ));this.Ci.Aa([B=A._GetAutoObject(A.Device.
Device),B.Iu,B.Ep]);this.Ci.Am(A._GetAutoObject(A.uk.AZ));this.Cd.Aa([B=A._GetAutoObject(
A.Device.Device),B.Iv,B.Eq]);this.Cd.Am(A._GetAutoObject(A.uk.AZ));this.Ce.Aa([B=
A._GetAutoObject(A.Device.Device),B.Iw,B.Er]);this.Ce.Am(A._GetAutoObject(A.uk.AZ
));this.Cf.Aa([B=A._GetAutoObject(A.Device.Device),B.Ix,B.Es]);this.Cf.Am(A._GetAutoObject(
A.uk.AZ));this.Cg.Aa([B=A._GetAutoObject(A.Device.Device),B.Iy,B.Et]);this.Cg.Am(
A._GetAutoObject(A.uk.AZ));this.Ch.Aa([B=A._GetAutoObject(A.Device.Device),B.G8,
B.Eu]);this.Ch.Am(A._GetAutoObject(A.uk.AZ));this.Cj.Aa([B=A._GetAutoObject(A.Device.
Device),B.Ik,B.Ef]);this.Cj.Am(A._GetAutoObject(A.uk.AZ));this.Ck.Aa([B=A._GetAutoObject(
A.Device.Device),B.Il,B.Eg]);this.Ck.Am(A._GetAutoObject(A.uk.AZ));this.Cl.Aa([B=
A._GetAutoObject(A.Device.Device),B.Im,B.Eh]);this.Cl.Am(A._GetAutoObject(A.uk.AZ
));this.Cm.Aa([B=A._GetAutoObject(A.Device.Device),B.In,B.Ei]);this.Cm.Am(A._GetAutoObject(
A.uk.AZ));this.Cn.Aa([B=A._GetAutoObject(A.Device.Device),B.Io,B.Ej]);this.Cn.Am(
A._GetAutoObject(A.uk.AZ));this.Co.Aa([B=A._GetAutoObject(A.Device.Device),B.Ip,
B.Ek]);this.Co.Am(A._GetAutoObject(A.uk.AZ));this.Cp.Aa([B=A._GetAutoObject(A.Device.
Device),B.Iq,B.El]);this.Cp.Am(A._GetAutoObject(A.uk.AZ));this.Cq.Aa([B=A._GetAutoObject(
A.Device.Device),B.Ir,B.Em]);this.Cq.Am(A._GetAutoObject(A.uk.AZ));this.Be(aArg);
},_Done:function(){this.__proto__=A.Core.Root;this.AV._Done();this.CI._Done();this.
C1._Done();this.C2._Done();this.C3._Done();this.C4._Done();this.C5._Done();this.
Timer._Done();this.Bm._Done();this.BZ._Done();this.B0._Done();this.B1._Done();this.
BJ._Done();this.B2._Done();this.B3._Done();this.BV._Done();this.BI._Done();this.
BW._Done();this.BX._Done();this.BY._Done();this.AM._Done();this.Bq._Done();this.
Q._Done();this.Cc._Done();this.Ci._Done();this.Cd._Done();this.Ce._Done();this.Cf.
_Done();this.Cg._Done();this.Ch._Done();this.Cj._Done();this.Ck._Done();this.Cl.
_Done();this.Cm._Done();this.Cn._Done();this.Co._Done();this.Cp._Done();this.Cq.
_Done();this.CY._Done();this.AL._Done();A.Core.Root._Done.call(this);},_ReInit:function(
){A.Core.Root._ReInit.call(this);this.AV._ReInit();this.CI._ReInit();this.C1._ReInit(
);this.C2._ReInit();this.C3._ReInit();this.C4._ReInit();this.C5._ReInit();this.Timer.
_ReInit();this.Bm._ReInit();this.BZ._ReInit();this.B0._ReInit();this.B1._ReInit(
);this.BJ._ReInit();this.B2._ReInit();this.B3._ReInit();this.BV._ReInit();this.BI.
_ReInit();this.BW._ReInit();this.BX._ReInit();this.BY._ReInit();this.AM._ReInit(
);this.Bq._ReInit();this.Q._ReInit();this.Cc._ReInit();this.Ci._ReInit();this.Cd.
_ReInit();this.Ce._ReInit();this.Cf._ReInit();this.Cg._ReInit();this.Ch._ReInit(
);this.Cj._ReInit();this.Ck._ReInit();this.Cl._ReInit();this.Cm._ReInit();this.Cn.
_ReInit();this.Co._ReInit();this.Cp._ReInit();this.Cq._ReInit();this.CY._ReInit(
);this.AL._ReInit();},_Mark:function(D){var B;A.Core.Root._Mark.call(this,D);if((
B=this.AV)._cycle!=D)B._Mark(B._cycle=D);if((B=this.CI)._cycle!=D)B._Mark(B._cycle=
D);if((B=this.C1)._cycle!=D)B._Mark(B._cycle=D);if((B=this.C2)._cycle!=D)B._Mark(
B._cycle=D);if((B=this.C3)._cycle!=D)B._Mark(B._cycle=D);if((B=this.C4)._cycle!=
D)B._Mark(B._cycle=D);if((B=this.C5)._cycle!=D)B._Mark(B._cycle=D);if((B=this.Timer
)._cycle!=D)B._Mark(B._cycle=D);if((B=this.Bm)._cycle!=D)B._Mark(B._cycle=D);if((
B=this.BZ)._cycle!=D)B._Mark(B._cycle=D);if((B=this.B0)._cycle!=D)B._Mark(B._cycle=
D);if((B=this.B1)._cycle!=D)B._Mark(B._cycle=D);if((B=this.BJ)._cycle!=D)B._Mark(
B._cycle=D);if((B=this.B2)._cycle!=D)B._Mark(B._cycle=D);if((B=this.B3)._cycle!=
D)B._Mark(B._cycle=D);if((B=this.BV)._cycle!=D)B._Mark(B._cycle=D);if((B=this.BI
)._cycle!=D)B._Mark(B._cycle=D);if((B=this.BW)._cycle!=D)B._Mark(B._cycle=D);if((
B=this.BX)._cycle!=D)B._Mark(B._cycle=D);if((B=this.BY)._cycle!=D)B._Mark(B._cycle=
D);if((B=this.AM)._cycle!=D)B._Mark(B._cycle=D);if((B=this.Bq)._cycle!=D)B._Mark(
B._cycle=D);if((B=this.Q)._cycle!=D)B._Mark(B._cycle=D);if((B=this.Cc)._cycle!=D
)B._Mark(B._cycle=D);if((B=this.Ci)._cycle!=D)B._Mark(B._cycle=D);if((B=this.Cd).
_cycle!=D)B._Mark(B._cycle=D);if((B=this.Ce)._cycle!=D)B._Mark(B._cycle=D);if((B=
this.Cf)._cycle!=D)B._Mark(B._cycle=D);if((B=this.Cg)._cycle!=D)B._Mark(B._cycle=
D);if((B=this.Ch)._cycle!=D)B._Mark(B._cycle=D);if((B=this.Cj)._cycle!=D)B._Mark(
B._cycle=D);if((B=this.Ck)._cycle!=D)B._Mark(B._cycle=D);if((B=this.Cl)._cycle!=
D)B._Mark(B._cycle=D);if((B=this.Cm)._cycle!=D)B._Mark(B._cycle=D);if((B=this.Cn
)._cycle!=D)B._Mark(B._cycle=D);if((B=this.Co)._cycle!=D)B._Mark(B._cycle=D);if((
B=this.Cp)._cycle!=D)B._Mark(B._cycle=D);if((B=this.Cq)._cycle!=D)B._Mark(B._cycle=
D);if((B=this.CY)._cycle!=D)B._Mark(B._cycle=D);if((B=this.AL)._cycle!=D)B._Mark(
B._cycle=D);},_className:"Application::Application"};E.AV={Bf:null,BG:null,B$:null
,BR:null,HD:KV,HE:KW,Gf:function(aSize){A.Core.Z.Gf.call(this,aSize);},Fl:function(
Gn){A.Core.Z.Fl.call(this,Gn);},Ds:function(C){if(this.HD===C)return;this.HD=C;this.
B$.EA(this.HD);},G_:function(C){if(this.HE===C)return;this.HE=C;this.BR.EA(this.
HE);},Aa:function(C){if(A.tn(this.Bf,C))return;if(!!this.Bf)A.sO([this,this.DH],
this.Bf,0);this.Bf=C;if(!!C)A.sB([this,this.DH],C,0);if(!!C)A.lq([this,this.DH],
this);},DH:function(B_){var B;if(!!this.Bf)this.G_((B=this.Bf,B[1].call(B[0])));
},_Init:function(aArg){A.Core.Z._Init.call(this,aArg);A.un.BG._Init.call(this.BG={
M:this},0);A.un.Text._Init.call(this.B$={M:this},0);A.un.Text._Init.call(this.BR={
M:this},0);this.__proto__=E.AV;this.BG.Fa(0x3F);this.BG.O(I3);this.O(I3);this.B$.
O(KX);this.B$.FZ(0x11);this.B$.EA(C6);this.B$.D6(0xFF636363);this.BR.Fa(0x3F);this.
BR.O(KY);this.BR.FZ(0x12);this.BR.EA(C6);this.BR.D6(0xFF636363);this.V(this.BG,0
);this.V(this.B$,0);this.V(this.BR,0);this.B$.F$(A.s$(A.ui.G3));this.BR.F$(A.s$(
A.ui.G2));},_Done:function(){this.__proto__=A.Core.Z;this.BG._Done();this.B$._Done(
);this.BR._Done();A.Core.Z._Done.call(this);},_ReInit:function(){A.Core.Z._ReInit.
call(this);this.BG._ReInit();this.B$._ReInit();this.BR._ReInit();},_Mark:function(
D){var B;A.Core.Z._Mark.call(this,D);if((B=this.Bf)&&((B=B[0])._cycle!=D))B._Mark(
B._cycle=D);if((B=this.BG)._cycle!=D)B._Mark(B._cycle=D);if((B=this.B$)._cycle!=
D)B._Mark(B._cycle=D);if((B=this.BR)._cycle!=D)B._Mark(B._cycle=D);},_className:
"Application::StringRectDataBox"};
E._Init=function(){E.GN.__proto__=A.Core.Root;E.AV.__proto__=A.Core.Z;};E.Au=function(
D){};return E;})();

/* Embedded Wizard */