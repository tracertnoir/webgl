/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.ia)throw new Error("The unit file 'Application.js' included twice!"
);EmWiApp.ia=(function(){var B=EmWiApp;var D={};
var Z="init...";var Ay="get data...";var B1=[0,0,1024,768];var Eg=[20,30,150,90];
var Cz="LOT-ID";var FW="SK0012";var FX=[160,30,290,90];var FY="RECIPE";var FZ="P2500-4.75";
var F0=[300,30,430,90];var Ib="STEP";var Ic=[440,30,570,90];var Id="JOB TIME";var
Ie=[580,30,710,90];var If="EVENT TIME";var Ig=[720,30,850,90];var Ih="HOLD TIME";
var Ii=[860,30,990,90];var Ij="TOTAL TIME";var Ik=[20,120,290,170];var Il="SV 1";
var Im=[20,170,290,220];var In="SV 2";var Io=[20,220,290,270];var Ip="SV 3";var Iq=[
20,270,290,320];var Ir="SV 4";var Is=[300,120,570,170];var It="FFC 1";var Iu=[300
,170,570,220];var Iv="FFC 2";var Iw=[300,220,570,270];var Ix="FFC 3";var Iy=[300
,270,570,320];var Iz="FFC 4";var IA=[580,120,850,170];var IB="DDC 1";var IC=[580
,170,850,220];var ID="DDC 2";var IE=[580,220,850,270];var IF="DDC 3";var IG=[580
,270,850,320];var IH="DDC 4";var II="Unit";var IJ="Name";var Hd=[0,0,170,70];var
IK=[4,1,170,20];var IL=[0,10,170,70];
D.Fo={AO:null,Cg:null,Cu:null,Cv:null,Cw:null,Cx:null,Cy:null,Timer:null,Bd:null,
BL:null,BM:null,BN:null,BO:null,BP:null,BQ:null,BG:null,BH:null,BI:null,BJ:null,
BK:null,A7:function(aArg){B.uf("%s",Z);B._GetAutoObject(B.Device.Device).EY();},
H3:function(BX){B.uf("%s",Ay);B._GetAutoObject(B.Device.Device).EX();},_Init:function(
aArg){B.Core.Root._Init.call(this,aArg);D.AO._Init.call(this.AO={P:this},0);D.AO.
_Init.call(this.Cg={P:this},0);D.AO._Init.call(this.Cu={P:this},0);D.AO._Init.call(
this.Cv={P:this},0);D.AO._Init.call(this.Cw={P:this},0);D.AO._Init.call(this.Cx={
P:this},0);D.AO._Init.call(this.Cy={P:this},0);B.Core.Timer._Init.call(this.Timer={
P:this},0);B.ui.Ai._Init.call(this.Bd={P:this},0);B.ui.Ai._Init.call(this.BL={P:
this},0);B.ui.Ai._Init.call(this.BM={P:this},0);B.ui.Ai._Init.call(this.BN={P:this
},0);B.ui.Ai._Init.call(this.BO={P:this},0);B.ui.Ai._Init.call(this.BP={P:this},
0);B.ui.Ai._Init.call(this.BQ={P:this},0);B.ui.Ai._Init.call(this.BG={P:this},0);
B.ui.Ai._Init.call(this.BH={P:this},0);B.ui.Ai._Init.call(this.BI={P:this},0);B.
ui.Ai._Init.call(this.BJ={P:this},0);B.ui.Ai._Init.call(this.BK={P:this},0);this.
__proto__=D.Fo;var A;this.U(B1);this.AO.U(Eg);this.AO.CT(Cz);this.AO.FI(FW);this.
Cg.U(FX);this.Cg.CT(FY);this.Cg.FI(FZ);this.Cu.U(F0);this.Cu.CT(Ib);this.Cv.U(Ic
);this.Cv.CT(Id);this.Cw.U(Ie);this.Cw.CT(If);this.Cx.U(Ig);this.Cx.CT(Ih);this.
Cy.U(Ii);this.Cy.CT(Ij);this.Timer.EP(true);this.Bd.HP(0);this.Bd.U(Ik);this.Bd.
Bu(Il);this.Bd.Bt(1);this.Bd.HM(0.000000);this.Bd.Bs(0.100000);this.Bd.Ha(20);this.
BL.U(Im);this.BL.Bu(In);this.BL.Bt(1);this.BL.Bs(0.100000);this.BM.U(Io);this.BM.
Bu(Ip);this.BM.Bt(1);this.BM.Bs(0.100000);this.BN.U(Iq);this.BN.Bu(Ir);this.BN.Bt(
1);this.BN.Bs(0.100000);this.BO.U(Is);this.BO.Bu(It);this.BO.Bt(1);this.BO.Bs(0.100000
);this.BP.U(Iu);this.BP.Bu(Iv);this.BP.Bt(1);this.BP.Bs(0.100000);this.BQ.U(Iw);
this.BQ.Bu(Ix);this.BQ.Bt(1);this.BQ.Bs(0.100000);this.BG.U(Iy);this.BG.Bu(Iz);this.
BG.Bt(1);this.BG.Bs(0.100000);this.BH.U(IA);this.BH.Bu(IB);this.BH.Bt(1);this.BH.
Bs(0.100000);this.BI.U(IC);this.BI.Bu(ID);this.BI.Bt(1);this.BI.Bs(0.100000);this.
BJ.U(IE);this.BJ.Bu(IF);this.BJ.Bt(1);this.BJ.Bs(0.100000);this.BK.U(IG);this.BK.
Bu(IH);this.BK.Bt(1);this.BK.Bs(0.100000);this.Aw(this.AO,0);this.Aw(this.Cg,0);
this.Aw(this.Cu,0);this.Aw(this.Cv,0);this.Aw(this.Cw,0);this.Aw(this.Cx,0);this.
Aw(this.Cy,0);this.Aw(this.Bd,0);this.Aw(this.BL,0);this.Aw(this.BM,0);this.Aw(this.
BN,0);this.Aw(this.BO,0);this.Aw(this.BP,0);this.Aw(this.BQ,0);this.Aw(this.BG,0
);this.Aw(this.BH,0);this.Aw(this.BI,0);this.Aw(this.BJ,0);this.Aw(this.BK,0);this.
AO.AH([A=B._GetAutoObject(B.Device.Device),A.G1,A.Du]);this.Cg.AH([A=B._GetAutoObject(
B.Device.Device),A.G2,A.Dv]);this.Cu.AH([A=B._GetAutoObject(B.Device.Device),A.G3
,A.Dw]);this.Cv.AH([A=B._GetAutoObject(B.Device.Device),A.G0,A.Dt]);this.Cw.AH([
A=B._GetAutoObject(B.Device.Device),A.GU,A.Dm]);this.Cx.AH([A=B._GetAutoObject(B.
Device.Device),A.GZ,A.Ds]);this.Cy.AH([A=B._GetAutoObject(B.Device.Device),A.G8,
A.DC]);this.Timer.ET=[this,this.H3];this.Bd.AH([A=B._GetAutoObject(B.Device.Device
),A.G4,A.Dy]);this.Bd.Br(B._GetAutoObject(B.uj.Ai));this.BL.AH([A=B._GetAutoObject(
B.Device.Device),A.G5,A.Dz]);this.BL.Br(B._GetAutoObject(B.uj.Ai));this.BM.AH([A=
B._GetAutoObject(B.Device.Device),A.G6,A.DA]);this.BM.Br(B._GetAutoObject(B.uj.Ai
));this.BN.AH([A=B._GetAutoObject(B.Device.Device),A.G7,A.DB]);this.BN.Br(B._GetAutoObject(
B.uj.Ai));this.BO.AH([A=B._GetAutoObject(B.Device.Device),A.GV,A.Dn]);this.BO.Br(
B._GetAutoObject(B.uj.Ai));this.BP.AH([A=B._GetAutoObject(B.Device.Device),A.GW,
A.Do]);this.BP.Br(B._GetAutoObject(B.uj.Ai));this.BQ.AH([A=B._GetAutoObject(B.Device.
Device),A.GX,A.Dp]);this.BQ.Br(B._GetAutoObject(B.uj.Ai));this.BG.AH([A=B._GetAutoObject(
B.Device.Device),A.GY,A.Dq]);this.BG.Br(B._GetAutoObject(B.uj.Ai));this.BH.AH([A=
B._GetAutoObject(B.Device.Device),A.GQ,A.Di]);this.BH.Br(B._GetAutoObject(B.uj.Ai
));this.BI.AH([A=B._GetAutoObject(B.Device.Device),A.GR,A.Dj]);this.BI.Br(B._GetAutoObject(
B.uj.Ai));this.BJ.AH([A=B._GetAutoObject(B.Device.Device),A.GS,A.Dk]);this.BJ.Br(
B._GetAutoObject(B.uj.Ai));this.BK.AH([A=B._GetAutoObject(B.Device.Device),A.GT,
A.Dl]);this.BK.Br(B._GetAutoObject(B.uj.Ai));this.A7(aArg);},_Done:function(){this.
__proto__=B.Core.Root;this.AO._Done();this.Cg._Done();this.Cu._Done();this.Cv._Done(
);this.Cw._Done();this.Cx._Done();this.Cy._Done();this.Timer._Done();this.Bd._Done(
);this.BL._Done();this.BM._Done();this.BN._Done();this.BO._Done();this.BP._Done(
);this.BQ._Done();this.BG._Done();this.BH._Done();this.BI._Done();this.BJ._Done(
);this.BK._Done();B.Core.Root._Done.call(this);},_ReInit:function(){B.Core.Root.
_ReInit.call(this);this.AO._ReInit();this.Cg._ReInit();this.Cu._ReInit();this.Cv.
_ReInit();this.Cw._ReInit();this.Cx._ReInit();this.Cy._ReInit();this.Timer._ReInit(
);this.Bd._ReInit();this.BL._ReInit();this.BM._ReInit();this.BN._ReInit();this.BO.
_ReInit();this.BP._ReInit();this.BQ._ReInit();this.BG._ReInit();this.BH._ReInit(
);this.BI._ReInit();this.BJ._ReInit();this.BK._ReInit();},_Mark:function(E){var A;
B.Core.Root._Mark.call(this,E);if((A=this.AO)._cycle!=E)A._Mark(A._cycle=E);if((
A=this.Cg)._cycle!=E)A._Mark(A._cycle=E);if((A=this.Cu)._cycle!=E)A._Mark(A._cycle=
E);if((A=this.Cv)._cycle!=E)A._Mark(A._cycle=E);if((A=this.Cw)._cycle!=E)A._Mark(
A._cycle=E);if((A=this.Cx)._cycle!=E)A._Mark(A._cycle=E);if((A=this.Cy)._cycle!=
E)A._Mark(A._cycle=E);if((A=this.Timer)._cycle!=E)A._Mark(A._cycle=E);if((A=this.
Bd)._cycle!=E)A._Mark(A._cycle=E);if((A=this.BL)._cycle!=E)A._Mark(A._cycle=E);if((
A=this.BM)._cycle!=E)A._Mark(A._cycle=E);if((A=this.BN)._cycle!=E)A._Mark(A._cycle=
E);if((A=this.BO)._cycle!=E)A._Mark(A._cycle=E);if((A=this.BP)._cycle!=E)A._Mark(
A._cycle=E);if((A=this.BQ)._cycle!=E)A._Mark(A._cycle=E);if((A=this.BG)._cycle!=
E)A._Mark(A._cycle=E);if((A=this.BH)._cycle!=E)A._Mark(A._cycle=E);if((A=this.BI
)._cycle!=E)A._Mark(A._cycle=E);if((A=this.BJ)._cycle!=E)A._Mark(A._cycle=E);if((
A=this.BK)._cycle!=E)A._Mark(A._cycle=E);},_className:"Application::Application"
};D.AO={A8:null,BF:null,BY:null,BD:null,Gk:II,Gl:IJ,EW:function(aSize){B.Core.Ac.
EW.call(this,aSize);},Ee:function(E3){B.Core.Ac.Ee.call(this,E3);},CT:function(C
){if(this.Gk===C)return;this.Gk=C;this.BY.Dx(this.Gk);},FI:function(C){if(this.Gl===
C)return;this.Gl=C;this.BD.Dx(this.Gl);},AH:function(C){if(B.tn(this.A8,C))return;
if(!!this.A8)B.sO([this,this.C8],this.A8,0);this.A8=C;if(!!C)B.sB([this,this.C8]
,C,0);if(!!C)B.lq([this,this.C8],this);},C8:function(BX){var A;if(!!this.A8)this.
FI((A=this.A8,A[1].call(A[0])));},_Init:function(aArg){B.Core.Ac._Init.call(this
,aArg);B.um.BF._Init.call(this.BF={P:this},0);B.um.Text._Init.call(this.BY={P:this
},0);B.um.Text._Init.call(this.BD={P:this},0);this.__proto__=D.AO;this.BF.ER(0x3F
);this.BF.U(Hd);this.U(Hd);this.BY.U(IK);this.BY.EN(0x11);this.BY.Dx(Cz);this.BY.
EO(0xFF636363);this.BD.ER(0x3F);this.BD.U(IL);this.BD.EN(0x12);this.BD.Dx(Cz);this.
BD.EO(0xFF636363);this.Aw(this.BF,0);this.Aw(this.BY,0);this.Aw(this.BD,0);this.
BY.EQ(B.s$(B.un.FF));this.BD.EQ(B.s$(B.un.FE));},_Done:function(){this.__proto__=
B.Core.Ac;this.BF._Done();this.BY._Done();this.BD._Done();B.Core.Ac._Done.call(this
);},_ReInit:function(){B.Core.Ac._ReInit.call(this);this.BF._ReInit();this.BY._ReInit(
);this.BD._ReInit();},_Mark:function(E){var A;B.Core.Ac._Mark.call(this,E);if((A=
this.A8)&&((A=A[0])._cycle!=E))A._Mark(A._cycle=E);if((A=this.BF)._cycle!=E)A._Mark(
A._cycle=E);if((A=this.BY)._cycle!=E)A._Mark(A._cycle=E);if((A=this.BD)._cycle!=
E)A._Mark(A._cycle=E);},_className:"Application::StringRectDataBox"};
D._Init=function(){D.Fo.__proto__=B.Core.Root;D.AO.__proto__=B.Core.Ac;};D.An=function(
E){};return D;})();

/* Embedded Wizard */