/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.ia)throw new Error("The unit file 'Application.js' included twice!"
);EmWiApp.ia=(function(){var B=EmWiApp;var D={};
var Z="init...";var An="get data...";var Ca=[0,0,1024,768];var Ex=[20,30,150,90];
var CN="LOT-ID";var Gx="SK0012";var Gy=[160,30,290,90];var Gz="RECIPE";var GA="P2500-4.75";
var GB=[300,30,430,90];var IT="STEP";var IU=[440,30,570,90];var IV="JOB TIME";var
IW=[580,30,710,90];var IX="EVENT TIME";var IY=[720,30,850,90];var IZ="HOLD TIME";
var I0=[860,30,990,90];var I1="TOTAL TIME";var I2=[20,152,290,202];var I3="SV 1";
var I4=[20,202,290,252];var I5="SV 2";var I6=[20,252,290,302];var I7="SV 3";var I8=[
20,302,290,352];var I9="SV 4";var I_=[220,152,490,202];var I$="FFC 1";var Ja=[220
,202,490,252];var Jb="FFC 2";var Jc=[220,252,490,302];var Jd="FFC 3";var Je=[220
,302,490,352];var Jf="FFC 4";var Jg=[420,152,690,202];var Jh="DDC 1";var Ji=[420
,202,690,252];var Jj="DDC 2";var Jk=[420,252,690,302];var Jl="DDC 3";var Jm=[420
,302,690,352];var Jn="DDC 4";var Jo=[630,162,990,342];var Jp="Unit";var Jq="Name";
var HL=[0,0,170,70];var Jr=[4,1,170,20];var Js=[0,10,170,70];
D.FM={AQ:null,Cr:null,CI:null,CJ:null,CK:null,CL:null,CM:null,Timer:null,Bg:null,
BX:null,BY:null,BZ:null,BH:null,B0:null,B1:null,BT:null,BG:null,BU:null,BV:null,
BW:null,AH:null,Bw:null,A_:function(aArg){B.uf("%s",Z);B._GetAutoObject(B.Device.
Device).Fh();},IH:function(B8){B.uf("%s",An);B._GetAutoObject(B.Device.Device).Fg(
);this.IP();},IP:function(){this.AH.H$();this.AH.Bv(B._GetAutoObject(B.Device.Device
).DW,B.ui.Gi);this.AH.Bv(B._GetAutoObject(B.Device.Device).DX,B.ui.Gj);this.AH.Bv(
B._GetAutoObject(B.Device.Device).DY,B.ui.Gk);this.AH.Bv(B._GetAutoObject(B.Device.
Device).DZ,B.ui.Gl);this.AH.Bv(B._GetAutoObject(B.Device.Device).Dw,B.ui.Gi);this.
AH.Bv(B._GetAutoObject(B.Device.Device).Cp,B.ui.Gj);this.AH.Bv(B._GetAutoObject(
B.Device.Device).Gd(),B.ui.Gk);this.AH.Bv(B._GetAutoObject(B.Device.Device).Dx,B.
ui.Gl);this.AH.Bv(B._GetAutoObject(B.Device.Device).Dt,B.ui.Gi);this.AH.Bv(B._GetAutoObject(
B.Device.Device).Co,B.ui.Gj);this.AH.Bv(B._GetAutoObject(B.Device.Device).Gc(),B.
ui.Gk);this.AH.Bv(B._GetAutoObject(B.Device.Device).Du,B.ui.Gl);this.Bw.Is(this.
AH);},_Init:function(aArg){B.Core.Root._Init.call(this,aArg);D.AQ._Init.call(this.
AQ={O:this},0);D.AQ._Init.call(this.Cr={O:this},0);D.AQ._Init.call(this.CI={O:this
},0);D.AQ._Init.call(this.CJ={O:this},0);D.AQ._Init.call(this.CK={O:this},0);D.AQ.
_Init.call(this.CL={O:this},0);D.AQ._Init.call(this.CM={O:this},0);B.Core.Timer.
_Init.call(this.Timer={O:this},0);B.uj.Ai._Init.call(this.Bg={O:this},0);B.uj.Ai.
_Init.call(this.BX={O:this},0);B.uj.Ai._Init.call(this.BY={O:this},0);B.uj.Ai._Init.
call(this.BZ={O:this},0);B.uj.Ai._Init.call(this.BH={O:this},0);B.uj.Ai._Init.call(
this.B0={O:this},0);B.uj.Ai._Init.call(this.B1={O:this},0);B.uj.Ai._Init.call(this.
BT={O:this},0);B.uj.Ai._Init.call(this.BG={O:this},0);B.uj.Ai._Init.call(this.BU={
O:this},0);B.uj.Ai._Init.call(this.BV={O:this},0);B.uj.Ai._Init.call(this.BW={O:
this},0);B.uo.AH._Init.call(this.AH={O:this},0);B.uo.Bw._Init.call(this.Bw={O:this
},0);this.__proto__=D.FM;var A;this.T(Ca);this.AQ.T(Ex);this.AQ.C_(CN);this.AQ.Gf(
Gx);this.Cr.T(Gy);this.Cr.C_(Gz);this.Cr.Gf(GA);this.CI.T(GB);this.CI.C_(IT);this.
CJ.T(IU);this.CJ.C_(IV);this.CK.T(IW);this.CK.C_(IX);this.CL.T(IY);this.CL.C_(IZ
);this.CM.T(I0);this.CM.C_(I1);this.Timer.E_(true);this.Bg.It(0);this.Bg.T(I2);this.
Bg.BC(I3);this.Bg.BB(1);this.Bg.Io(0.000000);this.Bg.BA(0.100000);this.Bg.E9(8000
);this.BX.T(I4);this.BX.BC(I5);this.BX.BB(1);this.BX.BA(0.100000);this.BY.T(I6);
this.BY.BC(I7);this.BY.BB(1);this.BY.BA(0.100000);this.BZ.T(I8);this.BZ.BC(I9);this.
BZ.BB(1);this.BZ.BA(0.100000);this.BH.T(I_);this.BH.BC(I$);this.BH.BB(1);this.BH.
BA(0.100000);this.BH.E9(8000);this.B0.T(Ja);this.B0.BC(Jb);this.B0.BB(1);this.B0.
BA(0.100000);this.B1.T(Jc);this.B1.BC(Jd);this.B1.BB(1);this.B1.BA(0.100000);this.
BT.T(Je);this.BT.BC(Jf);this.BT.BB(1);this.BT.BA(0.100000);this.BG.T(Jg);this.BG.
BC(Jh);this.BG.BB(1);this.BG.BA(0.100000);this.BG.E9(8000);this.BU.T(Ji);this.BU.
BC(Jj);this.BU.BB(1);this.BU.BA(0.100000);this.BV.T(Jk);this.BV.BC(Jl);this.BV.BB(
1);this.BV.BA(0.100000);this.BW.T(Jm);this.BW.BC(Jn);this.BW.BB(1);this.BW.BA(0.100000
);this.Bw.T(Jo);this.Bw.Iq(10000);this.As(this.AQ,0);this.As(this.Cr,0);this.As(
this.CI,0);this.As(this.CJ,0);this.As(this.CK,0);this.As(this.CL,0);this.As(this.
CM,0);this.As(this.Bg,0);this.As(this.BX,0);this.As(this.BY,0);this.As(this.BZ,0
);this.As(this.BH,0);this.As(this.B0,0);this.As(this.B1,0);this.As(this.BT,0);this.
As(this.BG,0);this.As(this.BU,0);this.As(this.BV,0);this.As(this.BW,0);this.As(this.
Bw,0);this.AQ.AJ([A=B._GetAutoObject(B.Device.Device),A.Hx,A.DL]);this.Cr.AJ([A=
B._GetAutoObject(B.Device.Device),A.Hy,A.DM]);this.CI.AJ([A=B._GetAutoObject(B.Device.
Device),A.Hz,A.DN]);this.CJ.AJ([A=B._GetAutoObject(B.Device.Device),A.Hw,A.DK]);
this.CK.AJ([A=B._GetAutoObject(B.Device.Device),A.Hr,A.DD]);this.CL.AJ([A=B._GetAutoObject(
B.Device.Device),A.Hv,A.DJ]);this.CM.AJ([A=B._GetAutoObject(B.Device.Device),A.HE
,A.DT]);this.Timer.Fb=[this,this.IH];this.Bg.AJ([A=B._GetAutoObject(B.Device.Device
),A.HA,A.DP]);this.Bg.Bz(B._GetAutoObject(B.uk.Ai));this.BX.AJ([A=B._GetAutoObject(
B.Device.Device),A.HB,A.DQ]);this.BX.Bz(B._GetAutoObject(B.uk.Ai));this.BY.AJ([A=
B._GetAutoObject(B.Device.Device),A.HC,A.DR]);this.BY.Bz(B._GetAutoObject(B.uk.Ai
));this.BZ.AJ([A=B._GetAutoObject(B.Device.Device),A.HD,A.DS]);this.BZ.Bz(B._GetAutoObject(
B.uk.Ai));this.BH.AJ([A=B._GetAutoObject(B.Device.Device),A.Hs,A.DE]);this.BH.Bz(
B._GetAutoObject(B.uk.Ai));this.B0.AJ([A=B._GetAutoObject(B.Device.Device),A.Ht,
A.DF]);this.B0.Bz(B._GetAutoObject(B.uk.Ai));this.B1.AJ([A=B._GetAutoObject(B.Device.
Device),A.Gd,A.DG]);this.B1.Bz(B._GetAutoObject(B.uk.Ai));this.BT.AJ([A=B._GetAutoObject(
B.Device.Device),A.Hu,A.DH]);this.BT.Bz(B._GetAutoObject(B.uk.Ai));this.BG.AJ([A=
B._GetAutoObject(B.Device.Device),A.Ho,A.Dz]);this.BG.Bz(B._GetAutoObject(B.uk.Ai
));this.BU.AJ([A=B._GetAutoObject(B.Device.Device),A.Hp,A.DA]);this.BU.Bz(B._GetAutoObject(
B.uk.Ai));this.BV.AJ([A=B._GetAutoObject(B.Device.Device),A.Gc,A.DB]);this.BV.Bz(
B._GetAutoObject(B.uk.Ai));this.BW.AJ([A=B._GetAutoObject(B.Device.Device),A.Hq,
A.DC]);this.BW.Bz(B._GetAutoObject(B.uk.Ai));this.A_(aArg);},_Done:function(){this.
__proto__=B.Core.Root;this.AQ._Done();this.Cr._Done();this.CI._Done();this.CJ._Done(
);this.CK._Done();this.CL._Done();this.CM._Done();this.Timer._Done();this.Bg._Done(
);this.BX._Done();this.BY._Done();this.BZ._Done();this.BH._Done();this.B0._Done(
);this.B1._Done();this.BT._Done();this.BG._Done();this.BU._Done();this.BV._Done(
);this.BW._Done();this.AH._Done();this.Bw._Done();B.Core.Root._Done.call(this);}
,_ReInit:function(){B.Core.Root._ReInit.call(this);this.AQ._ReInit();this.Cr._ReInit(
);this.CI._ReInit();this.CJ._ReInit();this.CK._ReInit();this.CL._ReInit();this.CM.
_ReInit();this.Timer._ReInit();this.Bg._ReInit();this.BX._ReInit();this.BY._ReInit(
);this.BZ._ReInit();this.BH._ReInit();this.B0._ReInit();this.B1._ReInit();this.BT.
_ReInit();this.BG._ReInit();this.BU._ReInit();this.BV._ReInit();this.BW._ReInit(
);this.AH._ReInit();this.Bw._ReInit();},_Mark:function(E){var A;B.Core.Root._Mark.
call(this,E);if((A=this.AQ)._cycle!=E)A._Mark(A._cycle=E);if((A=this.Cr)._cycle!=
E)A._Mark(A._cycle=E);if((A=this.CI)._cycle!=E)A._Mark(A._cycle=E);if((A=this.CJ
)._cycle!=E)A._Mark(A._cycle=E);if((A=this.CK)._cycle!=E)A._Mark(A._cycle=E);if((
A=this.CL)._cycle!=E)A._Mark(A._cycle=E);if((A=this.CM)._cycle!=E)A._Mark(A._cycle=
E);if((A=this.Timer)._cycle!=E)A._Mark(A._cycle=E);if((A=this.Bg)._cycle!=E)A._Mark(
A._cycle=E);if((A=this.BX)._cycle!=E)A._Mark(A._cycle=E);if((A=this.BY)._cycle!=
E)A._Mark(A._cycle=E);if((A=this.BZ)._cycle!=E)A._Mark(A._cycle=E);if((A=this.BH
)._cycle!=E)A._Mark(A._cycle=E);if((A=this.B0)._cycle!=E)A._Mark(A._cycle=E);if((
A=this.B1)._cycle!=E)A._Mark(A._cycle=E);if((A=this.BT)._cycle!=E)A._Mark(A._cycle=
E);if((A=this.BG)._cycle!=E)A._Mark(A._cycle=E);if((A=this.BU)._cycle!=E)A._Mark(
A._cycle=E);if((A=this.BV)._cycle!=E)A._Mark(A._cycle=E);if((A=this.BW)._cycle!=
E)A._Mark(A._cycle=E);if((A=this.AH)._cycle!=E)A._Mark(A._cycle=E);if((A=this.Bw
)._cycle!=E)A._Mark(A._cycle=E);},_className:"Application::Application"};D.AQ={A$:
null,BE:null,B9:null,BP:null,GP:Jp,GQ:Jq,Ff:function(aSize){B.Core.X.Ff.call(this
,aSize);},Ev:function(Fm){B.Core.X.Ev.call(this,Fm);},C_:function(C){if(this.GP===
C)return;this.GP=C;this.B9.DO(this.GP);},Gf:function(C){if(this.GQ===C)return;this.
GQ=C;this.BP.DO(this.GQ);},AJ:function(C){if(B.tn(this.A$,C))return;if(!!this.A$
)B.sO([this,this.Dn],this.A$,0);this.A$=C;if(!!C)B.sB([this,this.Dn],C,0);if(!!C
)B.lq([this,this.Dn],this);},Dn:function(B8){var A;if(!!this.A$)this.Gf((A=this.
A$,A[1].call(A[0])));},_Init:function(aArg){B.Core.X._Init.call(this,aArg);B.un.
BE._Init.call(this.BE={O:this},0);B.un.Text._Init.call(this.B9={O:this},0);B.un.
Text._Init.call(this.BP={O:this},0);this.__proto__=D.AQ;this.BE.Eo(0x3F);this.BE.
T(HL);this.T(HL);this.B9.T(Jr);this.B9.E8(0x11);this.B9.DO(CN);this.B9.Dy(0xFF636363
);this.BP.Eo(0x3F);this.BP.T(Js);this.BP.E8(0x12);this.BP.DO(CN);this.BP.Dy(0xFF636363
);this.As(this.BE,0);this.As(this.B9,0);this.As(this.BP,0);this.B9.E$(B.s$(B.ui.
F$));this.BP.E$(B.s$(B.ui.F_));},_Done:function(){this.__proto__=B.Core.X;this.BE.
_Done();this.B9._Done();this.BP._Done();B.Core.X._Done.call(this);},_ReInit:function(
){B.Core.X._ReInit.call(this);this.BE._ReInit();this.B9._ReInit();this.BP._ReInit(
);},_Mark:function(E){var A;B.Core.X._Mark.call(this,E);if((A=this.A$)&&((A=A[0]
)._cycle!=E))A._Mark(A._cycle=E);if((A=this.BE)._cycle!=E)A._Mark(A._cycle=E);if((
A=this.B9)._cycle!=E)A._Mark(A._cycle=E);if((A=this.BP)._cycle!=E)A._Mark(A._cycle=
E);},_className:"Application::StringRectDataBox"};
D._Init=function(){D.FM.__proto__=B.Core.Root;D.AQ.__proto__=B.Core.X;};D.Ao=function(
E){};return D;})();

/* Embedded Wizard */