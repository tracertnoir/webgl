/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.ia)throw new Error("The unit file 'Application.js' included twice!"
);EmWiApp.ia=(function(){var B=EmWiApp;var D={};
var Y="init...";var Ax="get data...";var BX=[0,0,1024,768];var Ec=[20,30,150,90];
var CQ="LOT-ID";var FQ="SK0012";var FR=[160,30,290,90];var FS="RECIPE";var FT="P2500-4.75";
var H6=[300,30,430,90];var H7="STEP";var H8=[440,30,570,90];var H9="JOB TIME";var
H_=[580,30,710,90];var H$="EVENT TIME";var Ia=[720,30,850,90];var Ib="HOLD TIME";
var Ic=[860,30,990,90];var Id="TOTAL TIME";var Ie=[20,120,290,170];var If="SV 1";
var Ig=[20,170,290,220];var Ih="SV 2";var Ii=[20,220,290,270];var Ij="SV 3";var Ik=[
20,270,290,320];var Il="SV 4";var Im=[300,120,570,170];var In="FFC 1";var Io=[300
,170,570,220];var Ip="FFC 2";var Iq=[300,220,570,270];var Ir="FFC 3";var Is=[300
,270,570,320];var It="FFC 4";var Iu=[580,120,850,170];var Iv="DDC 1";var Iw=[580
,170,850,220];var Ix="DDC 2";var Iy=[580,220,850,270];var Iz="DDC 3";var IA=[580
,270,850,320];var IB="DDC 4";var IC="Unit";var ID="Name";var G8=[0,0,170,70];var
IE=[4,1,170,20];var IF=[0,10,170,70];
D.Fk={AM:null,Cd:null,Cp:null,Cq:null,Cr:null,Cs:null,Ct:null,Timer:null,BQ:null,
BR:null,BS:null,BT:null,BU:null,BV:null,BW:null,BL:null,BM:null,BN:null,BO:null,
BP:null,A5:function(aArg){B.uf("%s",Y);B._GetAutoObject(B.Device.Device).ET();},
HW:function(BH){B.uf("%s",Ax);B._GetAutoObject(B.Device.Device).ES();},_Init:function(
aArg){B.Core.Root._Init.call(this,aArg);D.AM._Init.call(this.AM={O:this},0);D.AM.
_Init.call(this.Cd={O:this},0);D.AM._Init.call(this.Cp={O:this},0);D.AM._Init.call(
this.Cq={O:this},0);D.AM._Init.call(this.Cr={O:this},0);D.AM._Init.call(this.Cs={
O:this},0);D.AM._Init.call(this.Ct={O:this},0);B.Core.Timer._Init.call(this.Timer={
O:this},0);B.ui.Ah._Init.call(this.BQ={O:this},0);B.ui.Ah._Init.call(this.BR={O:
this},0);B.ui.Ah._Init.call(this.BS={O:this},0);B.ui.Ah._Init.call(this.BT={O:this
},0);B.ui.Ah._Init.call(this.BU={O:this},0);B.ui.Ah._Init.call(this.BV={O:this},
0);B.ui.Ah._Init.call(this.BW={O:this},0);B.ui.Ah._Init.call(this.BL={O:this},0);
B.ui.Ah._Init.call(this.BM={O:this},0);B.ui.Ah._Init.call(this.BN={O:this},0);B.
ui.Ah._Init.call(this.BO={O:this},0);B.ui.Ah._Init.call(this.BP={O:this},0);this.
__proto__=D.Fk;var A;this.S(BX);this.AM.S(Ec);this.AM.CN(CQ);this.AM.FC(FQ);this.
Cd.S(FR);this.Cd.CN(FS);this.Cd.FC(FT);this.Cp.S(H6);this.Cp.CN(H7);this.Cq.S(H8
);this.Cq.CN(H9);this.Cr.S(H_);this.Cr.CN(H$);this.Cs.S(Ia);this.Cs.CN(Ib);this.
Ct.S(Ic);this.Ct.CN(Id);this.Timer.EK(true);this.BQ.S(Ie);this.BQ.Bq(If);this.BQ.
Bp(1);this.BR.S(Ig);this.BR.Bq(Ih);this.BR.Bp(1);this.BS.S(Ii);this.BS.Bq(Ij);this.
BS.Bp(1);this.BT.S(Ik);this.BT.Bq(Il);this.BT.Bp(1);this.BU.S(Im);this.BU.Bq(In);
this.BU.Bp(1);this.BV.S(Io);this.BV.Bq(Ip);this.BV.Bp(1);this.BW.S(Iq);this.BW.Bq(
Ir);this.BW.Bp(1);this.BL.S(Is);this.BL.Bq(It);this.BL.Bp(1);this.BM.S(Iu);this.
BM.Bq(Iv);this.BM.Bp(1);this.BN.S(Iw);this.BN.Bq(Ix);this.BN.Bp(1);this.BO.S(Iy);
this.BO.Bq(Iz);this.BO.Bp(1);this.BP.S(IA);this.BP.Bq(IB);this.BP.Bp(1);this.Av(
this.AM,0);this.Av(this.Cd,0);this.Av(this.Cp,0);this.Av(this.Cq,0);this.Av(this.
Cr,0);this.Av(this.Cs,0);this.Av(this.Ct,0);this.Av(this.BQ,0);this.Av(this.BR,0
);this.Av(this.BS,0);this.Av(this.BT,0);this.Av(this.BU,0);this.Av(this.BV,0);this.
Av(this.BW,0);this.Av(this.BL,0);this.Av(this.BM,0);this.Av(this.BN,0);this.Av(this.
BO,0);this.Av(this.BP,0);this.AM.AG([A=B._GetAutoObject(B.Device.Device),A.GV,A.
Dm]);this.Cd.AG([A=B._GetAutoObject(B.Device.Device),A.GW,A.Dn]);this.Cp.AG([A=B.
_GetAutoObject(B.Device.Device),A.GX,A.Do]);this.Cq.AG([A=B._GetAutoObject(B.Device.
Device),A.GU,A.Dl]);this.Cr.AG([A=B._GetAutoObject(B.Device.Device),A.GO,A.Df]);
this.Cs.AG([A=B._GetAutoObject(B.Device.Device),A.GT,A.Dk]);this.Ct.AG([A=B._GetAutoObject(
B.Device.Device),A.G2,A.Dq]);this.Timer.EO=[this,this.HW];this.BQ.AG([A=B._GetAutoObject(
B.Device.Device),A.GY,A.DX]);this.BQ.Bo(B._GetAutoObject(B.uj.Ah));this.BR.AG([A=
B._GetAutoObject(B.Device.Device),A.GZ,A.DY]);this.BR.Bo(B._GetAutoObject(B.uj.Ah
));this.BS.AG([A=B._GetAutoObject(B.Device.Device),A.G0,A.DZ]);this.BS.Bo(B._GetAutoObject(
B.uj.Ah));this.BT.AG([A=B._GetAutoObject(B.Device.Device),A.G1,A.D0]);this.BT.Bo(
B._GetAutoObject(B.uj.Ah));this.BU.AG([A=B._GetAutoObject(B.Device.Device),A.GP,
A.Dg]);this.BU.Bo(B._GetAutoObject(B.uj.Ah));this.BV.AG([A=B._GetAutoObject(B.Device.
Device),A.GQ,A.Dh]);this.BV.Bo(B._GetAutoObject(B.uj.Ah));this.BW.AG([A=B._GetAutoObject(
B.Device.Device),A.GR,A.Di]);this.BW.Bo(B._GetAutoObject(B.uj.Ah));this.BL.AG([A=
B._GetAutoObject(B.Device.Device),A.GS,A.DW]);this.BL.Bo(B._GetAutoObject(B.uj.Ah
));this.BM.AG([A=B._GetAutoObject(B.Device.Device),A.GK,A.Dc]);this.BM.Bo(B._GetAutoObject(
B.uj.Ah));this.BN.AG([A=B._GetAutoObject(B.Device.Device),A.GL,A.Dd]);this.BN.Bo(
B._GetAutoObject(B.uj.Ah));this.BO.AG([A=B._GetAutoObject(B.Device.Device),A.GM,
A.De]);this.BO.Bo(B._GetAutoObject(B.uj.Ah));this.BP.AG([A=B._GetAutoObject(B.Device.
Device),A.GN,A.DV]);this.BP.Bo(B._GetAutoObject(B.uj.Ah));this.A5(aArg);},_Done:
function(){this.__proto__=B.Core.Root;this.AM._Done();this.Cd._Done();this.Cp._Done(
);this.Cq._Done();this.Cr._Done();this.Cs._Done();this.Ct._Done();this.Timer._Done(
);this.BQ._Done();this.BR._Done();this.BS._Done();this.BT._Done();this.BU._Done(
);this.BV._Done();this.BW._Done();this.BL._Done();this.BM._Done();this.BN._Done(
);this.BO._Done();this.BP._Done();B.Core.Root._Done.call(this);},_ReInit:function(
){B.Core.Root._ReInit.call(this);this.AM._ReInit();this.Cd._ReInit();this.Cp._ReInit(
);this.Cq._ReInit();this.Cr._ReInit();this.Cs._ReInit();this.Ct._ReInit();this.Timer.
_ReInit();this.BQ._ReInit();this.BR._ReInit();this.BS._ReInit();this.BT._ReInit(
);this.BU._ReInit();this.BV._ReInit();this.BW._ReInit();this.BL._ReInit();this.BM.
_ReInit();this.BN._ReInit();this.BO._ReInit();this.BP._ReInit();},_Mark:function(
E){var A;B.Core.Root._Mark.call(this,E);if((A=this.AM)._cycle!=E)A._Mark(A._cycle=
E);if((A=this.Cd)._cycle!=E)A._Mark(A._cycle=E);if((A=this.Cp)._cycle!=E)A._Mark(
A._cycle=E);if((A=this.Cq)._cycle!=E)A._Mark(A._cycle=E);if((A=this.Cr)._cycle!=
E)A._Mark(A._cycle=E);if((A=this.Cs)._cycle!=E)A._Mark(A._cycle=E);if((A=this.Ct
)._cycle!=E)A._Mark(A._cycle=E);if((A=this.Timer)._cycle!=E)A._Mark(A._cycle=E);
if((A=this.BQ)._cycle!=E)A._Mark(A._cycle=E);if((A=this.BR)._cycle!=E)A._Mark(A.
_cycle=E);if((A=this.BS)._cycle!=E)A._Mark(A._cycle=E);if((A=this.BT)._cycle!=E)
A._Mark(A._cycle=E);if((A=this.BU)._cycle!=E)A._Mark(A._cycle=E);if((A=this.BV).
_cycle!=E)A._Mark(A._cycle=E);if((A=this.BW)._cycle!=E)A._Mark(A._cycle=E);if((A=
this.BL)._cycle!=E)A._Mark(A._cycle=E);if((A=this.BM)._cycle!=E)A._Mark(A._cycle=
E);if((A=this.BN)._cycle!=E)A._Mark(A._cycle=E);if((A=this.BO)._cycle!=E)A._Mark(
A._cycle=E);if((A=this.BP)._cycle!=E)A._Mark(A._cycle=E);},_className:"Application::Application"
};D.AM={A6:null,BA:null,BI:null,By:null,Gd:IC,Ge:ID,ER:function(aSize){B.Core.Ab.
ER.call(this,aSize);},Ea:function(EY){B.Core.Ab.Ea.call(this,EY);},CN:function(C
){if(this.Gd===C)return;this.Gd=C;this.BI.Dp(this.Gd);},FC:function(C){if(this.Ge===
C)return;this.Ge=C;this.By.Dp(this.Ge);},AG:function(C){if(B.tn(this.A6,C))return;
if(!!this.A6)B.sO([this,this.C3],this.A6,0);this.A6=C;if(!!C)B.sB([this,this.C3]
,C,0);if(!!C)B.lq([this,this.C3],this);},C3:function(BH){var A;if(!!this.A6)this.
FC((A=this.A6,A[1].call(A[0])));},_Init:function(aArg){B.Core.Ab._Init.call(this
,aArg);B.um.BA._Init.call(this.BA={O:this},0);B.um.Text._Init.call(this.BI={O:this
},0);B.um.Text._Init.call(this.By={O:this},0);this.__proto__=D.AM;this.BA.EM(0x3F
);this.BA.S(G8);this.S(G8);this.BI.S(IE);this.BI.EI(0x11);this.BI.Dp(CQ);this.BI.
EJ(0xFF636363);this.By.EM(0x3F);this.By.S(IF);this.By.EI(0x12);this.By.Dp(CQ);this.
By.EJ(0xFF636363);this.Av(this.BA,0);this.Av(this.BI,0);this.Av(this.By,0);this.
BI.EL(B.s$(B.un.Fz));this.By.EL(B.s$(B.un.Fy));},_Done:function(){this.__proto__=
B.Core.Ab;this.BA._Done();this.BI._Done();this.By._Done();B.Core.Ab._Done.call(this
);},_ReInit:function(){B.Core.Ab._ReInit.call(this);this.BA._ReInit();this.BI._ReInit(
);this.By._ReInit();},_Mark:function(E){var A;B.Core.Ab._Mark.call(this,E);if((A=
this.A6)&&((A=A[0])._cycle!=E))A._Mark(A._cycle=E);if((A=this.BA)._cycle!=E)A._Mark(
A._cycle=E);if((A=this.BI)._cycle!=E)A._Mark(A._cycle=E);if((A=this.By)._cycle!=
E)A._Mark(A._cycle=E);},_className:"Application::StringRectDataBox"};
D._Init=function(){D.Fk.__proto__=B.Core.Root;D.AM.__proto__=B.Core.Ab;};D.Am=function(
E){};return D;})();

/* Embedded Wizard */