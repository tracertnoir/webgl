/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.Core)throw new Error("The unit file 'Core.js' included twice!");EmWiApp.
Core=(function(){var A=EmWiApp;var E={};
var Ab=[0,0];var At=[0,0,0,0];var Cr="The view does not belong to this group";var
Ds="No view to restack";var Dt="View is not in this group";var Hn="No view to remove";
var Ho="No view to add";var Hp="View already in a group";var Hq="Recursive invalidate during active update cycle.";
var Hr="The KeyPressHandler is embedded within an object not being derived "+"from Core::Group.";
E.Ch={T:null,O:null,K:null,AI:null,F:0x103,BH:0,AJ:0x14,FP:function(Ac,Ja){},JN:function(
C){if(this.BH===C)return;this.BH=C;if(!!this.K){var CQ=this.T;var A5=0;while(!!CQ&&(
C>CQ.BH)){CQ=CQ.T;A5=A5+1;}CQ=this.O;while(!!CQ&&(C<CQ.BH)){CQ=CQ.O;A5=A5-1;}if(
!!A5)this.K.JS(this,A5);}},Ec:function(C){var B;var A5=C^this.AJ;if(!A5)return;this.
AJ=C;if(!!this.AI&&!((this.F&0x400)===0x400)){this.K.F=this.K.F|0x5000;A.lq([B=this.
K,B.Bl],this);this.K.AM([0,0,(B=this.K.M)[2]-B[0],B[3]-B[1]]);}if(!!this.AI&&((this.
F&0x400)===0x400)){this.AI.DZ.F=this.AI.DZ.F|0x1000;this.K.F=this.K.F|0x4000;A.lq([
B=this.K,B.Bl],this);}},BU:function(Az,aClip,aOffset,AF,aBlend){},AU:function(V){
return null;},Dn:function(Ad,J,Bw,Hs,Hx){return null;},Gc:function(Ac,Dx){return Ab;
},Ia:function(aOffset,I$){},GetExtent:function(){return At;},A3:function(CJ,Dw){
var B;if(((this.F&0x200)===0x200))CJ=CJ&~0x400;var HP=(this.F&~Dw)|CJ;var C_=HP^
this.F;this.F=HP;if(!!this.K&&!!(C_&0x14)){var Ji=((this.F&0x14)===0x14);if(Ji&&
!this.K.Bs)this.K.DP(this);if(!Ji&&(this.K.Bs===this))this.K.DP(this.K.H6(this,0x14
));}if(!!this.K&&!!(C_&0x403))this.K.AM(this.GetExtent());if(((!!this.AI&&!!this.
K)&&((HP&0x400)===0x400))&&((C_&0x1)===0x1)){this.F=this.F|0x800;this.K.F=this.K.
F|0x4000;A.lq([B=this.K,B.Bl],this);}if(!!this.K&&((C_&0x400)===0x400)){this.AI=
null;this.F=this.F|0x800;this.K.F=this.K.F|0x4000;A.lq([B=this.K,B.Bl],this);}},
_Init:function(aArg){this.__proto__=E.Ch;A.gv++;},_Done:function(){this.__proto__=
null;A.gv--;},_ReInit:function(){},_Mark:function(D){var B;if((B=this.T)&&(B._cycle
!=D))B._Mark(B._cycle=D);if((B=this.O)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=
this.K)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.AI)&&(B._cycle!=D))B._Mark(
B._cycle=D);if((B=this.L)&&(B._cycle!=D))B._Mark(B._cycle=D);},L:null,_cycle:0,_observers:
null,_className:"Core::View"};E.AV={M:A.qy,FP:function(Ac,Ja){var AQ=A._NewObject(
E.H_,0);AQ.Db=this.M;AQ.Ap=Ac;AQ.DZ=Ja;this.AI=AQ;},Gc:function(Ac,Dx){var B;var
BO=this.AJ;var AQ=this.AI;var Ar=AQ.Db[0];var As=AQ.Db[1];var Ag=AQ.Db[2];var Ah=
AQ.Db[3];var Da=[Ac[2]-Ac[0],Ac[3]-Ac[1]];var Be=Ag-Ar;var Bc=Ah-As;if(!Dx){var D2=[(
B=AQ.Ap)[2]-B[0],B[3]-B[1]];Ar=Ar-AQ.Ap[0];As=As-AQ.Ap[1];if(D2[0]!==Da[0]){var Ct=((
BO&0x4)===0x4);var Cu=((BO&0x8)===0x8);var EF=((BO&0x1)===0x1);if(!Ct&&(EF||!Cu)
)Ar=((Ar*Da[0])/D2[0])|0;if(!Cu&&(EF||!Ct)){Ag=Ag-AQ.Ap[0];Ag=((Ag*Da[0])/D2[0])|
0;Ag=Ag-Da[0];}else Ag=Ag-AQ.Ap[2];Ar=Ar+Ac[0];Ag=Ag+Ac[2];if(!EF){if(Ct&&!Cu)Ag=
Ar+Be;else if(!Ct&&Cu)Ar=Ag-Be;else{Ar=Ar+((((Ag-Ar)-Be)/2)|0);Ag=Ar+Be;}}}else{
Ag=Ag-AQ.Ap[2];Ar=Ar+Ac[0];Ag=Ag+Ac[2];}if(D2[1]!==Da[1]){var Cv=((BO&0x10)===0x10
);var Cs=((BO&0x20)===0x20);var EG=((BO&0x2)===0x2);if(!Cv&&(EG||!Cs))As=((As*Da[
1])/D2[1])|0;if(!Cs&&(EG||!Cv)){Ah=Ah-AQ.Ap[1];Ah=((Ah*Da[1])/D2[1])|0;Ah=Ah-Da[
1];}else Ah=Ah-AQ.Ap[3];As=As+Ac[1];Ah=Ah+Ac[3];if(!EG){if(Cv&&!Cs)Ah=As+Bc;else
if(!Cv&&Cs)As=Ah-Bc;else{As=As+((((Ah-As)-Bc)/2)|0);Ah=As+Bc;}}}else{Ah=Ah-AQ.Ap[
3];As=As+Ac[1];Ah=Ah+Ac[3];}}else{switch(Dx){case 3:{Ar=Ac[0];Ag=Ar+Be;}break;case
4:{Ag=Ac[2];Ar=Ag-Be;}break;case 1:{As=Ac[1];Ah=As+Bc;}break;case 2:{Ah=Ac[3];As=
Ah-Bc;}break;default:;}if((Dx===3)||(Dx===4)){var Cv=((BO&0x10)===0x10);var Cs=((
BO&0x20)===0x20);var EG=((BO&0x2)===0x2);if(EG){As=Ac[1];Ah=Ac[3];}else if(Cv&&!
Cs){As=Ac[1];Ah=As+Bc;}else if(Cs&&!Cv){Ah=Ac[3];As=Ah-Bc;}else{As=Ac[1]+((((Ac[
3]-Ac[1])-Bc)/2)|0);Ah=As+Bc;}}if((Dx===1)||(Dx===2)){var Ct=((BO&0x4)===0x4);var
Cu=((BO&0x8)===0x8);var EF=((BO&0x1)===0x1);if(EF){Ar=Ac[0];Ag=Ac[2];}else if(Ct&&
!Cu){Ar=Ac[0];Ag=Ar+Be;}else if(Cu&&!Ct){Ag=Ac[2];Ar=Ag-Be;}else{Ar=Ac[0]+((((Ac[
2]-Ac[0])-Be)/2)|0);Ag=Ar+Be;}}}AQ.isEmpty=(Ar>=Ag)||(As>=Ah);if(((this.F&0x100)===
0x100)){this.M=[Ar,As,Ag,Ah];}else{this.N([Ar,As,Ag,Ah]);this.AI=AQ;}return[Ag-Ar
,Ah-As];},Ia:function(aOffset,I$){if(I$)this.M=A.tz(this.M,aOffset);else this.N(
A.tz(this.M,aOffset));},GetExtent:function(){return this.M;},N:function(C){var B;
if(A.tm(C,this.M))return;if(!!this.K&&((this.F&0x1)===0x1))this.K.AM(this.M);this.
AI=null;this.M=C;if(!!this.K&&((this.F&0x1)===0x1))this.K.AM(this.M);if((!!this.
K&&((this.F&0x400)===0x400))&&!((this.K.F&0x2000)===0x2000)){this.F=this.F|0x800;
this.K.F=this.K.F|0x4000;A.lq([B=this.K,B.Bl],this);}},_Init:function(aArg){E.Ch.
_Init.call(this,aArg);this.__proto__=E.AV;},_className:"Core::RectView"};E.Y={Ba:
null,AS:null,FR:null,Bq:null,C$:null,DD:null,Bs:null,Fp:255,BU:function(Az,aClip
,aOffset,AF,aBlend){var B;AF=((AF+1)*this.Fp)>>8;aBlend=aBlend&&((this.F&0x2)===
0x2);if(!this.Bq)this.Lc(Az,aClip,A.tx(aOffset,this.M.slice(0,2)),AF,aBlend);else{
var A4=255|(255<<8)|(255<<16)|((AF&0xFF)<<24);this.Bq.Update();Az.Jw(aClip,this.
Bq,0,A.tz(this.M,aOffset),Ab,A4,A4,A4,A4,aBlend);}},Dn:function(Ad,J,Bw,Hs,Hx){var
B;var G=this.AS;var DE=null;var S=At;var Ax=null;var HO=!!this.DD&&(!!this.DD.HD||
!!this.DD.Ba);if(((B=A.il(Ad,this.M))[0]>=B[2])||(B[1]>=B[3]))return null;Ad=A.ty(
Ad,this.M.slice(0,2));while(!!G){if(((G.F&0x400)===0x400)&&!Ax){Ax=G.O;while(!!Ax&&
!((Ax.F&0x200)===0x200))Ax=Ax.O;if(!!Ax)S=A.il(Ad,Ax.GetExtent());else S=At;}if(
Ax===G){Ax=null;S=At;}if((((((G.F&0x8)===0x8)&&((G.F&0x10)===0x10))&&!((G.F&0x40000
)===0x40000))&&!((G.F&0x20000)===0x20000))&&(!((G.F&0x10000)===0x10000)||((this.
C$.Bb===G)&&!HO))){var Db=G.GetExtent();var FL=Hs;var DC=null;if(FL===G)FL=null;
if(((G.F&0x400)===0x400)){if(!(((B=A.il(Db,S))[0]>=B[2])||(B[1]>=B[3])))DC=G.Dn(
S,J,Bw,FL,Hx);}else{if(!(((B=A.il(Db,Ad))[0]>=B[2])||(B[1]>=B[3]))||(Hs===G))DC=
G.Dn(Ad,J,Bw,FL,Hx);}G=G.O;if(!!DC){if(!DE||((DC.EU<DE.EU)&&(DC.EU>=0)))DE=DC;if(
!DC.EU)G=null;}}else G=G.O;}return DE;},A3:function(CJ,Dw){var B;var Le=this.F;E.
AV.A3.call(this,CJ,Dw);var C_=this.F^Le;if(!!this.Bs&&((C_&0x40)===0x40)){if(((this.
F&0x40)===0x40))this.Bs.A3(0x40,0x0);else this.Bs.A3(0x0,0x40);}if(!!this.C$&&((
C_&0x40)===0x40)){if(((this.F&0x40)===0x40)&&((this.C$.Bb.F&0x14)===0x14))this.C$.
Bb.A3(0x40,0x0);else this.C$.Bb.A3(0x0,0x40);}if(!!C_){this.F=this.F|0x8000;A.lq([
this,this.Bl],this);}},N:function(C){var B;if(A.tm(C,this.M))return;var Dg=[(B=this.
M)[2]-B[0],B[3]-B[1]];var FV=[C[2]-C[0],C[3]-C[1]];var DI=!A.tl(Dg,FV);if(DI&&!!
this.Bq){this.Bq.GJ(FV);A.qw(this,0);A.qw(this.Bq,0);}E.AV.N.call(this,C);if((DI&&(
Dg[0]>0))&&(Dg[1]>0)){var Ap=[].concat(Ab,Dg);var G=this.Ba;var Ex=0x14;while(!!
G){if((!G.AI&&(G.AJ!==Ex))&&!((G.F&0x400)===0x400))G.FP(Ap,null);G=G.T;}}if(DI){
this.F=this.F|0x5000;A.lq([this,this.Bl],this);}},HV:function(V){var Jk=(E.KeyEvent.
isPrototypeOf(V)?V:null);var BN=this.FR;if(!Jk)return null;while(!!BN&&(!BN.DM||
!BN.AU(Jk)))BN=BN.T;return BN;},Lc:function(Az,aClip,aOffset,AF,aBlend){var B;var
G=this.Ba;var Jg=At;var Jq=true;while(!!G){if(((G.F&0x200)===0x200)){var Jp=(E.Ed.
isPrototypeOf(G)?G:null);Jg=A.il(aClip,A.tz(Jp.M,aOffset));Jq=((Jp.F&0x1)===0x1);
}if(((G.F&0x1)===0x1)){if(((G.F&0x400)===0x400)){if(Jq){var S=A.il(A.tz(G.GetExtent(
),aOffset),Jg);if(!((S[0]>=S[2])||(S[1]>=S[3])))G.BU(Az,S,aOffset,AF,aBlend);}}else{
var S=A.il(A.tz(G.GetExtent(),aOffset),aClip);if(!((S[0]>=S[2])||(S[1]>=S[3])))G.
BU(Az,S,aOffset,AF,aBlend);}}G=G.T;}},Lg:function(){var B;var HJ=((this.F&0x1000
)===0x1000);var CM=[0,0,(B=this.M)[2]-B[0],B[3]-B[1]];var BL=false;var Cl=At;var
AG=At;var BM=Ab;var DW=0;var DX=0;var DV=0;var A6=0;var G=this.AS;var Ax=null;var
Ex=0x14;var Dd=null;while(!!G){if(((G.F&0x800)===0x800)){BL=true;G.F=G.F&~0x800;
}if(BL&&((G.F&0x200)===0x200)){BL=false;if(!!(E.Ed.isPrototypeOf(G)?G:null).E1)G.
F=G.F|0x1000;}G=G.O;}BL=false;G=this.Ba;if(HJ){this.F=this.F&~0x1000;HJ=!((CM[0]>=
CM[2])||(CM[1]>=CM[3]));}this.F=this.F|0x2000;while(!!G){if(!Dd&&(DV!==A6)){var Cp=
G;var FY=0;var EJ=Cl[2]-Cl[0];var Es=Cl[3]-Cl[1];var FI=0;var DL=Ab;do{if(((Cp.F&
0x200)===0x200))Cp=null;else if(((Cp.F&0x401)===0x401)){DL=[(B=Cp.GetExtent())[2
]-B[0],B[3]-B[1]];if((A6===3)||(A6===4))EJ=EJ-DL[0];if((A6===1)||(A6===2))Es=Es-
DL[1];if(!Dd||((EJ>=0)&&(Es>=0))){Dd=Cp;Cp=Cp.T;if((A6===3)||(A6===4)){EJ=EJ-DW;
if(DL[1]>FY)FY=DL[1];}if((A6===1)||(A6===2)){Es=Es-DX;if(DL[0]>FI)FI=DL[0];}}else
Cp=null;}else Cp=Cp.T;}while(!!Cp);if(!Dd)Dd=Ax;AG=Cl;switch(DV){case 9:case 11:
AG=[].concat(AG.slice(0,3),AG[1]+FY);break;case 10:case 12:AG=A.t3(AG,AG[3]-FY);
break;case 5:case 7:AG=A.t1(AG,AG[0]+FI);break;case 6:case 8:AG=[].concat(AG[2]-
FI,AG.slice(1,4));break;default:;}}if(((G.F&0x400)===0x400)){if(!!G.AI&&(G.AI.DZ
!==Ax))G.AI=null;if((!G.AI&&BL)&&((G.AJ!==Ex)||!!A6))G.FP(AG,Ax);}if(!!G.AI){if(
HJ&&!((G.F&0x400)===0x400))G.Gc(CM,0);if(BL&&((G.F&0x400)===0x400)){var F_=G.Gc(
A.tz(AG,BM),A6);if(((G.F&0x1)===0x1)){var Bk=Ab;switch(A6){case 3:Bk=[F_[0]+DW,Bk[
1]];break;case 4:Bk=[-F_[0]-DW,Bk[1]];break;case 1:Bk=[Bk[0],F_[1]+DX];break;case
2:Bk=[Bk[0],-F_[1]-DX];break;default:;}BM=A.tx(BM,Bk);}}}if(((G.F&0x200)===0x200
)){if(BL)A.lq(Ax.Cq,Ax);BL=((G.F&0x1000)===0x1000);Ax=(E.Ed.isPrototypeOf(G)?G:null
);if(BL){G.F=G.F&~0x1000;Cl=A.tz(Ax.M,Ax.Ef);AG=Cl;BM=Ab;DV=Ax.E1;A6=DV;DW=Ax.Space+
Ax.JU;DX=Ax.Space+Ax.JW;BL=!((Cl[0]>=Cl[2])||(Cl[1]>=Cl[3]));Dd=null;switch(DV){
case 9:case 10:A6=3;break;case 11:case 12:A6=4;break;case 5:case 6:A6=1;break;case
7:case 8:A6=2;break;default:;}}if(BL){this.AM(Ax.M);}}if(G===Dd){switch(DV){case
9:case 11:BM=[0,(BM[1]+(AG[3]-AG[1]))+DX];break;case 10:case 12:BM=[0,(BM[1]-(AG[
3]-AG[1]))-DX];break;case 5:case 7:BM=[(BM[0]+(AG[2]-AG[0]))+DW,0];break;case 6:
case 8:BM=[(BM[0]-(AG[2]-AG[0]))-DW,0];break;default:;}Dd=null;}G=G.T;}if(BL)A.lq(
Ax.Cq,Ax);this.F=this.F&~0x2000;this.Fw([CM[2]-CM[0],CM[3]-CM[1]]);},Bl:function(
Cn){var B;var Li=((this.F&0x1000)===0x1000);if(((this.F&0x4000)===0x4000)){this.
F=this.F&~0x4000;this.Lg();}if(((this.F&0x8000)===0x8000)||Li){this.F=this.F&~0x8000;
this.El(this.F);}},DP:function(C){var B;if(!!C&&(C.K!==this))throw new Error(Cr);
if(!!C&&!((C.F&0x14)===0x14))C=null;if(!!C&&((C.F&0x10000)===0x10000))C=null;if(
C===this.Bs)return;if(!!this.Bs)this.Bs.A3(0x0,0x60);this.Bs=C;if(!!C){if(((this.
F&0x40)===0x40))C.A3(0x60,0x0);else C.A3(0x20,0x0);}},H$:function(Hw){var tmp=this;
while(!!tmp){Hw=A.tw(Hw,tmp.M.slice(0,2));tmp=tmp.K;}return Hw;},DispatchEvent:function(
V){var B;var G=this.Bs;var R=(E.Y.isPrototypeOf(G)?G:null);var W=null;var HO=!!this.
DD&&(!!this.DD.HD||!!this.DD.Ba);if(!!G&&((((G.F&0x10000)===0x10000)||((G.F&0x40000
)===0x40000))||((G.F&0x20000)===0x20000))){G=null;R=null;}if(!!this.C$&&!HO)W=this.
C$.Bb.DispatchEvent(V);if(!W&&!!R)W=R.DispatchEvent(V);else if(!W&&!!G)W=G.AU(V);
if(!W)W=this.AU(V);if(!W)W=this.HV(V);return W;},BroadcastEventAtPosition:function(
V,Jb,Bh){var B;var G=this.AS;var W=null;while(!!G&&!W){if((!Bh||((B=Bh)&&((G.F&B
)===B)))&&A.qu(G.GetExtent(),Jb)){var R=(E.Y.isPrototypeOf(G)?G:null);if(!!R)W=R.
BroadcastEventAtPosition(V,A.tw(Jb,R.M.slice(0,2)),Bh);else W=G.AU(V);}G=G.O;}if(
!W)W=this.AU(V);return W;},BroadcastEvent:function(V,Bh){var B;var G=this.AS;var
W=null;while(!!G&&!W){if(!Bh||((B=Bh)&&((G.F&B)===B))){var R=(E.Y.isPrototypeOf(
G)?G:null);if(!!R)W=R.BroadcastEvent(V,Bh);else W=G.AU(V);}G=G.O;}if(!W)W=this.AU(
V);if(!W)W=this.HV(V);return W;},Fw:function(aSize){},El:function(FE){},Dp:function(
){this.F=this.F|0x8000;A.lq([this,this.Bl],this);},AM:function(Ad){var B;var R=this;
while(!!R&&!((Ad[0]>=Ad[2])||(Ad[1]>=Ad[3]))){var Dy=R.Bq;if(!R.K&&(R!==this)){R.
AM(Ad);return;}if(!!Dy){var HI=false;var Ld=Dy.BD;if(HI)Dy.BD=[0,0,(B=R.M)[2]-B[
0],B[3]-B[1]];else Dy.BD=A.qR(Dy.BD,Ad);if(!A.tm(Ld,Dy.BD)){A.qw(R,0);A.qw(Dy,0);
}}if(!((R.F&0x1)===0x1))return;Ad=A.il(A.tz(Ad,R.M.slice(0,2)),R.M);R=R.K;}},Bf:
function(aArg){this.Dp();},H6:function(I,Bh){var B;if(!I||(I.K!==this))return null;
var Df=I.T;var Di=I.O;var EC=0x10000;if(((Bh&0x10000)===0x10000))EC=0x0;while(!!
Df||!!Di){if((!!Df&&(!Bh||((B=Bh)&&((Df.F&B)===B))))&&(!EC||!((B=EC)&&((Df.F&B)===
B))))return Df;if((!!Di&&(!Bh||((B=Bh)&&((Di.F&B)===B))))&&(!EC||!((B=EC)&&((Di.
F&B)===B))))return Di;if(!!Df)Df=Df.T;if(!!Di)Di=Di.O;}return null;},JS:function(
I,Bv){var B;if(!I)throw new Error(Ds);if(I.K!==this)throw new Error(Dt);var CK=I;
var Aw=I;var DJ=I.BH;while(((Bv>0)&&!!CK.T)&&(CK.T.BH<=DJ)){CK=CK.T;Bv=Bv-1;}while(((
Bv<0)&&!!Aw.O)&&(Aw.O.BH>=DJ)){Aw=Aw.O;Bv=Bv+1;}if((CK===I)&&(Aw===I))return;if(((
I.F&0x401)===0x401)){if(!!I.O&&!!I.AI)I.O.F=I.O.F|0x800;I.F=I.F|0x800;this.F=this.
F|0x4000;A.lq([this,this.Bl],this);}if(((I.F&0x200)===0x200)){if(!!I.O)I.O.F=I.O.
F|0x800;I.F=I.F|0x800;this.F=this.F|0x4000;A.lq([this,this.Bl],this);}if(!!I.O)I.
O.T=I.T;if(!!I.T)I.T.O=I.O;if(this.Ba===I)this.Ba=I.T;if(this.AS===I)this.AS=I.O;
if(CK!==I){I.T=CK.T;I.O=CK;CK.T=I;if(!!I.T)I.T.O=I;}if(Aw!==I){I.T=Aw;I.O=Aw.O;Aw.
O=I;if(!!I.O)I.O.T=I;}if(!I.T)this.AS=I;if(!I.O)this.Ba=I;if(((I.F&0x1)===0x1))this.
AM(I.GetExtent());},I1:function(I){var B;if(!I)throw new Error(Hn);if(I.K!==this
)throw new Error(Dt);if((((I.F&0x401)===0x401)&&!!I.O)&&!!I.AI){I.O.F=I.O.F|0x800;
this.F=this.F|0x4000;A.lq([this,this.Bl],this);}if(((I.F&0x200)===0x200)){if(!!I.
O)I.O.F=I.O.F|0x800;this.F=this.F|0x4000;A.lq([this,this.Bl],this);}I.AI=null;if(
this.Bs===I)this.DP(this.H6(I,0x14));if(!!I.O)I.O.T=I.T;if(!!I.T)I.T.O=I.O;if(this.
Ba===I)this.Ba=I.T;if(this.AS===I)this.AS=I.O;I.K=null;I.T=null;I.O=null;if(((I.
F&0x1)===0x1))this.AM(I.GetExtent());},U:function(I,Bv){var B;if(!I)throw new Error(
Ho);if(!!I.K)throw new Error(Hp);var Aw=null;var DJ=I.BH;if(((Bv<0)&&!!this.AS)&&(
this.AS.BH>=DJ)){Aw=this.AS;Bv=Bv+1;}while((((Bv<0)&&!!Aw)&&!!Aw.O)&&(Aw.O.BH>=DJ
)){Aw=Aw.O;Bv=Bv+1;}if((!Aw&&!!this.AS)&&(this.AS.BH>DJ))Aw=this.AS;while((!!Aw&&
!!Aw.O)&&(Aw.O.BH>DJ))Aw=Aw.O;if(!Aw){I.K=this;I.O=this.AS;if(!!this.AS)this.AS.
T=I;if(!this.Ba)this.Ba=I;this.AS=I;}else{I.K=this;I.O=Aw.O;I.T=Aw;Aw.O=I;if(!!I.
O)I.O.T=I;else this.Ba=I;}if(((I.F&0x1)===0x1))this.AM(I.GetExtent());if(((!this.
Bs&&((I.F&0x4)===0x4))&&((I.F&0x10)===0x10))&&!((I.F&0x10000)===0x10000))this.DP(
I);if(((I.F&0x401)===0x401)){I.F=I.F|0x800;this.F=this.F|0x4000;A.lq([this,this.
Bl],this);}if(((I.F&0x200)===0x200)){I.F=I.F|0x800;this.F=this.F|0x4000;A.lq([this
,this.Bl],this);}},_Init:function(aArg){E.AV._Init.call(this,aArg);this.__proto__=
E.Y;this.F=0x1F;this.Bf(aArg);},_Mark:function(D){var B;E.AV._Mark.call(this,D);
if((B=this.Ba)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.AS)&&(B._cycle!=D))
B._Mark(B._cycle=D);if((B=this.FR)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.
Bq)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.C$)&&(B._cycle!=D))B._Mark(B._cycle=
D);if((B=this.DD)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.Bs)&&(B._cycle!=
D))B._Mark(B._cycle=D);},_className:"Core::Group"};E.Root={A9:null,CO:null,Cj:null
,AK:A.tA(10,null,null),DU:null,Bu:null,CL:null,EM:0,Hz:0,Ae:0,AX:A.tA(10,0,null)
,FK:A.tA(10,A.qy,null),Ck:A.tA(10,0,null),C9:A.tA(10,A.qx,null),Eu:A.tA(10,0,null
),DA:A.tA(10,A.qx,null),CA:A.tA(10,A.qx,null),CB:A.tA(10,A.qx,null),C8:A.tA(10,A.
qx,null),DB:0,FO:0,FN:0,FT:A.tA(3,A.qy,null),Jn:0,AZ:A.tA(4,0,null),AE:A.tA(4,A.
qy,null),AA:0,EP:8,Jy:250,Dc:0,CN:0,HK:true,FS:false,BU:function(Az,aClip,aOffset
,AF,aBlend){var fullScreenUpdate=false;fullScreenUpdate=A.jI;if(!fullScreenUpdate
)Az.EZ(aClip,A.tz(A.tz(aClip,aOffset),this.M.slice(0,2)),0x00000000,0x00000000,0x00000000
,0x00000000,false);E.Y.BU.call(this,Az,aClip,aOffset,AF,aBlend);},A3:function(CJ
,Dw){var B;E.Y.A3.call(this,CJ,Dw);if(!this.K&&(((CJ&0x1)===0x1)||((Dw&0x1)===0x1
)))this.AM([0,0,(B=this.M)[2]-B[0],B[3]-B[1]]);if(!this.K&&(((CJ&0x2)===0x2)||((
Dw&0x2)===0x2)))this.AM([0,0,(B=this.M)[2]-B[0],B[3]-B[1]]);},DP:function(C){if((
C!==this.Bu)||!C)E.Y.DP.call(this,C);},DispatchEvent:function(V){if((this.Hz>0)&&
!!(E.KeyEvent.isPrototypeOf(V)?V:null))return null;if(!!V){V.Eb=!!this.Ae;if(!!this.
Ae)V.Bt=this.Ae;}var W=null;if(!!this.Bu){W=this.Bu.DispatchEvent(V);if(!!W){this.
Ae=0;return W;}}if(!!this.CO){W=this.CO.Bb.DispatchEvent(V);if(!W)W=this.AU(V);if(
!W)W=this.HV(V);this.Ae=0;return W;}W=E.Y.DispatchEvent.call(this,V);this.Ae=0;return W;
},BroadcastEvent:function(V,Bh){if(!!V){V.Eb=!!this.Ae;if(!!this.Ae)V.Bt=this.Ae;
}var W=E.Y.BroadcastEvent.call(this,V,Bh);this.Ae=0;return W;},AM:function(Ad){var
B;if(this.EM>0)throw new Error(Hq);if(!!this.Bq&&!this.K){if(((B=this.Bq.BD)[0]>=
B[2])||(B[1]>=B[3])){A.qw(this,0);A.qw(this.Bq,0);}var HI=false;if(HI)this.Bq.BD=[
0,0,(B=this.M)[2]-B[0],B[3]-B[1]];else this.Bq.BD=A.qR(this.Bq.BD,Ad);}var fullScreenUpdate=
false;fullScreenUpdate=A.jI;if(fullScreenUpdate)Ad=[0,0,(B=this.M)[2]-B[0],B[3]-
B[1]];if(!!this.K){E.Y.AM.call(this,Ad);return;}Ad=A.il(A.tz(Ad,this.M.slice(0,2
)),this.M);if((Ad[0]>=Ad[2])||(Ad[1]>=Ad[3]))return;var H;for(H=0;H<this.AA;H=H+
1)if(!(((B=A.il(this.AE.Get(H),Ad))[0]>=B[2])||(B[1]>=B[3]))){this.AE.Set(H,A.qR(
this.AE.Get(H),Ad));this.AZ.Set(H,A.s9(this.AE.Get(H)));return;}if(this.AA<3){this.
AE.Set(this.AA,Ad);this.AZ.Set(this.AA,A.s9(Ad));this.AA=this.AA+1;return;}var Aq;
var A8;var Ey=0;var Ez=0;var Jd=2147483647;this.AE.Set(this.AA,Ad);this.AZ.Set(this.
AA,A.s9(Ad));for(Aq=0;Aq<=this.AA;Aq=Aq+1)for(A8=Aq+1;A8<=this.AA;A8=A8+1){var F$=
A.s9(A.qR(this.AE.Get(Aq),this.AE.Get(A8)));var Jr=((F$<<8)/(this.AZ.Get(Aq)+this.
AZ.Get(A8)))|0;if(Jr<Jd){Jd=Jr;Ey=Aq;Ez=A8;}}this.AE.Set(Ey,A.qR(this.AE.Get(Ey)
,this.AE.Get(Ez)));this.AZ.Set(Ey,A.s9(this.AE.Get(Ey)));if(Ez!==this.AA){this.AE.
Set(Ez,this.AE.Get(this.AA));this.AZ.Set(Ez,this.AZ.Get(this.AA));}},La:function(
){var AO=A._NewObject(E.Gk,0);AO.Eb=!!this.Ae;if(!!this.Ae)AO.Bt=this.Ae;return AO;
},Et:function(){var AO=A._NewObject(E.Gi,0);AO.Eb=!!this.Ae;if(!!this.Ae)AO.Bt=this.
Ae;return AO;},FJ:function(){var AO=A._NewObject(E.Gj,0);AO.Eb=!!this.Ae;if(!!this.
Ae)AO.Bt=this.Ae;return AO;},Lb:function(Cn){var H;var DE=false;for(H=0;H<10;H=H+
1)if(!!this.AK.Get(H)){var AY=this.CB.Get(H);var R=this.AK.Get(H).K;while(!!R&&(
R!==this)){AY=A.tw(AY,R.M.slice(0,2));R=R.K;}if(!R&&(this.AK.Get(H)!==this)){var
tmp=this.AK.Get(H);this.DB=H;this.AK.Set(H,null);tmp.AU(this.Et().InitializeUp(H
,this.DA.Get(H),this.C9.Get(H),this.Ck.Get(H),this.AX.Get(H)+1,this.CA.Get(H),false
,this.CB.Get(H),this.C8.Get(H)));if(tmp===this.Cj)this.Cj=null;this.BroadcastEvent(
this.FJ().InitializeUp(H,this.AX.Get(H)+1,false,tmp,this.CB.Get(H)),0x18);}else{
this.Ck.Set(H,(this.CL.Bt-this.Eu.Get(H))|0);if(this.Ck.Get(H)<10)this.Ck.Set(H,
10);this.DB=H;this.AK.Get(H).AU(this.Et().InitializeHold(H,AY,this.C9.Get(H),this.
Ck.Get(H),this.AX.Get(H)+1,this.CA.Get(H),this.CB.Get(H),this.C8.Get(H)));DE=true;
}}if(!DE)this.CL.Fk(false);},GetFPS:function(){var ticksCount=0;var Jj=0;ticksCount=((
new Date).getTime()-A.qt)|0;if(!!this.FO&&(ticksCount>this.FO))Jj=((this.FN*1000
)/((ticksCount-this.FO)|0))|0;this.FN=0;this.FO=ticksCount;return Jj;},Update:function(
){var B;if(!this.DU){this.DU=A._NewObject(A.Graphics.Canvas,0);this.DU.GJ([(B=this.
M)[2]-B[0],B[3]-B[1]]);}this.DU.Update();return this.UpdateGE20(this.DU);},UpdateGE20:
function(Az){if(!this.BeginUpdate())return At;var CE=this.UpdateCanvas(Az,Ab);this.
EndUpdate();return CE;},EndUpdate:function(){if(this.AA>0){this.FN=this.FN+1;this.
AA=0;}},UpdateCanvas:function(Az,aOffset){var B;var CE=At;var K_=[].concat(aOffset
,A.tx(Az.FrameSize,aOffset));var H;var Aq=this.AA;this.EM=this.EM+1;for(H=0;(H<Aq
)&&(H<4);H=H+1){if(this.AZ.Get(H)>0){this.BU(Az,A.ty(this.AE.Get(H),aOffset),[-aOffset[
0],-aOffset[1]],255,true);CE=A.qR(CE,A.il(K_,this.AE.Get(H)));}else Aq=Aq+1;}this.
EM=this.EM-1;if(!((CE[0]>=CE[2])||(CE[1]>=CE[3])))return A.ty(CE,aOffset);else return CE;
},GetUpdateRegion:function(FD){var H;var Aq=this.AA;if(FD<0)return At;for(H=0;(H<
Aq)&&(H<4);H=H+1){if(!this.AZ.Get(H)){Aq=Aq+1;FD=FD+1;}else if(H===FD)return this.
AE.Get(H);}return At;},BeginUpdate:function(){var Lf=true;var fullScreenUpdate=false;
var H;if((!Lf&&!fullScreenUpdate)&&(this.AA>0)){var Ju=A.tA(3,A.qy,null);var H0=
this.AA;for(H=0;H<H0;H=H+1)Ju.Set(H,this.AE.Get(H));for(H=0;H<this.Jn;H=H+1)this.
AM(this.FT.Get(H));for(H=0;H<H0;H=H+1)this.FT.Set(H,Ju.Get(H));this.Jn=H0;}var Aq;
var A8;for(Aq=0;Aq<(this.AA-1);Aq=Aq+1)if(this.AZ.Get(Aq)>0)for(A8=Aq+1;A8<this.
AA;A8=A8+1)if(this.AZ.Get(A8)>0){var F$=A.s9(A.qR(this.AE.Get(Aq),this.AE.Get(A8
)));if(((F$-this.AZ.Get(Aq))-this.AZ.Get(A8))<0){this.AE.Set(Aq,A.qR(this.AE.Get(
Aq),this.AE.Get(A8)));this.AZ.Set(Aq,F$);this.AZ.Set(A8,0);}}for(H=this.AA-1;H>=
0;H=H-1)if(!this.AZ.Get(H))this.AA=this.AA-1;return this.AA;},DoesNeedUpdate:function(
){if(this.AA>0)return true;return false;},Initialize:function(aSize){this.N([].concat(
Ab,aSize));if(this.HK)this.F=this.F|0x60;else this.F=this.F|0x20;this.AM(this.M);
return this;},SetRootFocus:function(Hu){if(Hu===this.HK)return false;this.HK=Hu;
if(!Hu){if(!!this.Bu)this.Bu.A3(0x0,0x40);if(!!this.CO)this.CO.Bb.A3(0x0,0x40);else
this.A3(0x0,0x40);}else{if(!!this.CO)this.CO.Bb.A3(0x40,0x0);else this.A3(0x40,0x0
);if(!!this.Bu)this.Bu.A3(0x40,0x0);}return true;},SetUserInputTimestamp:function(
K9){this.Ae=K9;},DriveKeyboardHitting:function(Av,Dv,Bp){var B;var HW=!!this.A9;
if(!!this.A9&&((!Bp||(this.Dc!==Av))||(this.CN!==Dv))){var AO=null;var G=(E.Ch.isPrototypeOf(
B=this.A9)?B:null);var BN=(E.Fh.isPrototypeOf(B=this.A9)?B:null);if(!!this.Dc)AO=
A._NewObject(E.KeyEvent,0).Initialize(this.Dc,false);if(this.CN!==0x00)AO=A._NewObject(
E.KeyEvent,0).Initialize2(this.CN,false);if(!!BN)BN.AU(AO);else if(!!G)G.AU(AO);
this.Dc=0;this.CN=0x00;this.A9=null;}if(!!this.A9){var AO=null;var G=(E.Ch.isPrototypeOf(
B=this.A9)?B:null);var BN=(E.Fh.isPrototypeOf(B=this.A9)?B:null);if(!!Av)AO=A._NewObject(
E.KeyEvent,0).Initialize(Av,true);if(this.CN!==0x00)AO=A._NewObject(E.KeyEvent,0
).Initialize2(Dv,true);if(!!BN)BN.AU(AO);else if(!!G)G.AU(AO);}if(this.FS&&((!Bp||(
this.Dc!==Av))||(this.CN!==Dv))){this.Dc=0;this.CN=0x00;this.FS=false;}if((!this.
A9&&Bp)&&(this.Hz>0)){this.Dc=Av;this.CN=Dv;this.FS=true;}if((!this.A9&&Bp)&&!this.
FS){if(!!Av)this.A9=this.DispatchEvent(A._NewObject(E.KeyEvent,0).Initialize(Av,
true));if(Dv!==0x00)this.A9=this.DispatchEvent(A._NewObject(E.KeyEvent,0).Initialize2(
Dv,true));if(!(E.Fh.isPrototypeOf(B=this.A9)?B:null)&&!(E.Ch.isPrototypeOf(B=this.
A9)?B:null))this.A9=null;this.Dc=Av;this.CN=Dv;HW=HW||!!this.A9;}this.Ae=0;return HW;
},DriveCursorMovement:function(AC){return this.DriveMultiTouchMovement(this.DB,AC
);},DriveMultiTouchMovement:function(J,AC){if((J<0)||(J>9)){this.Ae=0;return false;
}var ED=A.tw(AC,this.CB.Get(J));this.CB.Set(J,AC);if(!this.AK.Get(J)||A.tl(ED,Ab
)){this.Ae=0;return false;}var AY=AC;var R=this.AK.Get(J).K;while(!!R&&(R!==this
)){AY=A.tw(AY,R.M.slice(0,2));R=R.K;}if(!R&&(this.AK.Get(J)!==this)){var tmp=this.
AK.Get(J);this.DB=J;this.AK.Set(J,null);tmp.AU(this.Et().InitializeUp(J,this.DA.
Get(J),this.C9.Get(J),this.Ck.Get(J),this.AX.Get(J)+1,this.CA.Get(J),false,this.
CB.Get(J),this.C8.Get(J)));if(tmp===this.Cj)this.Cj=null;this.BroadcastEvent(this.
FJ().InitializeUp(J,this.AX.Get(J)+1,false,tmp,AC),0x18);}else{this.DA.Set(J,AY);
this.DB=J;this.AK.Get(J).AU(this.La().Initialize(J,AY,this.C9.Get(J),ED,this.Ck.
Get(J),this.AX.Get(J)+1,this.CA.Get(J),AC,this.C8.Get(J)));}this.Ae=0;return true;
},DriveCursorHitting:function(Bp,J,AC){return this.DriveMultiTouchHitting(Bp,J,AC
);},DriveMultiTouchHitting:function(Bp,J,AC){var B;if((J<0)||(J>9)){this.Ae=0;return false;
}var ticksCount=this.Ae;var Ev=[].concat([-this.EP,-this.EP],[this.EP+1,this.EP+
1]);if(!ticksCount){ticksCount=((new Date).getTime()-A.qt)|0;}var Lh=this.Ae;this.
DriveMultiTouchMovement(J,AC);AC=this.CB.Get(J);this.Ae=Lh;if(Bp)this.C8.Set(J,AC
);if((Bp&&!this.AK.Get(J))&&!this.Hz){var CC=null;var AY=AC;if(A.qu(this.FK.Get(
J),AC)&&((ticksCount-this.Eu.Get(J))<=(((B=this.Jy)<0)?B+0x100000000:B)))this.AX.
Set(J,this.AX.Get(J)+1);else this.AX.Set(J,0);this.FK.Set(J,A.tz(Ev,AC));this.Eu.
Set(J,ticksCount);if((!!this.Bu&&!!this.Bu.K)&&((this.Bu.F&0x18)===0x18)){var S=
A.tz(Ev,this.Bu.K.H$(AC));CC=this.Bu.Dn(S,J,this.AX.Get(J)+1,null,0x0);}if(!CC){
if(!!this.Cj&&!!this.Cj.K){if(((this.Cj.F&0x8)===0x8)&&((this.Cj.F&0x10)===0x10)
){var S=A.tz(Ev,this.Cj.K.H$(AC));CC=this.Cj.Dn(S,J,this.AX.Get(J)+1,null,0x0);}
}else if(!!this.CO)CC=this.Dn(A.tz(Ev,AC),J,this.AX.Get(J)+1,this.CO.Bb,0x0);else
CC=this.Dn(A.tz(Ev,AC),J,this.AX.Get(J)+1,null,0x0);}if(!!CC){this.BroadcastEvent(
this.FJ().InitializeDown(J,this.AX.Get(J)+1,false,CC.Ch,AC),0x18);this.AK.Set(J,
CC.Ch);this.CA.Set(J,CC.Gy);}else{this.AK.Set(J,null);this.CA.Set(J,Ab);this.Ae=
0;return false;}var R=CC.Ch.K;while(!!R&&(R!==this)){AY=A.tw(AY,R.M.slice(0,2));
R=R.K;}this.C9.Set(J,AY);this.DA.Set(J,AY);this.Ck.Set(J,0);this.CL.Fk(true);this.
DB=J;this.AK.Get(J).AU(this.Et().InitializeDown(J,AY,this.AX.Get(J)+1,this.CA.Get(
J),false,AC));this.Ae=0;return true;}if(!Bp&&!!this.AK.Get(J)){var AY=AC;var R=this.
AK.Get(J).K;while(!!R&&(R!==this)){AY=A.tw(AY,R.M.slice(0,2));R=R.K;}if(!R)AY=this.
DA.Get(J);this.DB=J;var tmp=this.AK.Get(J);this.AK.Set(J,null);tmp.AU(this.Et().
InitializeUp(J,AY,this.C9.Get(J),this.Ck.Get(J),this.AX.Get(J)+1,this.CA.Get(J),
false,AC,this.C8.Get(J)));this.BroadcastEvent(this.FJ().InitializeUp(J,this.AX.Get(
J)+1,false,tmp,AC),0x18);this.Ae=0;return true;}this.Ae=0;return false;},_Init:function(
aArg){E.Y._Init.call(this,aArg);E.Timer._Init.call(this.CL={L:this},0);(this.AK=[
]).__proto__=E.Root.AK;(this.AX=[]).__proto__=E.Root.AX;(this.FK=[]).__proto__=E.
Root.FK;(this.Ck=[]).__proto__=E.Root.Ck;(this.C9=[]).__proto__=E.Root.C9;(this.
Eu=[]).__proto__=E.Root.Eu;(this.DA=[]).__proto__=E.Root.DA;(this.CA=[]).__proto__=
E.Root.CA;(this.CB=[]).__proto__=E.Root.CB;(this.C8=[]).__proto__=E.Root.C8;(this.
FT=[]).__proto__=E.Root.FT;(this.AZ=[]).__proto__=E.Root.AZ;(this.AE=[]).__proto__=
E.Root.AE;this.__proto__=E.Root;this.F=0x7F;this.CL.JM(50);this.CL.Fo=[this,this.
Lb];},_Done:function(){this.__proto__=E.Y;this.CL._Done();E.Y._Done.call(this);}
,_ReInit:function(){E.Y._ReInit.call(this);this.CL._ReInit();},_Mark:function(D){
var B;E.Y._Mark.call(this,D);if((B=this.A9)&&(B._cycle!=D))B._Mark(B._cycle=D);if((
B=this.CO)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.Cj)&&(B._cycle!=D))B._Mark(
B._cycle=D);A.ts(this.AK,D);if((B=this.DU)&&(B._cycle!=D))B._Mark(B._cycle=D);if((
B=this.Bu)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.CL)._cycle!=D)B._Mark(B.
_cycle=D);},_className:"Core::Root"};E.Event={Bt:0,Eb:false,Fg:function(){var ticksCount=
0;ticksCount=((new Date).getTime()-A.qt)|0;return ticksCount;},Bf:function(aArg){
this.Bt=this.Fg();},_Init:function(aArg){this.__proto__=E.Event;this.Bf(aArg);A.
gv++;},_Done:function(){this.__proto__=null;A.gv--;},_ReInit:function(){},_Mark:
function(D){var B;if((B=this.L)&&(B._cycle!=D))B._Mark(B._cycle=D);},L:null,_cycle:
0,_observers:null,_className:"Core::Event"};E.KeyEvent={Ay:0,X:0,Down:false,Initialize2:
function(Av,Bp){this.Ay=0;this.X=Av;this.Down=Bp;if((Av>=0x30)&&(Av<=0x39))this.
Ay=(10+Av)-48;if((Av>=0x41)&&(Av<=0x5A))this.Ay=(105+Av)-65;if((Av>=0x61)&&(Av<=
0x7A))this.Ay=(105+Av)-97;if(Av===0x20)this.Ay=131;if(!this.Ay)switch(Av){case 0x2B:
this.Ay=132;break;case 0x2D:this.Ay=133;break;case 0x2A:this.Ay=134;break;case 0x2F:
this.Ay=135;break;case 0x3D:this.Ay=136;break;case 0x2E:this.Ay=137;break;case 0x2C:
this.Ay=138;break;case 0x3A:this.Ay=139;break;case 0x3B:this.Ay=140;break;default:;
}return this;},Initialize:function(Av,Bp){this.Ay=Av;this.Down=Bp;this.X=0x00;var
HB=Av-10;var HA=Av-105;if((HB>=0)&&(HB<=9))this.X=(48+HB)&0xFFFF;if((HA>=0)&&(HA<=
25))this.X=(65+HA)&0xFFFF;if(Av===131)this.X=0x20;if(this.X===0x00)switch(Av){case
132:this.X=0x2B;break;case 133:this.X=0x2D;break;case 134:this.X=0x2A;break;case
135:this.X=0x2F;break;case 136:this.X=0x3D;break;case 137:this.X=0x2E;break;case
138:this.X=0x2C;break;case 139:this.X=0x3A;break;case 140:this.X=0x3B;break;default:;
}return this;},JH:function(I_){switch(I_){case 141:return((this.X>=0x41)&&(this.
X<=0x5A))||((this.X>=0x61)&&(this.X<=0x7A));case 142:return(((this.X>=0x41)&&(this.
X<=0x5A))||((this.X>=0x61)&&(this.X<=0x7A)))||((this.X>=0x30)&&(this.X<=0x39));case
143:return(this.X>=0x30)&&(this.X<=0x39);case 144:return(((this.X>=0x41)&&(this.
X<=0x46))||((this.X>=0x61)&&(this.X<=0x66)))||((this.X>=0x30)&&(this.X<=0x39));case
145:return this.X!==0x00;case 146:return(this.X===0x00)&&!!this.Ay;case 147:return(((
this.Ay===6)||(this.Ay===7))||(this.Ay===4))||(this.Ay===5);case 148:return(this.
X!==0x00)||!!this.Ay;default:;}return I_===this.Ay;},_Init:function(aArg){E.Event.
_Init.call(this,aArg);this.__proto__=E.KeyEvent;},_className:"Core::KeyEvent"};E.
Gj={Hb:null,CY:A.qx,C0:0,CX:0,Down:false,D6:false,InitializeUp:function(J,Bw,Du,
Hy,BK){this.Down=false;this.CX=J;this.C0=Bw;this.CY=BK;this.Hb=Hy;this.D6=Du;return this;
},InitializeDown:function(J,Bw,Du,Hy,BK){this.Down=true;this.CX=J;this.C0=Bw;this.
CY=BK;this.Hb=Hy;this.D6=Du;return this;},_Init:function(aArg){E.Event._Init.call(
this,aArg);this.__proto__=E.Gj;},_Mark:function(D){var B;E.Event._Mark.call(this
,D);if((B=this.Hb)&&(B._cycle!=D))B._Mark(B._cycle=D);},_className:"Core::CursorGrabEvent"
};E.Gi={D_:A.qx,CY:A.qx,C0:0,Ea:0,D$:A.qx,D7:A.qx,CX:0,Down:false,D6:false,InitializeHold:
function(J,C6,Eo,Ep,Bw,Ci,BK,En){this.Down=true;this.CX=J;this.D7=A.tx(C6,Ci);this.
D$=A.tx(Eo,Ci);this.Ea=Ep;this.C0=Bw;this.CY=BK;this.D_=En;return this;},InitializeUp:
function(J,C6,Eo,Ep,Bw,Ci,Du,BK,En){this.Down=false;this.CX=J;this.D7=A.tx(C6,Ci
);this.D$=A.tx(Eo,Ci);this.Ea=Ep;this.C0=Bw;this.D6=Du;this.CY=BK;this.D_=En;return this;
},InitializeDown:function(J,C6,Bw,Ci,Du,BK){this.Down=true;this.CX=J;this.D7=A.tx(
C6,Ci);this.D$=A.tx(C6,Ci);this.Ea=0;this.C0=Bw;this.D6=Du;this.CY=BK;this.D_=BK;
return this;},_Init:function(aArg){E.Event._Init.call(this,aArg);this.__proto__=
E.Gi;},_className:"Core::CursorEvent"};E.Gk={D_:A.qx,CY:A.qx,C0:0,Ea:0,Gy:A.qx,D$:
A.qx,D7:A.qx,CX:0,Initialize:function(J,C6,Eo,aOffset,Ep,K8,Ci,BK,En){this.CX=J;
this.D7=A.tx(C6,Ci);this.D$=A.tx(Eo,Ci);this.Gy=aOffset;this.Ea=Ep;this.C0=K8;this.
CY=BK;this.D_=En;return this;},_Init:function(aArg){E.Event._Init.call(this,aArg
);this.__proto__=E.Gk;},_className:"Core::DragEvent"};E.Ed={Cq:null,Ef:A.qx,JW:0
,JU:0,Space:0,E1:0,BU:function(Az,aClip,aOffset,AF,aBlend){},N:function(C){var B;
if(A.tm(C,this.M))return;var Dg=[(B=this.M)[2]-B[0],B[3]-B[1]];var FV=[C[2]-C[0]
,C[3]-C[1]];var DI=!A.tl(Dg,FV);var ED=A.tw(C.slice(0,2),this.M.slice(0,2));if(!
A.tl(ED,Ab)&&!DI){var G=this.T;while(!!G&&!((G.F&0x200)===0x200)){if(((G.F&0x400
)===0x400)){var tmp=((G.F&0x100)===0x100);G.Ia(ED,tmp);}G=G.T;}A.lq(this.Cq,this
);}if((DI&&(Dg[0]>0))&&(Dg[1]>0)){var Ap=A.tz(this.M,this.Ef);var G=this.T;var Ex=
0x14;while(!!G&&!((G.F&0x200)===0x200)){if(((G.F&0x400)===0x400)){if(!!G.AI&&(G.
AI.DZ!==this))G.AI=null;if(!G.AI&&((G.AJ!==Ex)||!!this.E1))G.FP(Ap,this);}G=G.T;
}A.lq(this.Cq,this);}E.AV.N.call(this,C);if(!!this.K&&DI){this.F=this.F|0x1000;if(
!((this.K.F&0x2000)===0x2000)){this.K.F=this.K.F|0x4000;A.lq([B=this.K,B.Bl],this
);}}},_Init:function(aArg){E.AV._Init.call(this,aArg);this.__proto__=E.Ed;this.F=
0x203;},_Mark:function(D){var B;E.AV._Mark.call(this,D);if((B=this.Cq)&&((B=B[0]
)._cycle!=D))B._Mark(B._cycle=D);},_className:"Core::Outline"};E.Fh={T:null,IP:null
,IO:null,IN:null,DH:0,Bt:0,I2:0,JC:148,Ay:0,X:0,DM:true,Down:false,G$:false,EO:false
,AU:function(V){var B;if(!!V&&V.JH(this.JC)){this.Down=V.Down;this.Ay=V.Ay;this.
X=V.X;this.Bt=V.Bt;this.EO=false;if(V.Down){this.I2=this.DH;this.G$=this.DH>0;if(
this.G$)(B=this.IN)?B[1].call(B[0],this):null;else(B=this.IO)?B[1].call(B[0],this
):null;if(!this.EO)this.DH=this.DH+1;return!this.EO;}if(!V.Down){this.G$=this.DH>
1;this.I2=this.DH-1;this.DH=0;(B=this.IP)?B[1].call(B[0],this):null;return!this.
EO;}}return false;},Bf:function(aArg){var B;var Bb=(E.Y.isPrototypeOf(B=this.L)?
B:null);if(!Bb)throw new Error(Hr);this.T=Bb.FR;Bb.FR=this;},_Init:function(aArg
){this.__proto__=E.Fh;this.Bf(aArg);A.gv++;},_Done:function(){this.__proto__=null;
A.gv--;},_ReInit:function(){},_Mark:function(D){var B;if((B=this.T)&&(B._cycle!=
D))B._Mark(B._cycle=D);if((B=this.IP)&&((B=B[0])._cycle!=D))B._Mark(B._cycle=D);
if((B=this.IO)&&((B=B[0])._cycle!=D))B._Mark(B._cycle=D);if((B=this.IN)&&((B=B[0
])._cycle!=D))B._Mark(B._cycle=D);if((B=this.L)&&(B._cycle!=D))B._Mark(B._cycle=
D);},L:null,_cycle:0,_observers:null,_className:"Core::KeyPressHandler"};E.Jx={Ch:
null,EU:0,Gy:A.qx,_Init:function(aArg){this.__proto__=E.Jx;A.gv++;},_Done:function(
){this.__proto__=null;A.gv--;},_ReInit:function(){},_Mark:function(D){var B;if((
B=this.Ch)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.L)&&(B._cycle!=D))B._Mark(
B._cycle=D);},L:null,_cycle:0,_observers:null,_className:"Core::CursorHit"};E.JI={
Bb:null,_Init:function(aArg){this.__proto__=E.JI;A.gv++;},_Done:function(){this.
__proto__=null;A.gv--;},_ReInit:function(){},_Mark:function(D){var B;if((B=this.
Bb)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.L)&&(B._cycle!=D))B._Mark(B._cycle=
D);},L:null,_cycle:0,_observers:null,_className:"Core::ModalContext"};E.H_={DZ:null
,Db:A.qy,Ap:A.qy,isEmpty:false,_Init:function(aArg){this.__proto__=E.H_;A.gv++;}
,_Done:function(){this.__proto__=null;A.gv--;},_ReInit:function(){},_Mark:function(
D){var B;if((B=this.DZ)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.L)&&(B._cycle
!=D))B._Mark(B._cycle=D);},L:null,_cycle:0,_observers:null,_className:"Core::LayoutContext"
};E.Jz={Bb:null,_Init:function(aArg){this.__proto__=E.Jz;A.gv++;},_Done:function(
){this.__proto__=null;A.gv--;},_ReInit:function(){},_Mark:function(D){var B;if((
B=this.Bb)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.L)&&(B._cycle!=D))B._Mark(
B._cycle=D);},L:null,_cycle:0,_observers:null,_className:"Core::DialogContext"};
E.JY={HD:null,Ba:null,_Init:function(aArg){this.__proto__=E.JY;A.gv++;},_Done:function(
){this.__proto__=null;A.gv--;},_ReInit:function(){},_Mark:function(D){var B;if((
B=this.HD)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.Ba)&&(B._cycle!=D))B._Mark(
B._cycle=D);if((B=this.L)&&(B._cycle!=D))B._Mark(B._cycle=D);},L:null,_cycle:0,_observers:
null,_className:"Core::TaskQueue"};E.JX={_Init:function(aArg){this.__proto__=E.JX;
A.gv++;},_Done:function(){this.__proto__=null;A.gv--;},_ReInit:function(){},_Mark:
function(D){var B;if((B=this.L)&&(B._cycle!=D))B._Mark(B._cycle=D);},L:null,_cycle:
0,_observers:null,_className:"Core::Task"};E.CG={resource:null,BT:function(){this.
resource=null;},Bf:function(aArg){this.resource=aArg;},_Init:function(aArg){this.
__proto__=E.CG;this.Bf(aArg);A.gv++;},_Done:function(){this.BT();this.__proto__=
null;A.gv--;},_ReInit:function(){},_Mark:function(D){var B;if((B=this.L)&&(B._cycle
!=D))B._Mark(B._cycle=D);},L:null,_cycle:0,_observers:null,_className:"Core::Resource"
};E.Timer={Fo:null,timer:null,Bt:0,Period:1000,H2:0,DM:false,BT:function(){var tmp=
this.timer;if(!!tmp)tmp.DestroyTimer();this.timer=null;},HY:function(aBegin,aPeriod
){if(aBegin<0)aBegin=0;if(aPeriod<0)aPeriod=0;var tmp=this.timer;if(!tmp&&((aBegin>
0)||(aPeriod>0)))tmp=A.sL(this,this.Trigger);if(!!tmp){tmp.ResetTimer();tmp.StartTimer(
aBegin,aPeriod);}this.timer=tmp;},JM:function(C){if(C<0)C=0;if(C===this.Period)return;
this.Period=C;if(this.DM)this.HY(this.H2,C);},Fk:function(C){if(C===this.DM)return;
this.DM=C;if(C)this.HY(this.H2,this.Period);else this.HY(0,0);this.Bt=this.Fg();
},Fg:function(){var ticksCount=0;ticksCount=((new Date).getTime()-A.qt)|0;return ticksCount;
},Trigger:function(){var B;this.Bt=this.Fg();if(!this.Period)this.Fk(false);(B=this.
Fo)?B[1].call(B[0],this):null;},_Init:function(aArg){this.__proto__=E.Timer;A.gv++;
},_Done:function(){this.BT();this.__proto__=null;A.gv--;},_ReInit:function(){},_Mark:
function(D){var B;if((B=this.Fo)&&((B=B[0])._cycle!=D))B._Mark(B._cycle=D);if((B=
this.L)&&(B._cycle!=D))B._Mark(B._cycle=D);},L:null,_cycle:0,_observers:null,_className:
"Core::Timer"};E.Mg={Mh:0x1,Lz:0x2,LI:0x4,Mc:0x8,DM:0x10,L8:0x20,LJ:0x40,LR:0x80
,LH:0x100,LM:0x200,LG:0x400,LX:0x800,Fw:0x1000,Me:0x2000,LV:0x4000,LW:0x8000,LE:
0x10000,LU:0x20000,L7:0x40000};E.AJ={LY:0x1,LZ:0x2,Lp:0x4,Lq:0x8,Lr:0x10,Lo:0x20
};E.E1={LS:0,L$:1,LB:2,LN:3,L1:4,Ma:5,Mb:6,LC:7,LD:8,LP:9,LO:10,L3:11,L2:12};E.KeyCode={
NoKey:0,Ok:1,Exit:2,Menu:3,Up:4,Down:5,Left:6,Right:7,PageUp:8,PageDown:9,Key0:10
,Key1:11,Key2:12,Key3:13,Key4:14,Key5:15,Key6:16,Key7:17,Key8:18,Key9:19,Red:20,
Green:21,Blue:22,Yellow:23,White:24,Magenta:25,F1:26,F2:27,F3:28,F4:29,F5:30,F6:
31,F7:32,F8:33,F9:34,F10:35,ChannelUp:36,ChannelDown:37,Display:38,SkipPrev:39,SkipNext:
40,Home:41,End:42,Insert:43,Delete:44,Clear:45,VolumeUp:46,VolumeDown:47,Show:48
,Hide:49,Play:50,Pause:51,Record:52,Stop:53,Rev:54,Fwd:55,SlowRev:56,SlowFwd:57,
SkipBwd:58,SkipFwd:59,Repeat:60,Eject:61,Help:62,TV:63,DVD:64,VCR:65,EPG:66,OSD:
67,Text:68,PIP:69,Audio:70,Clock:71,Timer:72,Navigation:73,Karaoke:74,Game:75,Subtitle:
76,Zoom:77,Index:78,Info:79,Power:80,Setup:81,Angle:82,Mode:83,Mute:84,User0:85,
User1:86,User2:87,User3:88,User4:89,User5:90,User6:91,User7:92,User8:93,User9:94
,User10:95,User11:96,User12:97,User13:98,User14:99,User15:100,User16:101,User17:
102,User18:103,User19:104,KeyA:105,KeyB:106,KeyC:107,KeyD:108,KeyE:109,KeyF:110,
KeyG:111,KeyH:112,KeyI:113,KeyJ:114,KeyK:115,KeyL:116,KeyM:117,KeyN:118,KeyO:119
,KeyP:120,KeyQ:121,KeyR:122,KeyS:123,KeyT:124,KeyU:125,KeyV:126,KeyW:127,KeyX:128
,KeyY:129,KeyZ:130,Space:131,Plus:132,Minus:133,Multiply:134,Divide:135,Equals:136
,Period:137,Comma:138,Colon:139,Semicolon:140,AlphaKeys:141,AlphaOrDigitKeys:142
,DigitKeys:143,HexDigitKeys:144,CharacterKeys:145,ControlKeys:146,CursorKeys:147
,AnyKey:148,Enter:149,Escape:150,Backspace:151,Tab:152,CtrlKeyA:153,CtrlKeyB:154
,CtrlKeyC:155,CtrlKeyD:156,CtrlKeyE:157,CtrlKeyF:158,CtrlKeyG:159,CtrlKeyH:160,CtrlKeyI:
161,CtrlKeyJ:162,CtrlKeyK:163,CtrlKeyL:164,CtrlKeyM:165,CtrlKeyN:166,CtrlKeyO:167
,CtrlKeyP:168,CtrlKeyQ:169,CtrlKeyR:170,CtrlKeyS:171,CtrlKeyT:172,CtrlKeyU:173,CtrlKeyV:
174,CtrlKeyW:175,CtrlKeyX:176,CtrlKeyY:177,CtrlKeyZ:178,CtrlSpace:179,CtrlKey0:180
,CtrlKey1:181,CtrlKey2:182,CtrlKey3:183,CtrlKey4:184,CtrlKey5:185,CtrlKey6:186,CtrlKey7:
187,CtrlKey8:188,CtrlKey9:189,CtrlF1:190,CtrlF2:191,CtrlF3:192,CtrlF4:193,CtrlF5:
194,CtrlF6:195,CtrlF7:196,CtrlF8:197,CtrlF9:198,CtrlF10:199,CtrlEnter:200,CtrlEscape:
201,CtrlUp:202,CtrlDown:203,CtrlLeft:204,CtrlRight:205,CtrlPageUp:206,CtrlPageDown:
207,CtrlBackspace:208,CtrlInsert:209,CtrlDelete:210,CtrlHome:211,CtrlEnd:212,CtrlTab:
213,CtrlShiftKeyA:214,CtrlShiftKeyB:215,CtrlShiftKeyC:216,CtrlShiftKeyD:217,CtrlShiftKeyE:
218,CtrlShiftKeyF:219,CtrlShiftKeyG:220,CtrlShiftKeyH:221,CtrlShiftKeyI:222,CtrlShiftKeyJ:
223,CtrlShiftKeyK:224,CtrlShiftKeyL:225,CtrlShiftKeyM:226,CtrlShiftKeyN:227,CtrlShiftKeyO:
228,CtrlShiftKeyP:229,CtrlShiftKeyQ:230,CtrlShiftKeyR:231,CtrlShiftKeyS:232,CtrlShiftKeyT:
233,CtrlShiftKeyU:234,CtrlShiftKeyV:235,CtrlShiftKeyW:236,CtrlShiftKeyX:237,CtrlShiftKeyY:
238,CtrlShiftKeyZ:239,CtrlShiftSpace:240,CtrlShiftKey0:241,CtrlShiftKey1:242,CtrlShiftKey2:
243,CtrlShiftKey3:244,CtrlShiftKey4:245,CtrlShiftKey5:246,CtrlShiftKey6:247,CtrlShiftKey7:
248,CtrlShiftKey8:249,CtrlShiftKey9:250,CtrlShiftF1:251,CtrlShiftF2:252,CtrlShiftF3:
253,CtrlShiftF4:254,CtrlShiftF5:255,CtrlShiftF6:256,CtrlShiftF7:257,CtrlShiftF8:
258,CtrlShiftF9:259,CtrlShiftF10:260,CtrlShiftEnter:261,CtrlShiftEscape:262,CtrlShiftUp:
263,CtrlShiftDown:264,CtrlShiftLeft:265,CtrlShiftRight:266,CtrlShiftPageUp:267,CtrlShiftPageDown:
268,CtrlShiftBackspace:269,CtrlShiftInsert:270,CtrlShiftDelete:271,CtrlShiftHome:
272,CtrlShiftEnd:273,CtrlShiftTab:274,AltF1:275,AltF2:276,AltF3:277,AltF4:278,AltF5:
279,AltF6:280,AltF7:281,AltF8:282,AltF9:283,AltF10:284,AltEnter:285,AltEscape:286
,AltUp:287,AltDown:288,AltLeft:289,AltRight:290,AltPageUp:291,AltPageDown:292,AltBackspace:
293,AltInsert:294,AltDelete:295,AltHome:296,AltEnd:297,AltTab:298,AltShiftF1:299
,AltShiftF2:300,AltShiftF3:301,AltShiftF4:302,AltShiftF5:303,AltShiftF6:304,AltShiftF7:
305,AltShiftF8:306,AltShiftF9:307,AltShiftF10:308,AltShiftEnter:309,AltShiftEscape:
310,AltShiftUp:311,AltShiftDown:312,AltShiftLeft:313,AltShiftRight:314,AltShiftPageUp:
315,AltShiftPageDown:316,AltShiftBackspace:317,AltShiftInsert:318,AltShiftDelete:
319,AltShiftHome:320,AltShiftEnd:321,AltShiftTab:322,ShiftF1:323,ShiftF2:324,ShiftF3:
325,ShiftF4:326,ShiftF5:327,ShiftF6:328,ShiftF7:329,ShiftF8:330,ShiftF9:331,ShiftF10:
332,ShiftEnter:333,ShiftEscape:334,ShiftUp:335,ShiftDown:336,ShiftLeft:337,ShiftRight:
338,ShiftPageUp:339,ShiftPageDown:340,ShiftBackspace:341,ShiftInsert:342,ShiftDelete:
343,ShiftHome:344,ShiftEnd:345,ShiftTab:346};E.L0={Ml:0x1,Mi:0x2,Mj:0x4,Mk:0x8,LQ:
0x10,LK:0x20};
E._Init=function(){E.AV.__proto__=E.Ch;E.Y.__proto__=E.AV;E.Root.__proto__=E.Y;E.
KeyEvent.__proto__=E.Event;E.Gj.__proto__=E.Event;E.Gi.__proto__=E.Event;E.Gk.__proto__=
E.Event;E.Ed.__proto__=E.AV;};E.Au=function(D){};return E;})();

/* Embedded Wizard */