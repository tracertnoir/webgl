/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.Core)throw new Error("The unit file 'Core.js' included twice!");EmWiApp.
Core=(function(){var A=EmWiApp;var E={};
var Ab=[0,0];var At=[0,0,0,0];var Cr="The view does not belong to this group";var
Dr="No view to restack";var DR="View is not in this group";var Hk="No view to remove";
var Hl="No view to add";var Hm="View already in a group";var Hn="Recursive invalidate during active update cycle.";
var Ho="The KeyPressHandler is embedded within an object not being derived "+"from Core::Group.";
E.Ch={T:null,O:null,K:null,AI:null,F:0x103,BH:0,AJ:0x14,FN:function(Ac,I8){},JJ:function(
C){if(this.BH===C)return;this.BH=C;if(!!this.K){var CP=this.T;var A5=0;while(!!CP&&(
C>CP.BH)){CP=CP.T;A5=A5+1;}CP=this.O;while(!!CP&&(C<CP.BH)){CP=CP.O;A5=A5-1;}if(
!!A5)this.K.JO(this,A5);}},Eb:function(C){var B;var A5=C^this.AJ;if(!A5)return;this.
AJ=C;if(!!this.AI&&!((this.F&0x400)===0x400)){this.K.F=this.K.F|0x5000;A.lq([B=this.
K,B.Bl],this);this.K.AM([0,0,(B=this.K.M)[2]-B[0],B[3]-B[1]]);}if(!!this.AI&&((this.
F&0x400)===0x400)){this.AI.DY.F=this.AI.DY.F|0x1000;this.K.F=this.K.F|0x4000;A.lq([
B=this.K,B.Bl],this);}},BU:function(Az,aClip,aOffset,AF,aBlend){},AT:function(V){
return null;},Dl:function(Ad,J,Bw,Hp,Hu){return null;},Ga:function(Ac,Dv){return Ab;
},H9:function(aOffset,I7){},GetExtent:function(){return At;},A3:function(CI,Du){
var B;if(((this.F&0x200)===0x200))CI=CI&~0x400;var HM=(this.F&~Du)|CI;var C8=HM^
this.F;this.F=HM;if(!!this.K&&!!(C8&0x14)){var Je=((this.F&0x14)===0x14);if(Je&&
!this.K.Bs)this.K.DN(this);if(!Je&&(this.K.Bs===this))this.K.DN(this.K.H3(this,0x14
));}if(!!this.K&&!!(C8&0x403))this.K.AM(this.GetExtent());if(((!!this.AI&&!!this.
K)&&((HM&0x400)===0x400))&&((C8&0x1)===0x1)){this.F=this.F|0x800;this.K.F=this.K.
F|0x4000;A.lq([B=this.K,B.Bl],this);}if(!!this.K&&((C8&0x400)===0x400)){this.AI=
null;this.F=this.F|0x800;this.K.F=this.K.F|0x4000;A.lq([B=this.K,B.Bl],this);}},
_Init:function(aArg){this.__proto__=E.Ch;A.gv++;},_Done:function(){this.__proto__=
null;A.gv--;},_ReInit:function(){},_Mark:function(D){var B;if((B=this.T)&&(B._cycle
!=D))B._Mark(B._cycle=D);if((B=this.O)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=
this.K)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.AI)&&(B._cycle!=D))B._Mark(
B._cycle=D);if((B=this.L)&&(B._cycle!=D))B._Mark(B._cycle=D);},L:null,_cycle:0,_observers:
null,_className:"Core::View"};E.AU={M:A.qy,FN:function(Ac,I8){var AP=A._NewObject(
E.H7,0);AP.C$=this.M;AP.Ap=Ac;AP.DY=I8;this.AI=AP;},Ga:function(Ac,Dv){var B;var
BO=this.AJ;var AP=this.AI;var Ar=AP.C$[0];var As=AP.C$[1];var Ag=AP.C$[2];var Ah=
AP.C$[3];var C_=[Ac[2]-Ac[0],Ac[3]-Ac[1]];var Be=Ag-Ar;var Bc=Ah-As;if(!Dv){var D1=[(
B=AP.Ap)[2]-B[0],B[3]-B[1]];Ar=Ar-AP.Ap[0];As=As-AP.Ap[1];if(D1[0]!==C_[0]){var Ct=((
BO&0x4)===0x4);var Cu=((BO&0x8)===0x8);var EE=((BO&0x1)===0x1);if(!Ct&&(EE||!Cu)
)Ar=((Ar*C_[0])/D1[0])|0;if(!Cu&&(EE||!Ct)){Ag=Ag-AP.Ap[0];Ag=((Ag*C_[0])/D1[0])|
0;Ag=Ag-C_[0];}else Ag=Ag-AP.Ap[2];Ar=Ar+Ac[0];Ag=Ag+Ac[2];if(!EE){if(Ct&&!Cu)Ag=
Ar+Be;else if(!Ct&&Cu)Ar=Ag-Be;else{Ar=Ar+((((Ag-Ar)-Be)/2)|0);Ag=Ar+Be;}}}else{
Ag=Ag-AP.Ap[2];Ar=Ar+Ac[0];Ag=Ag+Ac[2];}if(D1[1]!==C_[1]){var Cv=((BO&0x10)===0x10
);var Cs=((BO&0x20)===0x20);var EF=((BO&0x2)===0x2);if(!Cv&&(EF||!Cs))As=((As*C_[
1])/D1[1])|0;if(!Cs&&(EF||!Cv)){Ah=Ah-AP.Ap[1];Ah=((Ah*C_[1])/D1[1])|0;Ah=Ah-C_[
1];}else Ah=Ah-AP.Ap[3];As=As+Ac[1];Ah=Ah+Ac[3];if(!EF){if(Cv&&!Cs)Ah=As+Bc;else
if(!Cv&&Cs)As=Ah-Bc;else{As=As+((((Ah-As)-Bc)/2)|0);Ah=As+Bc;}}}else{Ah=Ah-AP.Ap[
3];As=As+Ac[1];Ah=Ah+Ac[3];}}else{switch(Dv){case 3:{Ar=Ac[0];Ag=Ar+Be;}break;case
4:{Ag=Ac[2];Ar=Ag-Be;}break;case 1:{As=Ac[1];Ah=As+Bc;}break;case 2:{Ah=Ac[3];As=
Ah-Bc;}break;default:;}if((Dv===3)||(Dv===4)){var Cv=((BO&0x10)===0x10);var Cs=((
BO&0x20)===0x20);var EF=((BO&0x2)===0x2);if(EF){As=Ac[1];Ah=Ac[3];}else if(Cv&&!
Cs){As=Ac[1];Ah=As+Bc;}else if(Cs&&!Cv){Ah=Ac[3];As=Ah-Bc;}else{As=Ac[1]+((((Ac[
3]-Ac[1])-Bc)/2)|0);Ah=As+Bc;}}if((Dv===1)||(Dv===2)){var Ct=((BO&0x4)===0x4);var
Cu=((BO&0x8)===0x8);var EE=((BO&0x1)===0x1);if(EE){Ar=Ac[0];Ag=Ac[2];}else if(Ct&&
!Cu){Ar=Ac[0];Ag=Ar+Be;}else if(Cu&&!Ct){Ag=Ac[2];Ar=Ag-Be;}else{Ar=Ac[0]+((((Ac[
2]-Ac[0])-Be)/2)|0);Ag=Ar+Be;}}}AP.isEmpty=(Ar>=Ag)||(As>=Ah);if(((this.F&0x100)===
0x100)){this.M=[Ar,As,Ag,Ah];}else{this.N([Ar,As,Ag,Ah]);this.AI=AP;}return[Ag-Ar
,Ah-As];},H9:function(aOffset,I7){if(I7)this.M=A.tz(this.M,aOffset);else this.N(
A.tz(this.M,aOffset));},GetExtent:function(){return this.M;},N:function(C){var B;
if(A.tm(C,this.M))return;if(!!this.K&&((this.F&0x1)===0x1))this.K.AM(this.M);this.
AI=null;this.M=C;if(!!this.K&&((this.F&0x1)===0x1))this.K.AM(this.M);if((!!this.
K&&((this.F&0x400)===0x400))&&!((this.K.F&0x2000)===0x2000)){this.F=this.F|0x800;
this.K.F=this.K.F|0x4000;A.lq([B=this.K,B.Bl],this);}},_Init:function(aArg){E.Ch.
_Init.call(this,aArg);this.__proto__=E.AU;},_className:"Core::RectView"};E.Y={Ba:
null,AR:null,FP:null,Bq:null,C9:null,DB:null,Bs:null,Fn:255,BU:function(Az,aClip
,aOffset,AF,aBlend){var B;AF=((AF+1)*this.Fn)>>8;aBlend=aBlend&&((this.F&0x2)===
0x2);if(!this.Bq)this.K8(Az,aClip,A.tx(aOffset,this.M.slice(0,2)),AF,aBlend);else{
var A4=255|(255<<8)|(255<<16)|((AF&0xFF)<<24);this.Bq.Update();Az.Js(aClip,this.
Bq,0,A.tz(this.M,aOffset),Ab,A4,A4,A4,A4,aBlend);}},Dl:function(Ad,J,Bw,Hp,Hu){var
B;var G=this.AR;var DC=null;var S=At;var Ax=null;var HL=!!this.DB&&(!!this.DB.HA||
!!this.DB.Ba);if(((B=A.il(Ad,this.M))[0]>=B[2])||(B[1]>=B[3]))return null;Ad=A.ty(
Ad,this.M.slice(0,2));while(!!G){if(((G.F&0x400)===0x400)&&!Ax){Ax=G.O;while(!!Ax&&
!((Ax.F&0x200)===0x200))Ax=Ax.O;if(!!Ax)S=A.il(Ad,Ax.GetExtent());else S=At;}if(
Ax===G){Ax=null;S=At;}if((((((G.F&0x8)===0x8)&&((G.F&0x10)===0x10))&&!((G.F&0x40000
)===0x40000))&&!((G.F&0x20000)===0x20000))&&(!((G.F&0x10000)===0x10000)||((this.
C9.Bb===G)&&!HL))){var C$=G.GetExtent();var FJ=Hp;var DA=null;if(FJ===G)FJ=null;
if(((G.F&0x400)===0x400)){if(!(((B=A.il(C$,S))[0]>=B[2])||(B[1]>=B[3])))DA=G.Dl(
S,J,Bw,FJ,Hu);}else{if(!(((B=A.il(C$,Ad))[0]>=B[2])||(B[1]>=B[3]))||(Hp===G))DA=
G.Dl(Ad,J,Bw,FJ,Hu);}G=G.O;if(!!DA){if(!DC||((DA.ET<DC.ET)&&(DA.ET>=0)))DC=DA;if(
!DA.ET)G=null;}}else G=G.O;}return DC;},A3:function(CI,Du){var B;var K_=this.F;E.
AU.A3.call(this,CI,Du);var C8=this.F^K_;if(!!this.Bs&&((C8&0x40)===0x40)){if(((this.
F&0x40)===0x40))this.Bs.A3(0x40,0x0);else this.Bs.A3(0x0,0x40);}if(!!this.C9&&((
C8&0x40)===0x40)){if(((this.F&0x40)===0x40)&&((this.C9.Bb.F&0x14)===0x14))this.C9.
Bb.A3(0x40,0x0);else this.C9.Bb.A3(0x0,0x40);}if(!!C8){this.F=this.F|0x8000;A.lq([
this,this.Bl],this);}},N:function(C){var B;if(A.tm(C,this.M))return;var De=[(B=this.
M)[2]-B[0],B[3]-B[1]];var FT=[C[2]-C[0],C[3]-C[1]];var DG=!A.tl(De,FT);if(DG&&!!
this.Bq){this.Bq.GF(FT);A.qw(this,0);A.qw(this.Bq,0);}E.AU.N.call(this,C);if((DG&&(
De[0]>0))&&(De[1]>0)){var Ap=[].concat(Ab,De);var G=this.Ba;var Ew=0x14;while(!!
G){if((!G.AI&&(G.AJ!==Ew))&&!((G.F&0x400)===0x400))G.FN(Ap,null);G=G.T;}}if(DG){
this.F=this.F|0x5000;A.lq([this,this.Bl],this);}},HS:function(V){var Jg=(E.KeyEvent.
isPrototypeOf(V)?V:null);var BN=this.FP;if(!Jg)return null;while(!!BN&&(!BN.DK||
!BN.AT(Jg)))BN=BN.T;return BN;},K8:function(Az,aClip,aOffset,AF,aBlend){var B;var
G=this.Ba;var Jc=At;var Jm=true;while(!!G){if(((G.F&0x200)===0x200)){var Jl=(E.Ec.
isPrototypeOf(G)?G:null);Jc=A.il(aClip,A.tz(Jl.M,aOffset));Jm=((Jl.F&0x1)===0x1);
}if(((G.F&0x1)===0x1)){if(((G.F&0x400)===0x400)){if(Jm){var S=A.il(A.tz(G.GetExtent(
),aOffset),Jc);if(!((S[0]>=S[2])||(S[1]>=S[3])))G.BU(Az,S,aOffset,AF,aBlend);}}else{
var S=A.il(A.tz(G.GetExtent(),aOffset),aClip);if(!((S[0]>=S[2])||(S[1]>=S[3])))G.
BU(Az,S,aOffset,AF,aBlend);}}G=G.T;}},La:function(){var B;var HG=((this.F&0x1000
)===0x1000);var CL=[0,0,(B=this.M)[2]-B[0],B[3]-B[1]];var BL=false;var Cl=At;var
AG=At;var BM=Ab;var DV=0;var DW=0;var DU=0;var A6=0;var G=this.AR;var Ax=null;var
Ew=0x14;var Db=null;while(!!G){if(((G.F&0x800)===0x800)){BL=true;G.F=G.F&~0x800;
}if(BL&&((G.F&0x200)===0x200)){BL=false;if(!!(E.Ec.isPrototypeOf(G)?G:null).E0)G.
F=G.F|0x1000;}G=G.O;}BL=false;G=this.Ba;if(HG){this.F=this.F&~0x1000;HG=!((CL[0]>=
CL[2])||(CL[1]>=CL[3]));}this.F=this.F|0x2000;while(!!G){if(!Db&&(DU!==A6)){var Cp=
G;var FW=0;var EI=Cl[2]-Cl[0];var Er=Cl[3]-Cl[1];var FG=0;var DJ=Ab;do{if(((Cp.F&
0x200)===0x200))Cp=null;else if(((Cp.F&0x401)===0x401)){DJ=[(B=Cp.GetExtent())[2
]-B[0],B[3]-B[1]];if((A6===3)||(A6===4))EI=EI-DJ[0];if((A6===1)||(A6===2))Er=Er-
DJ[1];if(!Db||((EI>=0)&&(Er>=0))){Db=Cp;Cp=Cp.T;if((A6===3)||(A6===4)){EI=EI-DV;
if(DJ[1]>FW)FW=DJ[1];}if((A6===1)||(A6===2)){Er=Er-DW;if(DJ[0]>FG)FG=DJ[0];}}else
Cp=null;}else Cp=Cp.T;}while(!!Cp);if(!Db)Db=Ax;AG=Cl;switch(DU){case 9:case 11:
AG=[].concat(AG.slice(0,3),AG[1]+FW);break;case 10:case 12:AG=A.t3(AG,AG[3]-FW);
break;case 5:case 7:AG=A.t1(AG,AG[0]+FG);break;case 6:case 8:AG=[].concat(AG[2]-
FG,AG.slice(1,4));break;default:;}}if(((G.F&0x400)===0x400)){if(!!G.AI&&(G.AI.DY
!==Ax))G.AI=null;if((!G.AI&&BL)&&((G.AJ!==Ew)||!!A6))G.FN(AG,Ax);}if(!!G.AI){if(
HG&&!((G.F&0x400)===0x400))G.Ga(CL,0);if(BL&&((G.F&0x400)===0x400)){var FZ=G.Ga(
A.tz(AG,BM),A6);if(((G.F&0x1)===0x1)){var Bk=Ab;switch(A6){case 3:Bk=[FZ[0]+DV,Bk[
1]];break;case 4:Bk=[-FZ[0]-DV,Bk[1]];break;case 1:Bk=[Bk[0],FZ[1]+DW];break;case
2:Bk=[Bk[0],-FZ[1]-DW];break;default:;}BM=A.tx(BM,Bk);}}}if(((G.F&0x200)===0x200
)){if(BL)A.lq(Ax.Cq,Ax);BL=((G.F&0x1000)===0x1000);Ax=(E.Ec.isPrototypeOf(G)?G:null
);if(BL){G.F=G.F&~0x1000;Cl=A.tz(Ax.M,Ax.Ee);AG=Cl;BM=Ab;DU=Ax.E0;A6=DU;DV=Ax.Space+
Ax.JQ;DW=Ax.Space+Ax.JS;BL=!((Cl[0]>=Cl[2])||(Cl[1]>=Cl[3]));Db=null;switch(DU){
case 9:case 10:A6=3;break;case 11:case 12:A6=4;break;case 5:case 6:A6=1;break;case
7:case 8:A6=2;break;default:;}}if(BL){this.AM(Ax.M);}}if(G===Db){switch(DU){case
9:case 11:BM=[0,(BM[1]+(AG[3]-AG[1]))+DW];break;case 10:case 12:BM=[0,(BM[1]-(AG[
3]-AG[1]))-DW];break;case 5:case 7:BM=[(BM[0]+(AG[2]-AG[0]))+DV,0];break;case 6:
case 8:BM=[(BM[0]-(AG[2]-AG[0]))-DV,0];break;default:;}Db=null;}G=G.T;}if(BL)A.lq(
Ax.Cq,Ax);this.F=this.F&~0x2000;this.Fu([CL[2]-CL[0],CL[3]-CL[1]]);},Bl:function(
Cn){var B;var Lc=((this.F&0x1000)===0x1000);if(((this.F&0x4000)===0x4000)){this.
F=this.F&~0x4000;this.La();}if(((this.F&0x8000)===0x8000)||Lc){this.F=this.F&~0x8000;
this.Ek(this.F);}},DN:function(C){var B;if(!!C&&(C.K!==this))throw new Error(Cr);
if(!!C&&!((C.F&0x14)===0x14))C=null;if(!!C&&((C.F&0x10000)===0x10000))C=null;if(
C===this.Bs)return;if(!!this.Bs)this.Bs.A3(0x0,0x60);this.Bs=C;if(!!C){if(((this.
F&0x40)===0x40))C.A3(0x60,0x0);else C.A3(0x20,0x0);}},H8:function(Ht){var tmp=this;
while(!!tmp){Ht=A.tw(Ht,tmp.M.slice(0,2));tmp=tmp.K;}return Ht;},DispatchEvent:function(
V){var B;var G=this.Bs;var R=(E.Y.isPrototypeOf(G)?G:null);var W=null;var HL=!!this.
DB&&(!!this.DB.HA||!!this.DB.Ba);if(!!G&&((((G.F&0x10000)===0x10000)||((G.F&0x40000
)===0x40000))||((G.F&0x20000)===0x20000))){G=null;R=null;}if(!!this.C9&&!HL)W=this.
C9.Bb.DispatchEvent(V);if(!W&&!!R)W=R.DispatchEvent(V);else if(!W&&!!G)W=G.AT(V);
if(!W)W=this.AT(V);if(!W)W=this.HS(V);return W;},BroadcastEventAtPosition:function(
V,I9,Bh){var B;var G=this.AR;var W=null;while(!!G&&!W){if((!Bh||((B=Bh)&&((G.F&B
)===B)))&&A.qu(G.GetExtent(),I9)){var R=(E.Y.isPrototypeOf(G)?G:null);if(!!R)W=R.
BroadcastEventAtPosition(V,A.tw(I9,R.M.slice(0,2)),Bh);else W=G.AT(V);}G=G.O;}if(
!W)W=this.AT(V);return W;},BroadcastEvent:function(V,Bh){var B;var G=this.AR;var
W=null;while(!!G&&!W){if(!Bh||((B=Bh)&&((G.F&B)===B))){var R=(E.Y.isPrototypeOf(
G)?G:null);if(!!R)W=R.BroadcastEvent(V,Bh);else W=G.AT(V);}G=G.O;}if(!W)W=this.AT(
V);if(!W)W=this.HS(V);return W;},Fu:function(aSize){},Ek:function(FC){},Dn:function(
){this.F=this.F|0x8000;A.lq([this,this.Bl],this);},AM:function(Ad){var B;var R=this;
while(!!R&&!((Ad[0]>=Ad[2])||(Ad[1]>=Ad[3]))){var Dw=R.Bq;if(!R.K&&(R!==this)){R.
AM(Ad);return;}if(!!Dw){var HF=false;var K9=Dw.BD;if(HF)Dw.BD=[0,0,(B=R.M)[2]-B[
0],B[3]-B[1]];else Dw.BD=A.qR(Dw.BD,Ad);if(!A.tm(K9,Dw.BD)){A.qw(R,0);A.qw(Dw,0);
}}if(!((R.F&0x1)===0x1))return;Ad=A.il(A.tz(Ad,R.M.slice(0,2)),R.M);R=R.K;}},Bf:
function(aArg){this.Dn();},H3:function(I,Bh){var B;if(!I||(I.K!==this))return null;
var Dd=I.T;var Dg=I.O;var EB=0x10000;if(((Bh&0x10000)===0x10000))EB=0x0;while(!!
Dd||!!Dg){if((!!Dd&&(!Bh||((B=Bh)&&((Dd.F&B)===B))))&&(!EB||!((B=EB)&&((Dd.F&B)===
B))))return Dd;if((!!Dg&&(!Bh||((B=Bh)&&((Dg.F&B)===B))))&&(!EB||!((B=EB)&&((Dg.
F&B)===B))))return Dg;if(!!Dd)Dd=Dd.T;if(!!Dg)Dg=Dg.O;}return null;},JO:function(
I,Bv){var B;if(!I)throw new Error(Dr);if(I.K!==this)throw new Error(DR);var CJ=I;
var Aw=I;var DH=I.BH;while(((Bv>0)&&!!CJ.T)&&(CJ.T.BH<=DH)){CJ=CJ.T;Bv=Bv-1;}while(((
Bv<0)&&!!Aw.O)&&(Aw.O.BH>=DH)){Aw=Aw.O;Bv=Bv+1;}if((CJ===I)&&(Aw===I))return;if(((
I.F&0x401)===0x401)){if(!!I.O&&!!I.AI)I.O.F=I.O.F|0x800;I.F=I.F|0x800;this.F=this.
F|0x4000;A.lq([this,this.Bl],this);}if(((I.F&0x200)===0x200)){if(!!I.O)I.O.F=I.O.
F|0x800;I.F=I.F|0x800;this.F=this.F|0x4000;A.lq([this,this.Bl],this);}if(!!I.O)I.
O.T=I.T;if(!!I.T)I.T.O=I.O;if(this.Ba===I)this.Ba=I.T;if(this.AR===I)this.AR=I.O;
if(CJ!==I){I.T=CJ.T;I.O=CJ;CJ.T=I;if(!!I.T)I.T.O=I;}if(Aw!==I){I.T=Aw;I.O=Aw.O;Aw.
O=I;if(!!I.O)I.O.T=I;}if(!I.T)this.AR=I;if(!I.O)this.Ba=I;if(((I.F&0x1)===0x1))this.
AM(I.GetExtent());},IX:function(I){var B;if(!I)throw new Error(Hk);if(I.K!==this
)throw new Error(DR);if((((I.F&0x401)===0x401)&&!!I.O)&&!!I.AI){I.O.F=I.O.F|0x800;
this.F=this.F|0x4000;A.lq([this,this.Bl],this);}if(((I.F&0x200)===0x200)){if(!!I.
O)I.O.F=I.O.F|0x800;this.F=this.F|0x4000;A.lq([this,this.Bl],this);}I.AI=null;if(
this.Bs===I)this.DN(this.H3(I,0x14));if(!!I.O)I.O.T=I.T;if(!!I.T)I.T.O=I.O;if(this.
Ba===I)this.Ba=I.T;if(this.AR===I)this.AR=I.O;I.K=null;I.T=null;I.O=null;if(((I.
F&0x1)===0x1))this.AM(I.GetExtent());},U:function(I,Bv){var B;if(!I)throw new Error(
Hl);if(!!I.K)throw new Error(Hm);var Aw=null;var DH=I.BH;if(((Bv<0)&&!!this.AR)&&(
this.AR.BH>=DH)){Aw=this.AR;Bv=Bv+1;}while((((Bv<0)&&!!Aw)&&!!Aw.O)&&(Aw.O.BH>=DH
)){Aw=Aw.O;Bv=Bv+1;}if((!Aw&&!!this.AR)&&(this.AR.BH>DH))Aw=this.AR;while((!!Aw&&
!!Aw.O)&&(Aw.O.BH>DH))Aw=Aw.O;if(!Aw){I.K=this;I.O=this.AR;if(!!this.AR)this.AR.
T=I;if(!this.Ba)this.Ba=I;this.AR=I;}else{I.K=this;I.O=Aw.O;I.T=Aw;Aw.O=I;if(!!I.
O)I.O.T=I;else this.Ba=I;}if(((I.F&0x1)===0x1))this.AM(I.GetExtent());if(((!this.
Bs&&((I.F&0x4)===0x4))&&((I.F&0x10)===0x10))&&!((I.F&0x10000)===0x10000))this.DN(
I);if(((I.F&0x401)===0x401)){I.F=I.F|0x800;this.F=this.F|0x4000;A.lq([this,this.
Bl],this);}if(((I.F&0x200)===0x200)){I.F=I.F|0x800;this.F=this.F|0x4000;A.lq([this
,this.Bl],this);}},_Init:function(aArg){E.AU._Init.call(this,aArg);this.__proto__=
E.Y;this.F=0x1F;this.Bf(aArg);},_Mark:function(D){var B;E.AU._Mark.call(this,D);
if((B=this.Ba)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.AR)&&(B._cycle!=D))
B._Mark(B._cycle=D);if((B=this.FP)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.
Bq)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.C9)&&(B._cycle!=D))B._Mark(B._cycle=
D);if((B=this.DB)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.Bs)&&(B._cycle!=
D))B._Mark(B._cycle=D);},_className:"Core::Group"};E.Root={A9:null,CN:null,Cj:null
,AK:A.tA(10,null,null),DT:null,Bu:null,CK:null,EL:0,Hw:0,Ae:0,AX:A.tA(10,0,null)
,FI:A.tA(10,A.qy,null),Ck:A.tA(10,0,null),C7:A.tA(10,A.qx,null),Et:A.tA(10,0,null
),Dy:A.tA(10,A.qx,null),CA:A.tA(10,A.qx,null),CB:A.tA(10,A.qx,null),C6:A.tA(10,A.
qx,null),Dz:0,FM:0,FL:0,FR:A.tA(3,A.qy,null),Jj:0,AZ:A.tA(4,0,null),AE:A.tA(4,A.
qy,null),AA:0,EO:8,Ju:250,Da:0,CM:0,HH:true,FQ:false,BU:function(Az,aClip,aOffset
,AF,aBlend){var fullScreenUpdate=false;fullScreenUpdate=A.jI;if(!fullScreenUpdate
)Az.EY(aClip,A.tz(A.tz(aClip,aOffset),this.M.slice(0,2)),0x00000000,0x00000000,0x00000000
,0x00000000,false);E.Y.BU.call(this,Az,aClip,aOffset,AF,aBlend);},A3:function(CI
,Du){var B;E.Y.A3.call(this,CI,Du);if(!this.K&&(((CI&0x1)===0x1)||((Du&0x1)===0x1
)))this.AM([0,0,(B=this.M)[2]-B[0],B[3]-B[1]]);if(!this.K&&(((CI&0x2)===0x2)||((
Du&0x2)===0x2)))this.AM([0,0,(B=this.M)[2]-B[0],B[3]-B[1]]);},DN:function(C){if((
C!==this.Bu)||!C)E.Y.DN.call(this,C);},DispatchEvent:function(V){if((this.Hw>0)&&
!!(E.KeyEvent.isPrototypeOf(V)?V:null))return null;if(!!V){V.Ea=!!this.Ae;if(!!this.
Ae)V.Bt=this.Ae;}var W=null;if(!!this.Bu){W=this.Bu.DispatchEvent(V);if(!!W){this.
Ae=0;return W;}}if(!!this.CN){W=this.CN.Bb.DispatchEvent(V);if(!W)W=this.AT(V);if(
!W)W=this.HS(V);this.Ae=0;return W;}W=E.Y.DispatchEvent.call(this,V);this.Ae=0;return W;
},BroadcastEvent:function(V,Bh){if(!!V){V.Ea=!!this.Ae;if(!!this.Ae)V.Bt=this.Ae;
}var W=E.Y.BroadcastEvent.call(this,V,Bh);this.Ae=0;return W;},AM:function(Ad){var
B;if(this.EL>0)throw new Error(Hn);if(!!this.Bq&&!this.K){if(((B=this.Bq.BD)[0]>=
B[2])||(B[1]>=B[3])){A.qw(this,0);A.qw(this.Bq,0);}var HF=false;if(HF)this.Bq.BD=[
0,0,(B=this.M)[2]-B[0],B[3]-B[1]];else this.Bq.BD=A.qR(this.Bq.BD,Ad);}var fullScreenUpdate=
false;fullScreenUpdate=A.jI;if(fullScreenUpdate)Ad=[0,0,(B=this.M)[2]-B[0],B[3]-
B[1]];if(!!this.K){E.Y.AM.call(this,Ad);return;}Ad=A.il(A.tz(Ad,this.M.slice(0,2
)),this.M);if((Ad[0]>=Ad[2])||(Ad[1]>=Ad[3]))return;var H;for(H=0;H<this.AA;H=H+
1)if(!(((B=A.il(this.AE.Get(H),Ad))[0]>=B[2])||(B[1]>=B[3]))){this.AE.Set(H,A.qR(
this.AE.Get(H),Ad));this.AZ.Set(H,A.s9(this.AE.Get(H)));return;}if(this.AA<3){this.
AE.Set(this.AA,Ad);this.AZ.Set(this.AA,A.s9(Ad));this.AA=this.AA+1;return;}var Aq;
var A8;var Ex=0;var Ey=0;var I$=2147483647;this.AE.Set(this.AA,Ad);this.AZ.Set(this.
AA,A.s9(Ad));for(Aq=0;Aq<=this.AA;Aq=Aq+1)for(A8=Aq+1;A8<=this.AA;A8=A8+1){var F0=
A.s9(A.qR(this.AE.Get(Aq),this.AE.Get(A8)));var Jn=((F0<<8)/(this.AZ.Get(Aq)+this.
AZ.Get(A8)))|0;if(Jn<I$){I$=Jn;Ex=Aq;Ey=A8;}}this.AE.Set(Ex,A.qR(this.AE.Get(Ex)
,this.AE.Get(Ey)));this.AZ.Set(Ex,A.s9(this.AE.Get(Ex)));if(Ey!==this.AA){this.AE.
Set(Ey,this.AE.Get(this.AA));this.AZ.Set(Ey,this.AZ.Get(this.AA));}},K6:function(
){var AO=A._NewObject(E.Gi,0);AO.Ea=!!this.Ae;if(!!this.Ae)AO.Bt=this.Ae;return AO;
},Es:function(){var AO=A._NewObject(E.Gg,0);AO.Ea=!!this.Ae;if(!!this.Ae)AO.Bt=this.
Ae;return AO;},FH:function(){var AO=A._NewObject(E.Gh,0);AO.Ea=!!this.Ae;if(!!this.
Ae)AO.Bt=this.Ae;return AO;},K7:function(Cn){var H;var DC=false;for(H=0;H<10;H=H+
1)if(!!this.AK.Get(H)){var AY=this.CB.Get(H);var R=this.AK.Get(H).K;while(!!R&&(
R!==this)){AY=A.tw(AY,R.M.slice(0,2));R=R.K;}if(!R&&(this.AK.Get(H)!==this)){var
tmp=this.AK.Get(H);this.Dz=H;this.AK.Set(H,null);tmp.AT(this.Es().InitializeUp(H
,this.Dy.Get(H),this.C7.Get(H),this.Ck.Get(H),this.AX.Get(H)+1,this.CA.Get(H),false
,this.CB.Get(H),this.C6.Get(H)));if(tmp===this.Cj)this.Cj=null;this.BroadcastEvent(
this.FH().InitializeUp(H,this.AX.Get(H)+1,false,tmp,this.CB.Get(H)),0x18);}else{
this.Ck.Set(H,(this.CK.Bt-this.Et.Get(H))|0);if(this.Ck.Get(H)<10)this.Ck.Set(H,
10);this.Dz=H;this.AK.Get(H).AT(this.Es().InitializeHold(H,AY,this.C7.Get(H),this.
Ck.Get(H),this.AX.Get(H)+1,this.CA.Get(H),this.CB.Get(H),this.C6.Get(H)));DC=true;
}}if(!DC)this.CK.Fj(false);},GetFPS:function(){var ticksCount=0;var Jf=0;ticksCount=((
new Date).getTime()-A.qt)|0;if(!!this.FM&&(ticksCount>this.FM))Jf=((this.FL*1000
)/((ticksCount-this.FM)|0))|0;this.FL=0;this.FM=ticksCount;return Jf;},Update:function(
){var B;if(!this.DT){this.DT=A._NewObject(A.Graphics.Canvas,0);this.DT.GF([(B=this.
M)[2]-B[0],B[3]-B[1]]);}this.DT.Update();return this.UpdateGE20(this.DT);},UpdateGE20:
function(Az){if(!this.BeginUpdate())return At;var CE=this.UpdateCanvas(Az,Ab);this.
EndUpdate();return CE;},EndUpdate:function(){if(this.AA>0){this.FL=this.FL+1;this.
AA=0;}},UpdateCanvas:function(Az,aOffset){var B;var CE=At;var K4=[].concat(aOffset
,A.tx(Az.FrameSize,aOffset));var H;var Aq=this.AA;this.EL=this.EL+1;for(H=0;(H<Aq
)&&(H<4);H=H+1){if(this.AZ.Get(H)>0){this.BU(Az,A.ty(this.AE.Get(H),aOffset),[-aOffset[
0],-aOffset[1]],255,true);CE=A.qR(CE,A.il(K4,this.AE.Get(H)));}else Aq=Aq+1;}this.
EL=this.EL-1;if(!((CE[0]>=CE[2])||(CE[1]>=CE[3])))return A.ty(CE,aOffset);else return CE;
},GetUpdateRegion:function(FB){var H;var Aq=this.AA;if(FB<0)return At;for(H=0;(H<
Aq)&&(H<4);H=H+1){if(!this.AZ.Get(H)){Aq=Aq+1;FB=FB+1;}else if(H===FB)return this.
AE.Get(H);}return At;},BeginUpdate:function(){var K$=true;var fullScreenUpdate=false;
var H;if((!K$&&!fullScreenUpdate)&&(this.AA>0)){var Jq=A.tA(3,A.qy,null);var HX=
this.AA;for(H=0;H<HX;H=H+1)Jq.Set(H,this.AE.Get(H));for(H=0;H<this.Jj;H=H+1)this.
AM(this.FR.Get(H));for(H=0;H<HX;H=H+1)this.FR.Set(H,Jq.Get(H));this.Jj=HX;}var Aq;
var A8;for(Aq=0;Aq<(this.AA-1);Aq=Aq+1)if(this.AZ.Get(Aq)>0)for(A8=Aq+1;A8<this.
AA;A8=A8+1)if(this.AZ.Get(A8)>0){var F0=A.s9(A.qR(this.AE.Get(Aq),this.AE.Get(A8
)));if(((F0-this.AZ.Get(Aq))-this.AZ.Get(A8))<0){this.AE.Set(Aq,A.qR(this.AE.Get(
Aq),this.AE.Get(A8)));this.AZ.Set(Aq,F0);this.AZ.Set(A8,0);}}for(H=this.AA-1;H>=
0;H=H-1)if(!this.AZ.Get(H))this.AA=this.AA-1;return this.AA;},DoesNeedUpdate:function(
){if(this.AA>0)return true;return false;},Initialize:function(aSize){this.N([].concat(
Ab,aSize));if(this.HH)this.F=this.F|0x60;else this.F=this.F|0x20;this.AM(this.M);
return this;},SetRootFocus:function(Hr){if(Hr===this.HH)return false;this.HH=Hr;
if(!Hr){if(!!this.Bu)this.Bu.A3(0x0,0x40);if(!!this.CN)this.CN.Bb.A3(0x0,0x40);else
this.A3(0x0,0x40);}else{if(!!this.CN)this.CN.Bb.A3(0x40,0x0);else this.A3(0x40,0x0
);if(!!this.Bu)this.Bu.A3(0x40,0x0);}return true;},SetUserInputTimestamp:function(
K3){this.Ae=K3;},DriveKeyboardHitting:function(Av,Dt,Bp){var B;var HT=!!this.A9;
if(!!this.A9&&((!Bp||(this.Da!==Av))||(this.CM!==Dt))){var AO=null;var G=(E.Ch.isPrototypeOf(
B=this.A9)?B:null);var BN=(E.Fg.isPrototypeOf(B=this.A9)?B:null);if(!!this.Da)AO=
A._NewObject(E.KeyEvent,0).Initialize(this.Da,false);if(this.CM!==0x00)AO=A._NewObject(
E.KeyEvent,0).Initialize2(this.CM,false);if(!!BN)BN.AT(AO);else if(!!G)G.AT(AO);
this.Da=0;this.CM=0x00;this.A9=null;}if(!!this.A9){var AO=null;var G=(E.Ch.isPrototypeOf(
B=this.A9)?B:null);var BN=(E.Fg.isPrototypeOf(B=this.A9)?B:null);if(!!Av)AO=A._NewObject(
E.KeyEvent,0).Initialize(Av,true);if(this.CM!==0x00)AO=A._NewObject(E.KeyEvent,0
).Initialize2(Dt,true);if(!!BN)BN.AT(AO);else if(!!G)G.AT(AO);}if(this.FQ&&((!Bp||(
this.Da!==Av))||(this.CM!==Dt))){this.Da=0;this.CM=0x00;this.FQ=false;}if((!this.
A9&&Bp)&&(this.Hw>0)){this.Da=Av;this.CM=Dt;this.FQ=true;}if((!this.A9&&Bp)&&!this.
FQ){if(!!Av)this.A9=this.DispatchEvent(A._NewObject(E.KeyEvent,0).Initialize(Av,
true));if(Dt!==0x00)this.A9=this.DispatchEvent(A._NewObject(E.KeyEvent,0).Initialize2(
Dt,true));if(!(E.Fg.isPrototypeOf(B=this.A9)?B:null)&&!(E.Ch.isPrototypeOf(B=this.
A9)?B:null))this.A9=null;this.Da=Av;this.CM=Dt;HT=HT||!!this.A9;}this.Ae=0;return HT;
},DriveCursorMovement:function(AC){return this.DriveMultiTouchMovement(this.Dz,AC
);},DriveMultiTouchMovement:function(J,AC){if((J<0)||(J>9)){this.Ae=0;return false;
}var EC=A.tw(AC,this.CB.Get(J));this.CB.Set(J,AC);if(!this.AK.Get(J)||A.tl(EC,Ab
)){this.Ae=0;return false;}var AY=AC;var R=this.AK.Get(J).K;while(!!R&&(R!==this
)){AY=A.tw(AY,R.M.slice(0,2));R=R.K;}if(!R&&(this.AK.Get(J)!==this)){var tmp=this.
AK.Get(J);this.Dz=J;this.AK.Set(J,null);tmp.AT(this.Es().InitializeUp(J,this.Dy.
Get(J),this.C7.Get(J),this.Ck.Get(J),this.AX.Get(J)+1,this.CA.Get(J),false,this.
CB.Get(J),this.C6.Get(J)));if(tmp===this.Cj)this.Cj=null;this.BroadcastEvent(this.
FH().InitializeUp(J,this.AX.Get(J)+1,false,tmp,AC),0x18);}else{this.Dy.Set(J,AY);
this.Dz=J;this.AK.Get(J).AT(this.K6().Initialize(J,AY,this.C7.Get(J),EC,this.Ck.
Get(J),this.AX.Get(J)+1,this.CA.Get(J),AC,this.C6.Get(J)));}this.Ae=0;return true;
},DriveCursorHitting:function(Bp,J,AC){return this.DriveMultiTouchHitting(Bp,J,AC
);},DriveMultiTouchHitting:function(Bp,J,AC){var B;if((J<0)||(J>9)){this.Ae=0;return false;
}var ticksCount=this.Ae;var Eu=[].concat([-this.EO,-this.EO],[this.EO+1,this.EO+
1]);if(!ticksCount){ticksCount=((new Date).getTime()-A.qt)|0;}var Lb=this.Ae;this.
DriveMultiTouchMovement(J,AC);AC=this.CB.Get(J);this.Ae=Lb;if(Bp)this.C6.Set(J,AC
);if((Bp&&!this.AK.Get(J))&&!this.Hw){var CC=null;var AY=AC;if(A.qu(this.FI.Get(
J),AC)&&((ticksCount-this.Et.Get(J))<=(((B=this.Ju)<0)?B+0x100000000:B)))this.AX.
Set(J,this.AX.Get(J)+1);else this.AX.Set(J,0);this.FI.Set(J,A.tz(Eu,AC));this.Et.
Set(J,ticksCount);if((!!this.Bu&&!!this.Bu.K)&&((this.Bu.F&0x18)===0x18)){var S=
A.tz(Eu,this.Bu.K.H8(AC));CC=this.Bu.Dl(S,J,this.AX.Get(J)+1,null,0x0);}if(!CC){
if(!!this.Cj&&!!this.Cj.K){if(((this.Cj.F&0x8)===0x8)&&((this.Cj.F&0x10)===0x10)
){var S=A.tz(Eu,this.Cj.K.H8(AC));CC=this.Cj.Dl(S,J,this.AX.Get(J)+1,null,0x0);}
}else if(!!this.CN)CC=this.Dl(A.tz(Eu,AC),J,this.AX.Get(J)+1,this.CN.Bb,0x0);else
CC=this.Dl(A.tz(Eu,AC),J,this.AX.Get(J)+1,null,0x0);}if(!!CC){this.BroadcastEvent(
this.FH().InitializeDown(J,this.AX.Get(J)+1,false,CC.Ch,AC),0x18);this.AK.Set(J,
CC.Ch);this.CA.Set(J,CC.Gv);}else{this.AK.Set(J,null);this.CA.Set(J,Ab);this.Ae=
0;return false;}var R=CC.Ch.K;while(!!R&&(R!==this)){AY=A.tw(AY,R.M.slice(0,2));
R=R.K;}this.C7.Set(J,AY);this.Dy.Set(J,AY);this.Ck.Set(J,0);this.CK.Fj(true);this.
Dz=J;this.AK.Get(J).AT(this.Es().InitializeDown(J,AY,this.AX.Get(J)+1,this.CA.Get(
J),false,AC));this.Ae=0;return true;}if(!Bp&&!!this.AK.Get(J)){var AY=AC;var R=this.
AK.Get(J).K;while(!!R&&(R!==this)){AY=A.tw(AY,R.M.slice(0,2));R=R.K;}if(!R)AY=this.
Dy.Get(J);this.Dz=J;var tmp=this.AK.Get(J);this.AK.Set(J,null);tmp.AT(this.Es().
InitializeUp(J,AY,this.C7.Get(J),this.Ck.Get(J),this.AX.Get(J)+1,this.CA.Get(J),
false,AC,this.C6.Get(J)));this.BroadcastEvent(this.FH().InitializeUp(J,this.AX.Get(
J)+1,false,tmp,AC),0x18);this.Ae=0;return true;}this.Ae=0;return false;},_Init:function(
aArg){E.Y._Init.call(this,aArg);E.Timer._Init.call(this.CK={L:this},0);(this.AK=[
]).__proto__=E.Root.AK;(this.AX=[]).__proto__=E.Root.AX;(this.FI=[]).__proto__=E.
Root.FI;(this.Ck=[]).__proto__=E.Root.Ck;(this.C7=[]).__proto__=E.Root.C7;(this.
Et=[]).__proto__=E.Root.Et;(this.Dy=[]).__proto__=E.Root.Dy;(this.CA=[]).__proto__=
E.Root.CA;(this.CB=[]).__proto__=E.Root.CB;(this.C6=[]).__proto__=E.Root.C6;(this.
FR=[]).__proto__=E.Root.FR;(this.AZ=[]).__proto__=E.Root.AZ;(this.AE=[]).__proto__=
E.Root.AE;this.__proto__=E.Root;this.F=0x7F;this.CK.JI(50);this.CK.Fm=[this,this.
K7];},_Done:function(){this.__proto__=E.Y;this.CK._Done();E.Y._Done.call(this);}
,_ReInit:function(){E.Y._ReInit.call(this);this.CK._ReInit();},_Mark:function(D){
var B;E.Y._Mark.call(this,D);if((B=this.A9)&&(B._cycle!=D))B._Mark(B._cycle=D);if((
B=this.CN)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.Cj)&&(B._cycle!=D))B._Mark(
B._cycle=D);A.ts(this.AK,D);if((B=this.DT)&&(B._cycle!=D))B._Mark(B._cycle=D);if((
B=this.Bu)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.CK)._cycle!=D)B._Mark(B.
_cycle=D);},_className:"Core::Root"};E.Event={Bt:0,Ea:false,Ff:function(){var ticksCount=
0;ticksCount=((new Date).getTime()-A.qt)|0;return ticksCount;},Bf:function(aArg){
this.Bt=this.Ff();},_Init:function(aArg){this.__proto__=E.Event;this.Bf(aArg);A.
gv++;},_Done:function(){this.__proto__=null;A.gv--;},_ReInit:function(){},_Mark:
function(D){var B;if((B=this.L)&&(B._cycle!=D))B._Mark(B._cycle=D);},L:null,_cycle:
0,_observers:null,_className:"Core::Event"};E.KeyEvent={Ay:0,X:0,Down:false,Initialize2:
function(Av,Bp){this.Ay=0;this.X=Av;this.Down=Bp;if((Av>=0x30)&&(Av<=0x39))this.
Ay=(10+Av)-48;if((Av>=0x41)&&(Av<=0x5A))this.Ay=(105+Av)-65;if((Av>=0x61)&&(Av<=
0x7A))this.Ay=(105+Av)-97;if(Av===0x20)this.Ay=131;if(!this.Ay)switch(Av){case 0x2B:
this.Ay=132;break;case 0x2D:this.Ay=133;break;case 0x2A:this.Ay=134;break;case 0x2F:
this.Ay=135;break;case 0x3D:this.Ay=136;break;case 0x2E:this.Ay=137;break;case 0x2C:
this.Ay=138;break;case 0x3A:this.Ay=139;break;case 0x3B:this.Ay=140;break;default:;
}return this;},Initialize:function(Av,Bp){this.Ay=Av;this.Down=Bp;this.X=0x00;var
Hy=Av-10;var Hx=Av-105;if((Hy>=0)&&(Hy<=9))this.X=(48+Hy)&0xFFFF;if((Hx>=0)&&(Hx<=
25))this.X=(65+Hx)&0xFFFF;if(Av===131)this.X=0x20;if(this.X===0x00)switch(Av){case
132:this.X=0x2B;break;case 133:this.X=0x2D;break;case 134:this.X=0x2A;break;case
135:this.X=0x2F;break;case 136:this.X=0x3D;break;case 137:this.X=0x2E;break;case
138:this.X=0x2C;break;case 139:this.X=0x3A;break;case 140:this.X=0x3B;break;default:;
}return this;},JD:function(I6){switch(I6){case 141:return((this.X>=0x41)&&(this.
X<=0x5A))||((this.X>=0x61)&&(this.X<=0x7A));case 142:return(((this.X>=0x41)&&(this.
X<=0x5A))||((this.X>=0x61)&&(this.X<=0x7A)))||((this.X>=0x30)&&(this.X<=0x39));case
143:return(this.X>=0x30)&&(this.X<=0x39);case 144:return(((this.X>=0x41)&&(this.
X<=0x46))||((this.X>=0x61)&&(this.X<=0x66)))||((this.X>=0x30)&&(this.X<=0x39));case
145:return this.X!==0x00;case 146:return(this.X===0x00)&&!!this.Ay;case 147:return(((
this.Ay===6)||(this.Ay===7))||(this.Ay===4))||(this.Ay===5);case 148:return(this.
X!==0x00)||!!this.Ay;default:;}return I6===this.Ay;},_Init:function(aArg){E.Event.
_Init.call(this,aArg);this.__proto__=E.KeyEvent;},_className:"Core::KeyEvent"};E.
Gh={G_:null,CX:A.qx,CY:0,CW:0,Down:false,D5:false,InitializeUp:function(J,Bw,Ds,
Hv,BK){this.Down=false;this.CW=J;this.CY=Bw;this.CX=BK;this.G_=Hv;this.D5=Ds;return this;
},InitializeDown:function(J,Bw,Ds,Hv,BK){this.Down=true;this.CW=J;this.CY=Bw;this.
CX=BK;this.G_=Hv;this.D5=Ds;return this;},_Init:function(aArg){E.Event._Init.call(
this,aArg);this.__proto__=E.Gh;},_Mark:function(D){var B;E.Event._Mark.call(this
,D);if((B=this.G_)&&(B._cycle!=D))B._Mark(B._cycle=D);},_className:"Core::CursorGrabEvent"
};E.Gg={D9:A.qx,CX:A.qx,CY:0,D$:0,D_:A.qx,D6:A.qx,CW:0,Down:false,D5:false,InitializeHold:
function(J,C4,En,Eo,Bw,Ci,BK,Em){this.Down=true;this.CW=J;this.D6=A.tx(C4,Ci);this.
D_=A.tx(En,Ci);this.D$=Eo;this.CY=Bw;this.CX=BK;this.D9=Em;return this;},InitializeUp:
function(J,C4,En,Eo,Bw,Ci,Ds,BK,Em){this.Down=false;this.CW=J;this.D6=A.tx(C4,Ci
);this.D_=A.tx(En,Ci);this.D$=Eo;this.CY=Bw;this.D5=Ds;this.CX=BK;this.D9=Em;return this;
},InitializeDown:function(J,C4,Bw,Ci,Ds,BK){this.Down=true;this.CW=J;this.D6=A.tx(
C4,Ci);this.D_=A.tx(C4,Ci);this.D$=0;this.CY=Bw;this.D5=Ds;this.CX=BK;this.D9=BK;
return this;},_Init:function(aArg){E.Event._Init.call(this,aArg);this.__proto__=
E.Gg;},_className:"Core::CursorEvent"};E.Gi={D9:A.qx,CX:A.qx,CY:0,D$:0,Gv:A.qx,D_:
A.qx,D6:A.qx,CW:0,Initialize:function(J,C4,En,aOffset,Eo,K2,Ci,BK,Em){this.CW=J;
this.D6=A.tx(C4,Ci);this.D_=A.tx(En,Ci);this.Gv=aOffset;this.D$=Eo;this.CY=K2;this.
CX=BK;this.D9=Em;return this;},_Init:function(aArg){E.Event._Init.call(this,aArg
);this.__proto__=E.Gi;},_className:"Core::DragEvent"};E.Ec={Cq:null,Ee:A.qx,JS:0
,JQ:0,Space:0,E0:0,BU:function(Az,aClip,aOffset,AF,aBlend){},N:function(C){var B;
if(A.tm(C,this.M))return;var De=[(B=this.M)[2]-B[0],B[3]-B[1]];var FT=[C[2]-C[0]
,C[3]-C[1]];var DG=!A.tl(De,FT);var EC=A.tw(C.slice(0,2),this.M.slice(0,2));if(!
A.tl(EC,Ab)&&!DG){var G=this.T;while(!!G&&!((G.F&0x200)===0x200)){if(((G.F&0x400
)===0x400)){var tmp=((G.F&0x100)===0x100);G.H9(EC,tmp);}G=G.T;}A.lq(this.Cq,this
);}if((DG&&(De[0]>0))&&(De[1]>0)){var Ap=A.tz(this.M,this.Ee);var G=this.T;var Ew=
0x14;while(!!G&&!((G.F&0x200)===0x200)){if(((G.F&0x400)===0x400)){if(!!G.AI&&(G.
AI.DY!==this))G.AI=null;if(!G.AI&&((G.AJ!==Ew)||!!this.E0))G.FN(Ap,this);}G=G.T;
}A.lq(this.Cq,this);}E.AU.N.call(this,C);if(!!this.K&&DG){this.F=this.F|0x1000;if(
!((this.K.F&0x2000)===0x2000)){this.K.F=this.K.F|0x4000;A.lq([B=this.K,B.Bl],this
);}}},_Init:function(aArg){E.AU._Init.call(this,aArg);this.__proto__=E.Ec;this.F=
0x203;},_Mark:function(D){var B;E.AU._Mark.call(this,D);if((B=this.Cq)&&((B=B[0]
)._cycle!=D))B._Mark(B._cycle=D);},_className:"Core::Outline"};E.Fg={T:null,IL:null
,IK:null,IJ:null,DF:0,Bt:0,IY:0,Jy:148,Ay:0,X:0,DK:true,Down:false,G8:false,EN:false
,AT:function(V){var B;if(!!V&&V.JD(this.Jy)){this.Down=V.Down;this.Ay=V.Ay;this.
X=V.X;this.Bt=V.Bt;this.EN=false;if(V.Down){this.IY=this.DF;this.G8=this.DF>0;if(
this.G8)(B=this.IJ)?B[1].call(B[0],this):null;else(B=this.IK)?B[1].call(B[0],this
):null;if(!this.EN)this.DF=this.DF+1;return!this.EN;}if(!V.Down){this.G8=this.DF>
1;this.IY=this.DF-1;this.DF=0;(B=this.IL)?B[1].call(B[0],this):null;return!this.
EN;}}return false;},Bf:function(aArg){var B;var Bb=(E.Y.isPrototypeOf(B=this.L)?
B:null);if(!Bb)throw new Error(Ho);this.T=Bb.FP;Bb.FP=this;},_Init:function(aArg
){this.__proto__=E.Fg;this.Bf(aArg);A.gv++;},_Done:function(){this.__proto__=null;
A.gv--;},_ReInit:function(){},_Mark:function(D){var B;if((B=this.T)&&(B._cycle!=
D))B._Mark(B._cycle=D);if((B=this.IL)&&((B=B[0])._cycle!=D))B._Mark(B._cycle=D);
if((B=this.IK)&&((B=B[0])._cycle!=D))B._Mark(B._cycle=D);if((B=this.IJ)&&((B=B[0
])._cycle!=D))B._Mark(B._cycle=D);if((B=this.L)&&(B._cycle!=D))B._Mark(B._cycle=
D);},L:null,_cycle:0,_observers:null,_className:"Core::KeyPressHandler"};E.Jt={Ch:
null,ET:0,Gv:A.qx,_Init:function(aArg){this.__proto__=E.Jt;A.gv++;},_Done:function(
){this.__proto__=null;A.gv--;},_ReInit:function(){},_Mark:function(D){var B;if((
B=this.Ch)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.L)&&(B._cycle!=D))B._Mark(
B._cycle=D);},L:null,_cycle:0,_observers:null,_className:"Core::CursorHit"};E.JE={
Bb:null,_Init:function(aArg){this.__proto__=E.JE;A.gv++;},_Done:function(){this.
__proto__=null;A.gv--;},_ReInit:function(){},_Mark:function(D){var B;if((B=this.
Bb)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.L)&&(B._cycle!=D))B._Mark(B._cycle=
D);},L:null,_cycle:0,_observers:null,_className:"Core::ModalContext"};E.H7={DY:null
,C$:A.qy,Ap:A.qy,isEmpty:false,_Init:function(aArg){this.__proto__=E.H7;A.gv++;}
,_Done:function(){this.__proto__=null;A.gv--;},_ReInit:function(){},_Mark:function(
D){var B;if((B=this.DY)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.L)&&(B._cycle
!=D))B._Mark(B._cycle=D);},L:null,_cycle:0,_observers:null,_className:"Core::LayoutContext"
};E.Jv={Bb:null,_Init:function(aArg){this.__proto__=E.Jv;A.gv++;},_Done:function(
){this.__proto__=null;A.gv--;},_ReInit:function(){},_Mark:function(D){var B;if((
B=this.Bb)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.L)&&(B._cycle!=D))B._Mark(
B._cycle=D);},L:null,_cycle:0,_observers:null,_className:"Core::DialogContext"};
E.JU={HA:null,Ba:null,_Init:function(aArg){this.__proto__=E.JU;A.gv++;},_Done:function(
){this.__proto__=null;A.gv--;},_ReInit:function(){},_Mark:function(D){var B;if((
B=this.HA)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.Ba)&&(B._cycle!=D))B._Mark(
B._cycle=D);if((B=this.L)&&(B._cycle!=D))B._Mark(B._cycle=D);},L:null,_cycle:0,_observers:
null,_className:"Core::TaskQueue"};E.JT={_Init:function(aArg){this.__proto__=E.JT;
A.gv++;},_Done:function(){this.__proto__=null;A.gv--;},_ReInit:function(){},_Mark:
function(D){var B;if((B=this.L)&&(B._cycle!=D))B._Mark(B._cycle=D);},L:null,_cycle:
0,_observers:null,_className:"Core::Task"};E.CG={resource:null,BT:function(){this.
resource=null;},Bf:function(aArg){this.resource=aArg;},_Init:function(aArg){this.
__proto__=E.CG;this.Bf(aArg);A.gv++;},_Done:function(){this.BT();this.__proto__=
null;A.gv--;},_ReInit:function(){},_Mark:function(D){var B;if((B=this.L)&&(B._cycle
!=D))B._Mark(B._cycle=D);},L:null,_cycle:0,_observers:null,_className:"Core::Resource"
};E.Timer={Fm:null,timer:null,Bt:0,Period:1000,HZ:0,DK:false,BT:function(){var tmp=
this.timer;if(!!tmp)tmp.DestroyTimer();this.timer=null;},HV:function(aBegin,aPeriod
){if(aBegin<0)aBegin=0;if(aPeriod<0)aPeriod=0;var tmp=this.timer;if(!tmp&&((aBegin>
0)||(aPeriod>0)))tmp=A.sL(this,this.Trigger);if(!!tmp){tmp.ResetTimer();tmp.StartTimer(
aBegin,aPeriod);}this.timer=tmp;},JI:function(C){if(C<0)C=0;if(C===this.Period)return;
this.Period=C;if(this.DK)this.HV(this.HZ,C);},Fj:function(C){if(C===this.DK)return;
this.DK=C;if(C)this.HV(this.HZ,this.Period);else this.HV(0,0);this.Bt=this.Ff();
},Ff:function(){var ticksCount=0;ticksCount=((new Date).getTime()-A.qt)|0;return ticksCount;
},Trigger:function(){var B;this.Bt=this.Ff();if(!this.Period)this.Fj(false);(B=this.
Fm)?B[1].call(B[0],this):null;},_Init:function(aArg){this.__proto__=E.Timer;A.gv++;
},_Done:function(){this.BT();this.__proto__=null;A.gv--;},_ReInit:function(){},_Mark:
function(D){var B;if((B=this.Fm)&&((B=B[0])._cycle!=D))B._Mark(B._cycle=D);if((B=
this.L)&&(B._cycle!=D))B._Mark(B._cycle=D);},L:null,_cycle:0,_observers:null,_className:
"Core::Timer"};E.Ma={Mb:0x1,Lt:0x2,LC:0x4,L8:0x8,DK:0x10,L2:0x20,LD:0x40,LL:0x80
,LB:0x100,LG:0x200,LA:0x400,LR:0x800,Fu:0x1000,L_:0x2000,LP:0x4000,LQ:0x8000,Ly:
0x10000,LO:0x20000,L1:0x40000};E.AJ={LS:0x1,LT:0x2,Lj:0x4,Lk:0x8,Ll:0x10,Li:0x20
};E.E0={LM:0,L5:1,Lv:2,LH:3,LV:4,L6:5,L7:6,Lw:7,Lx:8,LJ:9,LI:10,LX:11,LW:12};E.KeyCode={
NoKey:0,Ok:1,Exit:2,Menu:3,Up:4,Down:5,Left:6,Right:7,PageUp:8,PageDown:9,Key0:10
,Key1:11,Key2:12,Key3:13,Key4:14,Key5:15,Key6:16,Key7:17,Key8:18,Key9:19,Red:20,
Green:21,Blue:22,Yellow:23,White:24,Magenta:25,F1:26,F2:27,F3:28,F4:29,F5:30,F6:
31,F7:32,F8:33,F9:34,F10:35,ChannelUp:36,ChannelDown:37,Display:38,SkipPrev:39,SkipNext:
40,Home:41,End:42,Insert:43,Delete:44,Clear:45,VolumeUp:46,VolumeDown:47,Show:48
,Hide:49,Play:50,Pause:51,Record:52,Stop:53,Rev:54,Fwd:55,SlowRev:56,SlowFwd:57,
SkipBwd:58,SkipFwd:59,Repeat:60,Eject:61,Help:62,TV:63,DVD:64,VCR:65,EPG:66,OSD:
67,Text:68,PIP:69,Audio:70,Clock:71,Timer:72,Navigation:73,Karaoke:74,Game:75,Subtitle:
76,Zoom:77,Index:78,Info:79,Power:80,Setup:81,Angle:82,Mode:83,Mute:84,User0:85,
User1:86,User2:87,User3:88,User4:89,User5:90,User6:91,User7:92,User8:93,User9:94
,User10:95,User11:96,User12:97,User13:98,User14:99,User15:100,User16:101,User17:
102,User18:103,User19:104,KeyA:105,KeyB:106,KeyC:107,KeyD:108,KeyE:109,KeyF:110,
KeyG:111,KeyH:112,KeyI:113,KeyJ:114,KeyK:115,KeyL:116,KeyM:117,KeyN:118,KeyO:119
,KeyP:120,KeyQ:121,KeyR:122,KeyS:123,KeyT:124,KeyU:125,KeyV:126,KeyW:127,KeyX:128
,KeyY:129,KeyZ:130,Space:131,Plus:132,Minus:133,Multiply:134,Divide:135,Equals:136
,Period:137,Comma:138,Colon:139,Semicolon:140,AlphaKeys:141,AlphaOrDigitKeys:142
,DigitKeys:143,HexDigitKeys:144,CharacterKeys:145,ControlKeys:146,CursorKeys:147
,AnyKey:148,Enter:149,Escape:150,Backspace:151,Tab:152,CtrlKeyA:153,CtrlKeyB:154
,CtrlKeyC:155,CtrlKeyD:156,CtrlKeyE:157,CtrlKeyF:158,CtrlKeyG:159,CtrlKeyH:160,CtrlKeyI:
161,CtrlKeyJ:162,CtrlKeyK:163,CtrlKeyL:164,CtrlKeyM:165,CtrlKeyN:166,CtrlKeyO:167
,CtrlKeyP:168,CtrlKeyQ:169,CtrlKeyR:170,CtrlKeyS:171,CtrlKeyT:172,CtrlKeyU:173,CtrlKeyV:
174,CtrlKeyW:175,CtrlKeyX:176,CtrlKeyY:177,CtrlKeyZ:178,CtrlSpace:179,CtrlKey0:180
,CtrlKey1:181,CtrlKey2:182,CtrlKey3:183,CtrlKey4:184,CtrlKey5:185,CtrlKey6:186,CtrlKey7:
187,CtrlKey8:188,CtrlKey9:189,CtrlF1:190,CtrlF2:191,CtrlF3:192,CtrlF4:193,CtrlF5:
194,CtrlF6:195,CtrlF7:196,CtrlF8:197,CtrlF9:198,CtrlF10:199,CtrlEnter:200,CtrlEscape:
201,CtrlUp:202,CtrlDown:203,CtrlLeft:204,CtrlRight:205,CtrlPageUp:206,CtrlPageDown:
207,CtrlBackspace:208,CtrlInsert:209,CtrlDelete:210,CtrlHome:211,CtrlEnd:212,CtrlTab:
213,CtrlShiftKeyA:214,CtrlShiftKeyB:215,CtrlShiftKeyC:216,CtrlShiftKeyD:217,CtrlShiftKeyE:
218,CtrlShiftKeyF:219,CtrlShiftKeyG:220,CtrlShiftKeyH:221,CtrlShiftKeyI:222,CtrlShiftKeyJ:
223,CtrlShiftKeyK:224,CtrlShiftKeyL:225,CtrlShiftKeyM:226,CtrlShiftKeyN:227,CtrlShiftKeyO:
228,CtrlShiftKeyP:229,CtrlShiftKeyQ:230,CtrlShiftKeyR:231,CtrlShiftKeyS:232,CtrlShiftKeyT:
233,CtrlShiftKeyU:234,CtrlShiftKeyV:235,CtrlShiftKeyW:236,CtrlShiftKeyX:237,CtrlShiftKeyY:
238,CtrlShiftKeyZ:239,CtrlShiftSpace:240,CtrlShiftKey0:241,CtrlShiftKey1:242,CtrlShiftKey2:
243,CtrlShiftKey3:244,CtrlShiftKey4:245,CtrlShiftKey5:246,CtrlShiftKey6:247,CtrlShiftKey7:
248,CtrlShiftKey8:249,CtrlShiftKey9:250,CtrlShiftF1:251,CtrlShiftF2:252,CtrlShiftF3:
253,CtrlShiftF4:254,CtrlShiftF5:255,CtrlShiftF6:256,CtrlShiftF7:257,CtrlShiftF8:
258,CtrlShiftF9:259,CtrlShiftF10:260,CtrlShiftEnter:261,CtrlShiftEscape:262,CtrlShiftUp:
263,CtrlShiftDown:264,CtrlShiftLeft:265,CtrlShiftRight:266,CtrlShiftPageUp:267,CtrlShiftPageDown:
268,CtrlShiftBackspace:269,CtrlShiftInsert:270,CtrlShiftDelete:271,CtrlShiftHome:
272,CtrlShiftEnd:273,CtrlShiftTab:274,AltF1:275,AltF2:276,AltF3:277,AltF4:278,AltF5:
279,AltF6:280,AltF7:281,AltF8:282,AltF9:283,AltF10:284,AltEnter:285,AltEscape:286
,AltUp:287,AltDown:288,AltLeft:289,AltRight:290,AltPageUp:291,AltPageDown:292,AltBackspace:
293,AltInsert:294,AltDelete:295,AltHome:296,AltEnd:297,AltTab:298,AltShiftF1:299
,AltShiftF2:300,AltShiftF3:301,AltShiftF4:302,AltShiftF5:303,AltShiftF6:304,AltShiftF7:
305,AltShiftF8:306,AltShiftF9:307,AltShiftF10:308,AltShiftEnter:309,AltShiftEscape:
310,AltShiftUp:311,AltShiftDown:312,AltShiftLeft:313,AltShiftRight:314,AltShiftPageUp:
315,AltShiftPageDown:316,AltShiftBackspace:317,AltShiftInsert:318,AltShiftDelete:
319,AltShiftHome:320,AltShiftEnd:321,AltShiftTab:322,ShiftF1:323,ShiftF2:324,ShiftF3:
325,ShiftF4:326,ShiftF5:327,ShiftF6:328,ShiftF7:329,ShiftF8:330,ShiftF9:331,ShiftF10:
332,ShiftEnter:333,ShiftEscape:334,ShiftUp:335,ShiftDown:336,ShiftLeft:337,ShiftRight:
338,ShiftPageUp:339,ShiftPageDown:340,ShiftBackspace:341,ShiftInsert:342,ShiftDelete:
343,ShiftHome:344,ShiftEnd:345,ShiftTab:346};E.LU={Mf:0x1,Mc:0x2,Md:0x4,Me:0x8,LK:
0x10,LE:0x20};
E._Init=function(){E.AU.__proto__=E.Ch;E.Y.__proto__=E.AU;E.Root.__proto__=E.Y;E.
KeyEvent.__proto__=E.Event;E.Gh.__proto__=E.Event;E.Gg.__proto__=E.Event;E.Gi.__proto__=
E.Event;E.Ec.__proto__=E.AU;};E.Au=function(D){};return E;})();

/* Embedded Wizard */