/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.Core)throw new Error("The unit file 'Core.js' included twice!");EmWiApp.
Core=(function(){var A=EmWiApp;var E={};
var Ac=[0,0];var At=[0,0,0,0];var Cr="The view does not belong to this group";var
Fn="No view to restack";var C6="View is not in this group";var Hl="No view to remove";
var Hm="No view to add";var Hn="View already in a group";var Ho="Recursive invalidate during active update cycle.";
var Hp="The KeyPressHandler is embedded within an object not being derived "+"from Core::Group.";
E.B4={U:null,P:null,L:null,AI:null,F:0x103,BH:0,AJ:0x14,Gy:function(Ad,I7){},JI:function(
C){if(this.BH===C)return;this.BH=C;if(!!this.L){var CQ=this.U;var A4=0;while(!!CQ&&(
C>CQ.BH)){CQ=CQ.U;A4=A4+1;}CQ=this.P;while(!!CQ&&(C<CQ.BH)){CQ=CQ.P;A4=A4-1;}if(
!!A4)this.L.JN(this,A4);}},Fa:function(C){var B;var A4=C^this.AJ;if(!A4)return;this.
AJ=C;if(!!this.AI&&!((this.F&0x400)===0x400)){this.L.F=this.L.F|0x5000;A.lq([B=this.
L,B.Bk],this);this.L.AN([0,0,(B=this.L.N)[2]-B[0],B[3]-B[1]]);}if(!!this.AI&&((this.
F&0x400)===0x400)){this.AI.ED.F=this.AI.ED.F|0x1000;this.L.F=this.L.F|0x4000;A.lq([
B=this.L,B.Bk],this);}},BU:function(Az,aClip,aOffset,AF,aBlend){},AT:function(W){
return null;},Do:function(Ae,K,Bv,Hq,Hv){return null;},GO:function(Ad,Dy){return Ac;
},Ia:function(aOffset,I6){},GetExtent:function(){return At;},A2:function(CJ,Dx){
var B;if(((this.F&0x200)===0x200))CJ=CJ&~0x400;var HN=(this.F&~Dx)|CJ;var C$=HN^
this.F;this.F=HN;if(!!this.L&&!!(C$&0x14)){var Jd=((this.F&0x14)===0x14);if(Jd&&
!this.L.Br)this.L.Ee(this);if(!Jd&&(this.L.Br===this))this.L.Ee(this.L.H6(this,0x14
));}if(!!this.L&&!!(C$&0x403))this.L.AN(this.GetExtent());if(((!!this.AI&&!!this.
L)&&((HN&0x400)===0x400))&&((C$&0x1)===0x1)){this.F=this.F|0x800;this.L.F=this.L.
F|0x4000;A.lq([B=this.L,B.Bk],this);}if(!!this.L&&((C$&0x400)===0x400)){this.AI=
null;this.F=this.F|0x800;this.L.F=this.L.F|0x4000;A.lq([B=this.L,B.Bk],this);}},
_Init:function(aArg){this.__proto__=E.B4;A.gv++;},_Done:function(){this.__proto__=
null;A.gv--;},_ReInit:function(){},_Mark:function(D){var B;if((B=this.U)&&(B._cycle
!=D))B._Mark(B._cycle=D);if((B=this.P)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=
this.L)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.AI)&&(B._cycle!=D))B._Mark(
B._cycle=D);if((B=this.M)&&(B._cycle!=D))B._Mark(B._cycle=D);},M:null,_cycle:0,_observers:
null,_className:"Core::View"};E.AU={N:A.qy,Gy:function(Ad,I7){var AP=A._NewObject(
E.H_,0);AP.Dc=this.N;AP.Ap=Ad;AP.ED=I7;this.AI=AP;},GO:function(Ad,Dy){var B;var
BO=this.AJ;var AP=this.AI;var Ar=AP.Dc[0];var As=AP.Dc[1];var Ah=AP.Dc[2];var Ai=
AP.Dc[3];var Db=[Ad[2]-Ad[0],Ad[3]-Ad[1]];var Bd=Ah-Ar;var Bb=Ai-As;if(!Dy){var EG=[(
B=AP.Ap)[2]-B[0],B[3]-B[1]];Ar=Ar-AP.Ap[0];As=As-AP.Ap[1];if(EG[0]!==Db[0]){var Ct=((
BO&0x4)===0x4);var Cu=((BO&0x8)===0x8);var FG=((BO&0x1)===0x1);if(!Ct&&(FG||!Cu)
)Ar=((Ar*Db[0])/EG[0])|0;if(!Cu&&(FG||!Ct)){Ah=Ah-AP.Ap[0];Ah=((Ah*Db[0])/EG[0])|
0;Ah=Ah-Db[0];}else Ah=Ah-AP.Ap[2];Ar=Ar+Ad[0];Ah=Ah+Ad[2];if(!FG){if(Ct&&!Cu)Ah=
Ar+Bd;else if(!Ct&&Cu)Ar=Ah-Bd;else{Ar=Ar+((((Ah-Ar)-Bd)/2)|0);Ah=Ar+Bd;}}}else{
Ah=Ah-AP.Ap[2];Ar=Ar+Ad[0];Ah=Ah+Ad[2];}if(EG[1]!==Db[1]){var Cv=((BO&0x10)===0x10
);var Cs=((BO&0x20)===0x20);var FH=((BO&0x2)===0x2);if(!Cv&&(FH||!Cs))As=((As*Db[
1])/EG[1])|0;if(!Cs&&(FH||!Cv)){Ai=Ai-AP.Ap[1];Ai=((Ai*Db[1])/EG[1])|0;Ai=Ai-Db[
1];}else Ai=Ai-AP.Ap[3];As=As+Ad[1];Ai=Ai+Ad[3];if(!FH){if(Cv&&!Cs)Ai=As+Bb;else
if(!Cv&&Cs)As=Ai-Bb;else{As=As+((((Ai-As)-Bb)/2)|0);Ai=As+Bb;}}}else{Ai=Ai-AP.Ap[
3];As=As+Ad[1];Ai=Ai+Ad[3];}}else{switch(Dy){case 3:{Ar=Ad[0];Ah=Ar+Bd;}break;case
4:{Ah=Ad[2];Ar=Ah-Bd;}break;case 1:{As=Ad[1];Ai=As+Bb;}break;case 2:{Ai=Ad[3];As=
Ai-Bb;}break;default:;}if((Dy===3)||(Dy===4)){var Cv=((BO&0x10)===0x10);var Cs=((
BO&0x20)===0x20);var FH=((BO&0x2)===0x2);if(FH){As=Ad[1];Ai=Ad[3];}else if(Cv&&!
Cs){As=Ad[1];Ai=As+Bb;}else if(Cs&&!Cv){Ai=Ad[3];As=Ai-Bb;}else{As=Ad[1]+((((Ad[
3]-Ad[1])-Bb)/2)|0);Ai=As+Bb;}}if((Dy===1)||(Dy===2)){var Ct=((BO&0x4)===0x4);var
Cu=((BO&0x8)===0x8);var FG=((BO&0x1)===0x1);if(FG){Ar=Ad[0];Ah=Ad[2];}else if(Ct&&
!Cu){Ar=Ad[0];Ah=Ar+Bd;}else if(Cu&&!Ct){Ah=Ad[2];Ar=Ah-Bd;}else{Ar=Ad[0]+((((Ad[
2]-Ad[0])-Bd)/2)|0);Ah=Ar+Bd;}}}AP.isEmpty=(Ar>=Ah)||(As>=Ai);if(((this.F&0x100)===
0x100)){this.N=[Ar,As,Ah,Ai];}else{this.O([Ar,As,Ah,Ai]);this.AI=AP;}return[Ah-Ar
,Ai-As];},Ia:function(aOffset,I6){if(I6)this.N=A.tz(this.N,aOffset);else this.O(
A.tz(this.N,aOffset));},GetExtent:function(){return this.N;},O:function(C){var B;
if(A.tm(C,this.N))return;if(!!this.L&&((this.F&0x1)===0x1))this.L.AN(this.N);this.
AI=null;this.N=C;if(!!this.L&&((this.F&0x1)===0x1))this.L.AN(this.N);if((!!this.
L&&((this.F&0x400)===0x400))&&!((this.L.F&0x2000)===0x2000)){this.F=this.F|0x800;
this.L.F=this.L.F|0x4000;A.lq([B=this.L,B.Bk],this);}},_Init:function(aArg){E.B4.
_Init.call(this,aArg);this.__proto__=E.AU;},_className:"Core::RectView"};E.Z={A$:
null,AR:null,GA:null,Bo:null,Da:null,DE:null,Br:null,Gc:255,BU:function(Az,aClip
,aOffset,AF,aBlend){var B;AF=((AF+1)*this.Gc)>>8;aBlend=aBlend&&((this.F&0x2)===
0x2);if(!this.Bo)this.LF(Az,aClip,A.tx(aOffset,this.N.slice(0,2)),AF,aBlend);else{
var A3=255|(255<<8)|(255<<16)|((AF&0xFF)<<24);this.Bo.Update();Az.Jr(aClip,this.
Bo,0,A.tz(this.N,aOffset),Ac,A3,A3,A3,A3,aBlend);}},Do:function(Ae,K,Bv,Hq,Hv){var
B;var G=this.AR;var DF=null;var T=At;var Ax=null;var HM=!!this.DE&&(!!this.DE.HB||
!!this.DE.A$);if(((B=A.il(Ae,this.N))[0]>=B[2])||(B[1]>=B[3]))return null;Ae=A.ty(
Ae,this.N.slice(0,2));while(!!G){if(((G.F&0x400)===0x400)&&!Ax){Ax=G.P;while(!!Ax&&
!((Ax.F&0x200)===0x200))Ax=Ax.P;if(!!Ax)T=A.il(Ae,Ax.GetExtent());else T=At;}if(
Ax===G){Ax=null;T=At;}if((((((G.F&0x8)===0x8)&&((G.F&0x10)===0x10))&&!((G.F&0x40000
)===0x40000))&&!((G.F&0x20000)===0x20000))&&(!((G.F&0x10000)===0x10000)||((this.
Da.Ba===G)&&!HM))){var Dc=G.GetExtent();var Gu=Hq;var DD=null;if(Gu===G)Gu=null;
if(((G.F&0x400)===0x400)){if(!(((B=A.il(Dc,T))[0]>=B[2])||(B[1]>=B[3])))DD=G.Do(
T,K,Bv,Gu,Hv);}else{if(!(((B=A.il(Dc,Ae))[0]>=B[2])||(B[1]>=B[3]))||(Hq===G))DD=
G.Do(Ae,K,Bv,Gu,Hv);}G=G.P;if(!!DD){if(!DF||((DD.FR<DF.FR)&&(DD.FR>=0)))DF=DD;if(
!DD.FR)G=null;}}else G=G.P;}return DF;},A2:function(CJ,Dx){var B;var LH=this.F;E.
AU.A2.call(this,CJ,Dx);var C$=this.F^LH;if(!!this.Br&&((C$&0x40)===0x40)){if(((this.
F&0x40)===0x40))this.Br.A2(0x40,0x0);else this.Br.A2(0x0,0x40);}if(!!this.Da&&((
C$&0x40)===0x40)){if(((this.F&0x40)===0x40)&&((this.Da.Ba.F&0x14)===0x14))this.Da.
Ba.A2(0x40,0x0);else this.Da.Ba.A2(0x0,0x40);}if(!!C$){this.F=this.F|0x8000;A.lq([
this,this.Bk],this);}},O:function(C){var B;if(A.tm(C,this.N))return;var Dh=[(B=this.
N)[2]-B[0],B[3]-B[1]];var GE=[C[2]-C[0],C[3]-C[1]];var DJ=!A.tl(Dh,GE);if(DJ&&!!
this.Bo){this.Bo.G9(GE);A.qw(this,0);A.qw(this.Bo,0);}E.AU.O.call(this,C);if((DJ&&(
Dh[0]>0))&&(Dh[1]>0)){var Ap=[].concat(Ac,Dh);var G=this.A$;var Fy=0x14;while(!!
G){if((!G.AI&&(G.AJ!==Fy))&&!((G.F&0x400)===0x400))G.Gy(Ap,null);G=G.U;}}if(DJ){
this.F=this.F|0x5000;A.lq([this,this.Bk],this);}},HT:function(W){var Jf=(E.KeyEvent.
isPrototypeOf(W)?W:null);var BN=this.GA;if(!Jf)return null;while(!!BN&&(!BN.DP||
!BN.AT(Jf)))BN=BN.U;return BN;},LF:function(Az,aClip,aOffset,AF,aBlend){var B;var
G=this.A$;var Jb=At;var Jl=true;while(!!G){if(((G.F&0x200)===0x200)){var Jk=(E.Fb.
isPrototypeOf(G)?G:null);Jb=A.il(aClip,A.tz(Jk.N,aOffset));Jl=((Jk.F&0x1)===0x1);
}if(((G.F&0x1)===0x1)){if(((G.F&0x400)===0x400)){if(Jl){var T=A.il(A.tz(G.GetExtent(
),aOffset),Jb);if(!((T[0]>=T[2])||(T[1]>=T[3])))G.BU(Az,T,aOffset,AF,aBlend);}}else{
var T=A.il(A.tz(G.GetExtent(),aOffset),aClip);if(!((T[0]>=T[2])||(T[1]>=T[3])))G.
BU(Az,T,aOffset,AF,aBlend);}}G=G.U;}},LJ:function(){var B;var HH=((this.F&0x1000
)===0x1000);var CM=[0,0,(B=this.N)[2]-B[0],B[3]-B[1]];var BL=false;var B8=At;var
AG=At;var BM=Ac;var EA=0;var EB=0;var Ez=0;var A5=0;var G=this.AR;var Ax=null;var
Fy=0x14;var De=null;while(!!G){if(((G.F&0x800)===0x800)){BL=true;G.F=G.F&~0x800;
}if(BL&&((G.F&0x200)===0x200)){BL=false;if(!!(E.Fb.isPrototypeOf(G)?G:null).FU)G.
F=G.F|0x1000;}G=G.P;}BL=false;G=this.A$;if(HH){this.F=this.F&~0x1000;HH=!((CM[0]>=
CM[2])||(CM[1]>=CM[3]));}this.F=this.F|0x2000;while(!!G){if(!De&&(Ez!==A5)){var Ca=
G;var GH=0;var FK=B8[2]-B8[0];var Ft=B8[3]-B8[1];var Gr=0;var DM=Ac;do{if(((Ca.F&
0x200)===0x200))Ca=null;else if(((Ca.F&0x401)===0x401)){DM=[(B=Ca.GetExtent())[2
]-B[0],B[3]-B[1]];if((A5===3)||(A5===4))FK=FK-DM[0];if((A5===1)||(A5===2))Ft=Ft-
DM[1];if(!De||((FK>=0)&&(Ft>=0))){De=Ca;Ca=Ca.U;if((A5===3)||(A5===4)){FK=FK-EA;
if(DM[1]>GH)GH=DM[1];}if((A5===1)||(A5===2)){Ft=Ft-EB;if(DM[0]>Gr)Gr=DM[0];}}else
Ca=null;}else Ca=Ca.U;}while(!!Ca);if(!De)De=Ax;AG=B8;switch(Ez){case 9:case 11:
AG=[].concat(AG.slice(0,3),AG[1]+GH);break;case 10:case 12:AG=A.t3(AG,AG[3]-GH);
break;case 5:case 7:AG=A.t1(AG,AG[0]+Gr);break;case 6:case 8:AG=[].concat(AG[2]-
Gr,AG.slice(1,4));break;default:;}}if(((G.F&0x400)===0x400)){if(!!G.AI&&(G.AI.ED
!==Ax))G.AI=null;if((!G.AI&&BL)&&((G.AJ!==Fy)||!!A5))G.Gy(AG,Ax);}if(!!G.AI){if(
HH&&!((G.F&0x400)===0x400))G.GO(CM,0);if(BL&&((G.F&0x400)===0x400)){var GK=G.GO(
A.tz(AG,BM),A5);if(((G.F&0x1)===0x1)){var Bj=Ac;switch(A5){case 3:Bj=[GK[0]+EA,Bj[
1]];break;case 4:Bj=[-GK[0]-EA,Bj[1]];break;case 1:Bj=[Bj[0],GK[1]+EB];break;case
2:Bj=[Bj[0],-GK[1]-EB];break;default:;}BM=A.tx(BM,Bj);}}}if(((G.F&0x200)===0x200
)){if(BL)A.lq(Ax.Cb,Ax);BL=((G.F&0x1000)===0x1000);Ax=(E.Fb.isPrototypeOf(G)?G:null
);if(BL){G.F=G.F&~0x1000;B8=A.tz(Ax.N,Ax.Fe);AG=B8;BM=Ac;Ez=Ax.FU;A5=Ez;EA=Ax.Space+
Ax.JP;EB=Ax.Space+Ax.JR;BL=!((B8[0]>=B8[2])||(B8[1]>=B8[3]));De=null;switch(Ez){
case 9:case 10:A5=3;break;case 11:case 12:A5=4;break;case 5:case 6:A5=1;break;case
7:case 8:A5=2;break;default:;}}if(BL){this.AN(Ax.N);}}if(G===De){switch(Ez){case
9:case 11:BM=[0,(BM[1]+(AG[3]-AG[1]))+EB];break;case 10:case 12:BM=[0,(BM[1]-(AG[
3]-AG[1]))-EB];break;case 5:case 7:BM=[(BM[0]+(AG[2]-AG[0]))+EA,0];break;case 6:
case 8:BM=[(BM[0]-(AG[2]-AG[0]))-EA,0];break;default:;}De=null;}G=G.U;}if(BL)A.lq(
Ax.Cb,Ax);this.F=this.F&~0x2000;this.Gf([CM[2]-CM[0],CM[3]-CM[1]]);},Bk:function(
B_){var B;var LL=((this.F&0x1000)===0x1000);if(((this.F&0x4000)===0x4000)){this.
F=this.F&~0x4000;this.LJ();}if(((this.F&0x8000)===0x8000)||LL){this.F=this.F&~0x8000;
this.Fl(this.F);}},Ee:function(C){var B;if(!!C&&(C.L!==this))throw new Error(Cr);
if(!!C&&!((C.F&0x14)===0x14))C=null;if(!!C&&((C.F&0x10000)===0x10000))C=null;if(
C===this.Br)return;if(!!this.Br)this.Br.A2(0x0,0x60);this.Br=C;if(!!C){if(((this.
F&0x40)===0x40))C.A2(0x60,0x0);else C.A2(0x20,0x0);}},H$:function(Hu){var tmp=this;
while(!!tmp){Hu=A.tw(Hu,tmp.N.slice(0,2));tmp=tmp.L;}return Hu;},DispatchEvent:function(
W){var B;var G=this.Br;var S=(E.Z.isPrototypeOf(G)?G:null);var X=null;var HM=!!this.
DE&&(!!this.DE.HB||!!this.DE.A$);if(!!G&&((((G.F&0x10000)===0x10000)||((G.F&0x40000
)===0x40000))||((G.F&0x20000)===0x20000))){G=null;S=null;}if(!!this.Da&&!HM)X=this.
Da.Ba.DispatchEvent(W);if(!X&&!!S)X=S.DispatchEvent(W);else if(!X&&!!G)X=G.AT(W);
if(!X)X=this.AT(W);if(!X)X=this.HT(W);return X;},BroadcastEventAtPosition:function(
W,I8,Bg){var B;var G=this.AR;var X=null;while(!!G&&!X){if((!Bg||((B=Bg)&&((G.F&B
)===B)))&&A.qu(G.GetExtent(),I8)){var S=(E.Z.isPrototypeOf(G)?G:null);if(!!S)X=S.
BroadcastEventAtPosition(W,A.tw(I8,S.N.slice(0,2)),Bg);else X=G.AT(W);}G=G.P;}if(
!X)X=this.AT(W);return X;},BroadcastEvent:function(W,Bg){var B;var G=this.AR;var
X=null;while(!!G&&!X){if(!Bg||((B=Bg)&&((G.F&B)===B))){var S=(E.Z.isPrototypeOf(
G)?G:null);if(!!S)X=S.BroadcastEvent(W,Bg);else X=G.AT(W);}G=G.P;}if(!X)X=this.AT(
W);if(!X)X=this.HT(W);return X;},Gf:function(aSize){},Fl:function(Gn){},Dr:function(
){this.F=this.F|0x8000;A.lq([this,this.Bk],this);},AN:function(Ae){var B;var S=this;
while(!!S&&!((Ae[0]>=Ae[2])||(Ae[1]>=Ae[3]))){var Dz=S.Bo;if(!S.L&&(S!==this)){S.
AN(Ae);return;}if(!!Dz){var HG=false;var LG=Dz.BC;if(HG)Dz.BC=[0,0,(B=S.N)[2]-B[
0],B[3]-B[1]];else Dz.BC=A.qR(Dz.BC,Ae);if(!A.tm(LG,Dz.BC)){A.qw(S,0);A.qw(Dz,0);
}}if(!((S.F&0x1)===0x1))return;Ae=A.il(A.tz(Ae,S.N.slice(0,2)),S.N);S=S.L;}},Be:
function(aArg){this.Dr();},H6:function(J,Bg){var B;if(!J||(J.L!==this))return null;
var Dg=J.U;var Dj=J.P;var FD=0x10000;if(((Bg&0x10000)===0x10000))FD=0x0;while(!!
Dg||!!Dj){if((!!Dg&&(!Bg||((B=Bg)&&((Dg.F&B)===B))))&&(!FD||!((B=FD)&&((Dg.F&B)===
B))))return Dg;if((!!Dj&&(!Bg||((B=Bg)&&((Dj.F&B)===B))))&&(!FD||!((B=FD)&&((Dj.
F&B)===B))))return Dj;if(!!Dg)Dg=Dg.U;if(!!Dj)Dj=Dj.P;}return null;},JN:function(
J,Bu){var B;if(!J)throw new Error(Fn);if(J.L!==this)throw new Error(C6);var CK=J;
var Aw=J;var DK=J.BH;while(((Bu>0)&&!!CK.U)&&(CK.U.BH<=DK)){CK=CK.U;Bu=Bu-1;}while(((
Bu<0)&&!!Aw.P)&&(Aw.P.BH>=DK)){Aw=Aw.P;Bu=Bu+1;}if((CK===J)&&(Aw===J))return;if(((
J.F&0x401)===0x401)){if(!!J.P&&!!J.AI)J.P.F=J.P.F|0x800;J.F=J.F|0x800;this.F=this.
F|0x4000;A.lq([this,this.Bk],this);}if(((J.F&0x200)===0x200)){if(!!J.P)J.P.F=J.P.
F|0x800;J.F=J.F|0x800;this.F=this.F|0x4000;A.lq([this,this.Bk],this);}if(!!J.P)J.
P.U=J.U;if(!!J.U)J.U.P=J.P;if(this.A$===J)this.A$=J.U;if(this.AR===J)this.AR=J.P;
if(CK!==J){J.U=CK.U;J.P=CK;CK.U=J;if(!!J.U)J.U.P=J;}if(Aw!==J){J.U=Aw;J.P=Aw.P;Aw.
P=J;if(!!J.P)J.P.U=J;}if(!J.U)this.AR=J;if(!J.P)this.A$=J;if(((J.F&0x1)===0x1))this.
AN(J.GetExtent());},IW:function(J){var B;if(!J)throw new Error(Hl);if(J.L!==this
)throw new Error(C6);if((((J.F&0x401)===0x401)&&!!J.P)&&!!J.AI){J.P.F=J.P.F|0x800;
this.F=this.F|0x4000;A.lq([this,this.Bk],this);}if(((J.F&0x200)===0x200)){if(!!J.
P)J.P.F=J.P.F|0x800;this.F=this.F|0x4000;A.lq([this,this.Bk],this);}J.AI=null;if(
this.Br===J)this.Ee(this.H6(J,0x14));if(!!J.P)J.P.U=J.U;if(!!J.U)J.U.P=J.P;if(this.
A$===J)this.A$=J.U;if(this.AR===J)this.AR=J.P;J.L=null;J.U=null;J.P=null;if(((J.
F&0x1)===0x1))this.AN(J.GetExtent());},V:function(J,Bu){var B;if(!J)throw new Error(
Hm);if(!!J.L)throw new Error(Hn);var Aw=null;var DK=J.BH;if(((Bu<0)&&!!this.AR)&&(
this.AR.BH>=DK)){Aw=this.AR;Bu=Bu+1;}while((((Bu<0)&&!!Aw)&&!!Aw.P)&&(Aw.P.BH>=DK
)){Aw=Aw.P;Bu=Bu+1;}if((!Aw&&!!this.AR)&&(this.AR.BH>DK))Aw=this.AR;while((!!Aw&&
!!Aw.P)&&(Aw.P.BH>DK))Aw=Aw.P;if(!Aw){J.L=this;J.P=this.AR;if(!!this.AR)this.AR.
U=J;if(!this.A$)this.A$=J;this.AR=J;}else{J.L=this;J.P=Aw.P;J.U=Aw;Aw.P=J;if(!!J.
P)J.P.U=J;else this.A$=J;}if(((J.F&0x1)===0x1))this.AN(J.GetExtent());if(((!this.
Br&&((J.F&0x4)===0x4))&&((J.F&0x10)===0x10))&&!((J.F&0x10000)===0x10000))this.Ee(
J);if(((J.F&0x401)===0x401)){J.F=J.F|0x800;this.F=this.F|0x4000;A.lq([this,this.
Bk],this);}if(((J.F&0x200)===0x200)){J.F=J.F|0x800;this.F=this.F|0x4000;A.lq([this
,this.Bk],this);}},_Init:function(aArg){E.AU._Init.call(this,aArg);this.__proto__=
E.Z;this.F=0x1F;this.Be(aArg);},_Mark:function(D){var B;E.AU._Mark.call(this,D);
if((B=this.A$)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.AR)&&(B._cycle!=D))
B._Mark(B._cycle=D);if((B=this.GA)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.
Bo)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.Da)&&(B._cycle!=D))B._Mark(B._cycle=
D);if((B=this.DE)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.Br)&&(B._cycle!=
D))B._Mark(B._cycle=D);},_className:"Core::Group"};E.Root={A8:null,CO:null,B6:null
,AK:A.tA(10,null,null),Ey:null,Bt:null,CL:null,FN:0,Hx:0,Af:0,AW:A.tA(10,0,null)
,Gt:A.tA(10,A.qy,null),B7:A.tA(10,0,null),C_:A.tA(10,A.qx,null),Fv:A.tA(10,0,null
),DB:A.tA(10,A.qx,null),CA:A.tA(10,A.qx,null),CB:A.tA(10,A.qx,null),C9:A.tA(10,A.
qx,null),DC:0,Gx:0,Gw:0,GC:A.tA(3,A.qy,null),Ji:0,AY:A.tA(4,0,null),AE:A.tA(4,A.
qy,null),AA:0,FQ:8,Jt:250,Dd:0,CN:0,HI:true,GB:false,BU:function(Az,aClip,aOffset
,AF,aBlend){var fullScreenUpdate=false;fullScreenUpdate=A.jI;if(!fullScreenUpdate
)Az.FS(aClip,A.tz(A.tz(aClip,aOffset),this.N.slice(0,2)),0x00000000,0x00000000,0x00000000
,0x00000000,false);E.Z.BU.call(this,Az,aClip,aOffset,AF,aBlend);},A2:function(CJ
,Dx){var B;E.Z.A2.call(this,CJ,Dx);if(!this.L&&(((CJ&0x1)===0x1)||((Dx&0x1)===0x1
)))this.AN([0,0,(B=this.N)[2]-B[0],B[3]-B[1]]);if(!this.L&&(((CJ&0x2)===0x2)||((
Dx&0x2)===0x2)))this.AN([0,0,(B=this.N)[2]-B[0],B[3]-B[1]]);},Ee:function(C){if((
C!==this.Bt)||!C)E.Z.Ee.call(this,C);},DispatchEvent:function(W){if((this.Hx>0)&&
!!(E.KeyEvent.isPrototypeOf(W)?W:null))return null;if(!!W){W.ET=!!this.Af;if(!!this.
Af)W.Bs=this.Af;}var X=null;if(!!this.Bt){X=this.Bt.DispatchEvent(W);if(!!X){this.
Af=0;return X;}}if(!!this.CO){X=this.CO.Ba.DispatchEvent(W);if(!X)X=this.AT(W);if(
!X)X=this.HT(W);this.Af=0;return X;}X=E.Z.DispatchEvent.call(this,W);this.Af=0;return X;
},BroadcastEvent:function(W,Bg){if(!!W){W.ET=!!this.Af;if(!!this.Af)W.Bs=this.Af;
}var X=E.Z.BroadcastEvent.call(this,W,Bg);this.Af=0;return X;},AN:function(Ae){var
B;if(this.FN>0)throw new Error(Ho);if(!!this.Bo&&!this.L){if(((B=this.Bo.BC)[0]>=
B[2])||(B[1]>=B[3])){A.qw(this,0);A.qw(this.Bo,0);}var HG=false;if(HG)this.Bo.BC=[
0,0,(B=this.N)[2]-B[0],B[3]-B[1]];else this.Bo.BC=A.qR(this.Bo.BC,Ae);}var fullScreenUpdate=
false;fullScreenUpdate=A.jI;if(fullScreenUpdate)Ae=[0,0,(B=this.N)[2]-B[0],B[3]-
B[1]];if(!!this.L){E.Z.AN.call(this,Ae);return;}Ae=A.il(A.tz(Ae,this.N.slice(0,2
)),this.N);if((Ae[0]>=Ae[2])||(Ae[1]>=Ae[3]))return;var I;for(I=0;I<this.AA;I=I+
1)if(!(((B=A.il(this.AE.Get(I),Ae))[0]>=B[2])||(B[1]>=B[3]))){this.AE.Set(I,A.qR(
this.AE.Get(I),Ae));this.AY.Set(I,A.s9(this.AE.Get(I)));return;}if(this.AA<3){this.
AE.Set(this.AA,Ae);this.AY.Set(this.AA,A.s9(Ae));this.AA=this.AA+1;return;}var Aq;
var A7;var Fz=0;var FA=0;var I_=2147483647;this.AE.Set(this.AA,Ae);this.AY.Set(this.
AA,A.s9(Ae));for(Aq=0;Aq<=this.AA;Aq=Aq+1)for(A7=Aq+1;A7<=this.AA;A7=A7+1){var GL=
A.s9(A.qR(this.AE.Get(Aq),this.AE.Get(A7)));var Jm=((GL<<8)/(this.AY.Get(Aq)+this.
AY.Get(A7)))|0;if(Jm<I_){I_=Jm;Fz=Aq;FA=A7;}}this.AE.Set(Fz,A.qR(this.AE.Get(Fz)
,this.AE.Get(FA)));this.AY.Set(Fz,A.s9(this.AE.Get(Fz)));if(FA!==this.AA){this.AE.
Set(FA,this.AE.Get(this.AA));this.AY.Set(FA,this.AY.Get(this.AA));}},LD:function(
){var AO=A._NewObject(E.GW,0);AO.ET=!!this.Af;if(!!this.Af)AO.Bs=this.Af;return AO;
},Fu:function(){var AO=A._NewObject(E.GU,0);AO.ET=!!this.Af;if(!!this.Af)AO.Bs=this.
Af;return AO;},Gs:function(){var AO=A._NewObject(E.GV,0);AO.ET=!!this.Af;if(!!this.
Af)AO.Bs=this.Af;return AO;},LE:function(B_){var I;var DF=false;for(I=0;I<10;I=I+
1)if(!!this.AK.Get(I)){var AX=this.CB.Get(I);var S=this.AK.Get(I).L;while(!!S&&(
S!==this)){AX=A.tw(AX,S.N.slice(0,2));S=S.L;}if(!S&&(this.AK.Get(I)!==this)){var
tmp=this.AK.Get(I);this.DC=I;this.AK.Set(I,null);tmp.AT(this.Fu().InitializeUp(I
,this.DB.Get(I),this.C_.Get(I),this.B7.Get(I),this.AW.Get(I)+1,this.CA.Get(I),false
,this.CB.Get(I),this.C9.Get(I)));if(tmp===this.B6)this.B6=null;this.BroadcastEvent(
this.Gs().InitializeUp(I,this.AW.Get(I)+1,false,tmp,this.CB.Get(I)),0x18);}else{
this.B7.Set(I,(this.CL.Bs-this.Fv.Get(I))|0);if(this.B7.Get(I)<10)this.B7.Set(I,
10);this.DC=I;this.AK.Get(I).AT(this.Fu().InitializeHold(I,AX,this.C_.Get(I),this.
B7.Get(I),this.AW.Get(I)+1,this.CA.Get(I),this.CB.Get(I),this.C9.Get(I)));DF=true;
}}if(!DF)this.CL.F_(false);},GetFPS:function(){var ticksCount=0;var Je=0;ticksCount=((
new Date).getTime()-A.qt)|0;if(!!this.Gx&&(ticksCount>this.Gx))Je=((this.Gw*1000
)/((ticksCount-this.Gx)|0))|0;this.Gw=0;this.Gx=ticksCount;return Je;},Update:function(
){var B;if(!this.Ey){this.Ey=A._NewObject(A.Graphics.Canvas,0);this.Ey.G9([(B=this.
N)[2]-B[0],B[3]-B[1]]);}this.Ey.Update();return this.UpdateGE20(this.Ey);},UpdateGE20:
function(Az){if(!this.BeginUpdate())return At;var CE=this.UpdateCanvas(Az,Ac);this.
EndUpdate();return CE;},EndUpdate:function(){if(this.AA>0){this.Gw=this.Gw+1;this.
AA=0;}},UpdateCanvas:function(Az,aOffset){var B;var CE=At;var LB=[].concat(aOffset
,A.tx(Az.FrameSize,aOffset));var I;var Aq=this.AA;this.FN=this.FN+1;for(I=0;(I<Aq
)&&(I<4);I=I+1){if(this.AY.Get(I)>0){this.BU(Az,A.ty(this.AE.Get(I),aOffset),[-aOffset[
0],-aOffset[1]],255,true);CE=A.qR(CE,A.il(LB,this.AE.Get(I)));}else Aq=Aq+1;}this.
FN=this.FN-1;if(!((CE[0]>=CE[2])||(CE[1]>=CE[3])))return A.ty(CE,aOffset);else return CE;
},GetUpdateRegion:function(Gm){var I;var Aq=this.AA;if(Gm<0)return At;for(I=0;(I<
Aq)&&(I<4);I=I+1){if(!this.AY.Get(I)){Aq=Aq+1;Gm=Gm+1;}else if(I===Gm)return this.
AE.Get(I);}return At;},BeginUpdate:function(){var LI=true;var fullScreenUpdate=false;
var I;if((!LI&&!fullScreenUpdate)&&(this.AA>0)){var Jp=A.tA(3,A.qy,null);var HY=
this.AA;for(I=0;I<HY;I=I+1)Jp.Set(I,this.AE.Get(I));for(I=0;I<this.Ji;I=I+1)this.
AN(this.GC.Get(I));for(I=0;I<HY;I=I+1)this.GC.Set(I,Jp.Get(I));this.Ji=HY;}var Aq;
var A7;for(Aq=0;Aq<(this.AA-1);Aq=Aq+1)if(this.AY.Get(Aq)>0)for(A7=Aq+1;A7<this.
AA;A7=A7+1)if(this.AY.Get(A7)>0){var GL=A.s9(A.qR(this.AE.Get(Aq),this.AE.Get(A7
)));if(((GL-this.AY.Get(Aq))-this.AY.Get(A7))<0){this.AE.Set(Aq,A.qR(this.AE.Get(
Aq),this.AE.Get(A7)));this.AY.Set(Aq,GL);this.AY.Set(A7,0);}}for(I=this.AA-1;I>=
0;I=I-1)if(!this.AY.Get(I))this.AA=this.AA-1;return this.AA;},DoesNeedUpdate:function(
){if(this.AA>0)return true;return false;},Initialize:function(aSize){this.O([].concat(
Ac,aSize));if(this.HI)this.F=this.F|0x60;else this.F=this.F|0x20;this.AN(this.N);
return this;},SetRootFocus:function(Hs){if(Hs===this.HI)return false;this.HI=Hs;
if(!Hs){if(!!this.Bt)this.Bt.A2(0x0,0x40);if(!!this.CO)this.CO.Ba.A2(0x0,0x40);else
this.A2(0x0,0x40);}else{if(!!this.CO)this.CO.Ba.A2(0x40,0x0);else this.A2(0x40,0x0
);if(!!this.Bt)this.Bt.A2(0x40,0x0);}return true;},SetUserInputTimestamp:function(
LA){this.Af=LA;},DriveKeyboardHitting:function(Av,Dw,Bn){var B;var HU=!!this.A8;
if(!!this.A8&&((!Bn||(this.Dd!==Av))||(this.CN!==Dw))){var AO=null;var G=(E.B4.isPrototypeOf(
B=this.A8)?B:null);var BN=(E.FX.isPrototypeOf(B=this.A8)?B:null);if(!!this.Dd)AO=
A._NewObject(E.KeyEvent,0).Initialize(this.Dd,false);if(this.CN!==0x00)AO=A._NewObject(
E.KeyEvent,0).Initialize2(this.CN,false);if(!!BN)BN.AT(AO);else if(!!G)G.AT(AO);
this.Dd=0;this.CN=0x00;this.A8=null;}if(!!this.A8){var AO=null;var G=(E.B4.isPrototypeOf(
B=this.A8)?B:null);var BN=(E.FX.isPrototypeOf(B=this.A8)?B:null);if(!!Av)AO=A._NewObject(
E.KeyEvent,0).Initialize(Av,true);if(this.CN!==0x00)AO=A._NewObject(E.KeyEvent,0
).Initialize2(Dw,true);if(!!BN)BN.AT(AO);else if(!!G)G.AT(AO);}if(this.GB&&((!Bn||(
this.Dd!==Av))||(this.CN!==Dw))){this.Dd=0;this.CN=0x00;this.GB=false;}if((!this.
A8&&Bn)&&(this.Hx>0)){this.Dd=Av;this.CN=Dw;this.GB=true;}if((!this.A8&&Bn)&&!this.
GB){if(!!Av)this.A8=this.DispatchEvent(A._NewObject(E.KeyEvent,0).Initialize(Av,
true));if(Dw!==0x00)this.A8=this.DispatchEvent(A._NewObject(E.KeyEvent,0).Initialize2(
Dw,true));if(!(E.FX.isPrototypeOf(B=this.A8)?B:null)&&!(E.B4.isPrototypeOf(B=this.
A8)?B:null))this.A8=null;this.Dd=Av;this.CN=Dw;HU=HU||!!this.A8;}this.Af=0;return HU;
},DriveCursorMovement:function(AC){return this.DriveMultiTouchMovement(this.DC,AC
);},DriveMultiTouchMovement:function(K,AC){if((K<0)||(K>9)){this.Af=0;return false;
}var FE=A.tw(AC,this.CB.Get(K));this.CB.Set(K,AC);if(!this.AK.Get(K)||A.tl(FE,Ac
)){this.Af=0;return false;}var AX=AC;var S=this.AK.Get(K).L;while(!!S&&(S!==this
)){AX=A.tw(AX,S.N.slice(0,2));S=S.L;}if(!S&&(this.AK.Get(K)!==this)){var tmp=this.
AK.Get(K);this.DC=K;this.AK.Set(K,null);tmp.AT(this.Fu().InitializeUp(K,this.DB.
Get(K),this.C_.Get(K),this.B7.Get(K),this.AW.Get(K)+1,this.CA.Get(K),false,this.
CB.Get(K),this.C9.Get(K)));if(tmp===this.B6)this.B6=null;this.BroadcastEvent(this.
Gs().InitializeUp(K,this.AW.Get(K)+1,false,tmp,AC),0x18);}else{this.DB.Set(K,AX);
this.DC=K;this.AK.Get(K).AT(this.LD().Initialize(K,AX,this.C_.Get(K),FE,this.B7.
Get(K),this.AW.Get(K)+1,this.CA.Get(K),AC,this.C9.Get(K)));}this.Af=0;return true;
},DriveCursorHitting:function(Bn,K,AC){return this.DriveMultiTouchHitting(Bn,K,AC
);},DriveMultiTouchHitting:function(Bn,K,AC){var B;if((K<0)||(K>9)){this.Af=0;return false;
}var ticksCount=this.Af;var Fw=[].concat([-this.FQ,-this.FQ],[this.FQ+1,this.FQ+
1]);if(!ticksCount){ticksCount=((new Date).getTime()-A.qt)|0;}var LK=this.Af;this.
DriveMultiTouchMovement(K,AC);AC=this.CB.Get(K);this.Af=LK;if(Bn)this.C9.Set(K,AC
);if((Bn&&!this.AK.Get(K))&&!this.Hx){var CC=null;var AX=AC;if(A.qu(this.Gt.Get(
K),AC)&&((ticksCount-this.Fv.Get(K))<=(((B=this.Jt)<0)?B+0x100000000:B)))this.AW.
Set(K,this.AW.Get(K)+1);else this.AW.Set(K,0);this.Gt.Set(K,A.tz(Fw,AC));this.Fv.
Set(K,ticksCount);if((!!this.Bt&&!!this.Bt.L)&&((this.Bt.F&0x18)===0x18)){var T=
A.tz(Fw,this.Bt.L.H$(AC));CC=this.Bt.Do(T,K,this.AW.Get(K)+1,null,0x0);}if(!CC){
if(!!this.B6&&!!this.B6.L){if(((this.B6.F&0x8)===0x8)&&((this.B6.F&0x10)===0x10)
){var T=A.tz(Fw,this.B6.L.H$(AC));CC=this.B6.Do(T,K,this.AW.Get(K)+1,null,0x0);}
}else if(!!this.CO)CC=this.Do(A.tz(Fw,AC),K,this.AW.Get(K)+1,this.CO.Ba,0x0);else
CC=this.Do(A.tz(Fw,AC),K,this.AW.Get(K)+1,null,0x0);}if(!!CC){this.BroadcastEvent(
this.Gs().InitializeDown(K,this.AW.Get(K)+1,false,CC.B4,AC),0x18);this.AK.Set(K,
CC.B4);this.CA.Set(K,CC.G5);}else{this.AK.Set(K,null);this.CA.Set(K,Ac);this.Af=
0;return false;}var S=CC.B4.L;while(!!S&&(S!==this)){AX=A.tw(AX,S.N.slice(0,2));
S=S.L;}this.C_.Set(K,AX);this.DB.Set(K,AX);this.B7.Set(K,0);this.CL.F_(true);this.
DC=K;this.AK.Get(K).AT(this.Fu().InitializeDown(K,AX,this.AW.Get(K)+1,this.CA.Get(
K),false,AC));this.Af=0;return true;}if(!Bn&&!!this.AK.Get(K)){var AX=AC;var S=this.
AK.Get(K).L;while(!!S&&(S!==this)){AX=A.tw(AX,S.N.slice(0,2));S=S.L;}if(!S)AX=this.
DB.Get(K);this.DC=K;var tmp=this.AK.Get(K);this.AK.Set(K,null);tmp.AT(this.Fu().
InitializeUp(K,AX,this.C_.Get(K),this.B7.Get(K),this.AW.Get(K)+1,this.CA.Get(K),
false,AC,this.C9.Get(K)));this.BroadcastEvent(this.Gs().InitializeUp(K,this.AW.Get(
K)+1,false,tmp,AC),0x18);this.Af=0;return true;}this.Af=0;return false;},_Init:function(
aArg){E.Z._Init.call(this,aArg);E.Timer._Init.call(this.CL={M:this},0);(this.AK=[
]).__proto__=E.Root.AK;(this.AW=[]).__proto__=E.Root.AW;(this.Gt=[]).__proto__=E.
Root.Gt;(this.B7=[]).__proto__=E.Root.B7;(this.C_=[]).__proto__=E.Root.C_;(this.
Fv=[]).__proto__=E.Root.Fv;(this.DB=[]).__proto__=E.Root.DB;(this.CA=[]).__proto__=
E.Root.CA;(this.CB=[]).__proto__=E.Root.CB;(this.C9=[]).__proto__=E.Root.C9;(this.
GC=[]).__proto__=E.Root.GC;(this.AY=[]).__proto__=E.Root.AY;(this.AE=[]).__proto__=
E.Root.AE;this.__proto__=E.Root;this.F=0x7F;this.CL.JH(50);this.CL.Gb=[this,this.
LE];},_Done:function(){this.__proto__=E.Z;this.CL._Done();E.Z._Done.call(this);}
,_ReInit:function(){E.Z._ReInit.call(this);this.CL._ReInit();},_Mark:function(D){
var B;E.Z._Mark.call(this,D);if((B=this.A8)&&(B._cycle!=D))B._Mark(B._cycle=D);if((
B=this.CO)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.B6)&&(B._cycle!=D))B._Mark(
B._cycle=D);A.ts(this.AK,D);if((B=this.Ey)&&(B._cycle!=D))B._Mark(B._cycle=D);if((
B=this.Bt)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.CL)._cycle!=D)B._Mark(B.
_cycle=D);},_className:"Core::Root"};E.Event={Bs:0,ET:false,FW:function(){var ticksCount=
0;ticksCount=((new Date).getTime()-A.qt)|0;return ticksCount;},Be:function(aArg){
this.Bs=this.FW();},_Init:function(aArg){this.__proto__=E.Event;this.Be(aArg);A.
gv++;},_Done:function(){this.__proto__=null;A.gv--;},_ReInit:function(){},_Mark:
function(D){var B;if((B=this.M)&&(B._cycle!=D))B._Mark(B._cycle=D);},M:null,_cycle:
0,_observers:null,_className:"Core::Event"};E.KeyEvent={Ay:0,Y:0,Down:false,Initialize2:
function(Av,Bn){this.Ay=0;this.Y=Av;this.Down=Bn;if((Av>=0x30)&&(Av<=0x39))this.
Ay=(10+Av)-48;if((Av>=0x41)&&(Av<=0x5A))this.Ay=(105+Av)-65;if((Av>=0x61)&&(Av<=
0x7A))this.Ay=(105+Av)-97;if(Av===0x20)this.Ay=131;if(!this.Ay)switch(Av){case 0x2B:
this.Ay=132;break;case 0x2D:this.Ay=133;break;case 0x2A:this.Ay=134;break;case 0x2F:
this.Ay=135;break;case 0x3D:this.Ay=136;break;case 0x2E:this.Ay=137;break;case 0x2C:
this.Ay=138;break;case 0x3A:this.Ay=139;break;case 0x3B:this.Ay=140;break;default:;
}return this;},Initialize:function(Av,Bn){this.Ay=Av;this.Down=Bn;this.Y=0x00;var
Hz=Av-10;var Hy=Av-105;if((Hz>=0)&&(Hz<=9))this.Y=(48+Hz)&0xFFFF;if((Hy>=0)&&(Hy<=
25))this.Y=(65+Hy)&0xFFFF;if(Av===131)this.Y=0x20;if(this.Y===0x00)switch(Av){case
132:this.Y=0x2B;break;case 133:this.Y=0x2D;break;case 134:this.Y=0x2A;break;case
135:this.Y=0x2F;break;case 136:this.Y=0x3D;break;case 137:this.Y=0x2E;break;case
138:this.Y=0x2C;break;case 139:this.Y=0x3A;break;case 140:this.Y=0x3B;break;default:;
}return this;},JC:function(I5){switch(I5){case 141:return((this.Y>=0x41)&&(this.
Y<=0x5A))||((this.Y>=0x61)&&(this.Y<=0x7A));case 142:return(((this.Y>=0x41)&&(this.
Y<=0x5A))||((this.Y>=0x61)&&(this.Y<=0x7A)))||((this.Y>=0x30)&&(this.Y<=0x39));case
143:return(this.Y>=0x30)&&(this.Y<=0x39);case 144:return(((this.Y>=0x41)&&(this.
Y<=0x46))||((this.Y>=0x61)&&(this.Y<=0x66)))||((this.Y>=0x30)&&(this.Y<=0x39));case
145:return this.Y!==0x00;case 146:return(this.Y===0x00)&&!!this.Ay;case 147:return(((
this.Ay===6)||(this.Ay===7))||(this.Ay===4))||(this.Ay===5);case 148:return(this.
Y!==0x00)||!!this.Ay;default:;}return I5===this.Ay;},_Init:function(aArg){E.Event.
_Init.call(this,aArg);this.__proto__=E.KeyEvent;},_className:"Core::KeyEvent"};E.
GV={Ha:null,CZ:A.qx,C0:0,CX:0,Down:false,EK:false,InitializeUp:function(K,Bv,Dv,
Hw,BK){this.Down=false;this.CX=K;this.C0=Bv;this.CZ=BK;this.Ha=Hw;this.EK=Dv;return this;
},InitializeDown:function(K,Bv,Dv,Hw,BK){this.Down=true;this.CX=K;this.C0=Bv;this.
CZ=BK;this.Ha=Hw;this.EK=Dv;return this;},_Init:function(aArg){E.Event._Init.call(
this,aArg);this.__proto__=E.GV;},_Mark:function(D){var B;E.Event._Mark.call(this
,D);if((B=this.Ha)&&(B._cycle!=D))B._Mark(B._cycle=D);},_className:"Core::CursorGrabEvent"
};E.GU={EP:A.qx,CZ:A.qx,C0:0,ER:0,EQ:A.qx,EL:A.qx,CX:0,Down:false,EK:false,InitializeHold:
function(K,C7,Fp,Fq,Bv,B5,BK,Fo){this.Down=true;this.CX=K;this.EL=A.tx(C7,B5);this.
EQ=A.tx(Fp,B5);this.ER=Fq;this.C0=Bv;this.CZ=BK;this.EP=Fo;return this;},InitializeUp:
function(K,C7,Fp,Fq,Bv,B5,Dv,BK,Fo){this.Down=false;this.CX=K;this.EL=A.tx(C7,B5
);this.EQ=A.tx(Fp,B5);this.ER=Fq;this.C0=Bv;this.EK=Dv;this.CZ=BK;this.EP=Fo;return this;
},InitializeDown:function(K,C7,Bv,B5,Dv,BK){this.Down=true;this.CX=K;this.EL=A.tx(
C7,B5);this.EQ=A.tx(C7,B5);this.ER=0;this.C0=Bv;this.EK=Dv;this.CZ=BK;this.EP=BK;
return this;},_Init:function(aArg){E.Event._Init.call(this,aArg);this.__proto__=
E.GU;},_className:"Core::CursorEvent"};E.GW={EP:A.qx,CZ:A.qx,C0:0,ER:0,G5:A.qx,EQ:
A.qx,EL:A.qx,CX:0,Initialize:function(K,C7,Fp,aOffset,Fq,Lz,B5,BK,Fo){this.CX=K;
this.EL=A.tx(C7,B5);this.EQ=A.tx(Fp,B5);this.G5=aOffset;this.ER=Fq;this.C0=Lz;this.
CZ=BK;this.EP=Fo;return this;},_Init:function(aArg){E.Event._Init.call(this,aArg
);this.__proto__=E.GW;},_className:"Core::DragEvent"};E.Fb={Cb:null,Fe:A.qx,JR:0
,JP:0,Space:0,FU:0,BU:function(Az,aClip,aOffset,AF,aBlend){},O:function(C){var B;
if(A.tm(C,this.N))return;var Dh=[(B=this.N)[2]-B[0],B[3]-B[1]];var GE=[C[2]-C[0]
,C[3]-C[1]];var DJ=!A.tl(Dh,GE);var FE=A.tw(C.slice(0,2),this.N.slice(0,2));if(!
A.tl(FE,Ac)&&!DJ){var G=this.U;while(!!G&&!((G.F&0x200)===0x200)){if(((G.F&0x400
)===0x400)){var tmp=((G.F&0x100)===0x100);G.Ia(FE,tmp);}G=G.U;}A.lq(this.Cb,this
);}if((DJ&&(Dh[0]>0))&&(Dh[1]>0)){var Ap=A.tz(this.N,this.Fe);var G=this.U;var Fy=
0x14;while(!!G&&!((G.F&0x200)===0x200)){if(((G.F&0x400)===0x400)){if(!!G.AI&&(G.
AI.ED!==this))G.AI=null;if(!G.AI&&((G.AJ!==Fy)||!!this.FU))G.Gy(Ap,this);}G=G.U;
}A.lq(this.Cb,this);}E.AU.O.call(this,C);if(!!this.L&&DJ){this.F=this.F|0x1000;if(
!((this.L.F&0x2000)===0x2000)){this.L.F=this.L.F|0x4000;A.lq([B=this.L,B.Bk],this
);}}},_Init:function(aArg){E.AU._Init.call(this,aArg);this.__proto__=E.Fb;this.F=
0x203;},_Mark:function(D){var B;E.AU._Mark.call(this,D);if((B=this.Cb)&&((B=B[0]
)._cycle!=D))B._Mark(B._cycle=D);},_className:"Core::Outline"};E.FX={U:null,IL:null
,IK:null,IJ:null,DI:0,Bs:0,IX:0,Jx:148,Ay:0,Y:0,DP:true,Down:false,G$:false,FP:false
,AT:function(W){var B;if(!!W&&W.JC(this.Jx)){this.Down=W.Down;this.Ay=W.Ay;this.
Y=W.Y;this.Bs=W.Bs;this.FP=false;if(W.Down){this.IX=this.DI;this.G$=this.DI>0;if(
this.G$)(B=this.IJ)?B[1].call(B[0],this):null;else(B=this.IK)?B[1].call(B[0],this
):null;if(!this.FP)this.DI=this.DI+1;return!this.FP;}if(!W.Down){this.G$=this.DI>
1;this.IX=this.DI-1;this.DI=0;(B=this.IL)?B[1].call(B[0],this):null;return!this.
FP;}}return false;},Be:function(aArg){var B;var Ba=(E.Z.isPrototypeOf(B=this.M)?
B:null);if(!Ba)throw new Error(Hp);this.U=Ba.GA;Ba.GA=this;},_Init:function(aArg
){this.__proto__=E.FX;this.Be(aArg);A.gv++;},_Done:function(){this.__proto__=null;
A.gv--;},_ReInit:function(){},_Mark:function(D){var B;if((B=this.U)&&(B._cycle!=
D))B._Mark(B._cycle=D);if((B=this.IL)&&((B=B[0])._cycle!=D))B._Mark(B._cycle=D);
if((B=this.IK)&&((B=B[0])._cycle!=D))B._Mark(B._cycle=D);if((B=this.IJ)&&((B=B[0
])._cycle!=D))B._Mark(B._cycle=D);if((B=this.M)&&(B._cycle!=D))B._Mark(B._cycle=
D);},M:null,_cycle:0,_observers:null,_className:"Core::KeyPressHandler"};E.Js={B4:
null,FR:0,G5:A.qx,_Init:function(aArg){this.__proto__=E.Js;A.gv++;},_Done:function(
){this.__proto__=null;A.gv--;},_ReInit:function(){},_Mark:function(D){var B;if((
B=this.B4)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.M)&&(B._cycle!=D))B._Mark(
B._cycle=D);},M:null,_cycle:0,_observers:null,_className:"Core::CursorHit"};E.JD={
Ba:null,_Init:function(aArg){this.__proto__=E.JD;A.gv++;},_Done:function(){this.
__proto__=null;A.gv--;},_ReInit:function(){},_Mark:function(D){var B;if((B=this.
Ba)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.M)&&(B._cycle!=D))B._Mark(B._cycle=
D);},M:null,_cycle:0,_observers:null,_className:"Core::ModalContext"};E.H_={ED:null
,Dc:A.qy,Ap:A.qy,isEmpty:false,_Init:function(aArg){this.__proto__=E.H_;A.gv++;}
,_Done:function(){this.__proto__=null;A.gv--;},_ReInit:function(){},_Mark:function(
D){var B;if((B=this.ED)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.M)&&(B._cycle
!=D))B._Mark(B._cycle=D);},M:null,_cycle:0,_observers:null,_className:"Core::LayoutContext"
};E.Ju={Ba:null,_Init:function(aArg){this.__proto__=E.Ju;A.gv++;},_Done:function(
){this.__proto__=null;A.gv--;},_ReInit:function(){},_Mark:function(D){var B;if((
B=this.Ba)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.M)&&(B._cycle!=D))B._Mark(
B._cycle=D);},M:null,_cycle:0,_observers:null,_className:"Core::DialogContext"};
E.JT={HB:null,A$:null,_Init:function(aArg){this.__proto__=E.JT;A.gv++;},_Done:function(
){this.__proto__=null;A.gv--;},_ReInit:function(){},_Mark:function(D){var B;if((
B=this.HB)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.A$)&&(B._cycle!=D))B._Mark(
B._cycle=D);if((B=this.M)&&(B._cycle!=D))B._Mark(B._cycle=D);},M:null,_cycle:0,_observers:
null,_className:"Core::TaskQueue"};E.JS={_Init:function(aArg){this.__proto__=E.JS;
A.gv++;},_Done:function(){this.__proto__=null;A.gv--;},_ReInit:function(){},_Mark:
function(D){var B;if((B=this.M)&&(B._cycle!=D))B._Mark(B._cycle=D);},M:null,_cycle:
0,_observers:null,_className:"Core::Task"};E.CH={resource:null,BT:function(){this.
resource=null;},Be:function(aArg){this.resource=aArg;},_Init:function(aArg){this.
__proto__=E.CH;this.Be(aArg);A.gv++;},_Done:function(){this.BT();this.__proto__=
null;A.gv--;},_ReInit:function(){},_Mark:function(D){var B;if((B=this.M)&&(B._cycle
!=D))B._Mark(B._cycle=D);},M:null,_cycle:0,_observers:null,_className:"Core::Resource"
};E.Timer={Gb:null,timer:null,Bs:0,Period:1000,H0:0,DP:false,BT:function(){var tmp=
this.timer;if(!!tmp)tmp.DestroyTimer();this.timer=null;},HW:function(aBegin,aPeriod
){if(aBegin<0)aBegin=0;if(aPeriod<0)aPeriod=0;var tmp=this.timer;if(!tmp&&((aBegin>
0)||(aPeriod>0)))tmp=A.sL(this,this.Trigger);if(!!tmp){tmp.ResetTimer();tmp.StartTimer(
aBegin,aPeriod);}this.timer=tmp;},JH:function(C){if(C<0)C=0;if(C===this.Period)return;
this.Period=C;if(this.DP)this.HW(this.H0,C);},F_:function(C){if(C===this.DP)return;
this.DP=C;if(C)this.HW(this.H0,this.Period);else this.HW(0,0);this.Bs=this.FW();
},FW:function(){var ticksCount=0;ticksCount=((new Date).getTime()-A.qt)|0;return ticksCount;
},Trigger:function(){var B;this.Bs=this.FW();if(!this.Period)this.F_(false);(B=this.
Gb)?B[1].call(B[0],this):null;},_Init:function(aArg){this.__proto__=E.Timer;A.gv++;
},_Done:function(){this.BT();this.__proto__=null;A.gv--;},_ReInit:function(){},_Mark:
function(D){var B;if((B=this.Gb)&&((B=B[0])._cycle!=D))B._Mark(B._cycle=D);if((B=
this.M)&&(B._cycle!=D))B._Mark(B._cycle=D);},M:null,_cycle:0,_observers:null,_className:
"Core::Timer"};E.MJ={MK:0x1,L2:0x2,L$:0x4,MF:0x8,DP:0x10,Mz:0x20,Ma:0x40,Mi:0x80
,L_:0x100,Md:0x200,L9:0x400,Mo:0x800,Gf:0x1000,MH:0x2000,Mm:0x4000,Mn:0x8000,L7:
0x10000,Ml:0x20000,My:0x40000};E.AJ={Mp:0x1,Mq:0x2,LS:0x4,LT:0x8,LU:0x10,LR:0x20
};E.FU={Mj:0,MC:1,L4:2,Me:3,Ms:4,MD:5,ME:6,L5:7,L6:8,Mg:9,Mf:10,Mu:11,Mt:12};E.KeyCode={
NoKey:0,Ok:1,Exit:2,Menu:3,Up:4,Down:5,Left:6,Right:7,PageUp:8,PageDown:9,Key0:10
,Key1:11,Key2:12,Key3:13,Key4:14,Key5:15,Key6:16,Key7:17,Key8:18,Key9:19,Red:20,
Green:21,Blue:22,Yellow:23,White:24,Magenta:25,F1:26,F2:27,F3:28,F4:29,F5:30,F6:
31,F7:32,F8:33,F9:34,F10:35,ChannelUp:36,ChannelDown:37,Display:38,SkipPrev:39,SkipNext:
40,Home:41,End:42,Insert:43,Delete:44,Clear:45,VolumeUp:46,VolumeDown:47,Show:48
,Hide:49,Play:50,Pause:51,Record:52,Stop:53,Rev:54,Fwd:55,SlowRev:56,SlowFwd:57,
SkipBwd:58,SkipFwd:59,Repeat:60,Eject:61,Help:62,TV:63,DVD:64,VCR:65,EPG:66,OSD:
67,Text:68,PIP:69,Audio:70,Clock:71,Timer:72,Navigation:73,Karaoke:74,Game:75,Subtitle:
76,Zoom:77,Index:78,Info:79,Power:80,Setup:81,Angle:82,Mode:83,Mute:84,User0:85,
User1:86,User2:87,User3:88,User4:89,User5:90,User6:91,User7:92,User8:93,User9:94
,User10:95,User11:96,User12:97,User13:98,User14:99,User15:100,User16:101,User17:
102,User18:103,User19:104,KeyA:105,KeyB:106,KeyC:107,KeyD:108,KeyE:109,KeyF:110,
KeyG:111,KeyH:112,KeyI:113,KeyJ:114,KeyK:115,KeyL:116,KeyM:117,KeyN:118,KeyO:119
,KeyP:120,KeyQ:121,KeyR:122,KeyS:123,KeyT:124,KeyU:125,KeyV:126,KeyW:127,KeyX:128
,KeyY:129,KeyZ:130,Space:131,Plus:132,Minus:133,Multiply:134,Divide:135,Equals:136
,Period:137,Comma:138,Colon:139,Semicolon:140,AlphaKeys:141,AlphaOrDigitKeys:142
,DigitKeys:143,HexDigitKeys:144,CharacterKeys:145,ControlKeys:146,CursorKeys:147
,AnyKey:148,Enter:149,Escape:150,Backspace:151,Tab:152,CtrlKeyA:153,CtrlKeyB:154
,CtrlKeyC:155,CtrlKeyD:156,CtrlKeyE:157,CtrlKeyF:158,CtrlKeyG:159,CtrlKeyH:160,CtrlKeyI:
161,CtrlKeyJ:162,CtrlKeyK:163,CtrlKeyL:164,CtrlKeyM:165,CtrlKeyN:166,CtrlKeyO:167
,CtrlKeyP:168,CtrlKeyQ:169,CtrlKeyR:170,CtrlKeyS:171,CtrlKeyT:172,CtrlKeyU:173,CtrlKeyV:
174,CtrlKeyW:175,CtrlKeyX:176,CtrlKeyY:177,CtrlKeyZ:178,CtrlSpace:179,CtrlKey0:180
,CtrlKey1:181,CtrlKey2:182,CtrlKey3:183,CtrlKey4:184,CtrlKey5:185,CtrlKey6:186,CtrlKey7:
187,CtrlKey8:188,CtrlKey9:189,CtrlF1:190,CtrlF2:191,CtrlF3:192,CtrlF4:193,CtrlF5:
194,CtrlF6:195,CtrlF7:196,CtrlF8:197,CtrlF9:198,CtrlF10:199,CtrlEnter:200,CtrlEscape:
201,CtrlUp:202,CtrlDown:203,CtrlLeft:204,CtrlRight:205,CtrlPageUp:206,CtrlPageDown:
207,CtrlBackspace:208,CtrlInsert:209,CtrlDelete:210,CtrlHome:211,CtrlEnd:212,CtrlTab:
213,CtrlShiftKeyA:214,CtrlShiftKeyB:215,CtrlShiftKeyC:216,CtrlShiftKeyD:217,CtrlShiftKeyE:
218,CtrlShiftKeyF:219,CtrlShiftKeyG:220,CtrlShiftKeyH:221,CtrlShiftKeyI:222,CtrlShiftKeyJ:
223,CtrlShiftKeyK:224,CtrlShiftKeyL:225,CtrlShiftKeyM:226,CtrlShiftKeyN:227,CtrlShiftKeyO:
228,CtrlShiftKeyP:229,CtrlShiftKeyQ:230,CtrlShiftKeyR:231,CtrlShiftKeyS:232,CtrlShiftKeyT:
233,CtrlShiftKeyU:234,CtrlShiftKeyV:235,CtrlShiftKeyW:236,CtrlShiftKeyX:237,CtrlShiftKeyY:
238,CtrlShiftKeyZ:239,CtrlShiftSpace:240,CtrlShiftKey0:241,CtrlShiftKey1:242,CtrlShiftKey2:
243,CtrlShiftKey3:244,CtrlShiftKey4:245,CtrlShiftKey5:246,CtrlShiftKey6:247,CtrlShiftKey7:
248,CtrlShiftKey8:249,CtrlShiftKey9:250,CtrlShiftF1:251,CtrlShiftF2:252,CtrlShiftF3:
253,CtrlShiftF4:254,CtrlShiftF5:255,CtrlShiftF6:256,CtrlShiftF7:257,CtrlShiftF8:
258,CtrlShiftF9:259,CtrlShiftF10:260,CtrlShiftEnter:261,CtrlShiftEscape:262,CtrlShiftUp:
263,CtrlShiftDown:264,CtrlShiftLeft:265,CtrlShiftRight:266,CtrlShiftPageUp:267,CtrlShiftPageDown:
268,CtrlShiftBackspace:269,CtrlShiftInsert:270,CtrlShiftDelete:271,CtrlShiftHome:
272,CtrlShiftEnd:273,CtrlShiftTab:274,AltF1:275,AltF2:276,AltF3:277,AltF4:278,AltF5:
279,AltF6:280,AltF7:281,AltF8:282,AltF9:283,AltF10:284,AltEnter:285,AltEscape:286
,AltUp:287,AltDown:288,AltLeft:289,AltRight:290,AltPageUp:291,AltPageDown:292,AltBackspace:
293,AltInsert:294,AltDelete:295,AltHome:296,AltEnd:297,AltTab:298,AltShiftF1:299
,AltShiftF2:300,AltShiftF3:301,AltShiftF4:302,AltShiftF5:303,AltShiftF6:304,AltShiftF7:
305,AltShiftF8:306,AltShiftF9:307,AltShiftF10:308,AltShiftEnter:309,AltShiftEscape:
310,AltShiftUp:311,AltShiftDown:312,AltShiftLeft:313,AltShiftRight:314,AltShiftPageUp:
315,AltShiftPageDown:316,AltShiftBackspace:317,AltShiftInsert:318,AltShiftDelete:
319,AltShiftHome:320,AltShiftEnd:321,AltShiftTab:322,ShiftF1:323,ShiftF2:324,ShiftF3:
325,ShiftF4:326,ShiftF5:327,ShiftF6:328,ShiftF7:329,ShiftF8:330,ShiftF9:331,ShiftF10:
332,ShiftEnter:333,ShiftEscape:334,ShiftUp:335,ShiftDown:336,ShiftLeft:337,ShiftRight:
338,ShiftPageUp:339,ShiftPageDown:340,ShiftBackspace:341,ShiftInsert:342,ShiftDelete:
343,ShiftHome:344,ShiftEnd:345,ShiftTab:346};E.Mr={MO:0x1,ML:0x2,MM:0x4,MN:0x8,Mh:
0x10,Mb:0x20};
E._Init=function(){E.AU.__proto__=E.B4;E.Z.__proto__=E.AU;E.Root.__proto__=E.Z;E.
KeyEvent.__proto__=E.Event;E.GV.__proto__=E.Event;E.GU.__proto__=E.Event;E.GW.__proto__=
E.Event;E.Fb.__proto__=E.AU;};E.Au=function(D){};return E;})();

/* Embedded Wizard */