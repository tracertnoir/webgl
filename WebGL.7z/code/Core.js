/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.Core)throw new Error("The unit file 'Core.js' included twice!");EmWiApp.
Core=(function(){var B=EmWiApp;var D={};
var Z=[0,0];var An=[0,0,0,0];var Ca="The view does not belong to this group";var Ex=
"No view to restack";var CN="View is not in this group";var Gx="No view to remove";
var Gy="No view to add";var Gz="View already in a group";var GA="Recursive invalidate during active update cycle.";
var GB="The KeyPressHandler is embedded within an object not being derived "+"from Core::Group.";
D.B2={S:null,N:null,K:null,AD:null,F:0x103,BF:0,AE:0x14,Fx:function(Aa,HP){},It:function(
C){if(this.BF===C)return;this.BF=C;if(!!this.K){var Cz=this.S;var AY=0;while(!!Cz&&(
C>Cz.BF)){Cz=Cz.S;AY=AY+1;}Cz=this.N;while(!!Cz&&(C<Cz.BF)){Cz=Cz.N;AY=AY-1;}if(
!!AY)this.K.IG(this,AY);}},Eo:function(C){var A;var AY=C^this.AE;if(!AY)return;this.
AE=C;if(!!this.AD&&!((this.F&0x400)===0x400)){this.K.F=this.K.F|0x5000;B.lq([A=this.
K,A.Be],this);this.K.AG([0,0,(A=this.K.M)[2]-A[0],A[3]-A[1]]);}if(!!this.AD&&((this.
F&0x400)===0x400)){this.AD.D7.F=this.AD.D7.F|0x1000;this.K.F=this.K.F|0x4000;B.lq([
A=this.K,A.Be],this);}},BS:function(Au,aClip,aOffset,AA,aBlend){},AO:function(U){
return null;},C7:function(Ab,J,Bo,GC,GH){return null;},FN:function(Aa,De){return Z;
},Hl:function(aOffset,HO){},GetExtent:function(){return An;},AW:function(Cs,Dd){
var A;if(((this.F&0x200)===0x200))Cs=Cs&~0x400;var GZ=(this.F&~Dd)|Cs;var CS=GZ^
this.F;this.F=GZ;if(!!this.K&&!!(CS&0x14)){var HX=((this.F&0x14)===0x14);if(HX&&
!this.K.Bk)this.K.DI(this);if(!HX&&(this.K.Bk===this))this.K.DI(this.K.Hf(this,0x14
));}if(!!this.K&&!!(CS&0x403))this.K.AG(this.GetExtent());if(((!!this.AD&&!!this.
K)&&((GZ&0x400)===0x400))&&((CS&0x1)===0x1)){this.F=this.F|0x800;this.K.F=this.K.
F|0x4000;B.lq([A=this.K,A.Be],this);}if(!!this.K&&((CS&0x400)===0x400)){this.AD=
null;this.F=this.F|0x800;this.K.F=this.K.F|0x4000;B.lq([A=this.K,A.Be],this);}},
_Init:function(aArg){this.__proto__=D.B2;B.gv++;},_Done:function(){this.__proto__=
null;B.gv--;},_ReInit:function(){},_Mark:function(E){var A;if((A=this.S)&&(A._cycle
!=E))A._Mark(A._cycle=E);if((A=this.N)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=
this.K)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.AD)&&(A._cycle!=E))A._Mark(
A._cycle=E);if((A=this.O)&&(A._cycle!=E))A._Mark(A._cycle=E);},O:null,_cycle:0,_observers:
null,_className:"Core::View"};D.AP={M:B.qy,Fx:function(Aa,HP){var AK=B._NewObject(
D.Hj,0);AK.CV=this.M;AK.Aj=Aa;AK.D7=HP;this.AD=AK;},FN:function(Aa,De){var A;var
BM=this.AE;var AK=this.AD;var Al=AK.CV[0];var Am=AK.CV[1];var Ae=AK.CV[2];var Af=
AK.CV[3];var CU=[Aa[2]-Aa[0],Aa[3]-Aa[1]];var A9=Ae-Al;var A7=Af-Am;if(!De){var D_=[(
A=AK.Aj)[2]-A[0],A[3]-A[1]];Al=Al-AK.Aj[0];Am=Am-AK.Aj[1];if(D_[0]!==CU[0]){var Cc=((
BM&0x4)===0x4);var Cd=((BM&0x8)===0x8);var EQ=((BM&0x1)===0x1);if(!Cc&&(EQ||!Cd)
)Al=((Al*CU[0])/D_[0])|0;if(!Cd&&(EQ||!Cc)){Ae=Ae-AK.Aj[0];Ae=((Ae*CU[0])/D_[0])|
0;Ae=Ae-CU[0];}else Ae=Ae-AK.Aj[2];Al=Al+Aa[0];Ae=Ae+Aa[2];if(!EQ){if(Cc&&!Cd)Ae=
Al+A9;else if(!Cc&&Cd)Al=Ae-A9;else{Al=Al+((((Ae-Al)-A9)/2)|0);Ae=Al+A9;}}}else{
Ae=Ae-AK.Aj[2];Al=Al+Aa[0];Ae=Ae+Aa[2];}if(D_[1]!==CU[1]){var Ce=((BM&0x10)===0x10
);var Cb=((BM&0x20)===0x20);var ER=((BM&0x2)===0x2);if(!Ce&&(ER||!Cb))Am=((Am*CU[
1])/D_[1])|0;if(!Cb&&(ER||!Ce)){Af=Af-AK.Aj[1];Af=((Af*CU[1])/D_[1])|0;Af=Af-CU[
1];}else Af=Af-AK.Aj[3];Am=Am+Aa[1];Af=Af+Aa[3];if(!ER){if(Ce&&!Cb)Af=Am+A7;else
if(!Ce&&Cb)Am=Af-A7;else{Am=Am+((((Af-Am)-A7)/2)|0);Af=Am+A7;}}}else{Af=Af-AK.Aj[
3];Am=Am+Aa[1];Af=Af+Aa[3];}}else{switch(De){case 3:{Al=Aa[0];Ae=Al+A9;}break;case
4:{Ae=Aa[2];Al=Ae-A9;}break;case 1:{Am=Aa[1];Af=Am+A7;}break;case 2:{Af=Aa[3];Am=
Af-A7;}break;default:;}if((De===3)||(De===4)){var Ce=((BM&0x10)===0x10);var Cb=((
BM&0x20)===0x20);var ER=((BM&0x2)===0x2);if(ER){Am=Aa[1];Af=Aa[3];}else if(Ce&&!
Cb){Am=Aa[1];Af=Am+A7;}else if(Cb&&!Ce){Af=Aa[3];Am=Af-A7;}else{Am=Aa[1]+((((Aa[
3]-Aa[1])-A7)/2)|0);Af=Am+A7;}}if((De===1)||(De===2)){var Cc=((BM&0x4)===0x4);var
Cd=((BM&0x8)===0x8);var EQ=((BM&0x1)===0x1);if(EQ){Al=Aa[0];Ae=Aa[2];}else if(Cc&&
!Cd){Al=Aa[0];Ae=Al+A9;}else if(Cd&&!Cc){Ae=Aa[2];Al=Ae-A9;}else{Al=Aa[0]+((((Aa[
2]-Aa[0])-A9)/2)|0);Ae=Al+A9;}}}AK.isEmpty=(Al>=Ae)||(Am>=Af);if(((this.F&0x100)===
0x100)){this.M=[Al,Am,Ae,Af];}else{this.T([Al,Am,Ae,Af]);this.AD=AK;}return[Ae-Al
,Af-Am];},Hl:function(aOffset,HO){if(HO)this.M=B.tz(this.M,aOffset);else this.T(
B.tz(this.M,aOffset));},GetExtent:function(){return this.M;},T:function(C){var A;
if(B.tm(C,this.M))return;if(!!this.K&&((this.F&0x1)===0x1))this.K.AG(this.M);this.
AD=null;this.M=C;if(!!this.K&&((this.F&0x1)===0x1))this.K.AG(this.M);if((!!this.
K&&((this.F&0x400)===0x400))&&!((this.K.F&0x2000)===0x2000)){this.F=this.F|0x800;
this.K.F=this.K.F|0x4000;B.lq([A=this.K,A.Be],this);}},_Init:function(aArg){D.B2.
_Init.call(this,aArg);this.__proto__=D.AP;},_className:"Core::RectView"};D.X={A5:
null,AM:null,Fz:null,Bi:null,CT:null,Dk:null,Bk:null,Fc:255,BS:function(Au,aClip
,aOffset,AA,aBlend){var A;AA=((AA+1)*this.Fc)>>8;aBlend=aBlend&&((this.F&0x2)===
0x2);if(!this.Bi)this.JV(Au,aClip,B.tx(aOffset,this.M.slice(0,2)),AA,aBlend);else{
var AX=255|(255<<8)|(255<<16)|((AA&0xFF)<<24);this.Bi.Update();Au.Ia(aClip,this.
Bi,0,B.tz(this.M,aOffset),Z,AX,AX,AX,AX,aBlend);}},C7:function(Ab,J,Bo,GC,GH){var
A;var G=this.AM;var Dl=null;var R=An;var Ar=null;var GY=!!this.Dk&&(!!this.Dk.GN||
!!this.Dk.A5);if(((A=B.il(Ab,this.M))[0]>=A[2])||(A[1]>=A[3]))return null;Ab=B.ty(
Ab,this.M.slice(0,2));while(!!G){if(((G.F&0x400)===0x400)&&!Ar){Ar=G.N;while(!!Ar&&
!((Ar.F&0x200)===0x200))Ar=Ar.N;if(!!Ar)R=B.il(Ab,Ar.GetExtent());else R=An;}if(
Ar===G){Ar=null;R=An;}if((((((G.F&0x8)===0x8)&&((G.F&0x10)===0x10))&&!((G.F&0x40000
)===0x40000))&&!((G.F&0x20000)===0x20000))&&(!((G.F&0x10000)===0x10000)||((this.
CT.A6===G)&&!GY))){var CV=G.GetExtent();var Ft=GC;var Dj=null;if(Ft===G)Ft=null;
if(((G.F&0x400)===0x400)){if(!(((A=B.il(CV,R))[0]>=A[2])||(A[1]>=A[3])))Dj=G.C7(
R,J,Bo,Ft,GH);}else{if(!(((A=B.il(CV,Ab))[0]>=A[2])||(A[1]>=A[3]))||(GC===G))Dj=
G.C7(Ab,J,Bo,Ft,GH);}G=G.N;if(!!Dj){if(!Dl||((Dj.E2<Dl.E2)&&(Dj.E2>=0)))Dl=Dj;if(
!Dj.E2)G=null;}}else G=G.N;}return Dl;},AW:function(Cs,Dd){var A;var JX=this.F;D.
AP.AW.call(this,Cs,Dd);var CS=this.F^JX;if(!!this.Bk&&((CS&0x40)===0x40)){if(((this.
F&0x40)===0x40))this.Bk.AW(0x40,0x0);else this.Bk.AW(0x0,0x40);}if(!!this.CT&&((
CS&0x40)===0x40)){if(((this.F&0x40)===0x40)&&((this.CT.A6.F&0x14)===0x14))this.CT.
A6.AW(0x40,0x0);else this.CT.A6.AW(0x0,0x40);}if(!!CS){this.F=this.F|0x8000;B.lq([
this,this.Be],this);}},T:function(C){var A;if(B.tm(C,this.M))return;var C0=[(A=this.
M)[2]-A[0],A[3]-A[1]];var FD=[C[2]-C[0],C[3]-C[1]];var Dp=!B.tl(C0,FD);if(Dp&&!!
this.Bi){this.Bi.Ge(FD);B.qw(this,0);B.qw(this.Bi,0);}D.AP.T.call(this,C);if((Dp&&(
C0[0]>0))&&(C0[1]>0)){var Aj=[].concat(Z,C0);var G=this.A5;var EI=0x14;while(!!G
){if((!G.AD&&(G.AE!==EI))&&!((G.F&0x400)===0x400))G.Fx(Aj,null);G=G.S;}}if(Dp){this.
F=this.F|0x5000;B.lq([this,this.Be],this);}},G5:function(U){var HZ=(D.KeyEvent.isPrototypeOf(
U)?U:null);var BL=this.Fz;if(!HZ)return null;while(!!BL&&(!BL.Dv||!BL.AO(HZ)))BL=
BL.S;return BL;},JV:function(Au,aClip,aOffset,AA,aBlend){var A;var G=this.A5;var
HV=An;var H5=true;while(!!G){if(((G.F&0x200)===0x200)){var H4=(D.Ep.isPrototypeOf(
G)?G:null);HV=B.il(aClip,B.tz(H4.M,aOffset));H5=((H4.F&0x1)===0x1);}if(((G.F&0x1
)===0x1)){if(((G.F&0x400)===0x400)){if(H5){var R=B.il(B.tz(G.GetExtent(),aOffset
),HV);if(!((R[0]>=R[2])||(R[1]>=R[3])))G.BS(Au,R,aOffset,AA,aBlend);}}else{var R=
B.il(B.tz(G.GetExtent(),aOffset),aClip);if(!((R[0]>=R[2])||(R[1]>=R[3])))G.BS(Au
,R,aOffset,AA,aBlend);}}G=G.S;}},JZ:function(){var A;var GT=((this.F&0x1000)===0x1000
);var Cv=[0,0,(A=this.M)[2]-A[0],A[3]-A[1]];var BJ=false;var B6=An;var AB=An;var
BK=Z;var D4=0;var D5=0;var D3=0;var AZ=0;var G=this.AM;var Ar=null;var EI=0x14;var
CX=null;while(!!G){if(((G.F&0x800)===0x800)){BJ=true;G.F=G.F&~0x800;}if(BJ&&((G.
F&0x200)===0x200)){BJ=false;if(!!(D.Ep.isPrototypeOf(G)?G:null).E4)G.F=G.F|0x1000;
}G=G.N;}BJ=false;G=this.A5;if(GT){this.F=this.F&~0x1000;GT=!((Cv[0]>=Cv[2])||(Cv[
1]>=Cv[3]));}this.F=this.F|0x2000;while(!!G){if(!CX&&(D3!==AZ)){var B_=G;var FG=
0;var EU=B6[2]-B6[0];var ED=B6[3]-B6[1];var Fq=0;var Ds=Z;do{if(((B_.F&0x200)===
0x200))B_=null;else if(((B_.F&0x401)===0x401)){Ds=[(A=B_.GetExtent())[2]-A[0],A[
3]-A[1]];if((AZ===3)||(AZ===4))EU=EU-Ds[0];if((AZ===1)||(AZ===2))ED=ED-Ds[1];if(
!CX||((EU>=0)&&(ED>=0))){CX=B_;B_=B_.S;if((AZ===3)||(AZ===4)){EU=EU-D4;if(Ds[1]>
FG)FG=Ds[1];}if((AZ===1)||(AZ===2)){ED=ED-D5;if(Ds[0]>Fq)Fq=Ds[0];}}else B_=null;
}else B_=B_.S;}while(!!B_);if(!CX)CX=Ar;AB=B6;switch(D3){case 9:case 11:AB=[].concat(
AB.slice(0,3),AB[1]+FG);break;case 10:case 12:AB=B.t3(AB,AB[3]-FG);break;case 5:
case 7:AB=B.t1(AB,AB[0]+Fq);break;case 6:case 8:AB=[].concat(AB[2]-Fq,AB.slice(1
,4));break;default:;}}if(((G.F&0x400)===0x400)){if(!!G.AD&&(G.AD.D7!==Ar))G.AD=null;
if((!G.AD&&BJ)&&((G.AE!==EI)||!!AZ))G.Fx(AB,Ar);}if(!!G.AD){if(GT&&!((G.F&0x400)===
0x400))G.FN(Cv,0);if(BJ&&((G.F&0x400)===0x400)){var FJ=G.FN(B.tz(AB,BK),AZ);if(((
G.F&0x1)===0x1)){var Bd=Z;switch(AZ){case 3:Bd=[FJ[0]+D4,Bd[1]];break;case 4:Bd=[-
FJ[0]-D4,Bd[1]];break;case 1:Bd=[Bd[0],FJ[1]+D5];break;case 2:Bd=[Bd[0],-FJ[1]-D5
];break;default:;}BK=B.tx(BK,Bd);}}}if(((G.F&0x200)===0x200)){if(BJ)B.lq(Ar.B$,Ar
);BJ=((G.F&0x1000)===0x1000);Ar=(D.Ep.isPrototypeOf(G)?G:null);if(BJ){G.F=G.F&~0x1000;
B6=B.tz(Ar.M,Ar.Es);AB=B6;BK=Z;D3=Ar.E4;AZ=D3;D4=Ar.Space+Ar.II;D5=Ar.Space+Ar.IK;
BJ=!((B6[0]>=B6[2])||(B6[1]>=B6[3]));CX=null;switch(D3){case 9:case 10:AZ=3;break;
case 11:case 12:AZ=4;break;case 5:case 6:AZ=1;break;case 7:case 8:AZ=2;break;default:;
}}if(BJ){this.AG(Ar.M);}}if(G===CX){switch(D3){case 9:case 11:BK=[0,(BK[1]+(AB[3
]-AB[1]))+D5];break;case 10:case 12:BK=[0,(BK[1]-(AB[3]-AB[1]))-D5];break;case 5:
case 7:BK=[(BK[0]+(AB[2]-AB[0]))+D4,0];break;case 6:case 8:BK=[(BK[0]-(AB[2]-AB[
0]))-D4,0];break;default:;}CX=null;}G=G.S;}if(BJ)B.lq(Ar.B$,Ar);this.F=this.F&~0x2000;
this.Ff([Cv[2]-Cv[0],Cv[3]-Cv[1]]);},Be:function(B8){var A;var J1=((this.F&0x1000
)===0x1000);if(((this.F&0x4000)===0x4000)){this.F=this.F&~0x4000;this.JZ();}if(((
this.F&0x8000)===0x8000)||J1){this.F=this.F&~0x8000;this.Ev(this.F);}},DI:function(
C){var A;if(!!C&&(C.K!==this))throw new Error(Ca);if(!!C&&!((C.F&0x14)===0x14))C=
null;if(!!C&&((C.F&0x10000)===0x10000))C=null;if(C===this.Bk)return;if(!!this.Bk
)this.Bk.AW(0x0,0x60);this.Bk=C;if(!!C){if(((this.F&0x40)===0x40))C.AW(0x60,0x0);
else C.AW(0x20,0x0);}},Hk:function(GG){var tmp=this;while(!!tmp){GG=B.tw(GG,tmp.
M.slice(0,2));tmp=tmp.K;}return GG;},DispatchEvent:function(U){var A;var G=this.
Bk;var Q=(D.X.isPrototypeOf(G)?G:null);var V=null;var GY=!!this.Dk&&(!!this.Dk.GN||
!!this.Dk.A5);if(!!G&&((((G.F&0x10000)===0x10000)||((G.F&0x40000)===0x40000))||((
G.F&0x20000)===0x20000))){G=null;Q=null;}if(!!this.CT&&!GY)V=this.CT.A6.DispatchEvent(
U);if(!V&&!!Q)V=Q.DispatchEvent(U);else if(!V&&!!G)V=G.AO(U);if(!V)V=this.AO(U);
if(!V)V=this.G5(U);return V;},BroadcastEventAtPosition:function(U,HQ,Ba){var A;var
G=this.AM;var V=null;while(!!G&&!V){if((!Ba||((A=Ba)&&((G.F&A)===A)))&&B.qu(G.GetExtent(
),HQ)){var Q=(D.X.isPrototypeOf(G)?G:null);if(!!Q)V=Q.BroadcastEventAtPosition(U
,B.tw(HQ,Q.M.slice(0,2)),Ba);else V=G.AO(U);}G=G.N;}if(!V)V=this.AO(U);return V;
},BroadcastEvent:function(U,Ba){var A;var G=this.AM;var V=null;while(!!G&&!V){if(
!Ba||((A=Ba)&&((G.F&A)===A))){var Q=(D.X.isPrototypeOf(G)?G:null);if(!!Q)V=Q.BroadcastEvent(
U,Ba);else V=G.AO(U);}G=G.N;}if(!V)V=this.AO(U);if(!V)V=this.G5(U);return V;},Ff:
function(aSize){},Ev:function(Fm){},C9:function(){this.F=this.F|0x8000;B.lq([this
,this.Be],this);},AG:function(Ab){var A;var Q=this;while(!!Q&&!((Ab[0]>=Ab[2])||(
Ab[1]>=Ab[3]))){var Df=Q.Bi;if(!Q.K&&(Q!==this)){Q.AG(Ab);return;}if(!!Df){var GS=
false;var JW=Df.Bx;if(GS)Df.Bx=[0,0,(A=Q.M)[2]-A[0],A[3]-A[1]];else Df.Bx=B.qR(Df.
Bx,Ab);if(!B.tm(JW,Df.Bx)){B.qw(Q,0);B.qw(Df,0);}}if(!((Q.F&0x1)===0x1))return;Ab=
B.il(B.tz(Ab,Q.M.slice(0,2)),Q.M);Q=Q.K;}},A_:function(aArg){this.C9();},Hf:function(
I,Ba){var A;if(!I||(I.K!==this))return null;var CZ=I.S;var C2=I.N;var EN=0x10000;
if(((Ba&0x10000)===0x10000))EN=0x0;while(!!CZ||!!C2){if((!!CZ&&(!Ba||((A=Ba)&&((
CZ.F&A)===A))))&&(!EN||!((A=EN)&&((CZ.F&A)===A))))return CZ;if((!!C2&&(!Ba||((A=
Ba)&&((C2.F&A)===A))))&&(!EN||!((A=EN)&&((C2.F&A)===A))))return C2;if(!!CZ)CZ=CZ.
S;if(!!C2)C2=C2.N;}return null;},IG:function(I,Bn){var A;if(!I)throw new Error(Ex
);if(I.K!==this)throw new Error(CN);var Ct=I;var Aq=I;var Dq=I.BF;while(((Bn>0)&&
!!Ct.S)&&(Ct.S.BF<=Dq)){Ct=Ct.S;Bn=Bn-1;}while(((Bn<0)&&!!Aq.N)&&(Aq.N.BF>=Dq)){
Aq=Aq.N;Bn=Bn+1;}if((Ct===I)&&(Aq===I))return;if(((I.F&0x401)===0x401)){if(!!I.N&&
!!I.AD)I.N.F=I.N.F|0x800;I.F=I.F|0x800;this.F=this.F|0x4000;B.lq([this,this.Be],
this);}if(((I.F&0x200)===0x200)){if(!!I.N)I.N.F=I.N.F|0x800;I.F=I.F|0x800;this.F=
this.F|0x4000;B.lq([this,this.Be],this);}if(!!I.N)I.N.S=I.S;if(!!I.S)I.S.N=I.N;if(
this.A5===I)this.A5=I.S;if(this.AM===I)this.AM=I.N;if(Ct!==I){I.S=Ct.S;I.N=Ct;Ct.
S=I;if(!!I.S)I.S.N=I;}if(Aq!==I){I.S=Aq;I.N=Aq.N;Aq.N=I;if(!!I.N)I.N.S=I;}if(!I.
S)this.AM=I;if(!I.N)this.A5=I;if(((I.F&0x1)===0x1))this.AG(I.GetExtent());},HI:function(
I){var A;if(!I)throw new Error(Gx);if(I.K!==this)throw new Error(CN);if((((I.F&0x401
)===0x401)&&!!I.N)&&!!I.AD){I.N.F=I.N.F|0x800;this.F=this.F|0x4000;B.lq([this,this.
Be],this);}if(((I.F&0x200)===0x200)){if(!!I.N)I.N.F=I.N.F|0x800;this.F=this.F|0x4000;
B.lq([this,this.Be],this);}I.AD=null;if(this.Bk===I)this.DI(this.Hf(I,0x14));if(
!!I.N)I.N.S=I.S;if(!!I.S)I.S.N=I.N;if(this.A5===I)this.A5=I.S;if(this.AM===I)this.
AM=I.N;I.K=null;I.S=null;I.N=null;if(((I.F&0x1)===0x1))this.AG(I.GetExtent());},
As:function(I,Bn){var A;if(!I)throw new Error(Gy);if(!!I.K)throw new Error(Gz);var
Aq=null;var Dq=I.BF;if(((Bn<0)&&!!this.AM)&&(this.AM.BF>=Dq)){Aq=this.AM;Bn=Bn+1;
}while((((Bn<0)&&!!Aq)&&!!Aq.N)&&(Aq.N.BF>=Dq)){Aq=Aq.N;Bn=Bn+1;}if((!Aq&&!!this.
AM)&&(this.AM.BF>Dq))Aq=this.AM;while((!!Aq&&!!Aq.N)&&(Aq.N.BF>Dq))Aq=Aq.N;if(!Aq
){I.K=this;I.N=this.AM;if(!!this.AM)this.AM.S=I;if(!this.A5)this.A5=I;this.AM=I;
}else{I.K=this;I.N=Aq.N;I.S=Aq;Aq.N=I;if(!!I.N)I.N.S=I;else this.A5=I;}if(((I.F&
0x1)===0x1))this.AG(I.GetExtent());if(((!this.Bk&&((I.F&0x4)===0x4))&&((I.F&0x10
)===0x10))&&!((I.F&0x10000)===0x10000))this.DI(I);if(((I.F&0x401)===0x401)){I.F=
I.F|0x800;this.F=this.F|0x4000;B.lq([this,this.Be],this);}if(((I.F&0x200)===0x200
)){I.F=I.F|0x800;this.F=this.F|0x4000;B.lq([this,this.Be],this);}},_Init:function(
aArg){D.AP._Init.call(this,aArg);this.__proto__=D.X;this.F=0x1F;this.A_(aArg);},
_Mark:function(E){var A;D.AP._Mark.call(this,E);if((A=this.A5)&&(A._cycle!=E))A.
_Mark(A._cycle=E);if((A=this.AM)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.Fz
)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.Bi)&&(A._cycle!=E))A._Mark(A._cycle=
E);if((A=this.CT)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.Dk)&&(A._cycle!=
E))A._Mark(A._cycle=E);if((A=this.Bk)&&(A._cycle!=E))A._Mark(A._cycle=E);},_className:
"Core::Group"};D.Root={A2:null,Cx:null,B4:null,AF:B.tA(10,null,null),D2:null,Bm:
null,Cu:null,EX:0,GJ:0,Ac:0,AR:B.tA(10,0,null),Fs:B.tA(10,B.qy,null),B5:B.tA(10,
0,null),CR:B.tA(10,B.qx,null),EF:B.tA(10,0,null),Dh:B.tA(10,B.qx,null),Cj:B.tA(10
,B.qx,null),Ck:B.tA(10,B.qx,null),CQ:B.tA(10,B.qx,null),Di:0,Fw:0,Fv:0,FB:B.tA(3
,B.qy,null),H2:0,AT:B.tA(4,0,null),Ay:B.tA(4,B.qy,null),Av:0,E1:8,Ic:250,CW:0,Cw:
0,GU:true,FA:false,BS:function(Au,aClip,aOffset,AA,aBlend){var fullScreenUpdate=
false;fullScreenUpdate=B.jI;if(!fullScreenUpdate)Au.E3(aClip,B.tz(B.tz(aClip,aOffset
),this.M.slice(0,2)),0x00000000,0x00000000,0x00000000,0x00000000,false);D.X.BS.call(
this,Au,aClip,aOffset,AA,aBlend);},AW:function(Cs,Dd){var A;D.X.AW.call(this,Cs,
Dd);if(!this.K&&(((Cs&0x1)===0x1)||((Dd&0x1)===0x1)))this.AG([0,0,(A=this.M)[2]-
A[0],A[3]-A[1]]);if(!this.K&&(((Cs&0x2)===0x2)||((Dd&0x2)===0x2)))this.AG([0,0,(
A=this.M)[2]-A[0],A[3]-A[1]]);},DI:function(C){if((C!==this.Bm)||!C)D.X.DI.call(
this,C);},DispatchEvent:function(U){if((this.GJ>0)&&!!(D.KeyEvent.isPrototypeOf(
U)?U:null))return null;if(!!U){U.El=!!this.Ac;if(!!this.Ac)U.Bl=this.Ac;}var V=null;
if(!!this.Bm){V=this.Bm.DispatchEvent(U);if(!!V){this.Ac=0;return V;}}if(!!this.
Cx){V=this.Cx.A6.DispatchEvent(U);if(!V)V=this.AO(U);if(!V)V=this.G5(U);this.Ac=
0;return V;}V=D.X.DispatchEvent.call(this,U);this.Ac=0;return V;},BroadcastEvent:
function(U,Ba){if(!!U){U.El=!!this.Ac;if(!!this.Ac)U.Bl=this.Ac;}var V=D.X.BroadcastEvent.
call(this,U,Ba);this.Ac=0;return V;},AG:function(Ab){var A;if(this.EX>0)throw new
Error(GA);if(!!this.Bi&&!this.K){if(((A=this.Bi.Bx)[0]>=A[2])||(A[1]>=A[3])){B.qw(
this,0);B.qw(this.Bi,0);}var GS=false;if(GS)this.Bi.Bx=[0,0,(A=this.M)[2]-A[0],A[
3]-A[1]];else this.Bi.Bx=B.qR(this.Bi.Bx,Ab);}var fullScreenUpdate=false;fullScreenUpdate=
B.jI;if(fullScreenUpdate)Ab=[0,0,(A=this.M)[2]-A[0],A[3]-A[1]];if(!!this.K){D.X.
AG.call(this,Ab);return;}Ab=B.il(B.tz(Ab,this.M.slice(0,2)),this.M);if((Ab[0]>=Ab[
2])||(Ab[1]>=Ab[3]))return;var H;for(H=0;H<this.Av;H=H+1)if(!(((A=B.il(this.Ay.Get(
H),Ab))[0]>=A[2])||(A[1]>=A[3]))){this.Ay.Set(H,B.qR(this.Ay.Get(H),Ab));this.AT.
Set(H,B.s9(this.Ay.Get(H)));return;}if(this.Av<3){this.Ay.Set(this.Av,Ab);this.AT.
Set(this.Av,B.s9(Ab));this.Av=this.Av+1;return;}var Ak;var A1;var EJ=0;var EK=0;
var HS=2147483647;this.Ay.Set(this.Av,Ab);this.AT.Set(this.Av,B.s9(Ab));for(Ak=0;
Ak<=this.Av;Ak=Ak+1)for(A1=Ak+1;A1<=this.Av;A1=A1+1){var FK=B.s9(B.qR(this.Ay.Get(
Ak),this.Ay.Get(A1)));var H6=((FK<<8)/(this.AT.Get(Ak)+this.AT.Get(A1)))|0;if(H6<
HS){HS=H6;EJ=Ak;EK=A1;}}this.Ay.Set(EJ,B.qR(this.Ay.Get(EJ),this.Ay.Get(EK)));this.
AT.Set(EJ,B.s9(this.Ay.Get(EJ)));if(EK!==this.Av){this.Ay.Set(EK,this.Ay.Get(this.
Av));this.AT.Set(EK,this.AT.Get(this.Av));}},JT:function(){var AI=B._NewObject(D.
FV,0);AI.El=!!this.Ac;if(!!this.Ac)AI.Bl=this.Ac;return AI;},EE:function(){var AI=
B._NewObject(D.FT,0);AI.El=!!this.Ac;if(!!this.Ac)AI.Bl=this.Ac;return AI;},Fr:function(
){var AI=B._NewObject(D.FU,0);AI.El=!!this.Ac;if(!!this.Ac)AI.Bl=this.Ac;return AI;
},JU:function(B8){var H;var Dl=false;for(H=0;H<10;H=H+1)if(!!this.AF.Get(H)){var
AS=this.Ck.Get(H);var Q=this.AF.Get(H).K;while(!!Q&&(Q!==this)){AS=B.tw(AS,Q.M.slice(
0,2));Q=Q.K;}if(!Q&&(this.AF.Get(H)!==this)){var tmp=this.AF.Get(H);this.Di=H;this.
AF.Set(H,null);tmp.AO(this.EE().InitializeUp(H,this.Dh.Get(H),this.CR.Get(H),this.
B5.Get(H),this.AR.Get(H)+1,this.Cj.Get(H),false,this.Ck.Get(H),this.CQ.Get(H)));
if(tmp===this.B4)this.B4=null;this.BroadcastEvent(this.Fr().InitializeUp(H,this.
AR.Get(H)+1,false,tmp,this.Ck.Get(H)),0x18);}else{this.B5.Set(H,(this.Cu.Bl-this.
EF.Get(H))|0);if(this.B5.Get(H)<10)this.B5.Set(H,10);this.Di=H;this.AF.Get(H).AO(
this.EE().InitializeHold(H,AS,this.CR.Get(H),this.B5.Get(H),this.AR.Get(H)+1,this.
Cj.Get(H),this.Ck.Get(H),this.CQ.Get(H)));Dl=true;}}if(!Dl)this.Cu.E_(false);},GetFPS:
function(){var ticksCount=0;var HY=0;ticksCount=((new Date).getTime()-B.qt)|0;if(
!!this.Fw&&(ticksCount>this.Fw))HY=((this.Fv*1000)/((ticksCount-this.Fw)|0))|0;this.
Fv=0;this.Fw=ticksCount;return HY;},Update:function(){var A;if(!this.D2){this.D2=
B._NewObject(B.Graphics.Canvas,0);this.D2.Ge([(A=this.M)[2]-A[0],A[3]-A[1]]);}this.
D2.Update();return this.UpdateGE20(this.D2);},UpdateGE20:function(Au){if(!this.BeginUpdate(
))return An;var Cn=this.UpdateCanvas(Au,Z);this.EndUpdate();return Cn;},EndUpdate:
function(){if(this.Av>0){this.Fv=this.Fv+1;this.Av=0;}},UpdateCanvas:function(Au
,aOffset){var A;var Cn=An;var JR=[].concat(aOffset,B.tx(Au.FrameSize,aOffset));var
H;var Ak=this.Av;this.EX=this.EX+1;for(H=0;(H<Ak)&&(H<4);H=H+1){if(this.AT.Get(H
)>0){this.BS(Au,B.ty(this.Ay.Get(H),aOffset),[-aOffset[0],-aOffset[1]],255,true);
Cn=B.qR(Cn,B.il(JR,this.Ay.Get(H)));}else Ak=Ak+1;}this.EX=this.EX-1;if(!((Cn[0]>=
Cn[2])||(Cn[1]>=Cn[3])))return B.ty(Cn,aOffset);else return Cn;},GetUpdateRegion:
function(Fl){var H;var Ak=this.Av;if(Fl<0)return An;for(H=0;(H<Ak)&&(H<4);H=H+1){
if(!this.AT.Get(H)){Ak=Ak+1;Fl=Fl+1;}else if(H===Fl)return this.Ay.Get(H);}return An;
},BeginUpdate:function(){var JY=true;var fullScreenUpdate=false;var H;if((!JY&&!
fullScreenUpdate)&&(this.Av>0)){var H9=B.tA(3,B.qy,null);var G_=this.Av;for(H=0;
H<G_;H=H+1)H9.Set(H,this.Ay.Get(H));for(H=0;H<this.H2;H=H+1)this.AG(this.FB.Get(
H));for(H=0;H<G_;H=H+1)this.FB.Set(H,H9.Get(H));this.H2=G_;}var Ak;var A1;for(Ak=
0;Ak<(this.Av-1);Ak=Ak+1)if(this.AT.Get(Ak)>0)for(A1=Ak+1;A1<this.Av;A1=A1+1)if(
this.AT.Get(A1)>0){var FK=B.s9(B.qR(this.Ay.Get(Ak),this.Ay.Get(A1)));if(((FK-this.
AT.Get(Ak))-this.AT.Get(A1))<0){this.Ay.Set(Ak,B.qR(this.Ay.Get(Ak),this.Ay.Get(
A1)));this.AT.Set(Ak,FK);this.AT.Set(A1,0);}}for(H=this.Av-1;H>=0;H=H-1)if(!this.
AT.Get(H))this.Av=this.Av-1;return this.Av;},DoesNeedUpdate:function(){if(this.Av>
0)return true;return false;},Initialize:function(aSize){this.T([].concat(Z,aSize
));if(this.GU)this.F=this.F|0x60;else this.F=this.F|0x20;this.AG(this.M);return this;
},SetRootFocus:function(GE){if(GE===this.GU)return false;this.GU=GE;if(!GE){if(!
!this.Bm)this.Bm.AW(0x0,0x40);if(!!this.Cx)this.Cx.A6.AW(0x0,0x40);else this.AW(
0x0,0x40);}else{if(!!this.Cx)this.Cx.A6.AW(0x40,0x0);else this.AW(0x40,0x0);if(!
!this.Bm)this.Bm.AW(0x40,0x0);}return true;},SetUserInputTimestamp:function(JQ){
this.Ac=JQ;},DriveKeyboardHitting:function(Ap,Dc,Bh){var A;var G6=!!this.A2;if(!
!this.A2&&((!Bh||(this.CW!==Ap))||(this.Cw!==Dc))){var AI=null;var G=(D.B2.isPrototypeOf(
A=this.A2)?A:null);var BL=(D.E6.isPrototypeOf(A=this.A2)?A:null);if(!!this.CW)AI=
B._NewObject(D.KeyEvent,0).Initialize(this.CW,false);if(this.Cw!==0x00)AI=B._NewObject(
D.KeyEvent,0).Initialize2(this.Cw,false);if(!!BL)BL.AO(AI);else if(!!G)G.AO(AI);
this.CW=0;this.Cw=0x00;this.A2=null;}if(!!this.A2){var AI=null;var G=(D.B2.isPrototypeOf(
A=this.A2)?A:null);var BL=(D.E6.isPrototypeOf(A=this.A2)?A:null);if(!!Ap)AI=B._NewObject(
D.KeyEvent,0).Initialize(Ap,true);if(this.Cw!==0x00)AI=B._NewObject(D.KeyEvent,0
).Initialize2(Dc,true);if(!!BL)BL.AO(AI);else if(!!G)G.AO(AI);}if(this.FA&&((!Bh||(
this.CW!==Ap))||(this.Cw!==Dc))){this.CW=0;this.Cw=0x00;this.FA=false;}if((!this.
A2&&Bh)&&(this.GJ>0)){this.CW=Ap;this.Cw=Dc;this.FA=true;}if((!this.A2&&Bh)&&!this.
FA){if(!!Ap)this.A2=this.DispatchEvent(B._NewObject(D.KeyEvent,0).Initialize(Ap,
true));if(Dc!==0x00)this.A2=this.DispatchEvent(B._NewObject(D.KeyEvent,0).Initialize2(
Dc,true));if(!(D.E6.isPrototypeOf(A=this.A2)?A:null)&&!(D.B2.isPrototypeOf(A=this.
A2)?A:null))this.A2=null;this.CW=Ap;this.Cw=Dc;G6=G6||!!this.A2;}this.Ac=0;return G6;
},DriveCursorMovement:function(Aw){return this.DriveMultiTouchMovement(this.Di,Aw
);},DriveMultiTouchMovement:function(J,Aw){if((J<0)||(J>9)){this.Ac=0;return false;
}var EO=B.tw(Aw,this.Ck.Get(J));this.Ck.Set(J,Aw);if(!this.AF.Get(J)||B.tl(EO,Z)
){this.Ac=0;return false;}var AS=Aw;var Q=this.AF.Get(J).K;while(!!Q&&(Q!==this)
){AS=B.tw(AS,Q.M.slice(0,2));Q=Q.K;}if(!Q&&(this.AF.Get(J)!==this)){var tmp=this.
AF.Get(J);this.Di=J;this.AF.Set(J,null);tmp.AO(this.EE().InitializeUp(J,this.Dh.
Get(J),this.CR.Get(J),this.B5.Get(J),this.AR.Get(J)+1,this.Cj.Get(J),false,this.
Ck.Get(J),this.CQ.Get(J)));if(tmp===this.B4)this.B4=null;this.BroadcastEvent(this.
Fr().InitializeUp(J,this.AR.Get(J)+1,false,tmp,Aw),0x18);}else{this.Dh.Set(J,AS);
this.Di=J;this.AF.Get(J).AO(this.JT().Initialize(J,AS,this.CR.Get(J),EO,this.B5.
Get(J),this.AR.Get(J)+1,this.Cj.Get(J),Aw,this.CQ.Get(J)));}this.Ac=0;return true;
},DriveCursorHitting:function(Bh,J,Aw){return this.DriveMultiTouchHitting(Bh,J,Aw
);},DriveMultiTouchHitting:function(Bh,J,Aw){var A;if((J<0)||(J>9)){this.Ac=0;return false;
}var ticksCount=this.Ac;var EG=[].concat([-this.E1,-this.E1],[this.E1+1,this.E1+
1]);if(!ticksCount){ticksCount=((new Date).getTime()-B.qt)|0;}var J0=this.Ac;this.
DriveMultiTouchMovement(J,Aw);Aw=this.Ck.Get(J);this.Ac=J0;if(Bh)this.CQ.Set(J,Aw
);if((Bh&&!this.AF.Get(J))&&!this.GJ){var Cl=null;var AS=Aw;if(B.qu(this.Fs.Get(
J),Aw)&&((ticksCount-this.EF.Get(J))<=(((A=this.Ic)<0)?A+0x100000000:A)))this.AR.
Set(J,this.AR.Get(J)+1);else this.AR.Set(J,0);this.Fs.Set(J,B.tz(EG,Aw));this.EF.
Set(J,ticksCount);if((!!this.Bm&&!!this.Bm.K)&&((this.Bm.F&0x18)===0x18)){var R=
B.tz(EG,this.Bm.K.Hk(Aw));Cl=this.Bm.C7(R,J,this.AR.Get(J)+1,null,0x0);}if(!Cl){
if(!!this.B4&&!!this.B4.K){if(((this.B4.F&0x8)===0x8)&&((this.B4.F&0x10)===0x10)
){var R=B.tz(EG,this.B4.K.Hk(Aw));Cl=this.B4.C7(R,J,this.AR.Get(J)+1,null,0x0);}
}else if(!!this.Cx)Cl=this.C7(B.tz(EG,Aw),J,this.AR.Get(J)+1,this.Cx.A6,0x0);else
Cl=this.C7(B.tz(EG,Aw),J,this.AR.Get(J)+1,null,0x0);}if(!!Cl){this.BroadcastEvent(
this.Fr().InitializeDown(J,this.AR.Get(J)+1,false,Cl.B2,Aw),0x18);this.AF.Set(J,
Cl.B2);this.Cj.Set(J,Cl.Gb);}else{this.AF.Set(J,null);this.Cj.Set(J,Z);this.Ac=0;
return false;}var Q=Cl.B2.K;while(!!Q&&(Q!==this)){AS=B.tw(AS,Q.M.slice(0,2));Q=
Q.K;}this.CR.Set(J,AS);this.Dh.Set(J,AS);this.B5.Set(J,0);this.Cu.E_(true);this.
Di=J;this.AF.Get(J).AO(this.EE().InitializeDown(J,AS,this.AR.Get(J)+1,this.Cj.Get(
J),false,Aw));this.Ac=0;return true;}if(!Bh&&!!this.AF.Get(J)){var AS=Aw;var Q=this.
AF.Get(J).K;while(!!Q&&(Q!==this)){AS=B.tw(AS,Q.M.slice(0,2));Q=Q.K;}if(!Q)AS=this.
Dh.Get(J);this.Di=J;var tmp=this.AF.Get(J);this.AF.Set(J,null);tmp.AO(this.EE().
InitializeUp(J,AS,this.CR.Get(J),this.B5.Get(J),this.AR.Get(J)+1,this.Cj.Get(J),
false,Aw,this.CQ.Get(J)));this.BroadcastEvent(this.Fr().InitializeUp(J,this.AR.Get(
J)+1,false,tmp,Aw),0x18);this.Ac=0;return true;}this.Ac=0;return false;},_Init:function(
aArg){D.X._Init.call(this,aArg);D.Timer._Init.call(this.Cu={O:this},0);(this.AF=[
]).__proto__=D.Root.AF;(this.AR=[]).__proto__=D.Root.AR;(this.Fs=[]).__proto__=D.
Root.Fs;(this.B5=[]).__proto__=D.Root.B5;(this.CR=[]).__proto__=D.Root.CR;(this.
EF=[]).__proto__=D.Root.EF;(this.Dh=[]).__proto__=D.Root.Dh;(this.Cj=[]).__proto__=
D.Root.Cj;(this.Ck=[]).__proto__=D.Root.Ck;(this.CQ=[]).__proto__=D.Root.CQ;(this.
FB=[]).__proto__=D.Root.FB;(this.AT=[]).__proto__=D.Root.AT;(this.Ay=[]).__proto__=
D.Root.Ay;this.__proto__=D.Root;this.F=0x7F;this.Cu.Ir(50);this.Cu.Fb=[this,this.
JU];},_Done:function(){this.__proto__=D.X;this.Cu._Done();D.X._Done.call(this);}
,_ReInit:function(){D.X._ReInit.call(this);this.Cu._ReInit();},_Mark:function(E){
var A;D.X._Mark.call(this,E);if((A=this.A2)&&(A._cycle!=E))A._Mark(A._cycle=E);if((
A=this.Cx)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.B4)&&(A._cycle!=E))A._Mark(
A._cycle=E);B.ts(this.AF,E);if((A=this.D2)&&(A._cycle!=E))A._Mark(A._cycle=E);if((
A=this.Bm)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.Cu)._cycle!=E)A._Mark(A.
_cycle=E);},_className:"Core::Root"};D.Event={Bl:0,El:false,E5:function(){var ticksCount=
0;ticksCount=((new Date).getTime()-B.qt)|0;return ticksCount;},A_:function(aArg){
this.Bl=this.E5();},_Init:function(aArg){this.__proto__=D.Event;this.A_(aArg);B.
gv++;},_Done:function(){this.__proto__=null;B.gv--;},_ReInit:function(){},_Mark:
function(E){var A;if((A=this.O)&&(A._cycle!=E))A._Mark(A._cycle=E);},O:null,_cycle:
0,_observers:null,_className:"Core::Event"};D.KeyEvent={At:0,W:0,Down:false,Initialize2:
function(Ap,Bh){this.At=0;this.W=Ap;this.Down=Bh;if((Ap>=0x30)&&(Ap<=0x39))this.
At=(10+Ap)-48;if((Ap>=0x41)&&(Ap<=0x5A))this.At=(105+Ap)-65;if((Ap>=0x61)&&(Ap<=
0x7A))this.At=(105+Ap)-97;if(Ap===0x20)this.At=131;if(!this.At)switch(Ap){case 0x2B:
this.At=132;break;case 0x2D:this.At=133;break;case 0x2A:this.At=134;break;case 0x2F:
this.At=135;break;case 0x3D:this.At=136;break;case 0x2E:this.At=137;break;case 0x2C:
this.At=138;break;case 0x3A:this.At=139;break;case 0x3B:this.At=140;break;default:;
}return this;},Initialize:function(Ap,Bh){this.At=Ap;this.Down=Bh;this.W=0x00;var
GL=Ap-10;var GK=Ap-105;if((GL>=0)&&(GL<=9))this.W=(48+GL)&0xFFFF;if((GK>=0)&&(GK<=
25))this.W=(65+GK)&0xFFFF;if(Ap===131)this.W=0x20;if(this.W===0x00)switch(Ap){case
132:this.W=0x2B;break;case 133:this.W=0x2D;break;case 134:this.W=0x2A;break;case
135:this.W=0x2F;break;case 136:this.W=0x3D;break;case 137:this.W=0x2E;break;case
138:this.W=0x2C;break;case 139:this.W=0x3A;break;case 140:this.W=0x3B;break;default:;
}return this;},Il:function(HN){switch(HN){case 141:return((this.W>=0x41)&&(this.
W<=0x5A))||((this.W>=0x61)&&(this.W<=0x7A));case 142:return(((this.W>=0x41)&&(this.
W<=0x5A))||((this.W>=0x61)&&(this.W<=0x7A)))||((this.W>=0x30)&&(this.W<=0x39));case
143:return(this.W>=0x30)&&(this.W<=0x39);case 144:return(((this.W>=0x41)&&(this.
W<=0x46))||((this.W>=0x61)&&(this.W<=0x66)))||((this.W>=0x30)&&(this.W<=0x39));case
145:return this.W!==0x00;case 146:return(this.W===0x00)&&!!this.At;case 147:return(((
this.At===6)||(this.At===7))||(this.At===4))||(this.At===5);case 148:return(this.
W!==0x00)||!!this.At;default:;}return HN===this.At;},_Init:function(aArg){D.Event.
_Init.call(this,aArg);this.__proto__=D.KeyEvent;},_className:"Core::KeyEvent"};D.
FU={Gh:null,CG:B.qx,CH:0,CF:0,Down:false,Ec:false,InitializeUp:function(J,Bo,Db,
GI,BI){this.Down=false;this.CF=J;this.CH=Bo;this.CG=BI;this.Gh=GI;this.Ec=Db;return this;
},InitializeDown:function(J,Bo,Db,GI,BI){this.Down=true;this.CF=J;this.CH=Bo;this.
CG=BI;this.Gh=GI;this.Ec=Db;return this;},_Init:function(aArg){D.Event._Init.call(
this,aArg);this.__proto__=D.FU;},_Mark:function(E){var A;D.Event._Mark.call(this
,E);if((A=this.Gh)&&(A._cycle!=E))A._Mark(A._cycle=E);},_className:"Core::CursorGrabEvent"
};D.FT={Eh:B.qx,CG:B.qx,CH:0,Ej:0,Ei:B.qx,Ed:B.qx,CF:0,Down:false,Ec:false,InitializeHold:
function(J,CO,Ez,EA,Bo,B3,BI,Ey){this.Down=true;this.CF=J;this.Ed=B.tx(CO,B3);this.
Ei=B.tx(Ez,B3);this.Ej=EA;this.CH=Bo;this.CG=BI;this.Eh=Ey;return this;},InitializeUp:
function(J,CO,Ez,EA,Bo,B3,Db,BI,Ey){this.Down=false;this.CF=J;this.Ed=B.tx(CO,B3
);this.Ei=B.tx(Ez,B3);this.Ej=EA;this.CH=Bo;this.Ec=Db;this.CG=BI;this.Eh=Ey;return this;
},InitializeDown:function(J,CO,Bo,B3,Db,BI){this.Down=true;this.CF=J;this.Ed=B.tx(
CO,B3);this.Ei=B.tx(CO,B3);this.Ej=0;this.CH=Bo;this.Ec=Db;this.CG=BI;this.Eh=BI;
return this;},_Init:function(aArg){D.Event._Init.call(this,aArg);this.__proto__=
D.FT;},_className:"Core::CursorEvent"};D.FV={Eh:B.qx,CG:B.qx,CH:0,Ej:0,Gb:B.qx,Ei:
B.qx,Ed:B.qx,CF:0,Initialize:function(J,CO,Ez,aOffset,EA,JP,B3,BI,Ey){this.CF=J;
this.Ed=B.tx(CO,B3);this.Ei=B.tx(Ez,B3);this.Gb=aOffset;this.Ej=EA;this.CH=JP;this.
CG=BI;this.Eh=Ey;return this;},_Init:function(aArg){D.Event._Init.call(this,aArg
);this.__proto__=D.FV;},_className:"Core::DragEvent"};D.Ep={B$:null,Es:B.qx,IK:0
,II:0,Space:0,E4:0,BS:function(Au,aClip,aOffset,AA,aBlend){},T:function(C){var A;
if(B.tm(C,this.M))return;var C0=[(A=this.M)[2]-A[0],A[3]-A[1]];var FD=[C[2]-C[0]
,C[3]-C[1]];var Dp=!B.tl(C0,FD);var EO=B.tw(C.slice(0,2),this.M.slice(0,2));if(!
B.tl(EO,Z)&&!Dp){var G=this.S;while(!!G&&!((G.F&0x200)===0x200)){if(((G.F&0x400)===
0x400)){var tmp=((G.F&0x100)===0x100);G.Hl(EO,tmp);}G=G.S;}B.lq(this.B$,this);}if((
Dp&&(C0[0]>0))&&(C0[1]>0)){var Aj=B.tz(this.M,this.Es);var G=this.S;var EI=0x14;
while(!!G&&!((G.F&0x200)===0x200)){if(((G.F&0x400)===0x400)){if(!!G.AD&&(G.AD.D7
!==this))G.AD=null;if(!G.AD&&((G.AE!==EI)||!!this.E4))G.Fx(Aj,this);}G=G.S;}B.lq(
this.B$,this);}D.AP.T.call(this,C);if(!!this.K&&Dp){this.F=this.F|0x1000;if(!((this.
K.F&0x2000)===0x2000)){this.K.F=this.K.F|0x4000;B.lq([A=this.K,A.Be],this);}}},_Init:
function(aArg){D.AP._Init.call(this,aArg);this.__proto__=D.Ep;this.F=0x203;},_Mark:
function(E){var A;D.AP._Mark.call(this,E);if((A=this.B$)&&((A=A[0])._cycle!=E))A.
_Mark(A._cycle=E);},_className:"Core::Outline"};D.E6={S:null,HH:null,HG:null,HF:
null,Do:0,Bl:0,HJ:0,Ig:148,At:0,W:0,Dv:true,Down:false,Gg:false,E0:false,AO:function(
U){var A;if(!!U&&U.Il(this.Ig)){this.Down=U.Down;this.At=U.At;this.W=U.W;this.Bl=
U.Bl;this.E0=false;if(U.Down){this.HJ=this.Do;this.Gg=this.Do>0;if(this.Gg)(A=this.
HF)?A[1].call(A[0],this):null;else(A=this.HG)?A[1].call(A[0],this):null;if(!this.
E0)this.Do=this.Do+1;return!this.E0;}if(!U.Down){this.Gg=this.Do>1;this.HJ=this.
Do-1;this.Do=0;(A=this.HH)?A[1].call(A[0],this):null;return!this.E0;}}return false;
},A_:function(aArg){var A;var A6=(D.X.isPrototypeOf(A=this.O)?A:null);if(!A6)throw new
Error(GB);this.S=A6.Fz;A6.Fz=this;},_Init:function(aArg){this.__proto__=D.E6;this.
A_(aArg);B.gv++;},_Done:function(){this.__proto__=null;B.gv--;},_ReInit:function(
){},_Mark:function(E){var A;if((A=this.S)&&(A._cycle!=E))A._Mark(A._cycle=E);if((
A=this.HH)&&((A=A[0])._cycle!=E))A._Mark(A._cycle=E);if((A=this.HG)&&((A=A[0])._cycle
!=E))A._Mark(A._cycle=E);if((A=this.HF)&&((A=A[0])._cycle!=E))A._Mark(A._cycle=E
);if((A=this.O)&&(A._cycle!=E))A._Mark(A._cycle=E);},O:null,_cycle:0,_observers:
null,_className:"Core::KeyPressHandler"};D.Ib={B2:null,E2:0,Gb:B.qx,_Init:function(
aArg){this.__proto__=D.Ib;B.gv++;},_Done:function(){this.__proto__=null;B.gv--;}
,_ReInit:function(){},_Mark:function(E){var A;if((A=this.B2)&&(A._cycle!=E))A._Mark(
A._cycle=E);if((A=this.O)&&(A._cycle!=E))A._Mark(A._cycle=E);},O:null,_cycle:0,_observers:
null,_className:"Core::CursorHit"};D.Im={A6:null,_Init:function(aArg){this.__proto__=
D.Im;B.gv++;},_Done:function(){this.__proto__=null;B.gv--;},_ReInit:function(){}
,_Mark:function(E){var A;if((A=this.A6)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=
this.O)&&(A._cycle!=E))A._Mark(A._cycle=E);},O:null,_cycle:0,_observers:null,_className:
"Core::ModalContext"};D.Hj={D7:null,CV:B.qy,Aj:B.qy,isEmpty:false,_Init:function(
aArg){this.__proto__=D.Hj;B.gv++;},_Done:function(){this.__proto__=null;B.gv--;}
,_ReInit:function(){},_Mark:function(E){var A;if((A=this.D7)&&(A._cycle!=E))A._Mark(
A._cycle=E);if((A=this.O)&&(A._cycle!=E))A._Mark(A._cycle=E);},O:null,_cycle:0,_observers:
null,_className:"Core::LayoutContext"};D.Id={A6:null,_Init:function(aArg){this.__proto__=
D.Id;B.gv++;},_Done:function(){this.__proto__=null;B.gv--;},_ReInit:function(){}
,_Mark:function(E){var A;if((A=this.A6)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=
this.O)&&(A._cycle!=E))A._Mark(A._cycle=E);},O:null,_cycle:0,_observers:null,_className:
"Core::DialogContext"};D.IM={GN:null,A5:null,_Init:function(aArg){this.__proto__=
D.IM;B.gv++;},_Done:function(){this.__proto__=null;B.gv--;},_ReInit:function(){}
,_Mark:function(E){var A;if((A=this.GN)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=
this.A5)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.O)&&(A._cycle!=E))A._Mark(
A._cycle=E);},O:null,_cycle:0,_observers:null,_className:"Core::TaskQueue"};D.IL={
_Init:function(aArg){this.__proto__=D.IL;B.gv++;},_Done:function(){this.__proto__=
null;B.gv--;},_ReInit:function(){},_Mark:function(E){var A;if((A=this.O)&&(A._cycle
!=E))A._Mark(A._cycle=E);},O:null,_cycle:0,_observers:null,_className:"Core::Task"
};D.Cq={resource:null,BR:function(){this.resource=null;},A_:function(aArg){this.
resource=aArg;},_Init:function(aArg){this.__proto__=D.Cq;this.A_(aArg);B.gv++;},
_Done:function(){this.BR();this.__proto__=null;B.gv--;},_ReInit:function(){},_Mark:
function(E){var A;if((A=this.O)&&(A._cycle!=E))A._Mark(A._cycle=E);},O:null,_cycle:
0,_observers:null,_className:"Core::Resource"};D.Timer={Fb:null,timer:null,Bl:0,
Period:1000,Ha:0,Dv:false,BR:function(){var tmp=this.timer;if(!!tmp)tmp.DestroyTimer(
);this.timer=null;},G8:function(aBegin,aPeriod){if(aBegin<0)aBegin=0;if(aPeriod<
0)aPeriod=0;var tmp=this.timer;if(!tmp&&((aBegin>0)||(aPeriod>0)))tmp=B.sL(this,
this.Trigger);if(!!tmp){tmp.ResetTimer();tmp.StartTimer(aBegin,aPeriod);}this.timer=
tmp;},Ir:function(C){if(C<0)C=0;if(C===this.Period)return;this.Period=C;if(this.
Dv)this.G8(this.Ha,C);},E_:function(C){if(C===this.Dv)return;this.Dv=C;if(C)this.
G8(this.Ha,this.Period);else this.G8(0,0);this.Bl=this.E5();},E5:function(){var ticksCount=
0;ticksCount=((new Date).getTime()-B.qt)|0;return ticksCount;},Trigger:function(
){var A;this.Bl=this.E5();if(!this.Period)this.E_(false);(A=this.Fb)?A[1].call(A[
0],this):null;},_Init:function(aArg){this.__proto__=D.Timer;B.gv++;},_Done:function(
){this.BR();this.__proto__=null;B.gv--;},_ReInit:function(){},_Mark:function(E){
var A;if((A=this.Fb)&&((A=A[0])._cycle!=E))A._Mark(A._cycle=E);if((A=this.O)&&(A.
_cycle!=E))A._Mark(A._cycle=E);},O:null,_cycle:0,_observers:null,_className:"Core::Timer"
};D.KZ={K0:0x1,Kg:0x2,Kp:0x4,KV:0x8,Dv:0x10,KP:0x20,Kq:0x40,Ky:0x80,Ko:0x100,Kt:
0x200,Kn:0x400,KE:0x800,Ff:0x1000,KX:0x2000,KC:0x4000,KD:0x8000,Kl:0x10000,KB:0x20000
,KO:0x40000};D.AE={KF:0x1,KG:0x2,J8:0x4,J9:0x8,J_:0x10,J7:0x20};D.E4={Kz:0,KS:1,
Ki:2,Ku:3,KI:4,KT:5,KU:6,Kj:7,Kk:8,Kw:9,Kv:10,KK:11,KJ:12};D.KeyCode={NoKey:0,Ok:
1,Exit:2,Menu:3,Up:4,Down:5,Left:6,Right:7,PageUp:8,PageDown:9,Key0:10,Key1:11,Key2:
12,Key3:13,Key4:14,Key5:15,Key6:16,Key7:17,Key8:18,Key9:19,Red:20,Green:21,Blue:
22,Yellow:23,White:24,Magenta:25,F1:26,F2:27,F3:28,F4:29,F5:30,F6:31,F7:32,F8:33
,F9:34,F10:35,ChannelUp:36,ChannelDown:37,Display:38,SkipPrev:39,SkipNext:40,Home:
41,End:42,Insert:43,Delete:44,Clear:45,VolumeUp:46,VolumeDown:47,Show:48,Hide:49
,Play:50,Pause:51,Record:52,Stop:53,Rev:54,Fwd:55,SlowRev:56,SlowFwd:57,SkipBwd:
58,SkipFwd:59,Repeat:60,Eject:61,Help:62,TV:63,DVD:64,VCR:65,EPG:66,OSD:67,Text:
68,PIP:69,Audio:70,Clock:71,Timer:72,Navigation:73,Karaoke:74,Game:75,Subtitle:76
,Zoom:77,Index:78,Info:79,Power:80,Setup:81,Angle:82,Mode:83,Mute:84,User0:85,User1:
86,User2:87,User3:88,User4:89,User5:90,User6:91,User7:92,User8:93,User9:94,User10:
95,User11:96,User12:97,User13:98,User14:99,User15:100,User16:101,User17:102,User18:
103,User19:104,KeyA:105,KeyB:106,KeyC:107,KeyD:108,KeyE:109,KeyF:110,KeyG:111,KeyH:
112,KeyI:113,KeyJ:114,KeyK:115,KeyL:116,KeyM:117,KeyN:118,KeyO:119,KeyP:120,KeyQ:
121,KeyR:122,KeyS:123,KeyT:124,KeyU:125,KeyV:126,KeyW:127,KeyX:128,KeyY:129,KeyZ:
130,Space:131,Plus:132,Minus:133,Multiply:134,Divide:135,Equals:136,Period:137,Comma:
138,Colon:139,Semicolon:140,AlphaKeys:141,AlphaOrDigitKeys:142,DigitKeys:143,HexDigitKeys:
144,CharacterKeys:145,ControlKeys:146,CursorKeys:147,AnyKey:148,Enter:149,Escape:
150,Backspace:151,Tab:152,CtrlKeyA:153,CtrlKeyB:154,CtrlKeyC:155,CtrlKeyD:156,CtrlKeyE:
157,CtrlKeyF:158,CtrlKeyG:159,CtrlKeyH:160,CtrlKeyI:161,CtrlKeyJ:162,CtrlKeyK:163
,CtrlKeyL:164,CtrlKeyM:165,CtrlKeyN:166,CtrlKeyO:167,CtrlKeyP:168,CtrlKeyQ:169,CtrlKeyR:
170,CtrlKeyS:171,CtrlKeyT:172,CtrlKeyU:173,CtrlKeyV:174,CtrlKeyW:175,CtrlKeyX:176
,CtrlKeyY:177,CtrlKeyZ:178,CtrlSpace:179,CtrlKey0:180,CtrlKey1:181,CtrlKey2:182,
CtrlKey3:183,CtrlKey4:184,CtrlKey5:185,CtrlKey6:186,CtrlKey7:187,CtrlKey8:188,CtrlKey9:
189,CtrlF1:190,CtrlF2:191,CtrlF3:192,CtrlF4:193,CtrlF5:194,CtrlF6:195,CtrlF7:196
,CtrlF8:197,CtrlF9:198,CtrlF10:199,CtrlEnter:200,CtrlEscape:201,CtrlUp:202,CtrlDown:
203,CtrlLeft:204,CtrlRight:205,CtrlPageUp:206,CtrlPageDown:207,CtrlBackspace:208
,CtrlInsert:209,CtrlDelete:210,CtrlHome:211,CtrlEnd:212,CtrlTab:213,CtrlShiftKeyA:
214,CtrlShiftKeyB:215,CtrlShiftKeyC:216,CtrlShiftKeyD:217,CtrlShiftKeyE:218,CtrlShiftKeyF:
219,CtrlShiftKeyG:220,CtrlShiftKeyH:221,CtrlShiftKeyI:222,CtrlShiftKeyJ:223,CtrlShiftKeyK:
224,CtrlShiftKeyL:225,CtrlShiftKeyM:226,CtrlShiftKeyN:227,CtrlShiftKeyO:228,CtrlShiftKeyP:
229,CtrlShiftKeyQ:230,CtrlShiftKeyR:231,CtrlShiftKeyS:232,CtrlShiftKeyT:233,CtrlShiftKeyU:
234,CtrlShiftKeyV:235,CtrlShiftKeyW:236,CtrlShiftKeyX:237,CtrlShiftKeyY:238,CtrlShiftKeyZ:
239,CtrlShiftSpace:240,CtrlShiftKey0:241,CtrlShiftKey1:242,CtrlShiftKey2:243,CtrlShiftKey3:
244,CtrlShiftKey4:245,CtrlShiftKey5:246,CtrlShiftKey6:247,CtrlShiftKey7:248,CtrlShiftKey8:
249,CtrlShiftKey9:250,CtrlShiftF1:251,CtrlShiftF2:252,CtrlShiftF3:253,CtrlShiftF4:
254,CtrlShiftF5:255,CtrlShiftF6:256,CtrlShiftF7:257,CtrlShiftF8:258,CtrlShiftF9:
259,CtrlShiftF10:260,CtrlShiftEnter:261,CtrlShiftEscape:262,CtrlShiftUp:263,CtrlShiftDown:
264,CtrlShiftLeft:265,CtrlShiftRight:266,CtrlShiftPageUp:267,CtrlShiftPageDown:268
,CtrlShiftBackspace:269,CtrlShiftInsert:270,CtrlShiftDelete:271,CtrlShiftHome:272
,CtrlShiftEnd:273,CtrlShiftTab:274,AltF1:275,AltF2:276,AltF3:277,AltF4:278,AltF5:
279,AltF6:280,AltF7:281,AltF8:282,AltF9:283,AltF10:284,AltEnter:285,AltEscape:286
,AltUp:287,AltDown:288,AltLeft:289,AltRight:290,AltPageUp:291,AltPageDown:292,AltBackspace:
293,AltInsert:294,AltDelete:295,AltHome:296,AltEnd:297,AltTab:298,AltShiftF1:299
,AltShiftF2:300,AltShiftF3:301,AltShiftF4:302,AltShiftF5:303,AltShiftF6:304,AltShiftF7:
305,AltShiftF8:306,AltShiftF9:307,AltShiftF10:308,AltShiftEnter:309,AltShiftEscape:
310,AltShiftUp:311,AltShiftDown:312,AltShiftLeft:313,AltShiftRight:314,AltShiftPageUp:
315,AltShiftPageDown:316,AltShiftBackspace:317,AltShiftInsert:318,AltShiftDelete:
319,AltShiftHome:320,AltShiftEnd:321,AltShiftTab:322,ShiftF1:323,ShiftF2:324,ShiftF3:
325,ShiftF4:326,ShiftF5:327,ShiftF6:328,ShiftF7:329,ShiftF8:330,ShiftF9:331,ShiftF10:
332,ShiftEnter:333,ShiftEscape:334,ShiftUp:335,ShiftDown:336,ShiftLeft:337,ShiftRight:
338,ShiftPageUp:339,ShiftPageDown:340,ShiftBackspace:341,ShiftInsert:342,ShiftDelete:
343,ShiftHome:344,ShiftEnd:345,ShiftTab:346};D.KH={K4:0x1,K1:0x2,K2:0x4,K3:0x8,Kx:
0x10,Kr:0x20};
D._Init=function(){D.AP.__proto__=D.B2;D.X.__proto__=D.AP;D.Root.__proto__=D.X;D.
KeyEvent.__proto__=D.Event;D.FU.__proto__=D.Event;D.FT.__proto__=D.Event;D.FV.__proto__=
D.Event;D.Ep.__proto__=D.AP;};D.Ao=function(E){};return D;})();

/* Embedded Wizard */