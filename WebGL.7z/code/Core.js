/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.Core)throw new Error("The unit file 'Core.js' included twice!");EmWiApp.
Core=(function(){var B=EmWiApp;var D={};
var Y=[0,0];var Ax=[0,0,0,0];var BX="The view does not belong to this group";var Ec=
"No view to remove";var CQ="View is not in this group";var FQ="No view to add";var
FR="View already in a group";var FS="Recursive invalidate during active update cycle.";
var FT="The KeyPressHandler is embedded within an object not being derived "+"from Core::Group.";
D.BB={As:null,X:null,K:null,AC:null,F:0x103,D5:0,AA:0x14,E8:function(W,Ha){},EM:function(
C){var A;var B8=C^this.AA;if(!B8)return;this.AA=C;if(!!this.AC&&!((this.F&0x400)===
0x400)){this.K.F=this.K.F|0x5000;B.lq([A=this.K,A.Bm],this);this.K.AT([0,0,(A=this.
K.M)[2]-A[0],A[3]-A[1]]);}if(!!this.AC&&((this.F&0x400)===0x400)){this.AC.Dz.F=this.
AC.Dz.F|0x1000;this.K.F=this.K.F|0x4000;B.lq([A=this.K,A.Bm],this);}},Cb:function(
AD,aClip,aOffset,AE,aBlend){},AK:function(R){return null;},CL:function(Z,I,Bg,FU
,FZ){return null;},Fl:function(W,CU){return Y;},GH:function(aOffset,G$){},GetExtent:
function(){return Ax;},AS:function(Ce,CT){var A;if(((this.F&0x200)===0x200))Ce=Ce&
~0x400;var Gn=(this.F&~CT)|Ce;var Cx=Gn^this.F;this.F=Gn;if(!!this.K&&!!(Cx&0x14
)){var Hh=((this.F&0x14)===0x14);if(Hh&&!this.K.Bd)this.K.Dj(this);if(!Hh&&(this.
K.Bd===this))this.K.Dj(this.K.GB(this,0x14));}if(!!this.K&&!!(Cx&0x403))this.K.AT(
this.GetExtent());if(((!!this.AC&&!!this.K)&&((Gn&0x400)===0x400))&&((Cx&0x1)===
0x1)){this.F=this.F|0x800;this.K.F=this.K.F|0x4000;B.lq([A=this.K,A.Bm],this);}if(
!!this.K&&((Cx&0x400)===0x400)){this.AC=null;this.F=this.F|0x800;this.K.F=this.K.
F|0x4000;B.lq([A=this.K,A.Bm],this);}},_Init:function(aArg){this.__proto__=D.BB;
B.gv++;},_Done:function(){this.__proto__=null;B.gv--;},_ReInit:function(){},_Mark:
function(E){var A;if((A=this.As)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.X
)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.K)&&(A._cycle!=E))A._Mark(A._cycle=
E);if((A=this.AC)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.O)&&(A._cycle!=E
))A._Mark(A._cycle=E);},O:null,_cycle:0,_observers:null,_className:"Core::View"};
D.AL={M:B.qy,E8:function(W,Ha){var AH=B._NewObject(D.GF,0);AH.CA=this.M;AH.Ai=W;
AH.Dz=Ha;this.AC=AH;},Fl:function(W,CU){var A;var Bv=this.AA;var AH=this.AC;var Ak=
AH.CA[0];var Al=AH.CA[1];var Ad=AH.CA[2];var Ae=AH.CA[3];var Cz=[W[2]-W[0],W[3]-
W[1]];var B$=Ad-Ak;var B9=Ae-Al;if(!CU){var DC=[(A=AH.Ai)[2]-A[0],A[3]-A[1]];Ak=
Ak-AH.Ai[0];Al=Al-AH.Ai[1];if(DC[0]!==Cz[0]){var BZ=((Bv&0x4)===0x4);var B0=((Bv&
0x8)===0x8);var Et=((Bv&0x1)===0x1);if(!BZ&&(Et||!B0))Ak=((Ak*Cz[0])/DC[0])|0;if(
!B0&&(Et||!BZ)){Ad=Ad-AH.Ai[0];Ad=((Ad*Cz[0])/DC[0])|0;Ad=Ad-Cz[0];}else Ad=Ad-AH.
Ai[2];Ak=Ak+W[0];Ad=Ad+W[2];if(!Et){if(BZ&&!B0)Ad=Ak+B$;else if(!BZ&&B0)Ak=Ad-B$;
else{Ak=Ak+((((Ad-Ak)-B$)/2)|0);Ad=Ak+B$;}}}else{Ad=Ad-AH.Ai[2];Ak=Ak+W[0];Ad=Ad+
W[2];}if(DC[1]!==Cz[1]){var B1=((Bv&0x10)===0x10);var BY=((Bv&0x20)===0x20);var Eu=((
Bv&0x2)===0x2);if(!B1&&(Eu||!BY))Al=((Al*Cz[1])/DC[1])|0;if(!BY&&(Eu||!B1)){Ae=Ae-
AH.Ai[1];Ae=((Ae*Cz[1])/DC[1])|0;Ae=Ae-Cz[1];}else Ae=Ae-AH.Ai[3];Al=Al+W[1];Ae=
Ae+W[3];if(!Eu){if(B1&&!BY)Ae=Al+B9;else if(!B1&&BY)Al=Ae-B9;else{Al=Al+((((Ae-Al
)-B9)/2)|0);Ae=Al+B9;}}}else{Ae=Ae-AH.Ai[3];Al=Al+W[1];Ae=Ae+W[3];}}else{switch(
CU){case 3:{Ak=W[0];Ad=Ak+B$;}break;case 4:{Ad=W[2];Ak=Ad-B$;}break;case 1:{Al=W[
1];Ae=Al+B9;}break;case 2:{Ae=W[3];Al=Ae-B9;}break;default:;}if((CU===3)||(CU===
4)){var B1=((Bv&0x10)===0x10);var BY=((Bv&0x20)===0x20);var Eu=((Bv&0x2)===0x2);
if(Eu){Al=W[1];Ae=W[3];}else if(B1&&!BY){Al=W[1];Ae=Al+B9;}else if(BY&&!B1){Ae=W[
3];Al=Ae-B9;}else{Al=W[1]+((((W[3]-W[1])-B9)/2)|0);Ae=Al+B9;}}if((CU===1)||(CU===
2)){var BZ=((Bv&0x4)===0x4);var B0=((Bv&0x8)===0x8);var Et=((Bv&0x1)===0x1);if(Et
){Ak=W[0];Ad=W[2];}else if(BZ&&!B0){Ak=W[0];Ad=Ak+B$;}else if(B0&&!BZ){Ad=W[2];Ak=
Ad-B$;}else{Ak=W[0]+((((W[2]-W[0])-B$)/2)|0);Ad=Ak+B$;}}}AH.isEmpty=(Ak>=Ad)||(Al>=
Ae);if(((this.F&0x100)===0x100)){this.M=[Ak,Al,Ad,Ae];}else{this.S([Ak,Al,Ad,Ae]
);this.AC=AH;}return[Ad-Ak,Ae-Al];},GH:function(aOffset,G$){if(G$)this.M=B.tz(this.
M,aOffset);else this.S(B.tz(this.M,aOffset));},GetExtent:function(){return this.
M;},S:function(C){var A;if(B.tm(C,this.M))return;if(!!this.K&&((this.F&0x1)===0x1
))this.K.AT(this.M);this.AC=null;this.M=C;if(!!this.K&&((this.F&0x1)===0x1))this.
K.AT(this.M);if((!!this.K&&((this.F&0x400)===0x400))&&!((this.K.F&0x2000)===0x2000
)){this.F=this.F|0x800;this.K.F=this.K.F|0x4000;B.lq([A=this.K,A.Bm],this);}},_Init:
function(aArg){D.BB._Init.call(this,aArg);this.__proto__=D.AL;},_className:"Core::RectView"
};D.Ab={Bj:null,A0:null,E_:null,Bb:null,Cy:null,C0:null,Bd:null,FD:255,Cb:function(
AD,aClip,aOffset,AE,aBlend){var A;AE=((AE+1)*this.FD)>>8;aBlend=aBlend&&((this.F&
0x2)===0x2);if(!this.Bb)this.I7(AD,aClip,B.tx(aOffset,this.M.slice(0,2)),AE,aBlend
);else{var AV=255|(255<<8)|(255<<16)|((AE&0xFF)<<24);this.Bb.Update();AD.Hu(aClip
,this.Bb,0,B.tz(this.M,aOffset),Y,AV,AV,AV,AV,aBlend);}},CL:function(Z,I,Bg,FU,FZ
){var A;var G=this.A0;var C1=null;var Q=Ax;var Ao=null;var Gm=!!this.C0&&(!!this.
C0.Gc||!!this.C0.Bj);if(((A=B.il(Z,this.M))[0]>=A[2])||(A[1]>=A[3]))return null;
Z=B.ty(Z,this.M.slice(0,2));while(!!G){if(((G.F&0x400)===0x400)&&!Ao){Ao=G.X;while(
!!Ao&&!((Ao.F&0x200)===0x200))Ao=Ao.X;if(!!Ao)Q=B.il(Z,Ao.GetExtent());else Q=Ax;
}if(Ao===G){Ao=null;Q=Ax;}if((((((G.F&0x8)===0x8)&&((G.F&0x10)===0x10))&&!((G.F&
0x40000)===0x40000))&&!((G.F&0x20000)===0x20000))&&(!((G.F&0x10000)===0x10000)||((
this.Cy.A3===G)&&!Gm))){var CA=G.GetExtent();var E5=FU;var CZ=null;if(E5===G)E5=
null;if(((G.F&0x400)===0x400)){if(!(((A=B.il(CA,Q))[0]>=A[2])||(A[1]>=A[3])))CZ=
G.CL(Q,I,Bg,E5,FZ);}else{if(!(((A=B.il(CA,Z))[0]>=A[2])||(A[1]>=A[3]))||(FU===G)
)CZ=G.CL(Z,I,Bg,E5,FZ);}G=G.X;if(!!CZ){if(!C1||((CZ.EE<C1.EE)&&(CZ.EE>=0)))C1=CZ;
if(!CZ.EE)G=null;}}else G=G.X;}return C1;},AS:function(Ce,CT){var A;var I9=this.
F;D.AL.AS.call(this,Ce,CT);var Cx=this.F^I9;if(!!this.Bd&&((Cx&0x40)===0x40)){if(((
this.F&0x40)===0x40))this.Bd.AS(0x40,0x0);else this.Bd.AS(0x0,0x40);}if(!!this.Cy&&((
Cx&0x40)===0x40)){if(((this.F&0x40)===0x40)&&((this.Cy.A3.F&0x14)===0x14))this.Cy.
A3.AS(0x40,0x0);else this.Cy.A3.AS(0x0,0x40);}if(!!Cx){this.F=this.F|0x8000;B.lq([
this,this.Bm],this);}},S:function(C){var A;if(B.tm(C,this.M))return;var CF=[(A=this.
M)[2]-A[0],A[3]-A[1]];var Fc=[C[2]-C[0],C[3]-C[1]];var C5=!B.tl(CF,Fc);if(C5&&!!
this.Bb){this.Bb.FB(Fc);B.qw(this,0);B.qw(this.Bb,0);}D.AL.S.call(this,C);if((C5&&(
CF[0]>0))&&(CF[1]>0)){var Ai=[].concat(Y,CF);var G=this.Bj;var Em=0x14;while(!!G
){if((!G.AC&&(G.AA!==Em))&&!((G.F&0x400)===0x400))G.E8(Ai,null);G=G.As;}}if(C5){
this.F=this.F|0x5000;B.lq([this,this.Bm],this);}},Gr:function(R){var Hj=(D.KeyEvent.
isPrototypeOf(R)?R:null);var Bu=this.E_;if(!Hj)return null;while(!!Bu&&(!Bu.Da||
!Bu.AK(Hj)))Bu=Bu.As;return Bu;},I7:function(AD,aClip,aOffset,AE,aBlend){var A;var
G=this.Bj;var Hf=Ax;var Hp=true;while(!!G){if(((G.F&0x200)===0x200)){var Ho=(D.D1.
isPrototypeOf(G)?G:null);Hf=B.il(aClip,B.tz(Ho.M,aOffset));Hp=((Ho.F&0x1)===0x1);
}if(((G.F&0x1)===0x1)){if(((G.F&0x400)===0x400)){if(Hp){var Q=B.il(B.tz(G.GetExtent(
),aOffset),Hf);if(!((Q[0]>=Q[2])||(Q[1]>=Q[3])))G.Cb(AD,Q,aOffset,AE,aBlend);}}else{
var Q=B.il(B.tz(G.GetExtent(),aOffset),aClip);if(!((Q[0]>=Q[2])||(Q[1]>=Q[3])))G.
Cb(AD,Q,aOffset,AE,aBlend);}}G=G.As;}},I$:function(){var A;var Gh=((this.F&0x1000
)===0x1000);var Cg=[0,0,(A=this.M)[2]-A[0],A[3]-A[1]];var Bs=false;var BF=Ax;var
Ay=Ax;var Bt=Y;var Dx=0;var Dy=0;var Dw=0;var AW=0;var G=this.A0;var Ao=null;var
Em=0x14;var CC=null;while(!!G){if(((G.F&0x800)===0x800)){Bs=true;G.F=G.F&~0x800;
}if(Bs&&((G.F&0x200)===0x200)){Bs=false;if(!!(D.D1.isPrototypeOf(G)?G:null).EF)G.
F=G.F|0x1000;}G=G.X;}Bs=false;G=this.Bj;if(Gh){this.F=this.F&~0x1000;Gh=!((Cg[0]>=
Cg[2])||(Cg[1]>=Cg[3]));}this.F=this.F|0x2000;while(!!G){if(!CC&&(Dw!==AW)){var BJ=
G;var Fe=0;var Ex=BF[2]-BF[0];var Ei=BF[3]-BF[1];var E2=0;var C6=Y;do{if(((BJ.F&
0x200)===0x200))BJ=null;else if(((BJ.F&0x401)===0x401)){C6=[(A=BJ.GetExtent())[2
]-A[0],A[3]-A[1]];if((AW===3)||(AW===4))Ex=Ex-C6[0];if((AW===1)||(AW===2))Ei=Ei-
C6[1];if(!CC||((Ex>=0)&&(Ei>=0))){CC=BJ;BJ=BJ.As;if((AW===3)||(AW===4)){Ex=Ex-Dx;
if(C6[1]>Fe)Fe=C6[1];}if((AW===1)||(AW===2)){Ei=Ei-Dy;if(C6[0]>E2)E2=C6[0];}}else
BJ=null;}else BJ=BJ.As;}while(!!BJ);if(!CC)CC=Ao;Ay=BF;switch(Dw){case 9:case 11:
Ay=[].concat(Ay.slice(0,3),Ay[1]+Fe);break;case 10:case 12:Ay=B.t3(Ay,Ay[3]-Fe);
break;case 5:case 7:Ay=B.t1(Ay,Ay[0]+E2);break;case 6:case 8:Ay=[].concat(Ay[2]-
E2,Ay.slice(1,4));break;default:;}}if(((G.F&0x400)===0x400)){if(!!G.AC&&(G.AC.Dz
!==Ao))G.AC=null;if((!G.AC&&Bs)&&((G.AA!==Em)||!!AW))G.E8(Ay,Ao);}if(!!G.AC){if(
Gh&&!((G.F&0x400)===0x400))G.Fl(Cg,0);if(Bs&&((G.F&0x400)===0x400)){var Fi=G.Fl(
B.tz(Ay,Bt),AW);if(((G.F&0x1)===0x1)){var A_=Y;switch(AW){case 3:A_=[Fi[0]+Dx,A_[
1]];break;case 4:A_=[-Fi[0]-Dx,A_[1]];break;case 1:A_=[A_[0],Fi[1]+Dy];break;case
2:A_=[A_[0],-Fi[1]-Dy];break;default:;}Bt=B.tx(Bt,A_);}}}if(((G.F&0x200)===0x200
)){if(Bs)B.lq(Ao.BK,Ao);Bs=((G.F&0x1000)===0x1000);Ao=(D.D1.isPrototypeOf(G)?G:null
);if(Bs){G.F=G.F&~0x1000;BF=B.tz(Ao.M,Ao.D4);Ay=BF;Bt=Y;Dw=Ao.EF;AW=Dw;Dx=Ao.Space+
Ao.HX;Dy=Ao.Space+Ao.HY;Bs=!((BF[0]>=BF[2])||(BF[1]>=BF[3]));CC=null;switch(Dw){
case 9:case 10:AW=3;break;case 11:case 12:AW=4;break;case 5:case 6:AW=1;break;case
7:case 8:AW=2;break;default:;}}if(Bs){this.AT(Ao.M);}}if(G===CC){switch(Dw){case
9:case 11:Bt=[0,(Bt[1]+(Ay[3]-Ay[1]))+Dy];break;case 10:case 12:Bt=[0,(Bt[1]-(Ay[
3]-Ay[1]))-Dy];break;case 5:case 7:Bt=[(Bt[0]+(Ay[2]-Ay[0]))+Dx,0];break;case 6:
case 8:Bt=[(Bt[0]-(Ay[2]-Ay[0]))-Dx,0];break;default:;}CC=null;}G=G.As;}if(Bs)B.
lq(Ao.BK,Ao);this.F=this.F&~0x2000;this.ER([Cg[2]-Cg[0],Cg[3]-Cg[1]]);},Bm:function(
BH){var A;var Jb=((this.F&0x1000)===0x1000);if(((this.F&0x4000)===0x4000)){this.
F=this.F&~0x4000;this.I$();}if(((this.F&0x8000)===0x8000)||Jb){this.F=this.F&~0x8000;
this.Ea(this.F);}},Dj:function(C){var A;if(!!C&&(C.K!==this))throw new Error(BX);
if(!!C&&!((C.F&0x14)===0x14))C=null;if(!!C&&((C.F&0x10000)===0x10000))C=null;if(
C===this.Bd)return;if(!!this.Bd)this.Bd.AS(0x0,0x60);this.Bd=C;if(!!C){if(((this.
F&0x40)===0x40))C.AS(0x60,0x0);else C.AS(0x20,0x0);}},GG:function(FY){var tmp=this;
while(!!tmp){FY=B.tw(FY,tmp.M.slice(0,2));tmp=tmp.K;}return FY;},DispatchEvent:function(
R){var A;var G=this.Bd;var P=(D.Ab.isPrototypeOf(G)?G:null);var T=null;var Gm=!!
this.C0&&(!!this.C0.Gc||!!this.C0.Bj);if(!!G&&((((G.F&0x10000)===0x10000)||((G.F&
0x40000)===0x40000))||((G.F&0x20000)===0x20000))){G=null;P=null;}if(!!this.Cy&&!
Gm)T=this.Cy.A3.DispatchEvent(R);if(!T&&!!P)T=P.DispatchEvent(R);else if(!T&&!!G
)T=G.AK(R);if(!T)T=this.AK(R);if(!T)T=this.Gr(R);return T;},BroadcastEventAtPosition:
function(R,Hb,A7){var A;var G=this.A0;var T=null;while(!!G&&!T){if((!A7||((A=A7)&&((
G.F&A)===A)))&&B.qu(G.GetExtent(),Hb)){var P=(D.Ab.isPrototypeOf(G)?G:null);if(!
!P)T=P.BroadcastEventAtPosition(R,B.tw(Hb,P.M.slice(0,2)),A7);else T=G.AK(R);}G=
G.X;}if(!T)T=this.AK(R);return T;},BroadcastEvent:function(R,A7){var A;var G=this.
A0;var T=null;while(!!G&&!T){if(!A7||((A=A7)&&((G.F&A)===A))){var P=(D.Ab.isPrototypeOf(
G)?G:null);if(!!P)T=P.BroadcastEvent(R,A7);else T=G.AK(R);}G=G.X;}if(!T)T=this.AK(
R);if(!T)T=this.Gr(R);return T;},ER:function(aSize){},Ea:function(EY){},Db:function(
){this.F=this.F|0x8000;B.lq([this,this.Bm],this);},AT:function(Z){var A;var P=this;
while(!!P&&!((Z[0]>=Z[2])||(Z[1]>=Z[3]))){var CV=P.Bb;if(!P.K&&(P!==this)){P.AT(
Z);return;}if(!!CV){var Gg=false;var I8=CV.Bn;if(Gg)CV.Bn=[0,0,(A=P.M)[2]-A[0],A[
3]-A[1]];else CV.Bn=B.qR(CV.Bn,Z);if(!B.tm(I8,CV.Bn)){B.qw(P,0);B.qw(CV,0);}}if(
!((P.F&0x1)===0x1))return;Z=B.il(B.tz(Z,P.M.slice(0,2)),P.M);P=P.K;}},A5:function(
aArg){this.Db();},GB:function(L,A7){var A;if(!L||(L.K!==this))return null;var CE=
L.As;var CH=L.X;var Eq=0x10000;if(((A7&0x10000)===0x10000))Eq=0x0;while(!!CE||!!
CH){if((!!CE&&(!A7||((A=A7)&&((CE.F&A)===A))))&&(!Eq||!((A=Eq)&&((CE.F&A)===A)))
)return CE;if((!!CH&&(!A7||((A=A7)&&((CH.F&A)===A))))&&(!Eq||!((A=Eq)&&((CH.F&A)===
A))))return CH;if(!!CE)CE=CE.As;if(!!CH)CH=CH.X;}return null;},G6:function(L){var
A;if(!L)throw new Error(Ec);if(L.K!==this)throw new Error(CQ);if((((L.F&0x401)===
0x401)&&!!L.X)&&!!L.AC){L.X.F=L.X.F|0x800;this.F=this.F|0x4000;B.lq([this,this.Bm
],this);}if(((L.F&0x200)===0x200)){if(!!L.X)L.X.F=L.X.F|0x800;this.F=this.F|0x4000;
B.lq([this,this.Bm],this);}L.AC=null;if(this.Bd===L)this.Dj(this.GB(L,0x14));if(
!!L.X)L.X.As=L.As;if(!!L.As)L.As.X=L.X;if(this.Bj===L)this.Bj=L.As;if(this.A0===
L)this.A0=L.X;L.K=null;L.As=null;L.X=null;if(((L.F&0x1)===0x1))this.AT(L.GetExtent(
));},Av:function(L,Du){var A;if(!L)throw new Error(FQ);if(!!L.K)throw new Error(
FR);var AU=null;var Fh=L.D5;if(((Du<0)&&!!this.A0)&&(this.A0.D5>=Fh)){AU=this.A0;
Du=Du+1;}while((((Du<0)&&!!AU)&&!!AU.X)&&(AU.X.D5>=Fh)){AU=AU.X;Du=Du+1;}if((!AU&&
!!this.A0)&&(this.A0.D5>Fh))AU=this.A0;while((!!AU&&!!AU.X)&&(AU.X.D5>Fh))AU=AU.
X;if(!AU){L.K=this;L.X=this.A0;if(!!this.A0)this.A0.As=L;if(!this.Bj)this.Bj=L;this.
A0=L;}else{L.K=this;L.X=AU.X;L.As=AU;AU.X=L;if(!!L.X)L.X.As=L;else this.Bj=L;}if(((
L.F&0x1)===0x1))this.AT(L.GetExtent());if(((!this.Bd&&((L.F&0x4)===0x4))&&((L.F&
0x10)===0x10))&&!((L.F&0x10000)===0x10000))this.Dj(L);if(((L.F&0x401)===0x401)){
L.F=L.F|0x800;this.F=this.F|0x4000;B.lq([this,this.Bm],this);}if(((L.F&0x200)===
0x200)){L.F=L.F|0x800;this.F=this.F|0x4000;B.lq([this,this.Bm],this);}},_Init:function(
aArg){D.AL._Init.call(this,aArg);this.__proto__=D.Ab;this.F=0x1F;this.A5(aArg);}
,_Mark:function(E){var A;D.AL._Mark.call(this,E);if((A=this.Bj)&&(A._cycle!=E))A.
_Mark(A._cycle=E);if((A=this.A0)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.E_
)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.Bb)&&(A._cycle!=E))A._Mark(A._cycle=
E);if((A=this.Cy)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.C0)&&(A._cycle!=
E))A._Mark(A._cycle=E);if((A=this.Bd)&&(A._cycle!=E))A._Mark(A._cycle=E);},_className:
"Core::Group"};D.Root={AZ:null,Ci:null,BD:null,AB:B.tA(10,null,null),Dv:null,Bf:
null,Cf:null,EA:0,F_:0,Aa:0,AN:B.tA(10,0,null),E4:B.tA(10,B.qy,null),BE:B.tA(10,
0,null),Cw:B.tA(10,B.qx,null),Ek:B.tA(10,0,null),CX:B.tA(10,B.qx,null),B6:B.tA(10
,B.qx,null),B7:B.tA(10,B.qx,null),Cv:B.tA(10,B.qx,null),CY:0,E7:0,E6:0,Fa:B.tA(3
,B.qy,null),Hm:0,AP:B.tA(4,0,null),Au:B.tA(4,B.qy,null),Aq:0,ED:8,Hy:250,CB:0,Ch:
0,Gi:true,E$:false,Cb:function(AD,aClip,aOffset,AE,aBlend){var fullScreenUpdate=
false;fullScreenUpdate=B.jI;if(!fullScreenUpdate)AD.Fu(aClip,B.tz(B.tz(aClip,aOffset
),this.M.slice(0,2)),0x00000000,0x00000000,0x00000000,0x00000000,false);D.Ab.Cb.
call(this,AD,aClip,aOffset,AE,aBlend);},AS:function(Ce,CT){var A;D.Ab.AS.call(this
,Ce,CT);if(!this.K&&(((Ce&0x1)===0x1)||((CT&0x1)===0x1)))this.AT([0,0,(A=this.M)[
2]-A[0],A[3]-A[1]]);if(!this.K&&(((Ce&0x2)===0x2)||((CT&0x2)===0x2)))this.AT([0,
0,(A=this.M)[2]-A[0],A[3]-A[1]]);},Dj:function(C){if((C!==this.Bf)||!C)D.Ab.Dj.call(
this,C);},DispatchEvent:function(R){if((this.F_>0)&&!!(D.KeyEvent.isPrototypeOf(
R)?R:null))return null;if(!!R){R.DS=!!this.Aa;if(!!this.Aa)R.Be=this.Aa;}var T=null;
if(!!this.Bf){T=this.Bf.DispatchEvent(R);if(!!T){this.Aa=0;return T;}}if(!!this.
Ci){T=this.Ci.A3.DispatchEvent(R);if(!T)T=this.AK(R);if(!T)T=this.Gr(R);this.Aa=
0;return T;}T=D.Ab.DispatchEvent.call(this,R);this.Aa=0;return T;},BroadcastEvent:
function(R,A7){if(!!R){R.DS=!!this.Aa;if(!!this.Aa)R.Be=this.Aa;}var T=D.Ab.BroadcastEvent.
call(this,R,A7);this.Aa=0;return T;},AT:function(Z){var A;if(this.EA>0)throw new
Error(FS);if(!!this.Bb&&!this.K){if(((A=this.Bb.Bn)[0]>=A[2])||(A[1]>=A[3])){B.qw(
this,0);B.qw(this.Bb,0);}var Gg=false;if(Gg)this.Bb.Bn=[0,0,(A=this.M)[2]-A[0],A[
3]-A[1]];else this.Bb.Bn=B.qR(this.Bb.Bn,Z);}var fullScreenUpdate=false;fullScreenUpdate=
B.jI;if(fullScreenUpdate)Z=[0,0,(A=this.M)[2]-A[0],A[3]-A[1]];if(!!this.K){D.Ab.
AT.call(this,Z);return;}Z=B.il(B.tz(Z,this.M.slice(0,2)),this.M);if((Z[0]>=Z[2])||(
Z[1]>=Z[3]))return;var H;for(H=0;H<this.Aq;H=H+1)if(!(((A=B.il(this.Au.Get(H),Z)
)[0]>=A[2])||(A[1]>=A[3]))){this.Au.Set(H,B.qR(this.Au.Get(H),Z));this.AP.Set(H,
B.s9(this.Au.Get(H)));return;}if(this.Aq<3){this.Au.Set(this.Aq,Z);this.AP.Set(this.
Aq,B.s9(Z));this.Aq=this.Aq+1;return;}var Aj;var AY;var En=0;var Eo=0;var Hc=2147483647;
this.Au.Set(this.Aq,Z);this.AP.Set(this.Aq,B.s9(Z));for(Aj=0;Aj<=this.Aq;Aj=Aj+1
)for(AY=Aj+1;AY<=this.Aq;AY=AY+1){var Fj=B.s9(B.qR(this.Au.Get(Aj),this.Au.Get(AY
)));var Hq=((Fj<<8)/(this.AP.Get(Aj)+this.AP.Get(AY)))|0;if(Hq<Hc){Hc=Hq;En=Aj;Eo=
AY;}}this.Au.Set(En,B.qR(this.Au.Get(En),this.Au.Get(Eo)));this.AP.Set(En,B.s9(this.
Au.Get(En)));if(Eo!==this.Aq){this.Au.Set(Eo,this.Au.Get(this.Aq));this.AP.Set(Eo
,this.AP.Get(this.Aq));}},I5:function(){var AF=B._NewObject(D.Fq,0);AF.DS=!!this.
Aa;if(!!this.Aa)AF.Be=this.Aa;return AF;},Ej:function(){var AF=B._NewObject(D.Fo
,0);AF.DS=!!this.Aa;if(!!this.Aa)AF.Be=this.Aa;return AF;},E3:function(){var AF=
B._NewObject(D.Fp,0);AF.DS=!!this.Aa;if(!!this.Aa)AF.Be=this.Aa;return AF;},I6:function(
BH){var H;var C1=false;for(H=0;H<10;H=H+1)if(!!this.AB.Get(H)){var AO=this.B7.Get(
H);var P=this.AB.Get(H).K;while(!!P&&(P!==this)){AO=B.tw(AO,P.M.slice(0,2));P=P.
K;}if(!P&&(this.AB.Get(H)!==this)){var tmp=this.AB.Get(H);this.CY=H;this.AB.Set(
H,null);tmp.AK(this.Ej().InitializeUp(H,this.CX.Get(H),this.Cw.Get(H),this.BE.Get(
H),this.AN.Get(H)+1,this.B6.Get(H),false,this.B7.Get(H),this.Cv.Get(H)));if(tmp===
this.BD)this.BD=null;this.BroadcastEvent(this.E3().InitializeUp(H,this.AN.Get(H)+
1,false,tmp,this.B7.Get(H)),0x18);}else{this.BE.Set(H,(this.Cf.Be-this.Ek.Get(H)
)|0);if(this.BE.Get(H)<10)this.BE.Set(H,10);this.CY=H;this.AB.Get(H).AK(this.Ej(
).InitializeHold(H,AO,this.Cw.Get(H),this.BE.Get(H),this.AN.Get(H)+1,this.B6.Get(
H),this.B7.Get(H),this.Cv.Get(H)));C1=true;}}if(!C1)this.Cf.EK(false);},GetFPS:function(
){var ticksCount=0;var Hi=0;ticksCount=((new Date).getTime()-B.qt)|0;if(!!this.E7&&(
ticksCount>this.E7))Hi=((this.E6*1000)/((ticksCount-this.E7)|0))|0;this.E6=0;this.
E7=ticksCount;return Hi;},Update:function(){var A;if(!this.Dv){this.Dv=B._NewObject(
B.Graphics.Canvas,0);this.Dv.FB([(A=this.M)[2]-A[0],A[3]-A[1]]);}this.Dv.Update(
);return this.UpdateGE20(this.Dv);},UpdateGE20:function(AD){if(!this.BeginUpdate(
))return Ax;var Ca=this.UpdateCanvas(AD,Y);this.EndUpdate();return Ca;},EndUpdate:
function(){if(this.Aq>0){this.E6=this.E6+1;this.Aq=0;}},UpdateCanvas:function(AD
,aOffset){var A;var Ca=Ax;var I3=[].concat(aOffset,B.tx(AD.FrameSize,aOffset));var
H;var Aj=this.Aq;this.EA=this.EA+1;for(H=0;(H<Aj)&&(H<4);H=H+1){if(this.AP.Get(H
)>0){this.Cb(AD,B.ty(this.Au.Get(H),aOffset),[-aOffset[0],-aOffset[1]],255,true);
Ca=B.qR(Ca,B.il(I3,this.Au.Get(H)));}else Aj=Aj+1;}this.EA=this.EA-1;if(!((Ca[0]>=
Ca[2])||(Ca[1]>=Ca[3])))return B.ty(Ca,aOffset);else return Ca;},GetUpdateRegion:
function(EX){var H;var Aj=this.Aq;if(EX<0)return Ax;for(H=0;(H<Aj)&&(H<4);H=H+1){
if(!this.AP.Get(H)){Aj=Aj+1;EX=EX+1;}else if(H===EX)return this.Au.Get(H);}return Ax;
},BeginUpdate:function(){var I_=true;var fullScreenUpdate=false;var H;if((!I_&&!
fullScreenUpdate)&&(this.Aq>0)){var Ht=B.tA(3,B.qy,null);var Gw=this.Aq;for(H=0;
H<Gw;H=H+1)Ht.Set(H,this.Au.Get(H));for(H=0;H<this.Hm;H=H+1)this.AT(this.Fa.Get(
H));for(H=0;H<Gw;H=H+1)this.Fa.Set(H,Ht.Get(H));this.Hm=Gw;}var Aj;var AY;for(Aj=
0;Aj<(this.Aq-1);Aj=Aj+1)if(this.AP.Get(Aj)>0)for(AY=Aj+1;AY<this.Aq;AY=AY+1)if(
this.AP.Get(AY)>0){var Fj=B.s9(B.qR(this.Au.Get(Aj),this.Au.Get(AY)));if(((Fj-this.
AP.Get(Aj))-this.AP.Get(AY))<0){this.Au.Set(Aj,B.qR(this.Au.Get(Aj),this.Au.Get(
AY)));this.AP.Set(Aj,Fj);this.AP.Set(AY,0);}}for(H=this.Aq-1;H>=0;H=H-1)if(!this.
AP.Get(H))this.Aq=this.Aq-1;return this.Aq;},DoesNeedUpdate:function(){if(this.Aq>
0)return true;return false;},Initialize:function(aSize){this.S([].concat(Y,aSize
));if(this.Gi)this.F=this.F|0x60;else this.F=this.F|0x20;this.AT(this.M);return this;
},SetRootFocus:function(FW){if(FW===this.Gi)return false;this.Gi=FW;if(!FW){if(!
!this.Bf)this.Bf.AS(0x0,0x40);if(!!this.Ci)this.Ci.A3.AS(0x0,0x40);else this.AS(
0x0,0x40);}else{if(!!this.Ci)this.Ci.A3.AS(0x40,0x0);else this.AS(0x40,0x0);if(!
!this.Bf)this.Bf.AS(0x40,0x0);}return true;},SetUserInputTimestamp:function(I2){
this.Aa=I2;},DriveKeyboardHitting:function(An,CS,Ba){var A;var Gs=!!this.AZ;if(!
!this.AZ&&((!Ba||(this.CB!==An))||(this.Ch!==CS))){var AF=null;var G=(D.BB.isPrototypeOf(
A=this.AZ)?A:null);var Bu=(D.EH.isPrototypeOf(A=this.AZ)?A:null);if(!!this.CB)AF=
B._NewObject(D.KeyEvent,0).Initialize(this.CB,false);if(this.Ch!==0x00)AF=B._NewObject(
D.KeyEvent,0).Initialize2(this.Ch,false);if(!!Bu)Bu.AK(AF);else if(!!G)G.AK(AF);
this.CB=0;this.Ch=0x00;this.AZ=null;}if(!!this.AZ){var AF=null;var G=(D.BB.isPrototypeOf(
A=this.AZ)?A:null);var Bu=(D.EH.isPrototypeOf(A=this.AZ)?A:null);if(!!An)AF=B._NewObject(
D.KeyEvent,0).Initialize(An,true);if(this.Ch!==0x00)AF=B._NewObject(D.KeyEvent,0
).Initialize2(CS,true);if(!!Bu)Bu.AK(AF);else if(!!G)G.AK(AF);}if(this.E$&&((!Ba||(
this.CB!==An))||(this.Ch!==CS))){this.CB=0;this.Ch=0x00;this.E$=false;}if((!this.
AZ&&Ba)&&(this.F_>0)){this.CB=An;this.Ch=CS;this.E$=true;}if((!this.AZ&&Ba)&&!this.
E$){if(!!An)this.AZ=this.DispatchEvent(B._NewObject(D.KeyEvent,0).Initialize(An,
true));if(CS!==0x00)this.AZ=this.DispatchEvent(B._NewObject(D.KeyEvent,0).Initialize2(
CS,true));if(!(D.EH.isPrototypeOf(A=this.AZ)?A:null)&&!(D.BB.isPrototypeOf(A=this.
AZ)?A:null))this.AZ=null;this.CB=An;this.Ch=CS;Gs=Gs||!!this.AZ;}this.Aa=0;return Gs;
},DriveCursorMovement:function(Ar){return this.DriveMultiTouchMovement(this.CY,Ar
);},DriveMultiTouchMovement:function(I,Ar){if((I<0)||(I>9)){this.Aa=0;return false;
}var Er=B.tw(Ar,this.B7.Get(I));this.B7.Set(I,Ar);if(!this.AB.Get(I)||B.tl(Er,Y)
){this.Aa=0;return false;}var AO=Ar;var P=this.AB.Get(I).K;while(!!P&&(P!==this)
){AO=B.tw(AO,P.M.slice(0,2));P=P.K;}if(!P&&(this.AB.Get(I)!==this)){var tmp=this.
AB.Get(I);this.CY=I;this.AB.Set(I,null);tmp.AK(this.Ej().InitializeUp(I,this.CX.
Get(I),this.Cw.Get(I),this.BE.Get(I),this.AN.Get(I)+1,this.B6.Get(I),false,this.
B7.Get(I),this.Cv.Get(I)));if(tmp===this.BD)this.BD=null;this.BroadcastEvent(this.
E3().InitializeUp(I,this.AN.Get(I)+1,false,tmp,Ar),0x18);}else{this.CX.Set(I,AO);
this.CY=I;this.AB.Get(I).AK(this.I5().Initialize(I,AO,this.Cw.Get(I),Er,this.BE.
Get(I),this.AN.Get(I)+1,this.B6.Get(I),Ar,this.Cv.Get(I)));}this.Aa=0;return true;
},DriveCursorHitting:function(Ba,I,Ar){return this.DriveMultiTouchHitting(Ba,I,Ar
);},DriveMultiTouchHitting:function(Ba,I,Ar){var A;if((I<0)||(I>9)){this.Aa=0;return false;
}var ticksCount=this.Aa;var El=[].concat([-this.ED,-this.ED],[this.ED+1,this.ED+
1]);if(!ticksCount){ticksCount=((new Date).getTime()-B.qt)|0;}var Ja=this.Aa;this.
DriveMultiTouchMovement(I,Ar);Ar=this.B7.Get(I);this.Aa=Ja;if(Ba)this.Cv.Set(I,Ar
);if((Ba&&!this.AB.Get(I))&&!this.F_){var B_=null;var AO=Ar;if(B.qu(this.E4.Get(
I),Ar)&&((ticksCount-this.Ek.Get(I))<=(((A=this.Hy)<0)?A+0x100000000:A)))this.AN.
Set(I,this.AN.Get(I)+1);else this.AN.Set(I,0);this.E4.Set(I,B.tz(El,Ar));this.Ek.
Set(I,ticksCount);if((!!this.Bf&&!!this.Bf.K)&&((this.Bf.F&0x18)===0x18)){var Q=
B.tz(El,this.Bf.K.GG(Ar));B_=this.Bf.CL(Q,I,this.AN.Get(I)+1,null,0x0);}if(!B_){
if(!!this.BD&&!!this.BD.K){if(((this.BD.F&0x8)===0x8)&&((this.BD.F&0x10)===0x10)
){var Q=B.tz(El,this.BD.K.GG(Ar));B_=this.BD.CL(Q,I,this.AN.Get(I)+1,null,0x0);}
}else if(!!this.Ci)B_=this.CL(B.tz(El,Ar),I,this.AN.Get(I)+1,this.Ci.A3,0x0);else
B_=this.CL(B.tz(El,Ar),I,this.AN.Get(I)+1,null,0x0);}if(!!B_){this.BroadcastEvent(
this.E3().InitializeDown(I,this.AN.Get(I)+1,false,B_.BB,Ar),0x18);this.AB.Set(I,
B_.BB);this.B6.Set(I,B_.FA);}else{this.AB.Set(I,null);this.B6.Set(I,Y);this.Aa=0;
return false;}var P=B_.BB.K;while(!!P&&(P!==this)){AO=B.tw(AO,P.M.slice(0,2));P=
P.K;}this.Cw.Set(I,AO);this.CX.Set(I,AO);this.BE.Set(I,0);this.Cf.EK(true);this.
CY=I;this.AB.Get(I).AK(this.Ej().InitializeDown(I,AO,this.AN.Get(I)+1,this.B6.Get(
I),false,Ar));this.Aa=0;return true;}if(!Ba&&!!this.AB.Get(I)){var AO=Ar;var P=this.
AB.Get(I).K;while(!!P&&(P!==this)){AO=B.tw(AO,P.M.slice(0,2));P=P.K;}if(!P)AO=this.
CX.Get(I);this.CY=I;var tmp=this.AB.Get(I);this.AB.Set(I,null);tmp.AK(this.Ej().
InitializeUp(I,AO,this.Cw.Get(I),this.BE.Get(I),this.AN.Get(I)+1,this.B6.Get(I),
false,Ar,this.Cv.Get(I)));this.BroadcastEvent(this.E3().InitializeUp(I,this.AN.Get(
I)+1,false,tmp,Ar),0x18);this.Aa=0;return true;}this.Aa=0;return false;},_Init:function(
aArg){D.Ab._Init.call(this,aArg);D.Timer._Init.call(this.Cf={O:this},0);(this.AB=[
]).__proto__=D.Root.AB;(this.AN=[]).__proto__=D.Root.AN;(this.E4=[]).__proto__=D.
Root.E4;(this.BE=[]).__proto__=D.Root.BE;(this.Cw=[]).__proto__=D.Root.Cw;(this.
Ek=[]).__proto__=D.Root.Ek;(this.CX=[]).__proto__=D.Root.CX;(this.B6=[]).__proto__=
D.Root.B6;(this.B7=[]).__proto__=D.Root.B7;(this.Cv=[]).__proto__=D.Root.Cv;(this.
Fa=[]).__proto__=D.Root.Fa;(this.AP=[]).__proto__=D.Root.AP;(this.Au=[]).__proto__=
D.Root.Au;this.__proto__=D.Root;this.F=0x7F;this.Cf.HJ(50);this.Cf.EO=[this,this.
I6];},_Done:function(){this.__proto__=D.Ab;this.Cf._Done();D.Ab._Done.call(this);
},_ReInit:function(){D.Ab._ReInit.call(this);this.Cf._ReInit();},_Mark:function(
E){var A;D.Ab._Mark.call(this,E);if((A=this.AZ)&&(A._cycle!=E))A._Mark(A._cycle=
E);if((A=this.Ci)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.BD)&&(A._cycle!=
E))A._Mark(A._cycle=E);B.ts(this.AB,E);if((A=this.Dv)&&(A._cycle!=E))A._Mark(A._cycle=
E);if((A=this.Bf)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.Cf)._cycle!=E)A.
_Mark(A._cycle=E);},_className:"Core::Root"};D.Event={Be:0,DS:false,EG:function(
){var ticksCount=0;ticksCount=((new Date).getTime()-B.qt)|0;return ticksCount;},
A5:function(aArg){this.Be=this.EG();},_Init:function(aArg){this.__proto__=D.Event;
this.A5(aArg);B.gv++;},_Done:function(){this.__proto__=null;B.gv--;},_ReInit:function(
){},_Mark:function(E){var A;if((A=this.O)&&(A._cycle!=E))A._Mark(A._cycle=E);},O:
null,_cycle:0,_observers:null,_className:"Core::Event"};D.KeyEvent={Ap:0,U:0,Down:
false,Initialize2:function(An,Ba){this.Ap=0;this.U=An;this.Down=Ba;if((An>=0x30)&&(
An<=0x39))this.Ap=(10+An)-48;if((An>=0x41)&&(An<=0x5A))this.Ap=(105+An)-65;if((An>=
0x61)&&(An<=0x7A))this.Ap=(105+An)-97;if(An===0x20)this.Ap=131;if(!this.Ap)switch(
An){case 0x2B:this.Ap=132;break;case 0x2D:this.Ap=133;break;case 0x2A:this.Ap=134;
break;case 0x2F:this.Ap=135;break;case 0x3D:this.Ap=136;break;case 0x2E:this.Ap=
137;break;case 0x2C:this.Ap=138;break;case 0x3A:this.Ap=139;break;case 0x3B:this.
Ap=140;break;default:;}return this;},Initialize:function(An,Ba){this.Ap=An;this.
Down=Ba;this.U=0x00;var Ga=An-10;var F$=An-105;if((Ga>=0)&&(Ga<=9))this.U=(48+Ga
)&0xFFFF;if((F$>=0)&&(F$<=25))this.U=(65+F$)&0xFFFF;if(An===131)this.U=0x20;if(this.
U===0x00)switch(An){case 132:this.U=0x2B;break;case 133:this.U=0x2D;break;case 134:
this.U=0x2A;break;case 135:this.U=0x2F;break;case 136:this.U=0x3D;break;case 137:
this.U=0x2E;break;case 138:this.U=0x2C;break;case 139:this.U=0x3A;break;case 140:
this.U=0x3B;break;default:;}return this;},HE:function(G_){switch(G_){case 141:return((
this.U>=0x41)&&(this.U<=0x5A))||((this.U>=0x61)&&(this.U<=0x7A));case 142:return(((
this.U>=0x41)&&(this.U<=0x5A))||((this.U>=0x61)&&(this.U<=0x7A)))||((this.U>=0x30
)&&(this.U<=0x39));case 143:return(this.U>=0x30)&&(this.U<=0x39);case 144:return(((
this.U>=0x41)&&(this.U<=0x46))||((this.U>=0x61)&&(this.U<=0x66)))||((this.U>=0x30
)&&(this.U<=0x39));case 145:return this.U!==0x00;case 146:return(this.U===0x00)&&
!!this.Ap;case 147:return(((this.Ap===6)||(this.Ap===7))||(this.Ap===4))||(this.
Ap===5);case 148:return(this.U!==0x00)||!!this.Ap;default:;}return G_===this.Ap;
},_Init:function(aArg){D.Event._Init.call(this,aArg);this.__proto__=D.KeyEvent;}
,_className:"Core::KeyEvent"};D.Fp={FF:null,Cn:B.qx,Co:0,Cm:0,Down:false,DG:false
,InitializeUp:function(I,Bg,CR,F0,Br){this.Down=false;this.Cm=I;this.Co=Bg;this.
Cn=Br;this.FF=F0;this.DG=CR;return this;},InitializeDown:function(I,Bg,CR,F0,Br){
this.Down=true;this.Cm=I;this.Co=Bg;this.Cn=Br;this.FF=F0;this.DG=CR;return this;
},_Init:function(aArg){D.Event._Init.call(this,aArg);this.__proto__=D.Fp;},_Mark:
function(E){var A;D.Event._Mark.call(this,E);if((A=this.FF)&&(A._cycle!=E))A._Mark(
A._cycle=E);},_className:"Core::CursorGrabEvent"};D.Fo={DO:B.qx,Cn:B.qx,Co:0,DQ:
0,DP:B.qx,DH:B.qx,Cm:0,Down:false,DG:false,InitializeHold:function(I,Cu,Ee,Ef,Bg
,BC,Br,Ed){this.Down=true;this.Cm=I;this.DH=B.tx(Cu,BC);this.DP=B.tx(Ee,BC);this.
DQ=Ef;this.Co=Bg;this.Cn=Br;this.DO=Ed;return this;},InitializeUp:function(I,Cu,
Ee,Ef,Bg,BC,CR,Br,Ed){this.Down=false;this.Cm=I;this.DH=B.tx(Cu,BC);this.DP=B.tx(
Ee,BC);this.DQ=Ef;this.Co=Bg;this.DG=CR;this.Cn=Br;this.DO=Ed;return this;},InitializeDown:
function(I,Cu,Bg,BC,CR,Br){this.Down=true;this.Cm=I;this.DH=B.tx(Cu,BC);this.DP=
B.tx(Cu,BC);this.DQ=0;this.Co=Bg;this.DG=CR;this.Cn=Br;this.DO=Br;return this;},
_Init:function(aArg){D.Event._Init.call(this,aArg);this.__proto__=D.Fo;},_className:
"Core::CursorEvent"};D.Fq={DO:B.qx,Cn:B.qx,Co:0,DQ:0,FA:B.qx,DP:B.qx,DH:B.qx,Cm:
0,Initialize:function(I,Cu,Ee,aOffset,Ef,I1,BC,Br,Ed){this.Cm=I;this.DH=B.tx(Cu,
BC);this.DP=B.tx(Ee,BC);this.FA=aOffset;this.DQ=Ef;this.Co=I1;this.Cn=Br;this.DO=
Ed;return this;},_Init:function(aArg){D.Event._Init.call(this,aArg);this.__proto__=
D.Fq;},_className:"Core::DragEvent"};D.D1={BK:null,D4:B.qx,HY:0,HX:0,Space:0,EF:
0,Cb:function(AD,aClip,aOffset,AE,aBlend){},S:function(C){var A;if(B.tm(C,this.M
))return;var CF=[(A=this.M)[2]-A[0],A[3]-A[1]];var Fc=[C[2]-C[0],C[3]-C[1]];var C5=
!B.tl(CF,Fc);var Er=B.tw(C.slice(0,2),this.M.slice(0,2));if(!B.tl(Er,Y)&&!C5){var
G=this.As;while(!!G&&!((G.F&0x200)===0x200)){if(((G.F&0x400)===0x400)){var tmp=((
G.F&0x100)===0x100);G.GH(Er,tmp);}G=G.As;}B.lq(this.BK,this);}if((C5&&(CF[0]>0))&&(
CF[1]>0)){var Ai=B.tz(this.M,this.D4);var G=this.As;var Em=0x14;while(!!G&&!((G.
F&0x200)===0x200)){if(((G.F&0x400)===0x400)){if(!!G.AC&&(G.AC.Dz!==this))G.AC=null;
if(!G.AC&&((G.AA!==Em)||!!this.EF))G.E8(Ai,this);}G=G.As;}B.lq(this.BK,this);}D.
AL.S.call(this,C);if(!!this.K&&C5){this.F=this.F|0x1000;if(!((this.K.F&0x2000)===
0x2000)){this.K.F=this.K.F|0x4000;B.lq([A=this.K,A.Bm],this);}}},_Init:function(
aArg){D.AL._Init.call(this,aArg);this.__proto__=D.D1;this.F=0x203;},_Mark:function(
E){var A;D.AL._Mark.call(this,E);if((A=this.BK)&&((A=A[0])._cycle!=E))A._Mark(A.
_cycle=E);},_className:"Core::Outline"};D.EH={As:null,G5:null,G4:null,G3:null,C4:
0,Be:0,G7:0,HA:148,Ap:0,U:0,Da:true,Down:false,FE:false,EC:false,AK:function(R){
var A;if(!!R&&R.HE(this.HA)){this.Down=R.Down;this.Ap=R.Ap;this.U=R.U;this.Be=R.
Be;this.EC=false;if(R.Down){this.G7=this.C4;this.FE=this.C4>0;if(this.FE)(A=this.
G3)?A[1].call(A[0],this):null;else(A=this.G4)?A[1].call(A[0],this):null;if(!this.
EC)this.C4=this.C4+1;return!this.EC;}if(!R.Down){this.FE=this.C4>1;this.G7=this.
C4-1;this.C4=0;(A=this.G5)?A[1].call(A[0],this):null;return!this.EC;}}return false;
},A5:function(aArg){var A;var A3=(D.Ab.isPrototypeOf(A=this.O)?A:null);if(!A3)throw new
Error(FT);this.As=A3.E_;A3.E_=this;},_Init:function(aArg){this.__proto__=D.EH;this.
A5(aArg);B.gv++;},_Done:function(){this.__proto__=null;B.gv--;},_ReInit:function(
){},_Mark:function(E){var A;if((A=this.As)&&(A._cycle!=E))A._Mark(A._cycle=E);if((
A=this.G5)&&((A=A[0])._cycle!=E))A._Mark(A._cycle=E);if((A=this.G4)&&((A=A[0])._cycle
!=E))A._Mark(A._cycle=E);if((A=this.G3)&&((A=A[0])._cycle!=E))A._Mark(A._cycle=E
);if((A=this.O)&&(A._cycle!=E))A._Mark(A._cycle=E);},O:null,_cycle:0,_observers:
null,_className:"Core::KeyPressHandler"};D.Hx={BB:null,EE:0,FA:B.qx,_Init:function(
aArg){this.__proto__=D.Hx;B.gv++;},_Done:function(){this.__proto__=null;B.gv--;}
,_ReInit:function(){},_Mark:function(E){var A;if((A=this.BB)&&(A._cycle!=E))A._Mark(
A._cycle=E);if((A=this.O)&&(A._cycle!=E))A._Mark(A._cycle=E);},O:null,_cycle:0,_observers:
null,_className:"Core::CursorHit"};D.HF={A3:null,_Init:function(aArg){this.__proto__=
D.HF;B.gv++;},_Done:function(){this.__proto__=null;B.gv--;},_ReInit:function(){}
,_Mark:function(E){var A;if((A=this.A3)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=
this.O)&&(A._cycle!=E))A._Mark(A._cycle=E);},O:null,_cycle:0,_observers:null,_className:
"Core::ModalContext"};D.GF={Dz:null,CA:B.qy,Ai:B.qy,isEmpty:false,_Init:function(
aArg){this.__proto__=D.GF;B.gv++;},_Done:function(){this.__proto__=null;B.gv--;}
,_ReInit:function(){},_Mark:function(E){var A;if((A=this.Dz)&&(A._cycle!=E))A._Mark(
A._cycle=E);if((A=this.O)&&(A._cycle!=E))A._Mark(A._cycle=E);},O:null,_cycle:0,_observers:
null,_className:"Core::LayoutContext"};D.Hz={A3:null,_Init:function(aArg){this.__proto__=
D.Hz;B.gv++;},_Done:function(){this.__proto__=null;B.gv--;},_ReInit:function(){}
,_Mark:function(E){var A;if((A=this.A3)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=
this.O)&&(A._cycle!=E))A._Mark(A._cycle=E);},O:null,_cycle:0,_observers:null,_className:
"Core::DialogContext"};D.H0={Gc:null,Bj:null,_Init:function(aArg){this.__proto__=
D.H0;B.gv++;},_Done:function(){this.__proto__=null;B.gv--;},_ReInit:function(){}
,_Mark:function(E){var A;if((A=this.Gc)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=
this.Bj)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.O)&&(A._cycle!=E))A._Mark(
A._cycle=E);},O:null,_cycle:0,_observers:null,_className:"Core::TaskQueue"};D.HZ={
_Init:function(aArg){this.__proto__=D.HZ;B.gv++;},_Done:function(){this.__proto__=
null;B.gv--;},_ReInit:function(){},_Mark:function(E){var A;if((A=this.O)&&(A._cycle
!=E))A._Mark(A._cycle=E);},O:null,_cycle:0,_observers:null,_className:"Core::Task"
};D.Cc={resource:null,Bz:function(){this.resource=null;},A5:function(aArg){this.
resource=aArg;},_Init:function(aArg){this.__proto__=D.Cc;this.A5(aArg);B.gv++;},
_Done:function(){this.Bz();this.__proto__=null;B.gv--;},_ReInit:function(){},_Mark:
function(E){var A;if((A=this.O)&&(A._cycle!=E))A._Mark(A._cycle=E);},O:null,_cycle:
0,_observers:null,_className:"Core::Resource"};D.Timer={EO:null,timer:null,Be:0,
Period:1000,Gx:0,Da:false,Bz:function(){var tmp=this.timer;if(!!tmp)tmp.DestroyTimer(
);this.timer=null;},Gu:function(aBegin,aPeriod){if(aBegin<0)aBegin=0;if(aPeriod<
0)aPeriod=0;var tmp=this.timer;if(!tmp&&((aBegin>0)||(aPeriod>0)))tmp=B.sL(this,
this.Trigger);if(!!tmp){tmp.ResetTimer();tmp.StartTimer(aBegin,aPeriod);}this.timer=
tmp;},HJ:function(C){if(C<0)C=0;if(C===this.Period)return;this.Period=C;if(this.
Da)this.Gu(this.Gx,C);},EK:function(C){if(C===this.Da)return;this.Da=C;if(C)this.
Gu(this.Gx,this.Period);else this.Gu(0,0);this.Be=this.EG();},EG:function(){var ticksCount=
0;ticksCount=((new Date).getTime()-B.qt)|0;return ticksCount;},Trigger:function(
){var A;this.Be=this.EG();if(!this.Period)this.EK(false);(A=this.EO)?A[1].call(A[
0],this):null;},_Init:function(aArg){this.__proto__=D.Timer;B.gv++;},_Done:function(
){this.Bz();this.__proto__=null;B.gv--;},_ReInit:function(){},_Mark:function(E){
var A;if((A=this.EO)&&((A=A[0])._cycle!=E))A._Mark(A._cycle=E);if((A=this.O)&&(A.
_cycle!=E))A._Mark(A._cycle=E);},O:null,_cycle:0,_observers:null,_className:"Core::Timer"
};D.J7={J8:0x1,Js:0x2,Jz:0x4,J3:0x8,Da:0x10,JY:0x20,JA:0x40,JH:0x80,Jy:0x100,JC:
0x200,Jx:0x400,JN:0x800,ER:0x1000,J5:0x2000,JL:0x4000,JM:0x8000,Jw:0x10000,JK:0x20000
,JX:0x40000};D.AA={JO:0x1,JP:0x2,Ji:0x4,Jj:0x8,Jk:0x10,Jh:0x20};D.EF={JI:0,J0:1,
Jt:2,JD:3,JR:4,J1:5,J2:6,Ju:7,Jv:8,JF:9,JE:10,JT:11,JS:12};D.KeyCode={NoKey:0,Ok:
1,Exit:2,Menu:3,Up:4,Down:5,Left:6,Right:7,PageUp:8,PageDown:9,Key0:10,Key1:11,Key2:
12,Key3:13,Key4:14,Key5:15,Key6:16,Key7:17,Key8:18,Key9:19,Red:20,Green:21,Blue:
22,Yellow:23,White:24,Magenta:25,F1:26,F2:27,F3:28,F4:29,F5:30,F6:31,F7:32,F8:33
,F9:34,F10:35,ChannelUp:36,ChannelDown:37,Display:38,SkipPrev:39,SkipNext:40,Home:
41,End:42,Insert:43,Delete:44,Clear:45,VolumeUp:46,VolumeDown:47,Show:48,Hide:49
,Play:50,Pause:51,Record:52,Stop:53,Rev:54,Fwd:55,SlowRev:56,SlowFwd:57,SkipBwd:
58,SkipFwd:59,Repeat:60,Eject:61,Help:62,TV:63,DVD:64,VCR:65,EPG:66,OSD:67,Text:
68,PIP:69,Audio:70,Clock:71,Timer:72,Navigation:73,Karaoke:74,Game:75,Subtitle:76
,Zoom:77,Index:78,Info:79,Power:80,Setup:81,Angle:82,Mode:83,Mute:84,User0:85,User1:
86,User2:87,User3:88,User4:89,User5:90,User6:91,User7:92,User8:93,User9:94,User10:
95,User11:96,User12:97,User13:98,User14:99,User15:100,User16:101,User17:102,User18:
103,User19:104,KeyA:105,KeyB:106,KeyC:107,KeyD:108,KeyE:109,KeyF:110,KeyG:111,KeyH:
112,KeyI:113,KeyJ:114,KeyK:115,KeyL:116,KeyM:117,KeyN:118,KeyO:119,KeyP:120,KeyQ:
121,KeyR:122,KeyS:123,KeyT:124,KeyU:125,KeyV:126,KeyW:127,KeyX:128,KeyY:129,KeyZ:
130,Space:131,Plus:132,Minus:133,Multiply:134,Divide:135,Equals:136,Period:137,Comma:
138,Colon:139,Semicolon:140,AlphaKeys:141,AlphaOrDigitKeys:142,DigitKeys:143,HexDigitKeys:
144,CharacterKeys:145,ControlKeys:146,CursorKeys:147,AnyKey:148,Enter:149,Escape:
150,Backspace:151,Tab:152,CtrlKeyA:153,CtrlKeyB:154,CtrlKeyC:155,CtrlKeyD:156,CtrlKeyE:
157,CtrlKeyF:158,CtrlKeyG:159,CtrlKeyH:160,CtrlKeyI:161,CtrlKeyJ:162,CtrlKeyK:163
,CtrlKeyL:164,CtrlKeyM:165,CtrlKeyN:166,CtrlKeyO:167,CtrlKeyP:168,CtrlKeyQ:169,CtrlKeyR:
170,CtrlKeyS:171,CtrlKeyT:172,CtrlKeyU:173,CtrlKeyV:174,CtrlKeyW:175,CtrlKeyX:176
,CtrlKeyY:177,CtrlKeyZ:178,CtrlSpace:179,CtrlKey0:180,CtrlKey1:181,CtrlKey2:182,
CtrlKey3:183,CtrlKey4:184,CtrlKey5:185,CtrlKey6:186,CtrlKey7:187,CtrlKey8:188,CtrlKey9:
189,CtrlF1:190,CtrlF2:191,CtrlF3:192,CtrlF4:193,CtrlF5:194,CtrlF6:195,CtrlF7:196
,CtrlF8:197,CtrlF9:198,CtrlF10:199,CtrlEnter:200,CtrlEscape:201,CtrlUp:202,CtrlDown:
203,CtrlLeft:204,CtrlRight:205,CtrlPageUp:206,CtrlPageDown:207,CtrlBackspace:208
,CtrlInsert:209,CtrlDelete:210,CtrlHome:211,CtrlEnd:212,CtrlTab:213,CtrlShiftKeyA:
214,CtrlShiftKeyB:215,CtrlShiftKeyC:216,CtrlShiftKeyD:217,CtrlShiftKeyE:218,CtrlShiftKeyF:
219,CtrlShiftKeyG:220,CtrlShiftKeyH:221,CtrlShiftKeyI:222,CtrlShiftKeyJ:223,CtrlShiftKeyK:
224,CtrlShiftKeyL:225,CtrlShiftKeyM:226,CtrlShiftKeyN:227,CtrlShiftKeyO:228,CtrlShiftKeyP:
229,CtrlShiftKeyQ:230,CtrlShiftKeyR:231,CtrlShiftKeyS:232,CtrlShiftKeyT:233,CtrlShiftKeyU:
234,CtrlShiftKeyV:235,CtrlShiftKeyW:236,CtrlShiftKeyX:237,CtrlShiftKeyY:238,CtrlShiftKeyZ:
239,CtrlShiftSpace:240,CtrlShiftKey0:241,CtrlShiftKey1:242,CtrlShiftKey2:243,CtrlShiftKey3:
244,CtrlShiftKey4:245,CtrlShiftKey5:246,CtrlShiftKey6:247,CtrlShiftKey7:248,CtrlShiftKey8:
249,CtrlShiftKey9:250,CtrlShiftF1:251,CtrlShiftF2:252,CtrlShiftF3:253,CtrlShiftF4:
254,CtrlShiftF5:255,CtrlShiftF6:256,CtrlShiftF7:257,CtrlShiftF8:258,CtrlShiftF9:
259,CtrlShiftF10:260,CtrlShiftEnter:261,CtrlShiftEscape:262,CtrlShiftUp:263,CtrlShiftDown:
264,CtrlShiftLeft:265,CtrlShiftRight:266,CtrlShiftPageUp:267,CtrlShiftPageDown:268
,CtrlShiftBackspace:269,CtrlShiftInsert:270,CtrlShiftDelete:271,CtrlShiftHome:272
,CtrlShiftEnd:273,CtrlShiftTab:274,AltF1:275,AltF2:276,AltF3:277,AltF4:278,AltF5:
279,AltF6:280,AltF7:281,AltF8:282,AltF9:283,AltF10:284,AltEnter:285,AltEscape:286
,AltUp:287,AltDown:288,AltLeft:289,AltRight:290,AltPageUp:291,AltPageDown:292,AltBackspace:
293,AltInsert:294,AltDelete:295,AltHome:296,AltEnd:297,AltTab:298,AltShiftF1:299
,AltShiftF2:300,AltShiftF3:301,AltShiftF4:302,AltShiftF5:303,AltShiftF6:304,AltShiftF7:
305,AltShiftF8:306,AltShiftF9:307,AltShiftF10:308,AltShiftEnter:309,AltShiftEscape:
310,AltShiftUp:311,AltShiftDown:312,AltShiftLeft:313,AltShiftRight:314,AltShiftPageUp:
315,AltShiftPageDown:316,AltShiftBackspace:317,AltShiftInsert:318,AltShiftDelete:
319,AltShiftHome:320,AltShiftEnd:321,AltShiftTab:322,ShiftF1:323,ShiftF2:324,ShiftF3:
325,ShiftF4:326,ShiftF5:327,ShiftF6:328,ShiftF7:329,ShiftF8:330,ShiftF9:331,ShiftF10:
332,ShiftEnter:333,ShiftEscape:334,ShiftUp:335,ShiftDown:336,ShiftLeft:337,ShiftRight:
338,ShiftPageUp:339,ShiftPageDown:340,ShiftBackspace:341,ShiftInsert:342,ShiftDelete:
343,ShiftHome:344,ShiftEnd:345,ShiftTab:346};D.JQ={Ka:0x1,J9:0x2,J_:0x4,J$:0x8,JG:
0x10,JB:0x20};
D._Init=function(){D.AL.__proto__=D.BB;D.Ab.__proto__=D.AL;D.Root.__proto__=D.Ab;
D.KeyEvent.__proto__=D.Event;D.Fp.__proto__=D.Event;D.Fo.__proto__=D.Event;D.Fq.
__proto__=D.Event;D.D1.__proto__=D.AL;};D.Am=function(E){};return D;})();

/* Embedded Wizard */