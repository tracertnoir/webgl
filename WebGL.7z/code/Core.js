/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.Core)throw new Error("The unit file 'Core.js' included twice!");EmWiApp.
Core=(function(){var B=EmWiApp;var D={};
var Ac=[0,0];var Ax=[0,0,0,0];var BV="The view does not belong to this group";var
CP="No view to remove";var Eb="View is not in this group";var FO="No view to add";
var FP="View already in a group";var FQ="Recursive invalidate during active update cycle.";
var FR="The KeyPressHandler is embedded within an object not being derived "+"from Core::Group.";
D.BB={As:null,Y:null,K:null,AC:null,F:0x103,D3:0,AA:0x14,E4:function(X,G_){},EK:function(
C){var A;var B6=C^this.AA;if(!B6)return;this.AA=C;if(!!this.AC&&!((this.F&0x400)===
0x400)){this.K.F=this.K.F|0x5000;B.lq([A=this.K,A.Bm],this);this.K.AT([0,0,(A=this.
K.M)[2]-A[0],A[3]-A[1]]);}if(!!this.AC&&((this.F&0x400)===0x400)){this.AC.Dk.F=this.
AC.Dk.F|0x1000;this.K.F=this.K.F|0x4000;B.lq([A=this.K,A.Bm],this);}},Ca:function(
AD,aClip,aOffset,AE,aBlend){},AK:function(R){return null;},CK:function(Z,I,Bg,FS
,FX){return null;},Fh:function(X,CT){return Ac;},GF:function(aOffset,G9){},GetExtent:
function(){return Ax;},AS:function(Cd,CS){var A;if(((this.F&0x200)===0x200))Cd=Cd&
~0x400;var Gl=(this.F&~CS)|Cd;var Cw=Gl^this.F;this.F=Gl;if(!!this.K&&!!(Cw&0x14
)){var Hf=((this.F&0x14)===0x14);if(Hf&&!this.K.Bd)this.K.Db(this);if(!Hf&&(this.
K.Bd===this))this.K.Db(this.K.Gz(this,0x14));}if(!!this.K&&!!(Cw&0x403))this.K.AT(
this.GetExtent());if(((!!this.AC&&!!this.K)&&((Gl&0x400)===0x400))&&((Cw&0x1)===
0x1)){this.F=this.F|0x800;this.K.F=this.K.F|0x4000;B.lq([A=this.K,A.Bm],this);}if(
!!this.K&&((Cw&0x400)===0x400)){this.AC=null;this.F=this.F|0x800;this.K.F=this.K.
F|0x4000;B.lq([A=this.K,A.Bm],this);}},_Init:function(aArg){this.__proto__=D.BB;
B.gv++;},_Done:function(){this.__proto__=null;B.gv--;},_ReInit:function(){},_Mark:
function(E){var A;if((A=this.As)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.Y
)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.K)&&(A._cycle!=E))A._Mark(A._cycle=
E);if((A=this.AC)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.P)&&(A._cycle!=E
))A._Mark(A._cycle=E);},P:null,_cycle:0,_observers:null,_className:"Core::View"};
D.AL={M:B.qy,E4:function(X,G_){var AH=B._NewObject(D.GD,0);AH.Cz=this.M;AH.Ai=X;
AH.Dk=G_;this.AC=AH;},Fh:function(X,CT){var A;var Bv=this.AA;var AH=this.AC;var Ak=
AH.Cz[0];var Al=AH.Cz[1];var Ae=AH.Cz[2];var Af=AH.Cz[3];var Cy=[X[2]-X[0],X[3]-
X[1]];var B_=Ae-Ak;var B7=Af-Al;if(!CT){var Dn=[(A=AH.Ai)[2]-A[0],A[3]-A[1]];Ak=
Ak-AH.Ai[0];Al=Al-AH.Ai[1];if(Dn[0]!==Cy[0]){var BX=((Bv&0x4)===0x4);var BY=((Bv&
0x8)===0x8);var Es=((Bv&0x1)===0x1);if(!BX&&(Es||!BY))Ak=((Ak*Cy[0])/Dn[0])|0;if(
!BY&&(Es||!BX)){Ae=Ae-AH.Ai[0];Ae=((Ae*Cy[0])/Dn[0])|0;Ae=Ae-Cy[0];}else Ae=Ae-AH.
Ai[2];Ak=Ak+X[0];Ae=Ae+X[2];if(!Es){if(BX&&!BY)Ae=Ak+B_;else if(!BX&&BY)Ak=Ae-B_;
else{Ak=Ak+((((Ae-Ak)-B_)/2)|0);Ae=Ak+B_;}}}else{Ae=Ae-AH.Ai[2];Ak=Ak+X[0];Ae=Ae+
X[2];}if(Dn[1]!==Cy[1]){var BZ=((Bv&0x10)===0x10);var BW=((Bv&0x20)===0x20);var Et=((
Bv&0x2)===0x2);if(!BZ&&(Et||!BW))Al=((Al*Cy[1])/Dn[1])|0;if(!BW&&(Et||!BZ)){Af=Af-
AH.Ai[1];Af=((Af*Cy[1])/Dn[1])|0;Af=Af-Cy[1];}else Af=Af-AH.Ai[3];Al=Al+X[1];Af=
Af+X[3];if(!Et){if(BZ&&!BW)Af=Al+B7;else if(!BZ&&BW)Al=Af-B7;else{Al=Al+((((Af-Al
)-B7)/2)|0);Af=Al+B7;}}}else{Af=Af-AH.Ai[3];Al=Al+X[1];Af=Af+X[3];}}else{switch(
CT){case 3:{Ak=X[0];Ae=Ak+B_;}break;case 4:{Ae=X[2];Ak=Ae-B_;}break;case 1:{Al=X[
1];Af=Al+B7;}break;case 2:{Af=X[3];Al=Af-B7;}break;default:;}if((CT===3)||(CT===
4)){var BZ=((Bv&0x10)===0x10);var BW=((Bv&0x20)===0x20);var Et=((Bv&0x2)===0x2);
if(Et){Al=X[1];Af=X[3];}else if(BZ&&!BW){Al=X[1];Af=Al+B7;}else if(BW&&!BZ){Af=X[
3];Al=Af-B7;}else{Al=X[1]+((((X[3]-X[1])-B7)/2)|0);Af=Al+B7;}}if((CT===1)||(CT===
2)){var BX=((Bv&0x4)===0x4);var BY=((Bv&0x8)===0x8);var Es=((Bv&0x1)===0x1);if(Es
){Ak=X[0];Ae=X[2];}else if(BX&&!BY){Ak=X[0];Ae=Ak+B_;}else if(BY&&!BX){Ae=X[2];Ak=
Ae-B_;}else{Ak=X[0]+((((X[2]-X[0])-B_)/2)|0);Ae=Ak+B_;}}}AH.isEmpty=(Ak>=Ae)||(Al>=
Af);if(((this.F&0x100)===0x100)){this.M=[Ak,Al,Ae,Af];}else{this.S([Ak,Al,Ae,Af]
);this.AC=AH;}return[Ae-Ak,Af-Al];},GF:function(aOffset,G9){if(G9)this.M=B.tz(this.
M,aOffset);else this.S(B.tz(this.M,aOffset));},GetExtent:function(){return this.
M;},S:function(C){var A;if(B.tm(C,this.M))return;if(!!this.K&&((this.F&0x1)===0x1
))this.K.AT(this.M);this.AC=null;this.M=C;if(!!this.K&&((this.F&0x1)===0x1))this.
K.AT(this.M);if((!!this.K&&((this.F&0x400)===0x400))&&!((this.K.F&0x2000)===0x2000
)){this.F=this.F|0x800;this.K.F=this.K.F|0x4000;B.lq([A=this.K,A.Bm],this);}},_Init:
function(aArg){D.BB._Init.call(this,aArg);this.__proto__=D.AL;},_className:"Core::RectView"
};D.Ab={Bj:null,A0:null,E6:null,Bb:null,Cx:null,CZ:null,Bd:null,FB:255,Ca:function(
AD,aClip,aOffset,AE,aBlend){var A;AE=((AE+1)*this.FB)>>8;aBlend=aBlend&&((this.F&
0x2)===0x2);if(!this.Bb)this.I2(AD,aClip,B.tx(aOffset,this.M.slice(0,2)),AE,aBlend
);else{var AV=255|(255<<8)|(255<<16)|((AE&0xFF)<<24);this.Bb.Update();AD.Hs(aClip
,this.Bb,0,B.tz(this.M,aOffset),Ac,AV,AV,AV,AV,aBlend);}},CK:function(Z,I,Bg,FS,
FX){var A;var G=this.A0;var C0=null;var Q=Ax;var Ao=null;var Gk=!!this.CZ&&(!!this.
CZ.Ga||!!this.CZ.Bj);if(((A=B.il(Z,this.M))[0]>=A[2])||(A[1]>=A[3]))return null;
Z=B.ty(Z,this.M.slice(0,2));while(!!G){if(((G.F&0x400)===0x400)&&!Ao){Ao=G.Y;while(
!!Ao&&!((Ao.F&0x200)===0x200))Ao=Ao.Y;if(!!Ao)Q=B.il(Z,Ao.GetExtent());else Q=Ax;
}if(Ao===G){Ao=null;Q=Ax;}if((((((G.F&0x8)===0x8)&&((G.F&0x10)===0x10))&&!((G.F&
0x40000)===0x40000))&&!((G.F&0x20000)===0x20000))&&(!((G.F&0x10000)===0x10000)||((
this.Cx.A3===G)&&!Gk))){var Cz=G.GetExtent();var E1=FS;var CY=null;if(E1===G)E1=
null;if(((G.F&0x400)===0x400)){if(!(((A=B.il(Cz,Q))[0]>=A[2])||(A[1]>=A[3])))CY=
G.CK(Q,I,Bg,E1,FX);}else{if(!(((A=B.il(Cz,Z))[0]>=A[2])||(A[1]>=A[3]))||(FS===G)
)CY=G.CK(Z,I,Bg,E1,FX);}G=G.Y;if(!!CY){if(!C0||((CY.ED<C0.ED)&&(CY.ED>=0)))C0=CY;
if(!CY.ED)G=null;}}else G=G.Y;}return C0;},AS:function(Cd,CS){var A;var I4=this.
F;D.AL.AS.call(this,Cd,CS);var Cw=this.F^I4;if(!!this.Bd&&((Cw&0x40)===0x40)){if(((
this.F&0x40)===0x40))this.Bd.AS(0x40,0x0);else this.Bd.AS(0x0,0x40);}if(!!this.Cx&&((
Cw&0x40)===0x40)){if(((this.F&0x40)===0x40)&&((this.Cx.A3.F&0x14)===0x14))this.Cx.
A3.AS(0x40,0x0);else this.Cx.A3.AS(0x0,0x40);}if(!!Cw){this.F=this.F|0x8000;B.lq([
this,this.Bm],this);}},S:function(C){var A;if(B.tm(C,this.M))return;var CE=[(A=this.
M)[2]-A[0],A[3]-A[1]];var E_=[C[2]-C[0],C[3]-C[1]];var C4=!B.tl(CE,E_);if(C4&&!!
this.Bb){this.Bb.Fy(E_);B.qw(this,0);B.qw(this.Bb,0);}D.AL.S.call(this,C);if((C4&&(
CE[0]>0))&&(CE[1]>0)){var Ai=[].concat(Ac,CE);var G=this.Bj;var El=0x14;while(!!
G){if((!G.AC&&(G.AA!==El))&&!((G.F&0x400)===0x400))G.E4(Ai,null);G=G.As;}}if(C4){
this.F=this.F|0x5000;B.lq([this,this.Bm],this);}},Gp:function(R){var Hh=(D.KeyEvent.
isPrototypeOf(R)?R:null);var Bu=this.E6;if(!Hh)return null;while(!!Bu&&(!Bu.C$||
!Bu.AK(Hh)))Bu=Bu.As;return Bu;},I2:function(AD,aClip,aOffset,AE,aBlend){var A;var
G=this.Bj;var Hd=Ax;var Hn=true;while(!!G){if(((G.F&0x200)===0x200)){var Hm=(D.DZ.
isPrototypeOf(G)?G:null);Hd=B.il(aClip,B.tz(Hm.M,aOffset));Hn=((Hm.F&0x1)===0x1);
}if(((G.F&0x1)===0x1)){if(((G.F&0x400)===0x400)){if(Hn){var Q=B.il(B.tz(G.GetExtent(
),aOffset),Hd);if(!((Q[0]>=Q[2])||(Q[1]>=Q[3])))G.Ca(AD,Q,aOffset,AE,aBlend);}}else{
var Q=B.il(B.tz(G.GetExtent(),aOffset),aClip);if(!((Q[0]>=Q[2])||(Q[1]>=Q[3])))G.
Ca(AD,Q,aOffset,AE,aBlend);}}G=G.As;}},I6:function(){var A;var Gf=((this.F&0x1000
)===0x1000);var Cf=[0,0,(A=this.M)[2]-A[0],A[3]-A[1]];var Bs=false;var BF=Ax;var
Ay=Ax;var Bt=Ac;var Di=0;var Dj=0;var Dh=0;var AW=0;var G=this.A0;var Ao=null;var
El=0x14;var CB=null;while(!!G){if(((G.F&0x800)===0x800)){Bs=true;G.F=G.F&~0x800;
}if(Bs&&((G.F&0x200)===0x200)){Bs=false;if(!!(D.DZ.isPrototypeOf(G)?G:null).EE)G.
F=G.F|0x1000;}G=G.Y;}Bs=false;G=this.Bj;if(Gf){this.F=this.F&~0x1000;Gf=!((Cf[0]>=
Cf[2])||(Cf[1]>=Cf[3]));}this.F=this.F|0x2000;while(!!G){if(!CB&&(Dh!==AW)){var BI=
G;var Fa=0;var Ew=BF[2]-BF[0];var Eh=BF[3]-BF[1];var EY=0;var C5=Ac;do{if(((BI.F&
0x200)===0x200))BI=null;else if(((BI.F&0x401)===0x401)){C5=[(A=BI.GetExtent())[2
]-A[0],A[3]-A[1]];if((AW===3)||(AW===4))Ew=Ew-C5[0];if((AW===1)||(AW===2))Eh=Eh-
C5[1];if(!CB||((Ew>=0)&&(Eh>=0))){CB=BI;BI=BI.As;if((AW===3)||(AW===4)){Ew=Ew-Di;
if(C5[1]>Fa)Fa=C5[1];}if((AW===1)||(AW===2)){Eh=Eh-Dj;if(C5[0]>EY)EY=C5[0];}}else
BI=null;}else BI=BI.As;}while(!!BI);if(!CB)CB=Ao;Ay=BF;switch(Dh){case 9:case 11:
Ay=[].concat(Ay.slice(0,3),Ay[1]+Fa);break;case 10:case 12:Ay=B.t3(Ay,Ay[3]-Fa);
break;case 5:case 7:Ay=B.t1(Ay,Ay[0]+EY);break;case 6:case 8:Ay=[].concat(Ay[2]-
EY,Ay.slice(1,4));break;default:;}}if(((G.F&0x400)===0x400)){if(!!G.AC&&(G.AC.Dk
!==Ao))G.AC=null;if((!G.AC&&Bs)&&((G.AA!==El)||!!AW))G.E4(Ay,Ao);}if(!!G.AC){if(
Gf&&!((G.F&0x400)===0x400))G.Fh(Cf,0);if(Bs&&((G.F&0x400)===0x400)){var Fe=G.Fh(
B.tz(Ay,Bt),AW);if(((G.F&0x1)===0x1)){var A_=Ac;switch(AW){case 3:A_=[Fe[0]+Di,A_[
1]];break;case 4:A_=[-Fe[0]-Di,A_[1]];break;case 1:A_=[A_[0],Fe[1]+Dj];break;case
2:A_=[A_[0],-Fe[1]-Dj];break;default:;}Bt=B.tx(Bt,A_);}}}if(((G.F&0x200)===0x200
)){if(Bs)B.lq(Ao.BJ,Ao);Bs=((G.F&0x1000)===0x1000);Ao=(D.DZ.isPrototypeOf(G)?G:null
);if(Bs){G.F=G.F&~0x1000;BF=B.tz(Ao.M,Ao.D2);Ay=BF;Bt=Ac;Dh=Ao.EE;AW=Dh;Di=Ao.Space+
Ao.HU;Dj=Ao.Space+Ao.HV;Bs=!((BF[0]>=BF[2])||(BF[1]>=BF[3]));CB=null;switch(Dh){
case 9:case 10:AW=3;break;case 11:case 12:AW=4;break;case 5:case 6:AW=1;break;case
7:case 8:AW=2;break;default:;}}if(Bs){this.AT(Ao.M);}}if(G===CB){switch(Dh){case
9:case 11:Bt=[0,(Bt[1]+(Ay[3]-Ay[1]))+Dj];break;case 10:case 12:Bt=[0,(Bt[1]-(Ay[
3]-Ay[1]))-Dj];break;case 5:case 7:Bt=[(Bt[0]+(Ay[2]-Ay[0]))+Di,0];break;case 6:
case 8:Bt=[(Bt[0]-(Ay[2]-Ay[0]))-Di,0];break;default:;}CB=null;}G=G.As;}if(Bs)B.
lq(Ao.BJ,Ao);this.F=this.F&~0x2000;this.EO([Cf[2]-Cf[0],Cf[3]-Cf[1]]);},Bm:function(
B9){var A;var I8=((this.F&0x1000)===0x1000);if(((this.F&0x4000)===0x4000)){this.
F=this.F&~0x4000;this.I6();}if(((this.F&0x8000)===0x8000)||I8){this.F=this.F&~0x8000;
this.D$(this.F);}},Db:function(C){var A;if(!!C&&(C.K!==this))throw new Error(BV);
if(!!C&&!((C.F&0x14)===0x14))C=null;if(!!C&&((C.F&0x10000)===0x10000))C=null;if(
C===this.Bd)return;if(!!this.Bd)this.Bd.AS(0x0,0x60);this.Bd=C;if(!!C){if(((this.
F&0x40)===0x40))C.AS(0x60,0x0);else C.AS(0x20,0x0);}},GE:function(FW){var tmp=this;
while(!!tmp){FW=B.tw(FW,tmp.M.slice(0,2));tmp=tmp.K;}return FW;},DispatchEvent:function(
R){var A;var G=this.Bd;var O=(D.Ab.isPrototypeOf(G)?G:null);var U=null;var Gk=!!
this.CZ&&(!!this.CZ.Ga||!!this.CZ.Bj);if(!!G&&((((G.F&0x10000)===0x10000)||((G.F&
0x40000)===0x40000))||((G.F&0x20000)===0x20000))){G=null;O=null;}if(!!this.Cx&&!
Gk)U=this.Cx.A3.DispatchEvent(R);if(!U&&!!O)U=O.DispatchEvent(R);else if(!U&&!!G
)U=G.AK(R);if(!U)U=this.AK(R);if(!U)U=this.Gp(R);return U;},BroadcastEventAtPosition:
function(R,G$,A7){var A;var G=this.A0;var U=null;while(!!G&&!U){if((!A7||((A=A7)&&((
G.F&A)===A)))&&B.qu(G.GetExtent(),G$)){var O=(D.Ab.isPrototypeOf(G)?G:null);if(!
!O)U=O.BroadcastEventAtPosition(R,B.tw(G$,O.M.slice(0,2)),A7);else U=G.AK(R);}G=
G.Y;}if(!U)U=this.AK(R);return U;},BroadcastEvent:function(R,A7){var A;var G=this.
A0;var U=null;while(!!G&&!U){if(!A7||((A=A7)&&((G.F&A)===A))){var O=(D.Ab.isPrototypeOf(
G)?G:null);if(!!O)U=O.BroadcastEvent(R,A7);else U=G.AK(R);}G=G.Y;}if(!U)U=this.AK(
R);if(!U)U=this.Gp(R);return U;},EO:function(aSize){},D$:function(EU){},Da:function(
){this.F=this.F|0x8000;B.lq([this,this.Bm],this);},AT:function(Z){var A;var O=this;
while(!!O&&!((Z[0]>=Z[2])||(Z[1]>=Z[3]))){var CU=O.Bb;if(!O.K&&(O!==this)){O.AT(
Z);return;}if(!!CU){var Ge=false;var I3=CU.Bn;if(Ge)CU.Bn=[0,0,(A=O.M)[2]-A[0],A[
3]-A[1]];else CU.Bn=B.qR(CU.Bn,Z);if(!B.tm(I3,CU.Bn)){B.qw(O,0);B.qw(CU,0);}}if(
!((O.F&0x1)===0x1))return;Z=B.il(B.tz(Z,O.M.slice(0,2)),O.M);O=O.K;}},A5:function(
aArg){this.Da();},Gz:function(L,A7){var A;if(!L||(L.K!==this))return null;var CD=
L.As;var CG=L.Y;var Ep=0x10000;if(((A7&0x10000)===0x10000))Ep=0x0;while(!!CD||!!
CG){if((!!CD&&(!A7||((A=A7)&&((CD.F&A)===A))))&&(!Ep||!((A=Ep)&&((CD.F&A)===A)))
)return CD;if((!!CG&&(!A7||((A=A7)&&((CG.F&A)===A))))&&(!Ep||!((A=Ep)&&((CG.F&A)===
A))))return CG;if(!!CD)CD=CD.As;if(!!CG)CG=CG.Y;}return null;},G4:function(L){var
A;if(!L)throw new Error(CP);if(L.K!==this)throw new Error(Eb);if((((L.F&0x401)===
0x401)&&!!L.Y)&&!!L.AC){L.Y.F=L.Y.F|0x800;this.F=this.F|0x4000;B.lq([this,this.Bm
],this);}if(((L.F&0x200)===0x200)){if(!!L.Y)L.Y.F=L.Y.F|0x800;this.F=this.F|0x4000;
B.lq([this,this.Bm],this);}L.AC=null;if(this.Bd===L)this.Db(this.Gz(L,0x14));if(
!!L.Y)L.Y.As=L.As;if(!!L.As)L.As.Y=L.Y;if(this.Bj===L)this.Bj=L.As;if(this.A0===
L)this.A0=L.Y;L.K=null;L.As=null;L.Y=null;if(((L.F&0x1)===0x1))this.AT(L.GetExtent(
));},Av:function(L,Df){var A;if(!L)throw new Error(FO);if(!!L.K)throw new Error(
FP);var AU=null;var Fd=L.D3;if(((Df<0)&&!!this.A0)&&(this.A0.D3>=Fd)){AU=this.A0;
Df=Df+1;}while((((Df<0)&&!!AU)&&!!AU.Y)&&(AU.Y.D3>=Fd)){AU=AU.Y;Df=Df+1;}if((!AU&&
!!this.A0)&&(this.A0.D3>Fd))AU=this.A0;while((!!AU&&!!AU.Y)&&(AU.Y.D3>Fd))AU=AU.
Y;if(!AU){L.K=this;L.Y=this.A0;if(!!this.A0)this.A0.As=L;if(!this.Bj)this.Bj=L;this.
A0=L;}else{L.K=this;L.Y=AU.Y;L.As=AU;AU.Y=L;if(!!L.Y)L.Y.As=L;else this.Bj=L;}if(((
L.F&0x1)===0x1))this.AT(L.GetExtent());if(((!this.Bd&&((L.F&0x4)===0x4))&&((L.F&
0x10)===0x10))&&!((L.F&0x10000)===0x10000))this.Db(L);if(((L.F&0x401)===0x401)){
L.F=L.F|0x800;this.F=this.F|0x4000;B.lq([this,this.Bm],this);}if(((L.F&0x200)===
0x200)){L.F=L.F|0x800;this.F=this.F|0x4000;B.lq([this,this.Bm],this);}},_Init:function(
aArg){D.AL._Init.call(this,aArg);this.__proto__=D.Ab;this.F=0x1F;this.A5(aArg);}
,_Mark:function(E){var A;D.AL._Mark.call(this,E);if((A=this.Bj)&&(A._cycle!=E))A.
_Mark(A._cycle=E);if((A=this.A0)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.E6
)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.Bb)&&(A._cycle!=E))A._Mark(A._cycle=
E);if((A=this.Cx)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.CZ)&&(A._cycle!=
E))A._Mark(A._cycle=E);if((A=this.Bd)&&(A._cycle!=E))A._Mark(A._cycle=E);},_className:
"Core::Group"};D.Root={AZ:null,Ch:null,BD:null,AB:B.tA(10,null,null),Dg:null,Bf:
null,Ce:null,Ez:0,FZ:0,Aa:0,AN:B.tA(10,0,null),E0:B.tA(10,B.qy,null),BE:B.tA(10,
0,null),Cv:B.tA(10,B.qx,null),Ej:B.tA(10,0,null),CW:B.tA(10,B.qx,null),B4:B.tA(10
,B.qx,null),B5:B.tA(10,B.qx,null),Cu:B.tA(10,B.qx,null),CX:0,E3:0,E2:0,E8:B.tA(3
,B.qy,null),Hk:0,AP:B.tA(4,0,null),Au:B.tA(4,B.qy,null),Aq:0,EC:8,Hw:250,CA:0,Cg:
0,Gg:true,E7:false,Ca:function(AD,aClip,aOffset,AE,aBlend){var fullScreenUpdate=
false;fullScreenUpdate=B.jI;if(!fullScreenUpdate)AD.Fq(aClip,B.tz(B.tz(aClip,aOffset
),this.M.slice(0,2)),0x00000000,0x00000000,0x00000000,0x00000000,false);D.Ab.Ca.
call(this,AD,aClip,aOffset,AE,aBlend);},AS:function(Cd,CS){var A;D.Ab.AS.call(this
,Cd,CS);if(!this.K&&(((Cd&0x1)===0x1)||((CS&0x1)===0x1)))this.AT([0,0,(A=this.M)[
2]-A[0],A[3]-A[1]]);if(!this.K&&(((Cd&0x2)===0x2)||((CS&0x2)===0x2)))this.AT([0,
0,(A=this.M)[2]-A[0],A[3]-A[1]]);},Db:function(C){if((C!==this.Bf)||!C)D.Ab.Db.call(
this,C);},DispatchEvent:function(R){if((this.FZ>0)&&!!(D.KeyEvent.isPrototypeOf(
R)?R:null))return null;if(!!R){R.DD=!!this.Aa;if(!!this.Aa)R.Be=this.Aa;}var U=null;
if(!!this.Bf){U=this.Bf.DispatchEvent(R);if(!!U){this.Aa=0;return U;}}if(!!this.
Ch){U=this.Ch.A3.DispatchEvent(R);if(!U)U=this.AK(R);if(!U)U=this.Gp(R);this.Aa=
0;return U;}U=D.Ab.DispatchEvent.call(this,R);this.Aa=0;return U;},BroadcastEvent:
function(R,A7){if(!!R){R.DD=!!this.Aa;if(!!this.Aa)R.Be=this.Aa;}var U=D.Ab.BroadcastEvent.
call(this,R,A7);this.Aa=0;return U;},AT:function(Z){var A;if(this.Ez>0)throw new
Error(FQ);if(!!this.Bb&&!this.K){if(((A=this.Bb.Bn)[0]>=A[2])||(A[1]>=A[3])){B.qw(
this,0);B.qw(this.Bb,0);}var Ge=false;if(Ge)this.Bb.Bn=[0,0,(A=this.M)[2]-A[0],A[
3]-A[1]];else this.Bb.Bn=B.qR(this.Bb.Bn,Z);}var fullScreenUpdate=false;fullScreenUpdate=
B.jI;if(fullScreenUpdate)Z=[0,0,(A=this.M)[2]-A[0],A[3]-A[1]];if(!!this.K){D.Ab.
AT.call(this,Z);return;}Z=B.il(B.tz(Z,this.M.slice(0,2)),this.M);if((Z[0]>=Z[2])||(
Z[1]>=Z[3]))return;var H;for(H=0;H<this.Aq;H=H+1)if(!(((A=B.il(this.Au.Get(H),Z)
)[0]>=A[2])||(A[1]>=A[3]))){this.Au.Set(H,B.qR(this.Au.Get(H),Z));this.AP.Set(H,
B.s9(this.Au.Get(H)));return;}if(this.Aq<3){this.Au.Set(this.Aq,Z);this.AP.Set(this.
Aq,B.s9(Z));this.Aq=this.Aq+1;return;}var Aj;var AY;var Em=0;var En=0;var Ha=2147483647;
this.Au.Set(this.Aq,Z);this.AP.Set(this.Aq,B.s9(Z));for(Aj=0;Aj<=this.Aq;Aj=Aj+1
)for(AY=Aj+1;AY<=this.Aq;AY=AY+1){var Ff=B.s9(B.qR(this.Au.Get(Aj),this.Au.Get(AY
)));var Ho=((Ff<<8)/(this.AP.Get(Aj)+this.AP.Get(AY)))|0;if(Ho<Ha){Ha=Ho;Em=Aj;En=
AY;}}this.Au.Set(Em,B.qR(this.Au.Get(Em),this.Au.Get(En)));this.AP.Set(Em,B.s9(this.
Au.Get(Em)));if(En!==this.Aq){this.Au.Set(En,this.Au.Get(this.Aq));this.AP.Set(En
,this.AP.Get(this.Aq));}},I0:function(){var AF=B._NewObject(D.Fm,0);AF.DD=!!this.
Aa;if(!!this.Aa)AF.Be=this.Aa;return AF;},Ei:function(){var AF=B._NewObject(D.Fk
,0);AF.DD=!!this.Aa;if(!!this.Aa)AF.Be=this.Aa;return AF;},EZ:function(){var AF=
B._NewObject(D.Fl,0);AF.DD=!!this.Aa;if(!!this.Aa)AF.Be=this.Aa;return AF;},I1:function(
B9){var H;var C0=false;for(H=0;H<10;H=H+1)if(!!this.AB.Get(H)){var AO=this.B5.Get(
H);var O=this.AB.Get(H).K;while(!!O&&(O!==this)){AO=B.tw(AO,O.M.slice(0,2));O=O.
K;}if(!O&&(this.AB.Get(H)!==this)){var tmp=this.AB.Get(H);this.CX=H;this.AB.Set(
H,null);tmp.AK(this.Ei().InitializeUp(H,this.CW.Get(H),this.Cv.Get(H),this.BE.Get(
H),this.AN.Get(H)+1,this.B4.Get(H),false,this.B5.Get(H),this.Cu.Get(H)));if(tmp===
this.BD)this.BD=null;this.BroadcastEvent(this.EZ().InitializeUp(H,this.AN.Get(H)+
1,false,tmp,this.B5.Get(H)),0x18);}else{this.BE.Set(H,(this.Ce.Be-this.Ej.Get(H)
)|0);if(this.BE.Get(H)<10)this.BE.Set(H,10);this.CX=H;this.AB.Get(H).AK(this.Ei(
).InitializeHold(H,AO,this.Cv.Get(H),this.BE.Get(H),this.AN.Get(H)+1,this.B4.Get(
H),this.B5.Get(H),this.Cu.Get(H)));C0=true;}}if(!C0)this.Ce.Fx(false);},GetFPS:function(
){var ticksCount=0;var Hg=0;ticksCount=((new Date).getTime()-B.qt)|0;if(!!this.E3&&(
ticksCount>this.E3))Hg=((this.E2*1000)/((ticksCount-this.E3)|0))|0;this.E2=0;this.
E3=ticksCount;return Hg;},Update:function(){var A;if(!this.Dg){this.Dg=B._NewObject(
B.Graphics.Canvas,0);this.Dg.Fy([(A=this.M)[2]-A[0],A[3]-A[1]]);}this.Dg.Update(
);return this.UpdateGE20(this.Dg);},UpdateGE20:function(AD){if(!this.BeginUpdate(
))return Ax;var B$=this.UpdateCanvas(AD,Ac);this.EndUpdate();return B$;},EndUpdate:
function(){if(this.Aq>0){this.E2=this.E2+1;this.Aq=0;}},UpdateCanvas:function(AD
,aOffset){var A;var B$=Ax;var IY=[].concat(aOffset,B.tx(AD.FrameSize,aOffset));var
H;var Aj=this.Aq;this.Ez=this.Ez+1;for(H=0;(H<Aj)&&(H<4);H=H+1){if(this.AP.Get(H
)>0){this.Ca(AD,B.ty(this.Au.Get(H),aOffset),[-aOffset[0],-aOffset[1]],255,true);
B$=B.qR(B$,B.il(IY,this.Au.Get(H)));}else Aj=Aj+1;}this.Ez=this.Ez-1;if(!((B$[0]>=
B$[2])||(B$[1]>=B$[3])))return B.ty(B$,aOffset);else return B$;},GetUpdateRegion:
function(ET){var H;var Aj=this.Aq;if(ET<0)return Ax;for(H=0;(H<Aj)&&(H<4);H=H+1){
if(!this.AP.Get(H)){Aj=Aj+1;ET=ET+1;}else if(H===ET)return this.Au.Get(H);}return Ax;
},BeginUpdate:function(){var I5=true;var fullScreenUpdate=false;var H;if((!I5&&!
fullScreenUpdate)&&(this.Aq>0)){var Hr=B.tA(3,B.qy,null);var Gu=this.Aq;for(H=0;
H<Gu;H=H+1)Hr.Set(H,this.Au.Get(H));for(H=0;H<this.Hk;H=H+1)this.AT(this.E8.Get(
H));for(H=0;H<Gu;H=H+1)this.E8.Set(H,Hr.Get(H));this.Hk=Gu;}var Aj;var AY;for(Aj=
0;Aj<(this.Aq-1);Aj=Aj+1)if(this.AP.Get(Aj)>0)for(AY=Aj+1;AY<this.Aq;AY=AY+1)if(
this.AP.Get(AY)>0){var Ff=B.s9(B.qR(this.Au.Get(Aj),this.Au.Get(AY)));if(((Ff-this.
AP.Get(Aj))-this.AP.Get(AY))<0){this.Au.Set(Aj,B.qR(this.Au.Get(Aj),this.Au.Get(
AY)));this.AP.Set(Aj,Ff);this.AP.Set(AY,0);}}for(H=this.Aq-1;H>=0;H=H-1)if(!this.
AP.Get(H))this.Aq=this.Aq-1;return this.Aq;},DoesNeedUpdate:function(){if(this.Aq>
0)return true;return false;},Initialize:function(aSize){this.S([].concat(Ac,aSize
));if(this.Gg)this.F=this.F|0x60;else this.F=this.F|0x20;this.AT(this.M);return this;
},SetRootFocus:function(FU){if(FU===this.Gg)return false;this.Gg=FU;if(!FU){if(!
!this.Bf)this.Bf.AS(0x0,0x40);if(!!this.Ch)this.Ch.A3.AS(0x0,0x40);else this.AS(
0x0,0x40);}else{if(!!this.Ch)this.Ch.A3.AS(0x40,0x0);else this.AS(0x40,0x0);if(!
!this.Bf)this.Bf.AS(0x40,0x0);}return true;},SetUserInputTimestamp:function(IX){
this.Aa=IX;},DriveKeyboardHitting:function(An,CR,Ba){var A;var Gq=!!this.AZ;if(!
!this.AZ&&((!Ba||(this.CA!==An))||(this.Cg!==CR))){var AF=null;var G=(D.BB.isPrototypeOf(
A=this.AZ)?A:null);var Bu=(D.EG.isPrototypeOf(A=this.AZ)?A:null);if(!!this.CA)AF=
B._NewObject(D.KeyEvent,0).Initialize(this.CA,false);if(this.Cg!==0x00)AF=B._NewObject(
D.KeyEvent,0).Initialize2(this.Cg,false);if(!!Bu)Bu.AK(AF);else if(!!G)G.AK(AF);
this.CA=0;this.Cg=0x00;this.AZ=null;}if(!!this.AZ){var AF=null;var G=(D.BB.isPrototypeOf(
A=this.AZ)?A:null);var Bu=(D.EG.isPrototypeOf(A=this.AZ)?A:null);if(!!An)AF=B._NewObject(
D.KeyEvent,0).Initialize(An,true);if(this.Cg!==0x00)AF=B._NewObject(D.KeyEvent,0
).Initialize2(CR,true);if(!!Bu)Bu.AK(AF);else if(!!G)G.AK(AF);}if(this.E7&&((!Ba||(
this.CA!==An))||(this.Cg!==CR))){this.CA=0;this.Cg=0x00;this.E7=false;}if((!this.
AZ&&Ba)&&(this.FZ>0)){this.CA=An;this.Cg=CR;this.E7=true;}if((!this.AZ&&Ba)&&!this.
E7){if(!!An)this.AZ=this.DispatchEvent(B._NewObject(D.KeyEvent,0).Initialize(An,
true));if(CR!==0x00)this.AZ=this.DispatchEvent(B._NewObject(D.KeyEvent,0).Initialize2(
CR,true));if(!(D.EG.isPrototypeOf(A=this.AZ)?A:null)&&!(D.BB.isPrototypeOf(A=this.
AZ)?A:null))this.AZ=null;this.CA=An;this.Cg=CR;Gq=Gq||!!this.AZ;}this.Aa=0;return Gq;
},DriveCursorMovement:function(Ar){return this.DriveMultiTouchMovement(this.CX,Ar
);},DriveMultiTouchMovement:function(I,Ar){if((I<0)||(I>9)){this.Aa=0;return false;
}var Eq=B.tw(Ar,this.B5.Get(I));this.B5.Set(I,Ar);if(!this.AB.Get(I)||B.tl(Eq,Ac
)){this.Aa=0;return false;}var AO=Ar;var O=this.AB.Get(I).K;while(!!O&&(O!==this
)){AO=B.tw(AO,O.M.slice(0,2));O=O.K;}if(!O&&(this.AB.Get(I)!==this)){var tmp=this.
AB.Get(I);this.CX=I;this.AB.Set(I,null);tmp.AK(this.Ei().InitializeUp(I,this.CW.
Get(I),this.Cv.Get(I),this.BE.Get(I),this.AN.Get(I)+1,this.B4.Get(I),false,this.
B5.Get(I),this.Cu.Get(I)));if(tmp===this.BD)this.BD=null;this.BroadcastEvent(this.
EZ().InitializeUp(I,this.AN.Get(I)+1,false,tmp,Ar),0x18);}else{this.CW.Set(I,AO);
this.CX=I;this.AB.Get(I).AK(this.I0().Initialize(I,AO,this.Cv.Get(I),Eq,this.BE.
Get(I),this.AN.Get(I)+1,this.B4.Get(I),Ar,this.Cu.Get(I)));}this.Aa=0;return true;
},DriveCursorHitting:function(Ba,I,Ar){return this.DriveMultiTouchHitting(Ba,I,Ar
);},DriveMultiTouchHitting:function(Ba,I,Ar){var A;if((I<0)||(I>9)){this.Aa=0;return false;
}var ticksCount=this.Aa;var Ek=[].concat([-this.EC,-this.EC],[this.EC+1,this.EC+
1]);if(!ticksCount){ticksCount=((new Date).getTime()-B.qt)|0;}var I7=this.Aa;this.
DriveMultiTouchMovement(I,Ar);Ar=this.B5.Get(I);this.Aa=I7;if(Ba)this.Cu.Set(I,Ar
);if((Ba&&!this.AB.Get(I))&&!this.FZ){var B8=null;var AO=Ar;if(B.qu(this.E0.Get(
I),Ar)&&((ticksCount-this.Ej.Get(I))<=(((A=this.Hw)<0)?A+0x100000000:A)))this.AN.
Set(I,this.AN.Get(I)+1);else this.AN.Set(I,0);this.E0.Set(I,B.tz(Ek,Ar));this.Ej.
Set(I,ticksCount);if((!!this.Bf&&!!this.Bf.K)&&((this.Bf.F&0x18)===0x18)){var Q=
B.tz(Ek,this.Bf.K.GE(Ar));B8=this.Bf.CK(Q,I,this.AN.Get(I)+1,null,0x0);}if(!B8){
if(!!this.BD&&!!this.BD.K){if(((this.BD.F&0x8)===0x8)&&((this.BD.F&0x10)===0x10)
){var Q=B.tz(Ek,this.BD.K.GE(Ar));B8=this.BD.CK(Q,I,this.AN.Get(I)+1,null,0x0);}
}else if(!!this.Ch)B8=this.CK(B.tz(Ek,Ar),I,this.AN.Get(I)+1,this.Ch.A3,0x0);else
B8=this.CK(B.tz(Ek,Ar),I,this.AN.Get(I)+1,null,0x0);}if(!!B8){this.BroadcastEvent(
this.EZ().InitializeDown(I,this.AN.Get(I)+1,false,B8.BB,Ar),0x18);this.AB.Set(I,
B8.BB);this.B4.Set(I,B8.Fw);}else{this.AB.Set(I,null);this.B4.Set(I,Ac);this.Aa=
0;return false;}var O=B8.BB.K;while(!!O&&(O!==this)){AO=B.tw(AO,O.M.slice(0,2));
O=O.K;}this.Cv.Set(I,AO);this.CW.Set(I,AO);this.BE.Set(I,0);this.Ce.Fx(true);this.
CX=I;this.AB.Get(I).AK(this.Ei().InitializeDown(I,AO,this.AN.Get(I)+1,this.B4.Get(
I),false,Ar));this.Aa=0;return true;}if(!Ba&&!!this.AB.Get(I)){var AO=Ar;var O=this.
AB.Get(I).K;while(!!O&&(O!==this)){AO=B.tw(AO,O.M.slice(0,2));O=O.K;}if(!O)AO=this.
CW.Get(I);this.CX=I;var tmp=this.AB.Get(I);this.AB.Set(I,null);tmp.AK(this.Ei().
InitializeUp(I,AO,this.Cv.Get(I),this.BE.Get(I),this.AN.Get(I)+1,this.B4.Get(I),
false,Ar,this.Cu.Get(I)));this.BroadcastEvent(this.EZ().InitializeUp(I,this.AN.Get(
I)+1,false,tmp,Ar),0x18);this.Aa=0;return true;}this.Aa=0;return false;},_Init:function(
aArg){D.Ab._Init.call(this,aArg);D.Timer._Init.call(this.Ce={P:this},0);(this.AB=[
]).__proto__=D.Root.AB;(this.AN=[]).__proto__=D.Root.AN;(this.E0=[]).__proto__=D.
Root.E0;(this.BE=[]).__proto__=D.Root.BE;(this.Cv=[]).__proto__=D.Root.Cv;(this.
Ej=[]).__proto__=D.Root.Ej;(this.CW=[]).__proto__=D.Root.CW;(this.B4=[]).__proto__=
D.Root.B4;(this.B5=[]).__proto__=D.Root.B5;(this.Cu=[]).__proto__=D.Root.Cu;(this.
E8=[]).__proto__=D.Root.E8;(this.AP=[]).__proto__=D.Root.AP;(this.Au=[]).__proto__=
D.Root.Au;this.__proto__=D.Root;this.F=0x7F;this.Ce.HH(50);this.Ce.FA=[this,this.
I1];},_Done:function(){this.__proto__=D.Ab;this.Ce._Done();D.Ab._Done.call(this);
},_ReInit:function(){D.Ab._ReInit.call(this);this.Ce._ReInit();},_Mark:function(
E){var A;D.Ab._Mark.call(this,E);if((A=this.AZ)&&(A._cycle!=E))A._Mark(A._cycle=
E);if((A=this.Ch)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.BD)&&(A._cycle!=
E))A._Mark(A._cycle=E);B.ts(this.AB,E);if((A=this.Dg)&&(A._cycle!=E))A._Mark(A._cycle=
E);if((A=this.Bf)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.Ce)._cycle!=E)A.
_Mark(A._cycle=E);},_className:"Core::Root"};D.Event={Be:0,DD:false,EF:function(
){var ticksCount=0;ticksCount=((new Date).getTime()-B.qt)|0;return ticksCount;},
A5:function(aArg){this.Be=this.EF();},_Init:function(aArg){this.__proto__=D.Event;
this.A5(aArg);B.gv++;},_Done:function(){this.__proto__=null;B.gv--;},_ReInit:function(
){},_Mark:function(E){var A;if((A=this.P)&&(A._cycle!=E))A._Mark(A._cycle=E);},P:
null,_cycle:0,_observers:null,_className:"Core::Event"};D.KeyEvent={Ap:0,V:0,Down:
false,Initialize2:function(An,Ba){this.Ap=0;this.V=An;this.Down=Ba;if((An>=0x30)&&(
An<=0x39))this.Ap=(10+An)-48;if((An>=0x41)&&(An<=0x5A))this.Ap=(105+An)-65;if((An>=
0x61)&&(An<=0x7A))this.Ap=(105+An)-97;if(An===0x20)this.Ap=131;if(!this.Ap)switch(
An){case 0x2B:this.Ap=132;break;case 0x2D:this.Ap=133;break;case 0x2A:this.Ap=134;
break;case 0x2F:this.Ap=135;break;case 0x3D:this.Ap=136;break;case 0x2E:this.Ap=
137;break;case 0x2C:this.Ap=138;break;case 0x3A:this.Ap=139;break;case 0x3B:this.
Ap=140;break;default:;}return this;},Initialize:function(An,Ba){this.Ap=An;this.
Down=Ba;this.V=0x00;var F_=An-10;var F0=An-105;if((F_>=0)&&(F_<=9))this.V=(48+F_
)&0xFFFF;if((F0>=0)&&(F0<=25))this.V=(65+F0)&0xFFFF;if(An===131)this.V=0x20;if(this.
V===0x00)switch(An){case 132:this.V=0x2B;break;case 133:this.V=0x2D;break;case 134:
this.V=0x2A;break;case 135:this.V=0x2F;break;case 136:this.V=0x3D;break;case 137:
this.V=0x2E;break;case 138:this.V=0x2C;break;case 139:this.V=0x3A;break;case 140:
this.V=0x3B;break;default:;}return this;},HC:function(G8){switch(G8){case 141:return((
this.V>=0x41)&&(this.V<=0x5A))||((this.V>=0x61)&&(this.V<=0x7A));case 142:return(((
this.V>=0x41)&&(this.V<=0x5A))||((this.V>=0x61)&&(this.V<=0x7A)))||((this.V>=0x30
)&&(this.V<=0x39));case 143:return(this.V>=0x30)&&(this.V<=0x39);case 144:return(((
this.V>=0x41)&&(this.V<=0x46))||((this.V>=0x61)&&(this.V<=0x66)))||((this.V>=0x30
)&&(this.V<=0x39));case 145:return this.V!==0x00;case 146:return(this.V===0x00)&&
!!this.Ap;case 147:return(((this.Ap===6)||(this.Ap===7))||(this.Ap===4))||(this.
Ap===5);case 148:return(this.V!==0x00)||!!this.Ap;default:;}return G8===this.Ap;
},_Init:function(aArg){D.Event._Init.call(this,aArg);this.__proto__=D.KeyEvent;}
,_className:"Core::KeyEvent"};D.Fl={FD:null,Cm:B.qx,Cn:0,Cl:0,Down:false,Dr:false
,InitializeUp:function(I,Bg,CQ,FY,Br){this.Down=false;this.Cl=I;this.Cn=Bg;this.
Cm=Br;this.FD=FY;this.Dr=CQ;return this;},InitializeDown:function(I,Bg,CQ,FY,Br){
this.Down=true;this.Cl=I;this.Cn=Bg;this.Cm=Br;this.FD=FY;this.Dr=CQ;return this;
},_Init:function(aArg){D.Event._Init.call(this,aArg);this.__proto__=D.Fl;},_Mark:
function(E){var A;D.Event._Mark.call(this,E);if((A=this.FD)&&(A._cycle!=E))A._Mark(
A._cycle=E);},_className:"Core::CursorGrabEvent"};D.Fk={Dz:B.qx,Cm:B.qx,Cn:0,DB:
0,DA:B.qx,Ds:B.qx,Cl:0,Down:false,Dr:false,InitializeHold:function(I,Ct,Ed,Ee,Bg
,BC,Br,Ec){this.Down=true;this.Cl=I;this.Ds=B.tx(Ct,BC);this.DA=B.tx(Ed,BC);this.
DB=Ee;this.Cn=Bg;this.Cm=Br;this.Dz=Ec;return this;},InitializeUp:function(I,Ct,
Ed,Ee,Bg,BC,CQ,Br,Ec){this.Down=false;this.Cl=I;this.Ds=B.tx(Ct,BC);this.DA=B.tx(
Ed,BC);this.DB=Ee;this.Cn=Bg;this.Dr=CQ;this.Cm=Br;this.Dz=Ec;return this;},InitializeDown:
function(I,Ct,Bg,BC,CQ,Br){this.Down=true;this.Cl=I;this.Ds=B.tx(Ct,BC);this.DA=
B.tx(Ct,BC);this.DB=0;this.Cn=Bg;this.Dr=CQ;this.Cm=Br;this.Dz=Br;return this;},
_Init:function(aArg){D.Event._Init.call(this,aArg);this.__proto__=D.Fk;},_className:
"Core::CursorEvent"};D.Fm={Dz:B.qx,Cm:B.qx,Cn:0,DB:0,Fw:B.qx,DA:B.qx,Ds:B.qx,Cl:
0,Initialize:function(I,Ct,Ed,aOffset,Ee,IW,BC,Br,Ec){this.Cl=I;this.Ds=B.tx(Ct,
BC);this.DA=B.tx(Ed,BC);this.Fw=aOffset;this.DB=Ee;this.Cn=IW;this.Cm=Br;this.Dz=
Ec;return this;},_Init:function(aArg){D.Event._Init.call(this,aArg);this.__proto__=
D.Fm;},_className:"Core::DragEvent"};D.DZ={BJ:null,D2:B.qx,HV:0,HU:0,Space:0,EE:
0,Ca:function(AD,aClip,aOffset,AE,aBlend){},S:function(C){var A;if(B.tm(C,this.M
))return;var CE=[(A=this.M)[2]-A[0],A[3]-A[1]];var E_=[C[2]-C[0],C[3]-C[1]];var C4=
!B.tl(CE,E_);var Eq=B.tw(C.slice(0,2),this.M.slice(0,2));if(!B.tl(Eq,Ac)&&!C4){var
G=this.As;while(!!G&&!((G.F&0x200)===0x200)){if(((G.F&0x400)===0x400)){var tmp=((
G.F&0x100)===0x100);G.GF(Eq,tmp);}G=G.As;}B.lq(this.BJ,this);}if((C4&&(CE[0]>0))&&(
CE[1]>0)){var Ai=B.tz(this.M,this.D2);var G=this.As;var El=0x14;while(!!G&&!((G.
F&0x200)===0x200)){if(((G.F&0x400)===0x400)){if(!!G.AC&&(G.AC.Dk!==this))G.AC=null;
if(!G.AC&&((G.AA!==El)||!!this.EE))G.E4(Ai,this);}G=G.As;}B.lq(this.BJ,this);}D.
AL.S.call(this,C);if(!!this.K&&C4){this.F=this.F|0x1000;if(!((this.K.F&0x2000)===
0x2000)){this.K.F=this.K.F|0x4000;B.lq([A=this.K,A.Bm],this);}}},_Init:function(
aArg){D.AL._Init.call(this,aArg);this.__proto__=D.DZ;this.F=0x203;},_Mark:function(
E){var A;D.AL._Mark.call(this,E);if((A=this.BJ)&&((A=A[0])._cycle!=E))A._Mark(A.
_cycle=E);},_className:"Core::Outline"};D.EG={As:null,G3:null,G2:null,G1:null,C3:
0,Be:0,G5:0,Hy:148,Ap:0,V:0,C$:true,Down:false,FC:false,EB:false,AK:function(R){
var A;if(!!R&&R.HC(this.Hy)){this.Down=R.Down;this.Ap=R.Ap;this.V=R.V;this.Be=R.
Be;this.EB=false;if(R.Down){this.G5=this.C3;this.FC=this.C3>0;if(this.FC)(A=this.
G1)?A[1].call(A[0],this):null;else(A=this.G2)?A[1].call(A[0],this):null;if(!this.
EB)this.C3=this.C3+1;return!this.EB;}if(!R.Down){this.FC=this.C3>1;this.G5=this.
C3-1;this.C3=0;(A=this.G3)?A[1].call(A[0],this):null;return!this.EB;}}return false;
},A5:function(aArg){var A;var A3=(D.Ab.isPrototypeOf(A=this.P)?A:null);if(!A3)throw new
Error(FR);this.As=A3.E6;A3.E6=this;},_Init:function(aArg){this.__proto__=D.EG;this.
A5(aArg);B.gv++;},_Done:function(){this.__proto__=null;B.gv--;},_ReInit:function(
){},_Mark:function(E){var A;if((A=this.As)&&(A._cycle!=E))A._Mark(A._cycle=E);if((
A=this.G3)&&((A=A[0])._cycle!=E))A._Mark(A._cycle=E);if((A=this.G2)&&((A=A[0])._cycle
!=E))A._Mark(A._cycle=E);if((A=this.G1)&&((A=A[0])._cycle!=E))A._Mark(A._cycle=E
);if((A=this.P)&&(A._cycle!=E))A._Mark(A._cycle=E);},P:null,_cycle:0,_observers:
null,_className:"Core::KeyPressHandler"};D.Hv={BB:null,ED:0,Fw:B.qx,_Init:function(
aArg){this.__proto__=D.Hv;B.gv++;},_Done:function(){this.__proto__=null;B.gv--;}
,_ReInit:function(){},_Mark:function(E){var A;if((A=this.BB)&&(A._cycle!=E))A._Mark(
A._cycle=E);if((A=this.P)&&(A._cycle!=E))A._Mark(A._cycle=E);},P:null,_cycle:0,_observers:
null,_className:"Core::CursorHit"};D.HD={A3:null,_Init:function(aArg){this.__proto__=
D.HD;B.gv++;},_Done:function(){this.__proto__=null;B.gv--;},_ReInit:function(){}
,_Mark:function(E){var A;if((A=this.A3)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=
this.P)&&(A._cycle!=E))A._Mark(A._cycle=E);},P:null,_cycle:0,_observers:null,_className:
"Core::ModalContext"};D.GD={Dk:null,Cz:B.qy,Ai:B.qy,isEmpty:false,_Init:function(
aArg){this.__proto__=D.GD;B.gv++;},_Done:function(){this.__proto__=null;B.gv--;}
,_ReInit:function(){},_Mark:function(E){var A;if((A=this.Dk)&&(A._cycle!=E))A._Mark(
A._cycle=E);if((A=this.P)&&(A._cycle!=E))A._Mark(A._cycle=E);},P:null,_cycle:0,_observers:
null,_className:"Core::LayoutContext"};D.Hx={A3:null,_Init:function(aArg){this.__proto__=
D.Hx;B.gv++;},_Done:function(){this.__proto__=null;B.gv--;},_ReInit:function(){}
,_Mark:function(E){var A;if((A=this.A3)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=
this.P)&&(A._cycle!=E))A._Mark(A._cycle=E);},P:null,_cycle:0,_observers:null,_className:
"Core::DialogContext"};D.HX={Ga:null,Bj:null,_Init:function(aArg){this.__proto__=
D.HX;B.gv++;},_Done:function(){this.__proto__=null;B.gv--;},_ReInit:function(){}
,_Mark:function(E){var A;if((A=this.Ga)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=
this.Bj)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.P)&&(A._cycle!=E))A._Mark(
A._cycle=E);},P:null,_cycle:0,_observers:null,_className:"Core::TaskQueue"};D.HW={
_Init:function(aArg){this.__proto__=D.HW;B.gv++;},_Done:function(){this.__proto__=
null;B.gv--;},_ReInit:function(){},_Mark:function(E){var A;if((A=this.P)&&(A._cycle
!=E))A._Mark(A._cycle=E);},P:null,_cycle:0,_observers:null,_className:"Core::Task"
};D.Cb={resource:null,Bz:function(){this.resource=null;},A5:function(aArg){this.
resource=aArg;},_Init:function(aArg){this.__proto__=D.Cb;this.A5(aArg);B.gv++;},
_Done:function(){this.Bz();this.__proto__=null;B.gv--;},_ReInit:function(){},_Mark:
function(E){var A;if((A=this.P)&&(A._cycle!=E))A._Mark(A._cycle=E);},P:null,_cycle:
0,_observers:null,_className:"Core::Resource"};D.Timer={FA:null,timer:null,Be:0,
Period:1000,Gv:0,C$:false,Bz:function(){var tmp=this.timer;if(!!tmp)tmp.DestroyTimer(
);this.timer=null;},Gs:function(aBegin,aPeriod){if(aBegin<0)aBegin=0;if(aPeriod<
0)aPeriod=0;var tmp=this.timer;if(!tmp&&((aBegin>0)||(aPeriod>0)))tmp=B.sL(this,
this.Trigger);if(!!tmp){tmp.ResetTimer();tmp.StartTimer(aBegin,aPeriod);}this.timer=
tmp;},HH:function(C){if(C<0)C=0;if(C===this.Period)return;this.Period=C;if(this.
C$)this.Gs(this.Gv,C);},Fx:function(C){if(C===this.C$)return;this.C$=C;if(C)this.
Gs(this.Gv,this.Period);else this.Gs(0,0);this.Be=this.EF();},EF:function(){var ticksCount=
0;ticksCount=((new Date).getTime()-B.qt)|0;return ticksCount;},Trigger:function(
){var A;this.Be=this.EF();if(!this.Period)this.Fx(false);(A=this.FA)?A[1].call(A[
0],this):null;},_Init:function(aArg){this.__proto__=D.Timer;B.gv++;},_Done:function(
){this.Bz();this.__proto__=null;B.gv--;},_ReInit:function(){},_Mark:function(E){
var A;if((A=this.FA)&&((A=A[0])._cycle!=E))A._Mark(A._cycle=E);if((A=this.P)&&(A.
_cycle!=E))A._Mark(A._cycle=E);},P:null,_cycle:0,_observers:null,_className:"Core::Timer"
};D.J2={J3:0x1,Jn:0x2,Ju:0x4,JY:0x8,C$:0x10,JT:0x20,Jv:0x40,JC:0x80,Jt:0x100,Jx:
0x200,Js:0x400,JI:0x800,EO:0x1000,J0:0x2000,JG:0x4000,JH:0x8000,Jr:0x10000,JF:0x20000
,JS:0x40000};D.AA={JJ:0x1,JK:0x2,Jd:0x4,Je:0x8,Jf:0x10,Jc:0x20};D.EE={JD:0,JV:1,
Jo:2,Jy:3,JM:4,JW:5,JX:6,Jp:7,Jq:8,JA:9,Jz:10,JO:11,JN:12};D.KeyCode={NoKey:0,Ok:
1,Exit:2,Menu:3,Up:4,Down:5,Left:6,Right:7,PageUp:8,PageDown:9,Key0:10,Key1:11,Key2:
12,Key3:13,Key4:14,Key5:15,Key6:16,Key7:17,Key8:18,Key9:19,Red:20,Green:21,Blue:
22,Yellow:23,White:24,Magenta:25,F1:26,F2:27,F3:28,F4:29,F5:30,F6:31,F7:32,F8:33
,F9:34,F10:35,ChannelUp:36,ChannelDown:37,Display:38,SkipPrev:39,SkipNext:40,Home:
41,End:42,Insert:43,Delete:44,Clear:45,VolumeUp:46,VolumeDown:47,Show:48,Hide:49
,Play:50,Pause:51,Record:52,Stop:53,Rev:54,Fwd:55,SlowRev:56,SlowFwd:57,SkipBwd:
58,SkipFwd:59,Repeat:60,Eject:61,Help:62,TV:63,DVD:64,VCR:65,EPG:66,OSD:67,Text:
68,PIP:69,Audio:70,Clock:71,Timer:72,Navigation:73,Karaoke:74,Game:75,Subtitle:76
,Zoom:77,Index:78,Info:79,Power:80,Setup:81,Angle:82,Mode:83,Mute:84,User0:85,User1:
86,User2:87,User3:88,User4:89,User5:90,User6:91,User7:92,User8:93,User9:94,User10:
95,User11:96,User12:97,User13:98,User14:99,User15:100,User16:101,User17:102,User18:
103,User19:104,KeyA:105,KeyB:106,KeyC:107,KeyD:108,KeyE:109,KeyF:110,KeyG:111,KeyH:
112,KeyI:113,KeyJ:114,KeyK:115,KeyL:116,KeyM:117,KeyN:118,KeyO:119,KeyP:120,KeyQ:
121,KeyR:122,KeyS:123,KeyT:124,KeyU:125,KeyV:126,KeyW:127,KeyX:128,KeyY:129,KeyZ:
130,Space:131,Plus:132,Minus:133,Multiply:134,Divide:135,Equals:136,Period:137,Comma:
138,Colon:139,Semicolon:140,AlphaKeys:141,AlphaOrDigitKeys:142,DigitKeys:143,HexDigitKeys:
144,CharacterKeys:145,ControlKeys:146,CursorKeys:147,AnyKey:148,Enter:149,Escape:
150,Backspace:151,Tab:152,CtrlKeyA:153,CtrlKeyB:154,CtrlKeyC:155,CtrlKeyD:156,CtrlKeyE:
157,CtrlKeyF:158,CtrlKeyG:159,CtrlKeyH:160,CtrlKeyI:161,CtrlKeyJ:162,CtrlKeyK:163
,CtrlKeyL:164,CtrlKeyM:165,CtrlKeyN:166,CtrlKeyO:167,CtrlKeyP:168,CtrlKeyQ:169,CtrlKeyR:
170,CtrlKeyS:171,CtrlKeyT:172,CtrlKeyU:173,CtrlKeyV:174,CtrlKeyW:175,CtrlKeyX:176
,CtrlKeyY:177,CtrlKeyZ:178,CtrlSpace:179,CtrlKey0:180,CtrlKey1:181,CtrlKey2:182,
CtrlKey3:183,CtrlKey4:184,CtrlKey5:185,CtrlKey6:186,CtrlKey7:187,CtrlKey8:188,CtrlKey9:
189,CtrlF1:190,CtrlF2:191,CtrlF3:192,CtrlF4:193,CtrlF5:194,CtrlF6:195,CtrlF7:196
,CtrlF8:197,CtrlF9:198,CtrlF10:199,CtrlEnter:200,CtrlEscape:201,CtrlUp:202,CtrlDown:
203,CtrlLeft:204,CtrlRight:205,CtrlPageUp:206,CtrlPageDown:207,CtrlBackspace:208
,CtrlInsert:209,CtrlDelete:210,CtrlHome:211,CtrlEnd:212,CtrlTab:213,CtrlShiftKeyA:
214,CtrlShiftKeyB:215,CtrlShiftKeyC:216,CtrlShiftKeyD:217,CtrlShiftKeyE:218,CtrlShiftKeyF:
219,CtrlShiftKeyG:220,CtrlShiftKeyH:221,CtrlShiftKeyI:222,CtrlShiftKeyJ:223,CtrlShiftKeyK:
224,CtrlShiftKeyL:225,CtrlShiftKeyM:226,CtrlShiftKeyN:227,CtrlShiftKeyO:228,CtrlShiftKeyP:
229,CtrlShiftKeyQ:230,CtrlShiftKeyR:231,CtrlShiftKeyS:232,CtrlShiftKeyT:233,CtrlShiftKeyU:
234,CtrlShiftKeyV:235,CtrlShiftKeyW:236,CtrlShiftKeyX:237,CtrlShiftKeyY:238,CtrlShiftKeyZ:
239,CtrlShiftSpace:240,CtrlShiftKey0:241,CtrlShiftKey1:242,CtrlShiftKey2:243,CtrlShiftKey3:
244,CtrlShiftKey4:245,CtrlShiftKey5:246,CtrlShiftKey6:247,CtrlShiftKey7:248,CtrlShiftKey8:
249,CtrlShiftKey9:250,CtrlShiftF1:251,CtrlShiftF2:252,CtrlShiftF3:253,CtrlShiftF4:
254,CtrlShiftF5:255,CtrlShiftF6:256,CtrlShiftF7:257,CtrlShiftF8:258,CtrlShiftF9:
259,CtrlShiftF10:260,CtrlShiftEnter:261,CtrlShiftEscape:262,CtrlShiftUp:263,CtrlShiftDown:
264,CtrlShiftLeft:265,CtrlShiftRight:266,CtrlShiftPageUp:267,CtrlShiftPageDown:268
,CtrlShiftBackspace:269,CtrlShiftInsert:270,CtrlShiftDelete:271,CtrlShiftHome:272
,CtrlShiftEnd:273,CtrlShiftTab:274,AltF1:275,AltF2:276,AltF3:277,AltF4:278,AltF5:
279,AltF6:280,AltF7:281,AltF8:282,AltF9:283,AltF10:284,AltEnter:285,AltEscape:286
,AltUp:287,AltDown:288,AltLeft:289,AltRight:290,AltPageUp:291,AltPageDown:292,AltBackspace:
293,AltInsert:294,AltDelete:295,AltHome:296,AltEnd:297,AltTab:298,AltShiftF1:299
,AltShiftF2:300,AltShiftF3:301,AltShiftF4:302,AltShiftF5:303,AltShiftF6:304,AltShiftF7:
305,AltShiftF8:306,AltShiftF9:307,AltShiftF10:308,AltShiftEnter:309,AltShiftEscape:
310,AltShiftUp:311,AltShiftDown:312,AltShiftLeft:313,AltShiftRight:314,AltShiftPageUp:
315,AltShiftPageDown:316,AltShiftBackspace:317,AltShiftInsert:318,AltShiftDelete:
319,AltShiftHome:320,AltShiftEnd:321,AltShiftTab:322,ShiftF1:323,ShiftF2:324,ShiftF3:
325,ShiftF4:326,ShiftF5:327,ShiftF6:328,ShiftF7:329,ShiftF8:330,ShiftF9:331,ShiftF10:
332,ShiftEnter:333,ShiftEscape:334,ShiftUp:335,ShiftDown:336,ShiftLeft:337,ShiftRight:
338,ShiftPageUp:339,ShiftPageDown:340,ShiftBackspace:341,ShiftInsert:342,ShiftDelete:
343,ShiftHome:344,ShiftEnd:345,ShiftTab:346};D.JL={J7:0x1,J4:0x2,J5:0x4,J6:0x8,JB:
0x10,Jw:0x20};
D._Init=function(){D.AL.__proto__=D.BB;D.Ab.__proto__=D.AL;D.Root.__proto__=D.Ab;
D.KeyEvent.__proto__=D.Event;D.Fl.__proto__=D.Event;D.Fk.__proto__=D.Event;D.Fm.
__proto__=D.Event;D.DZ.__proto__=D.AL;};D.Am=function(E){};return D;})();

/* Embedded Wizard */