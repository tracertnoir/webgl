/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.Core)throw new Error("The unit file 'Core.js' included twice!");EmWiApp.
Core=(function(){var B=EmWiApp;var D={};
var Z=[0,0];var Ay=[0,0,0,0];var B1="The view does not belong to this group";var Eg=
"No view to restack";var Cz="View is not in this group";var FW="No view to remove";
var FX="No view to add";var FY="View already in a group";var FZ="Recursive invalidate during active update cycle.";
var F0="The KeyPressHandler is embedded within an object not being derived "+"from Core::Group.";
D.BR={T:null,N:null,L:null,AB:null,F:0x103,Bv:0,AC:0x14,Fb:function(Y,Hh){},HP:function(
C){if(this.Bv===C)return;this.Bv=C;if(!!this.L){var Co=this.T;var AX=0;while(!!Co&&(
C>Co.Bv)){Co=Co.T;AX=AX+1;}Co=this.N;while(!!Co&&(C<Co.Bv)){Co=Co.N;AX=AX-1;}if(
!!AX)this.L.H2(this,AX);}},ER:function(C){var A;var AX=C^this.AC;if(!AX)return;this.
AC=C;if(!!this.AB&&!((this.F&0x400)===0x400)){this.L.F=this.L.F|0x5000;B.lq([A=this.
L,A.Bb],this);this.L.AS([0,0,(A=this.L.M)[2]-A[0],A[3]-A[1]]);}if(!!this.AB&&((this.
F&0x400)===0x400)){this.AB.DK.F=this.AB.DK.F|0x1000;this.L.F=this.L.F|0x4000;B.lq([
A=this.L,A.Bb],this);}},Ce:function(AE,aClip,aOffset,AF,aBlend){},AM:function(S){
return null;},CR:function(Aa,J,Bl,F_,Gd){return null;},Fp:function(Y,CZ){return Z;
},GN:function(aOffset,Hg){},GetExtent:function(){return Ay;},AV:function(Ch,CY){
var A;if(((this.F&0x200)===0x200))Ch=Ch&~0x400;var Gu=(this.F&~CY)|Ch;var CD=Gu^
this.F;this.F=Gu;if(!!this.L&&!!(CD&0x14)){var Ho=((this.F&0x14)===0x14);if(Ho&&
!this.L.Bh)this.L.Dr(this);if(!Ho&&(this.L.Bh===this))this.L.Dr(this.L.GH(this,0x14
));}if(!!this.L&&!!(CD&0x403))this.L.AS(this.GetExtent());if(((!!this.AB&&!!this.
L)&&((Gu&0x400)===0x400))&&((CD&0x1)===0x1)){this.F=this.F|0x800;this.L.F=this.L.
F|0x4000;B.lq([A=this.L,A.Bb],this);}if(!!this.L&&((CD&0x400)===0x400)){this.AB=
null;this.F=this.F|0x800;this.L.F=this.L.F|0x4000;B.lq([A=this.L,A.Bb],this);}},
_Init:function(aArg){this.__proto__=D.BR;B.gv++;},_Done:function(){this.__proto__=
null;B.gv--;},_ReInit:function(){},_Mark:function(E){var A;if((A=this.T)&&(A._cycle
!=E))A._Mark(A._cycle=E);if((A=this.N)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=
this.L)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.AB)&&(A._cycle!=E))A._Mark(
A._cycle=E);if((A=this.P)&&(A._cycle!=E))A._Mark(A._cycle=E);},P:null,_cycle:0,_observers:
null,_className:"Core::View"};D.AN={M:B.qy,Fb:function(Y,Hh){var AI=B._NewObject(
D.GL,0);AI.CG=this.M;AI.Aj=Y;AI.DK=Hh;this.AB=AI;},Fp:function(Y,CZ){var A;var BA=
this.AC;var AI=this.AB;var Al=AI.CG[0];var Am=AI.CG[1];var Ae=AI.CG[2];var Af=AI.
CG[3];var CF=[Y[2]-Y[0],Y[3]-Y[1]];var Cc=Ae-Al;var Ca=Af-Am;if(!CZ){var DN=[(A=
AI.Aj)[2]-A[0],A[3]-A[1]];Al=Al-AI.Aj[0];Am=Am-AI.Aj[1];if(DN[0]!==CF[0]){var B3=((
BA&0x4)===0x4);var B4=((BA&0x8)===0x8);var Ey=((BA&0x1)===0x1);if(!B3&&(Ey||!B4)
)Al=((Al*CF[0])/DN[0])|0;if(!B4&&(Ey||!B3)){Ae=Ae-AI.Aj[0];Ae=((Ae*CF[0])/DN[0])|
0;Ae=Ae-CF[0];}else Ae=Ae-AI.Aj[2];Al=Al+Y[0];Ae=Ae+Y[2];if(!Ey){if(B3&&!B4)Ae=Al+
Cc;else if(!B3&&B4)Al=Ae-Cc;else{Al=Al+((((Ae-Al)-Cc)/2)|0);Ae=Al+Cc;}}}else{Ae=
Ae-AI.Aj[2];Al=Al+Y[0];Ae=Ae+Y[2];}if(DN[1]!==CF[1]){var B5=((BA&0x10)===0x10);var
B2=((BA&0x20)===0x20);var Ez=((BA&0x2)===0x2);if(!B5&&(Ez||!B2))Am=((Am*CF[1])/DN[
1])|0;if(!B2&&(Ez||!B5)){Af=Af-AI.Aj[1];Af=((Af*CF[1])/DN[1])|0;Af=Af-CF[1];}else
Af=Af-AI.Aj[3];Am=Am+Y[1];Af=Af+Y[3];if(!Ez){if(B5&&!B2)Af=Am+Ca;else if(!B5&&B2
)Am=Af-Ca;else{Am=Am+((((Af-Am)-Ca)/2)|0);Af=Am+Ca;}}}else{Af=Af-AI.Aj[3];Am=Am+
Y[1];Af=Af+Y[3];}}else{switch(CZ){case 3:{Al=Y[0];Ae=Al+Cc;}break;case 4:{Ae=Y[2
];Al=Ae-Cc;}break;case 1:{Am=Y[1];Af=Am+Ca;}break;case 2:{Af=Y[3];Am=Af-Ca;}break;
default:;}if((CZ===3)||(CZ===4)){var B5=((BA&0x10)===0x10);var B2=((BA&0x20)===0x20
);var Ez=((BA&0x2)===0x2);if(Ez){Am=Y[1];Af=Y[3];}else if(B5&&!B2){Am=Y[1];Af=Am+
Ca;}else if(B2&&!B5){Af=Y[3];Am=Af-Ca;}else{Am=Y[1]+((((Y[3]-Y[1])-Ca)/2)|0);Af=
Am+Ca;}}if((CZ===1)||(CZ===2)){var B3=((BA&0x4)===0x4);var B4=((BA&0x8)===0x8);var
Ey=((BA&0x1)===0x1);if(Ey){Al=Y[0];Ae=Y[2];}else if(B3&&!B4){Al=Y[0];Ae=Al+Cc;}else
if(B4&&!B3){Ae=Y[2];Al=Ae-Cc;}else{Al=Y[0]+((((Y[2]-Y[0])-Cc)/2)|0);Ae=Al+Cc;}}}
AI.isEmpty=(Al>=Ae)||(Am>=Af);if(((this.F&0x100)===0x100)){this.M=[Al,Am,Ae,Af];
}else{this.U([Al,Am,Ae,Af]);this.AB=AI;}return[Ae-Al,Af-Am];},GN:function(aOffset
,Hg){if(Hg)this.M=B.tz(this.M,aOffset);else this.U(B.tz(this.M,aOffset));},GetExtent:
function(){return this.M;},U:function(C){var A;if(B.tm(C,this.M))return;if(!!this.
L&&((this.F&0x1)===0x1))this.L.AS(this.M);this.AB=null;this.M=C;if(!!this.L&&((this.
F&0x1)===0x1))this.L.AS(this.M);if((!!this.L&&((this.F&0x400)===0x400))&&!((this.
L.F&0x2000)===0x2000)){this.F=this.F|0x800;this.L.F=this.L.F|0x4000;B.lq([A=this.
L,A.Bb],this);}},_Init:function(aArg){D.BR._Init.call(this,aArg);this.__proto__=
D.AN;},_className:"Core::RectView"};D.Ac={A4:null,AK:null,Fd:null,Bf:null,CE:null
,C5:null,Bh:null,FJ:255,Ce:function(AE,aClip,aOffset,AF,aBlend){var A;AF=((AF+1)
*this.FJ)>>8;aBlend=aBlend&&((this.F&0x2)===0x2);if(!this.Bf)this.Jb(AE,aClip,B.
tx(aOffset,this.M.slice(0,2)),AF,aBlend);else{var AW=255|(255<<8)|(255<<16)|((AF&
0xFF)<<24);this.Bf.Update();AE.HB(aClip,this.Bf,0,B.tz(this.M,aOffset),Z,AW,AW,AW
,AW,aBlend);}},CR:function(Aa,J,Bl,F_,Gd){var A;var G=this.AK;var C6=null;var R=
Ay;var Aq=null;var Gt=!!this.C5&&(!!this.C5.Gj||!!this.C5.A4);if(((A=B.il(Aa,this.
M))[0]>=A[2])||(A[1]>=A[3]))return null;Aa=B.ty(Aa,this.M.slice(0,2));while(!!G){
if(((G.F&0x400)===0x400)&&!Aq){Aq=G.N;while(!!Aq&&!((Aq.F&0x200)===0x200))Aq=Aq.
N;if(!!Aq)R=B.il(Aa,Aq.GetExtent());else R=Ay;}if(Aq===G){Aq=null;R=Ay;}if((((((
G.F&0x8)===0x8)&&((G.F&0x10)===0x10))&&!((G.F&0x40000)===0x40000))&&!((G.F&0x20000
)===0x20000))&&(!((G.F&0x10000)===0x10000)||((this.CE.A5===G)&&!Gt))){var CG=G.GetExtent(
);var E_=F_;var C4=null;if(E_===G)E_=null;if(((G.F&0x400)===0x400)){if(!(((A=B.il(
CG,R))[0]>=A[2])||(A[1]>=A[3])))C4=G.CR(R,J,Bl,E_,Gd);}else{if(!(((A=B.il(CG,Aa)
)[0]>=A[2])||(A[1]>=A[3]))||(F_===G))C4=G.CR(Aa,J,Bl,E_,Gd);}G=G.N;if(!!C4){if(!
C6||((C4.EJ<C6.EJ)&&(C4.EJ>=0)))C6=C4;if(!C4.EJ)G=null;}}else G=G.N;}return C6;}
,AV:function(Ch,CY){var A;var Jd=this.F;D.AN.AV.call(this,Ch,CY);var CD=this.F^Jd;
if(!!this.Bh&&((CD&0x40)===0x40)){if(((this.F&0x40)===0x40))this.Bh.AV(0x40,0x0);
else this.Bh.AV(0x0,0x40);}if(!!this.CE&&((CD&0x40)===0x40)){if(((this.F&0x40)===
0x40)&&((this.CE.A5.F&0x14)===0x14))this.CE.A5.AV(0x40,0x0);else this.CE.A5.AV(0x0
,0x40);}if(!!CD){this.F=this.F|0x8000;B.lq([this,this.Bb],this);}},U:function(C){
var A;if(B.tm(C,this.M))return;var CL=[(A=this.M)[2]-A[0],A[3]-A[1]];var Fh=[C[2
]-C[0],C[3]-C[1]];var C_=!B.tl(CL,Fh);if(C_&&!!this.Bf){this.Bf.FH(Fh);B.qw(this
,0);B.qw(this.Bf,0);}D.AN.U.call(this,C);if((C_&&(CL[0]>0))&&(CL[1]>0)){var Aj=[
].concat(Z,CL);var G=this.A4;var Eq=0x14;while(!!G){if((!G.AB&&(G.AC!==Eq))&&!((
G.F&0x400)===0x400))G.Fb(Aj,null);G=G.T;}}if(C_){this.F=this.F|0x5000;B.lq([this
,this.Bb],this);}},Gx:function(S){var Hq=(D.KeyEvent.isPrototypeOf(S)?S:null);var
Bz=this.Fd;if(!Hq)return null;while(!!Bz&&(!Bz.Dg||!Bz.AM(Hq)))Bz=Bz.T;return Bz;
},Jb:function(AE,aClip,aOffset,AF,aBlend){var A;var G=this.A4;var Hm=Ay;var Hw=true;
while(!!G){if(((G.F&0x200)===0x200)){var Hv=(D.D6.isPrototypeOf(G)?G:null);Hm=B.
il(aClip,B.tz(Hv.M,aOffset));Hw=((Hv.F&0x1)===0x1);}if(((G.F&0x1)===0x1)){if(((G.
F&0x400)===0x400)){if(Hw){var R=B.il(B.tz(G.GetExtent(),aOffset),Hm);if(!((R[0]>=
R[2])||(R[1]>=R[3])))G.Ce(AE,R,aOffset,AF,aBlend);}}else{var R=B.il(B.tz(G.GetExtent(
),aOffset),aClip);if(!((R[0]>=R[2])||(R[1]>=R[3])))G.Ce(AE,R,aOffset,AF,aBlend);
}}G=G.T;}},Jf:function(){var A;var Go=((this.F&0x1000)===0x1000);var Ck=[0,0,(A=
this.M)[2]-A[0],A[3]-A[1]];var Bx=false;var BV=Ay;var Az=Ay;var By=Z;var DI=0;var
DJ=0;var DH=0;var AY=0;var G=this.AK;var Aq=null;var Eq=0x14;var CI=null;while(!
!G){if(((G.F&0x800)===0x800)){Bx=true;G.F=G.F&~0x800;}if(Bx&&((G.F&0x200)===0x200
)){Bx=false;if(!!(D.D6.isPrototypeOf(G)?G:null).EK)G.F=G.F|0x1000;}G=G.N;}Bx=false;
G=this.A4;if(Go){this.F=this.F&~0x1000;Go=!((Ck[0]>=Ck[2])||(Ck[1]>=Ck[3]));}this.
F=this.F|0x2000;while(!!G){if(!CI&&(DH!==AY)){var BZ=G;var Fj=0;var EC=BV[2]-BV[
0];var Em=BV[3]-BV[1];var E7=0;var Da=Z;do{if(((BZ.F&0x200)===0x200))BZ=null;else
if(((BZ.F&0x401)===0x401)){Da=[(A=BZ.GetExtent())[2]-A[0],A[3]-A[1]];if((AY===3)||(
AY===4))EC=EC-Da[0];if((AY===1)||(AY===2))Em=Em-Da[1];if(!CI||((EC>=0)&&(Em>=0))
){CI=BZ;BZ=BZ.T;if((AY===3)||(AY===4)){EC=EC-DI;if(Da[1]>Fj)Fj=Da[1];}if((AY===1
)||(AY===2)){Em=Em-DJ;if(Da[0]>E7)E7=Da[0];}}else BZ=null;}else BZ=BZ.T;}while(!
!BZ);if(!CI)CI=Aq;Az=BV;switch(DH){case 9:case 11:Az=[].concat(Az.slice(0,3),Az[
1]+Fj);break;case 10:case 12:Az=B.t3(Az,Az[3]-Fj);break;case 5:case 7:Az=B.t1(Az
,Az[0]+E7);break;case 6:case 8:Az=[].concat(Az[2]-E7,Az.slice(1,4));break;default:;
}}if(((G.F&0x400)===0x400)){if(!!G.AB&&(G.AB.DK!==Aq))G.AB=null;if((!G.AB&&Bx)&&((
G.AC!==Eq)||!!AY))G.Fb(Az,Aq);}if(!!G.AB){if(Go&&!((G.F&0x400)===0x400))G.Fp(Ck,
0);if(Bx&&((G.F&0x400)===0x400)){var Fm=G.Fp(B.tz(Az,By),AY);if(((G.F&0x1)===0x1
)){var Ba=Z;switch(AY){case 3:Ba=[Fm[0]+DI,Ba[1]];break;case 4:Ba=[-Fm[0]-DI,Ba[
1]];break;case 1:Ba=[Ba[0],Fm[1]+DJ];break;case 2:Ba=[Ba[0],-Fm[1]-DJ];break;default:;
}By=B.tx(By,Ba);}}}if(((G.F&0x200)===0x200)){if(Bx)B.lq(Aq.B0,Aq);Bx=((G.F&0x1000
)===0x1000);Aq=(D.D6.isPrototypeOf(G)?G:null);if(Bx){G.F=G.F&~0x1000;BV=B.tz(Aq.
M,Aq.D9);Az=BV;By=Z;DH=Aq.EK;AY=DH;DI=Aq.Space+Aq.H4;DJ=Aq.Space+Aq.H5;Bx=!((BV[
0]>=BV[2])||(BV[1]>=BV[3]));CI=null;switch(DH){case 9:case 10:AY=3;break;case 11:
case 12:AY=4;break;case 5:case 6:AY=1;break;case 7:case 8:AY=2;break;default:;}}
if(Bx){this.AS(Aq.M);}}if(G===CI){switch(DH){case 9:case 11:By=[0,(By[1]+(Az[3]-
Az[1]))+DJ];break;case 10:case 12:By=[0,(By[1]-(Az[3]-Az[1]))-DJ];break;case 5:case
7:By=[(By[0]+(Az[2]-Az[0]))+DI,0];break;case 6:case 8:By=[(By[0]-(Az[2]-Az[0]))-
DI,0];break;default:;}CI=null;}G=G.T;}if(Bx)B.lq(Aq.B0,Aq);this.F=this.F&~0x2000;
this.EW([Ck[2]-Ck[0],Ck[3]-Ck[1]]);},Bb:function(BX){var A;var Jh=((this.F&0x1000
)===0x1000);if(((this.F&0x4000)===0x4000)){this.F=this.F&~0x4000;this.Jf();}if(((
this.F&0x8000)===0x8000)||Jh){this.F=this.F&~0x8000;this.Ee(this.F);}},Dr:function(
C){var A;if(!!C&&(C.L!==this))throw new Error(B1);if(!!C&&!((C.F&0x14)===0x14))C=
null;if(!!C&&((C.F&0x10000)===0x10000))C=null;if(C===this.Bh)return;if(!!this.Bh
)this.Bh.AV(0x0,0x60);this.Bh=C;if(!!C){if(((this.F&0x40)===0x40))C.AV(0x60,0x0);
else C.AV(0x20,0x0);}},GM:function(Gc){var tmp=this;while(!!tmp){Gc=B.tw(Gc,tmp.
M.slice(0,2));tmp=tmp.L;}return Gc;},DispatchEvent:function(S){var A;var G=this.
Bh;var Q=(D.Ac.isPrototypeOf(G)?G:null);var V=null;var Gt=!!this.C5&&(!!this.C5.
Gj||!!this.C5.A4);if(!!G&&((((G.F&0x10000)===0x10000)||((G.F&0x40000)===0x40000)
)||((G.F&0x20000)===0x20000))){G=null;Q=null;}if(!!this.CE&&!Gt)V=this.CE.A5.DispatchEvent(
S);if(!V&&!!Q)V=Q.DispatchEvent(S);else if(!V&&!!G)V=G.AM(S);if(!V)V=this.AM(S);
if(!V)V=this.Gx(S);return V;},BroadcastEventAtPosition:function(S,Hi,A9){var A;var
G=this.AK;var V=null;while(!!G&&!V){if((!A9||((A=A9)&&((G.F&A)===A)))&&B.qu(G.GetExtent(
),Hi)){var Q=(D.Ac.isPrototypeOf(G)?G:null);if(!!Q)V=Q.BroadcastEventAtPosition(
S,B.tw(Hi,Q.M.slice(0,2)),A9);else V=G.AM(S);}G=G.N;}if(!V)V=this.AM(S);return V;
},BroadcastEvent:function(S,A9){var A;var G=this.AK;var V=null;while(!!G&&!V){if(
!A9||((A=A9)&&((G.F&A)===A))){var Q=(D.Ac.isPrototypeOf(G)?G:null);if(!!Q)V=Q.BroadcastEvent(
S,A9);else V=G.AM(S);}G=G.N;}if(!V)V=this.AM(S);if(!V)V=this.Gx(S);return V;},EW:
function(aSize){},Ee:function(E3){},Dh:function(){this.F=this.F|0x8000;B.lq([this
,this.Bb],this);},AS:function(Aa){var A;var Q=this;while(!!Q&&!((Aa[0]>=Aa[2])||(
Aa[1]>=Aa[3]))){var C0=Q.Bf;if(!Q.L&&(Q!==this)){Q.AS(Aa);return;}if(!!C0){var Gn=
false;var Jc=C0.Bq;if(Gn)C0.Bq=[0,0,(A=Q.M)[2]-A[0],A[3]-A[1]];else C0.Bq=B.qR(C0.
Bq,Aa);if(!B.tm(Jc,C0.Bq)){B.qw(Q,0);B.qw(C0,0);}}if(!((Q.F&0x1)===0x1))return;Aa=
B.il(B.tz(Aa,Q.M.slice(0,2)),Q.M);Q=Q.L;}},A7:function(aArg){this.Dh();},GH:function(
H,A9){var A;if(!H||(H.L!==this))return null;var CK=H.T;var CN=H.N;var Eu=0x10000;
if(((A9&0x10000)===0x10000))Eu=0x0;while(!!CK||!!CN){if((!!CK&&(!A9||((A=A9)&&((
CK.F&A)===A))))&&(!Eu||!((A=Eu)&&((CK.F&A)===A))))return CK;if((!!CN&&(!A9||((A=
A9)&&((CN.F&A)===A))))&&(!Eu||!((A=Eu)&&((CN.F&A)===A))))return CN;if(!!CK)CK=CK.
T;if(!!CN)CN=CN.N;}return null;},H2:function(H,Bk){var A;if(!H)throw new Error(Eg
);if(H.L!==this)throw new Error(Cz);var Ci=H;var Ap=H;var C$=H.Bv;while(((Bk>0)&&
!!Ci.T)&&(Ci.T.Bv<=C$)){Ci=Ci.T;Bk=Bk-1;}while(((Bk<0)&&!!Ap.N)&&(Ap.N.Bv>=C$)){
Ap=Ap.N;Bk=Bk+1;}if((Ci===H)&&(Ap===H))return;if(((H.F&0x401)===0x401)){if(!!H.N&&
!!H.AB)H.N.F=H.N.F|0x800;H.F=H.F|0x800;this.F=this.F|0x4000;B.lq([this,this.Bb],
this);}if(((H.F&0x200)===0x200)){if(!!H.N)H.N.F=H.N.F|0x800;H.F=H.F|0x800;this.F=
this.F|0x4000;B.lq([this,this.Bb],this);}if(!!H.N)H.N.T=H.T;if(!!H.T)H.T.N=H.N;if(
this.A4===H)this.A4=H.T;if(this.AK===H)this.AK=H.N;if(Ci!==H){H.T=Ci.T;H.N=Ci;Ci.
T=H;if(!!H.T)H.T.N=H;}if(Ap!==H){H.T=Ap;H.N=Ap.N;Ap.N=H;if(!!H.N)H.N.T=H;}if(!H.
T)this.AK=H;if(!H.N)this.A4=H;if(((H.F&0x1)===0x1))this.AS(H.GetExtent());},Hb:function(
H){var A;if(!H)throw new Error(FW);if(H.L!==this)throw new Error(Cz);if((((H.F&0x401
)===0x401)&&!!H.N)&&!!H.AB){H.N.F=H.N.F|0x800;this.F=this.F|0x4000;B.lq([this,this.
Bb],this);}if(((H.F&0x200)===0x200)){if(!!H.N)H.N.F=H.N.F|0x800;this.F=this.F|0x4000;
B.lq([this,this.Bb],this);}H.AB=null;if(this.Bh===H)this.Dr(this.GH(H,0x14));if(
!!H.N)H.N.T=H.T;if(!!H.T)H.T.N=H.N;if(this.A4===H)this.A4=H.T;if(this.AK===H)this.
AK=H.N;H.L=null;H.T=null;H.N=null;if(((H.F&0x1)===0x1))this.AS(H.GetExtent());},
Aw:function(H,Bk){var A;if(!H)throw new Error(FX);if(!!H.L)throw new Error(FY);var
Ap=null;var C$=H.Bv;if(((Bk<0)&&!!this.AK)&&(this.AK.Bv>=C$)){Ap=this.AK;Bk=Bk+1;
}while((((Bk<0)&&!!Ap)&&!!Ap.N)&&(Ap.N.Bv>=C$)){Ap=Ap.N;Bk=Bk+1;}if((!Ap&&!!this.
AK)&&(this.AK.Bv>C$))Ap=this.AK;while((!!Ap&&!!Ap.N)&&(Ap.N.Bv>C$))Ap=Ap.N;if(!Ap
){H.L=this;H.N=this.AK;if(!!this.AK)this.AK.T=H;if(!this.A4)this.A4=H;this.AK=H;
}else{H.L=this;H.N=Ap.N;H.T=Ap;Ap.N=H;if(!!H.N)H.N.T=H;else this.A4=H;}if(((H.F&
0x1)===0x1))this.AS(H.GetExtent());if(((!this.Bh&&((H.F&0x4)===0x4))&&((H.F&0x10
)===0x10))&&!((H.F&0x10000)===0x10000))this.Dr(H);if(((H.F&0x401)===0x401)){H.F=
H.F|0x800;this.F=this.F|0x4000;B.lq([this,this.Bb],this);}if(((H.F&0x200)===0x200
)){H.F=H.F|0x800;this.F=this.F|0x4000;B.lq([this,this.Bb],this);}},_Init:function(
aArg){D.AN._Init.call(this,aArg);this.__proto__=D.Ac;this.F=0x1F;this.A7(aArg);}
,_Mark:function(E){var A;D.AN._Mark.call(this,E);if((A=this.A4)&&(A._cycle!=E))A.
_Mark(A._cycle=E);if((A=this.AK)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.Fd
)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.Bf)&&(A._cycle!=E))A._Mark(A._cycle=
E);if((A=this.CE)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.C5)&&(A._cycle!=
E))A._Mark(A._cycle=E);if((A=this.Bh)&&(A._cycle!=E))A._Mark(A._cycle=E);},_className:
"Core::Group"};D.Root={A1:null,Cm:null,BT:null,AD:B.tA(10,null,null),DG:null,Bj:
null,Cj:null,EF:0,Gf:0,Ab:0,AP:B.tA(10,0,null),E9:B.tA(10,B.qy,null),BU:B.tA(10,
0,null),CC:B.tA(10,B.qx,null),Eo:B.tA(10,0,null),C2:B.tA(10,B.qx,null),B_:B.tA(10
,B.qx,null),B$:B.tA(10,B.qx,null),CB:B.tA(10,B.qx,null),C3:0,Fa:0,E$:0,Ff:B.tA(3
,B.qy,null),Ht:0,AR:B.tA(4,0,null),Av:B.tA(4,B.qy,null),As:0,EI:8,HD:250,CH:0,Cl:
0,Gp:true,Fe:false,Ce:function(AE,aClip,aOffset,AF,aBlend){var fullScreenUpdate=
false;fullScreenUpdate=B.jI;if(!fullScreenUpdate)AE.FA(aClip,B.tz(B.tz(aClip,aOffset
),this.M.slice(0,2)),0x00000000,0x00000000,0x00000000,0x00000000,false);D.Ac.Ce.
call(this,AE,aClip,aOffset,AF,aBlend);},AV:function(Ch,CY){var A;D.Ac.AV.call(this
,Ch,CY);if(!this.L&&(((Ch&0x1)===0x1)||((CY&0x1)===0x1)))this.AS([0,0,(A=this.M)[
2]-A[0],A[3]-A[1]]);if(!this.L&&(((Ch&0x2)===0x2)||((CY&0x2)===0x2)))this.AS([0,
0,(A=this.M)[2]-A[0],A[3]-A[1]]);},Dr:function(C){if((C!==this.Bj)||!C)D.Ac.Dr.call(
this,C);},DispatchEvent:function(S){if((this.Gf>0)&&!!(D.KeyEvent.isPrototypeOf(
S)?S:null))return null;if(!!S){S.D3=!!this.Ab;if(!!this.Ab)S.Bi=this.Ab;}var V=null;
if(!!this.Bj){V=this.Bj.DispatchEvent(S);if(!!V){this.Ab=0;return V;}}if(!!this.
Cm){V=this.Cm.A5.DispatchEvent(S);if(!V)V=this.AM(S);if(!V)V=this.Gx(S);this.Ab=
0;return V;}V=D.Ac.DispatchEvent.call(this,S);this.Ab=0;return V;},BroadcastEvent:
function(S,A9){if(!!S){S.D3=!!this.Ab;if(!!this.Ab)S.Bi=this.Ab;}var V=D.Ac.BroadcastEvent.
call(this,S,A9);this.Ab=0;return V;},AS:function(Aa){var A;if(this.EF>0)throw new
Error(FZ);if(!!this.Bf&&!this.L){if(((A=this.Bf.Bq)[0]>=A[2])||(A[1]>=A[3])){B.qw(
this,0);B.qw(this.Bf,0);}var Gn=false;if(Gn)this.Bf.Bq=[0,0,(A=this.M)[2]-A[0],A[
3]-A[1]];else this.Bf.Bq=B.qR(this.Bf.Bq,Aa);}var fullScreenUpdate=false;fullScreenUpdate=
B.jI;if(fullScreenUpdate)Aa=[0,0,(A=this.M)[2]-A[0],A[3]-A[1]];if(!!this.L){D.Ac.
AS.call(this,Aa);return;}Aa=B.il(B.tz(Aa,this.M.slice(0,2)),this.M);if((Aa[0]>=Aa[
2])||(Aa[1]>=Aa[3]))return;var I;for(I=0;I<this.As;I=I+1)if(!(((A=B.il(this.Av.Get(
I),Aa))[0]>=A[2])||(A[1]>=A[3]))){this.Av.Set(I,B.qR(this.Av.Get(I),Aa));this.AR.
Set(I,B.s9(this.Av.Get(I)));return;}if(this.As<3){this.Av.Set(this.As,Aa);this.AR.
Set(this.As,B.s9(Aa));this.As=this.As+1;return;}var Ak;var A0;var Er=0;var Es=0;
var Hj=2147483647;this.Av.Set(this.As,Aa);this.AR.Set(this.As,B.s9(Aa));for(Ak=0;
Ak<=this.As;Ak=Ak+1)for(A0=Ak+1;A0<=this.As;A0=A0+1){var Fn=B.s9(B.qR(this.Av.Get(
Ak),this.Av.Get(A0)));var Hx=((Fn<<8)/(this.AR.Get(Ak)+this.AR.Get(A0)))|0;if(Hx<
Hj){Hj=Hx;Er=Ak;Es=A0;}}this.Av.Set(Er,B.qR(this.Av.Get(Er),this.Av.Get(Es)));this.
AR.Set(Er,B.s9(this.Av.Get(Er)));if(Es!==this.As){this.Av.Set(Es,this.Av.Get(this.
As));this.AR.Set(Es,this.AR.Get(this.As));}},I$:function(){var AG=B._NewObject(D.
Fw,0);AG.D3=!!this.Ab;if(!!this.Ab)AG.Bi=this.Ab;return AG;},En:function(){var AG=
B._NewObject(D.Fu,0);AG.D3=!!this.Ab;if(!!this.Ab)AG.Bi=this.Ab;return AG;},E8:function(
){var AG=B._NewObject(D.Fv,0);AG.D3=!!this.Ab;if(!!this.Ab)AG.Bi=this.Ab;return AG;
},Ja:function(BX){var I;var C6=false;for(I=0;I<10;I=I+1)if(!!this.AD.Get(I)){var
AQ=this.B$.Get(I);var Q=this.AD.Get(I).L;while(!!Q&&(Q!==this)){AQ=B.tw(AQ,Q.M.slice(
0,2));Q=Q.L;}if(!Q&&(this.AD.Get(I)!==this)){var tmp=this.AD.Get(I);this.C3=I;this.
AD.Set(I,null);tmp.AM(this.En().InitializeUp(I,this.C2.Get(I),this.CC.Get(I),this.
BU.Get(I),this.AP.Get(I)+1,this.B_.Get(I),false,this.B$.Get(I),this.CB.Get(I)));
if(tmp===this.BT)this.BT=null;this.BroadcastEvent(this.E8().InitializeUp(I,this.
AP.Get(I)+1,false,tmp,this.B$.Get(I)),0x18);}else{this.BU.Set(I,(this.Cj.Bi-this.
Eo.Get(I))|0);if(this.BU.Get(I)<10)this.BU.Set(I,10);this.C3=I;this.AD.Get(I).AM(
this.En().InitializeHold(I,AQ,this.CC.Get(I),this.BU.Get(I),this.AP.Get(I)+1,this.
B_.Get(I),this.B$.Get(I),this.CB.Get(I)));C6=true;}}if(!C6)this.Cj.EP(false);},GetFPS:
function(){var ticksCount=0;var Hp=0;ticksCount=((new Date).getTime()-B.qt)|0;if(
!!this.Fa&&(ticksCount>this.Fa))Hp=((this.E$*1000)/((ticksCount-this.Fa)|0))|0;this.
E$=0;this.Fa=ticksCount;return Hp;},Update:function(){var A;if(!this.DG){this.DG=
B._NewObject(B.Graphics.Canvas,0);this.DG.FH([(A=this.M)[2]-A[0],A[3]-A[1]]);}this.
DG.Update();return this.UpdateGE20(this.DG);},UpdateGE20:function(AE){if(!this.BeginUpdate(
))return Ay;var Cd=this.UpdateCanvas(AE,Z);this.EndUpdate();return Cd;},EndUpdate:
function(){if(this.As>0){this.E$=this.E$+1;this.As=0;}},UpdateCanvas:function(AE
,aOffset){var A;var Cd=Ay;var I9=[].concat(aOffset,B.tx(AE.FrameSize,aOffset));var
I;var Ak=this.As;this.EF=this.EF+1;for(I=0;(I<Ak)&&(I<4);I=I+1){if(this.AR.Get(I
)>0){this.Ce(AE,B.ty(this.Av.Get(I),aOffset),[-aOffset[0],-aOffset[1]],255,true);
Cd=B.qR(Cd,B.il(I9,this.Av.Get(I)));}else Ak=Ak+1;}this.EF=this.EF-1;if(!((Cd[0]>=
Cd[2])||(Cd[1]>=Cd[3])))return B.ty(Cd,aOffset);else return Cd;},GetUpdateRegion:
function(E2){var I;var Ak=this.As;if(E2<0)return Ay;for(I=0;(I<Ak)&&(I<4);I=I+1){
if(!this.AR.Get(I)){Ak=Ak+1;E2=E2+1;}else if(I===E2)return this.Av.Get(I);}return Ay;
},BeginUpdate:function(){var Je=true;var fullScreenUpdate=false;var I;if((!Je&&!
fullScreenUpdate)&&(this.As>0)){var HA=B.tA(3,B.qy,null);var GC=this.As;for(I=0;
I<GC;I=I+1)HA.Set(I,this.Av.Get(I));for(I=0;I<this.Ht;I=I+1)this.AS(this.Ff.Get(
I));for(I=0;I<GC;I=I+1)this.Ff.Set(I,HA.Get(I));this.Ht=GC;}var Ak;var A0;for(Ak=
0;Ak<(this.As-1);Ak=Ak+1)if(this.AR.Get(Ak)>0)for(A0=Ak+1;A0<this.As;A0=A0+1)if(
this.AR.Get(A0)>0){var Fn=B.s9(B.qR(this.Av.Get(Ak),this.Av.Get(A0)));if(((Fn-this.
AR.Get(Ak))-this.AR.Get(A0))<0){this.Av.Set(Ak,B.qR(this.Av.Get(Ak),this.Av.Get(
A0)));this.AR.Set(Ak,Fn);this.AR.Set(A0,0);}}for(I=this.As-1;I>=0;I=I-1)if(!this.
AR.Get(I))this.As=this.As-1;return this.As;},DoesNeedUpdate:function(){if(this.As>
0)return true;return false;},Initialize:function(aSize){this.U([].concat(Z,aSize
));if(this.Gp)this.F=this.F|0x60;else this.F=this.F|0x20;this.AS(this.M);return this;
},SetRootFocus:function(Ga){if(Ga===this.Gp)return false;this.Gp=Ga;if(!Ga){if(!
!this.Bj)this.Bj.AV(0x0,0x40);if(!!this.Cm)this.Cm.A5.AV(0x0,0x40);else this.AV(
0x0,0x40);}else{if(!!this.Cm)this.Cm.A5.AV(0x40,0x0);else this.AV(0x40,0x0);if(!
!this.Bj)this.Bj.AV(0x40,0x0);}return true;},SetUserInputTimestamp:function(I8){
this.Ab=I8;},DriveKeyboardHitting:function(Ao,CX,Be){var A;var Gy=!!this.A1;if(!
!this.A1&&((!Be||(this.CH!==Ao))||(this.Cl!==CX))){var AG=null;var G=(D.BR.isPrototypeOf(
A=this.A1)?A:null);var Bz=(D.EM.isPrototypeOf(A=this.A1)?A:null);if(!!this.CH)AG=
B._NewObject(D.KeyEvent,0).Initialize(this.CH,false);if(this.Cl!==0x00)AG=B._NewObject(
D.KeyEvent,0).Initialize2(this.Cl,false);if(!!Bz)Bz.AM(AG);else if(!!G)G.AM(AG);
this.CH=0;this.Cl=0x00;this.A1=null;}if(!!this.A1){var AG=null;var G=(D.BR.isPrototypeOf(
A=this.A1)?A:null);var Bz=(D.EM.isPrototypeOf(A=this.A1)?A:null);if(!!Ao)AG=B._NewObject(
D.KeyEvent,0).Initialize(Ao,true);if(this.Cl!==0x00)AG=B._NewObject(D.KeyEvent,0
).Initialize2(CX,true);if(!!Bz)Bz.AM(AG);else if(!!G)G.AM(AG);}if(this.Fe&&((!Be||(
this.CH!==Ao))||(this.Cl!==CX))){this.CH=0;this.Cl=0x00;this.Fe=false;}if((!this.
A1&&Be)&&(this.Gf>0)){this.CH=Ao;this.Cl=CX;this.Fe=true;}if((!this.A1&&Be)&&!this.
Fe){if(!!Ao)this.A1=this.DispatchEvent(B._NewObject(D.KeyEvent,0).Initialize(Ao,
true));if(CX!==0x00)this.A1=this.DispatchEvent(B._NewObject(D.KeyEvent,0).Initialize2(
CX,true));if(!(D.EM.isPrototypeOf(A=this.A1)?A:null)&&!(D.BR.isPrototypeOf(A=this.
A1)?A:null))this.A1=null;this.CH=Ao;this.Cl=CX;Gy=Gy||!!this.A1;}this.Ab=0;return Gy;
},DriveCursorMovement:function(At){return this.DriveMultiTouchMovement(this.C3,At
);},DriveMultiTouchMovement:function(J,At){if((J<0)||(J>9)){this.Ab=0;return false;
}var Ev=B.tw(At,this.B$.Get(J));this.B$.Set(J,At);if(!this.AD.Get(J)||B.tl(Ev,Z)
){this.Ab=0;return false;}var AQ=At;var Q=this.AD.Get(J).L;while(!!Q&&(Q!==this)
){AQ=B.tw(AQ,Q.M.slice(0,2));Q=Q.L;}if(!Q&&(this.AD.Get(J)!==this)){var tmp=this.
AD.Get(J);this.C3=J;this.AD.Set(J,null);tmp.AM(this.En().InitializeUp(J,this.C2.
Get(J),this.CC.Get(J),this.BU.Get(J),this.AP.Get(J)+1,this.B_.Get(J),false,this.
B$.Get(J),this.CB.Get(J)));if(tmp===this.BT)this.BT=null;this.BroadcastEvent(this.
E8().InitializeUp(J,this.AP.Get(J)+1,false,tmp,At),0x18);}else{this.C2.Set(J,AQ);
this.C3=J;this.AD.Get(J).AM(this.I$().Initialize(J,AQ,this.CC.Get(J),Ev,this.BU.
Get(J),this.AP.Get(J)+1,this.B_.Get(J),At,this.CB.Get(J)));}this.Ab=0;return true;
},DriveCursorHitting:function(Be,J,At){return this.DriveMultiTouchHitting(Be,J,At
);},DriveMultiTouchHitting:function(Be,J,At){var A;if((J<0)||(J>9)){this.Ab=0;return false;
}var ticksCount=this.Ab;var Ep=[].concat([-this.EI,-this.EI],[this.EI+1,this.EI+
1]);if(!ticksCount){ticksCount=((new Date).getTime()-B.qt)|0;}var Jg=this.Ab;this.
DriveMultiTouchMovement(J,At);At=this.B$.Get(J);this.Ab=Jg;if(Be)this.CB.Set(J,At
);if((Be&&!this.AD.Get(J))&&!this.Gf){var Cb=null;var AQ=At;if(B.qu(this.E9.Get(
J),At)&&((ticksCount-this.Eo.Get(J))<=(((A=this.HD)<0)?A+0x100000000:A)))this.AP.
Set(J,this.AP.Get(J)+1);else this.AP.Set(J,0);this.E9.Set(J,B.tz(Ep,At));this.Eo.
Set(J,ticksCount);if((!!this.Bj&&!!this.Bj.L)&&((this.Bj.F&0x18)===0x18)){var R=
B.tz(Ep,this.Bj.L.GM(At));Cb=this.Bj.CR(R,J,this.AP.Get(J)+1,null,0x0);}if(!Cb){
if(!!this.BT&&!!this.BT.L){if(((this.BT.F&0x8)===0x8)&&((this.BT.F&0x10)===0x10)
){var R=B.tz(Ep,this.BT.L.GM(At));Cb=this.BT.CR(R,J,this.AP.Get(J)+1,null,0x0);}
}else if(!!this.Cm)Cb=this.CR(B.tz(Ep,At),J,this.AP.Get(J)+1,this.Cm.A5,0x0);else
Cb=this.CR(B.tz(Ep,At),J,this.AP.Get(J)+1,null,0x0);}if(!!Cb){this.BroadcastEvent(
this.E8().InitializeDown(J,this.AP.Get(J)+1,false,Cb.BR,At),0x18);this.AD.Set(J,
Cb.BR);this.B_.Set(J,Cb.FG);}else{this.AD.Set(J,null);this.B_.Set(J,Z);this.Ab=0;
return false;}var Q=Cb.BR.L;while(!!Q&&(Q!==this)){AQ=B.tw(AQ,Q.M.slice(0,2));Q=
Q.L;}this.CC.Set(J,AQ);this.C2.Set(J,AQ);this.BU.Set(J,0);this.Cj.EP(true);this.
C3=J;this.AD.Get(J).AM(this.En().InitializeDown(J,AQ,this.AP.Get(J)+1,this.B_.Get(
J),false,At));this.Ab=0;return true;}if(!Be&&!!this.AD.Get(J)){var AQ=At;var Q=this.
AD.Get(J).L;while(!!Q&&(Q!==this)){AQ=B.tw(AQ,Q.M.slice(0,2));Q=Q.L;}if(!Q)AQ=this.
C2.Get(J);this.C3=J;var tmp=this.AD.Get(J);this.AD.Set(J,null);tmp.AM(this.En().
InitializeUp(J,AQ,this.CC.Get(J),this.BU.Get(J),this.AP.Get(J)+1,this.B_.Get(J),
false,At,this.CB.Get(J)));this.BroadcastEvent(this.E8().InitializeUp(J,this.AP.Get(
J)+1,false,tmp,At),0x18);this.Ab=0;return true;}this.Ab=0;return false;},_Init:function(
aArg){D.Ac._Init.call(this,aArg);D.Timer._Init.call(this.Cj={P:this},0);(this.AD=[
]).__proto__=D.Root.AD;(this.AP=[]).__proto__=D.Root.AP;(this.E9=[]).__proto__=D.
Root.E9;(this.BU=[]).__proto__=D.Root.BU;(this.CC=[]).__proto__=D.Root.CC;(this.
Eo=[]).__proto__=D.Root.Eo;(this.C2=[]).__proto__=D.Root.C2;(this.B_=[]).__proto__=
D.Root.B_;(this.B$=[]).__proto__=D.Root.B$;(this.CB=[]).__proto__=D.Root.CB;(this.
Ff=[]).__proto__=D.Root.Ff;(this.AR=[]).__proto__=D.Root.AR;(this.Av=[]).__proto__=
D.Root.Av;this.__proto__=D.Root;this.F=0x7F;this.Cj.HO(50);this.Cj.ET=[this,this.
Ja];},_Done:function(){this.__proto__=D.Ac;this.Cj._Done();D.Ac._Done.call(this);
},_ReInit:function(){D.Ac._ReInit.call(this);this.Cj._ReInit();},_Mark:function(
E){var A;D.Ac._Mark.call(this,E);if((A=this.A1)&&(A._cycle!=E))A._Mark(A._cycle=
E);if((A=this.Cm)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.BT)&&(A._cycle!=
E))A._Mark(A._cycle=E);B.ts(this.AD,E);if((A=this.DG)&&(A._cycle!=E))A._Mark(A._cycle=
E);if((A=this.Bj)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.Cj)._cycle!=E)A.
_Mark(A._cycle=E);},_className:"Core::Root"};D.Event={Bi:0,D3:false,EL:function(
){var ticksCount=0;ticksCount=((new Date).getTime()-B.qt)|0;return ticksCount;},
A7:function(aArg){this.Bi=this.EL();},_Init:function(aArg){this.__proto__=D.Event;
this.A7(aArg);B.gv++;},_Done:function(){this.__proto__=null;B.gv--;},_ReInit:function(
){},_Mark:function(E){var A;if((A=this.P)&&(A._cycle!=E))A._Mark(A._cycle=E);},P:
null,_cycle:0,_observers:null,_className:"Core::Event"};D.KeyEvent={Ar:0,W:0,Down:
false,Initialize2:function(Ao,Be){this.Ar=0;this.W=Ao;this.Down=Be;if((Ao>=0x30)&&(
Ao<=0x39))this.Ar=(10+Ao)-48;if((Ao>=0x41)&&(Ao<=0x5A))this.Ar=(105+Ao)-65;if((Ao>=
0x61)&&(Ao<=0x7A))this.Ar=(105+Ao)-97;if(Ao===0x20)this.Ar=131;if(!this.Ar)switch(
Ao){case 0x2B:this.Ar=132;break;case 0x2D:this.Ar=133;break;case 0x2A:this.Ar=134;
break;case 0x2F:this.Ar=135;break;case 0x3D:this.Ar=136;break;case 0x2E:this.Ar=
137;break;case 0x2C:this.Ar=138;break;case 0x3A:this.Ar=139;break;case 0x3B:this.
Ar=140;break;default:;}return this;},Initialize:function(Ao,Be){this.Ar=Ao;this.
Down=Be;this.W=0x00;var Gh=Ao-10;var Gg=Ao-105;if((Gh>=0)&&(Gh<=9))this.W=(48+Gh
)&0xFFFF;if((Gg>=0)&&(Gg<=25))this.W=(65+Gg)&0xFFFF;if(Ao===131)this.W=0x20;if(this.
W===0x00)switch(Ao){case 132:this.W=0x2B;break;case 133:this.W=0x2D;break;case 134:
this.W=0x2A;break;case 135:this.W=0x2F;break;case 136:this.W=0x3D;break;case 137:
this.W=0x2E;break;case 138:this.W=0x2C;break;case 139:this.W=0x3A;break;case 140:
this.W=0x3B;break;default:;}return this;},HJ:function(Hf){switch(Hf){case 141:return((
this.W>=0x41)&&(this.W<=0x5A))||((this.W>=0x61)&&(this.W<=0x7A));case 142:return(((
this.W>=0x41)&&(this.W<=0x5A))||((this.W>=0x61)&&(this.W<=0x7A)))||((this.W>=0x30
)&&(this.W<=0x39));case 143:return(this.W>=0x30)&&(this.W<=0x39);case 144:return(((
this.W>=0x41)&&(this.W<=0x46))||((this.W>=0x61)&&(this.W<=0x66)))||((this.W>=0x30
)&&(this.W<=0x39));case 145:return this.W!==0x00;case 146:return(this.W===0x00)&&
!!this.Ar;case 147:return(((this.Ar===6)||(this.Ar===7))||(this.Ar===4))||(this.
Ar===5);case 148:return(this.W!==0x00)||!!this.Ar;default:;}return Hf===this.Ar;
},_Init:function(aArg){D.Event._Init.call(this,aArg);this.__proto__=D.KeyEvent;}
,_className:"Core::KeyEvent"};D.Fv={FL:null,Cs:B.qx,Ct:0,Cr:0,Down:false,DR:false
,InitializeUp:function(J,Bl,CW,Ge,Bw){this.Down=false;this.Cr=J;this.Ct=Bl;this.
Cs=Bw;this.FL=Ge;this.DR=CW;return this;},InitializeDown:function(J,Bl,CW,Ge,Bw){
this.Down=true;this.Cr=J;this.Ct=Bl;this.Cs=Bw;this.FL=Ge;this.DR=CW;return this;
},_Init:function(aArg){D.Event._Init.call(this,aArg);this.__proto__=D.Fv;},_Mark:
function(E){var A;D.Event._Mark.call(this,E);if((A=this.FL)&&(A._cycle!=E))A._Mark(
A._cycle=E);},_className:"Core::CursorGrabEvent"};D.Fu={DZ:B.qx,Cs:B.qx,Ct:0,D1:
0,D0:B.qx,DS:B.qx,Cr:0,Down:false,DR:false,InitializeHold:function(J,CA,Ei,Ej,Bl
,BS,Bw,Eh){this.Down=true;this.Cr=J;this.DS=B.tx(CA,BS);this.D0=B.tx(Ei,BS);this.
D1=Ej;this.Ct=Bl;this.Cs=Bw;this.DZ=Eh;return this;},InitializeUp:function(J,CA,
Ei,Ej,Bl,BS,CW,Bw,Eh){this.Down=false;this.Cr=J;this.DS=B.tx(CA,BS);this.D0=B.tx(
Ei,BS);this.D1=Ej;this.Ct=Bl;this.DR=CW;this.Cs=Bw;this.DZ=Eh;return this;},InitializeDown:
function(J,CA,Bl,BS,CW,Bw){this.Down=true;this.Cr=J;this.DS=B.tx(CA,BS);this.D0=
B.tx(CA,BS);this.D1=0;this.Ct=Bl;this.DR=CW;this.Cs=Bw;this.DZ=Bw;return this;},
_Init:function(aArg){D.Event._Init.call(this,aArg);this.__proto__=D.Fu;},_className:
"Core::CursorEvent"};D.Fw={DZ:B.qx,Cs:B.qx,Ct:0,D1:0,FG:B.qx,D0:B.qx,DS:B.qx,Cr:
0,Initialize:function(J,CA,Ei,aOffset,Ej,I7,BS,Bw,Eh){this.Cr=J;this.DS=B.tx(CA,
BS);this.D0=B.tx(Ei,BS);this.FG=aOffset;this.D1=Ej;this.Ct=I7;this.Cs=Bw;this.DZ=
Eh;return this;},_Init:function(aArg){D.Event._Init.call(this,aArg);this.__proto__=
D.Fw;},_className:"Core::DragEvent"};D.D6={B0:null,D9:B.qx,H5:0,H4:0,Space:0,EK:
0,Ce:function(AE,aClip,aOffset,AF,aBlend){},U:function(C){var A;if(B.tm(C,this.M
))return;var CL=[(A=this.M)[2]-A[0],A[3]-A[1]];var Fh=[C[2]-C[0],C[3]-C[1]];var C_=
!B.tl(CL,Fh);var Ev=B.tw(C.slice(0,2),this.M.slice(0,2));if(!B.tl(Ev,Z)&&!C_){var
G=this.T;while(!!G&&!((G.F&0x200)===0x200)){if(((G.F&0x400)===0x400)){var tmp=((
G.F&0x100)===0x100);G.GN(Ev,tmp);}G=G.T;}B.lq(this.B0,this);}if((C_&&(CL[0]>0))&&(
CL[1]>0)){var Aj=B.tz(this.M,this.D9);var G=this.T;var Eq=0x14;while(!!G&&!((G.F&
0x200)===0x200)){if(((G.F&0x400)===0x400)){if(!!G.AB&&(G.AB.DK!==this))G.AB=null;
if(!G.AB&&((G.AC!==Eq)||!!this.EK))G.Fb(Aj,this);}G=G.T;}B.lq(this.B0,this);}D.AN.
U.call(this,C);if(!!this.L&&C_){this.F=this.F|0x1000;if(!((this.L.F&0x2000)===0x2000
)){this.L.F=this.L.F|0x4000;B.lq([A=this.L,A.Bb],this);}}},_Init:function(aArg){
D.AN._Init.call(this,aArg);this.__proto__=D.D6;this.F=0x203;},_Mark:function(E){
var A;D.AN._Mark.call(this,E);if((A=this.B0)&&((A=A[0])._cycle!=E))A._Mark(A._cycle=
E);},_className:"Core::Outline"};D.EM={T:null,G$:null,G_:null,G9:null,C9:0,Bi:0,
Hc:0,HF:148,Ar:0,W:0,Dg:true,Down:false,FK:false,EH:false,AM:function(S){var A;if(
!!S&&S.HJ(this.HF)){this.Down=S.Down;this.Ar=S.Ar;this.W=S.W;this.Bi=S.Bi;this.EH=
false;if(S.Down){this.Hc=this.C9;this.FK=this.C9>0;if(this.FK)(A=this.G9)?A[1].call(
A[0],this):null;else(A=this.G_)?A[1].call(A[0],this):null;if(!this.EH)this.C9=this.
C9+1;return!this.EH;}if(!S.Down){this.FK=this.C9>1;this.Hc=this.C9-1;this.C9=0;(
A=this.G$)?A[1].call(A[0],this):null;return!this.EH;}}return false;},A7:function(
aArg){var A;var A5=(D.Ac.isPrototypeOf(A=this.P)?A:null);if(!A5)throw new Error(
F0);this.T=A5.Fd;A5.Fd=this;},_Init:function(aArg){this.__proto__=D.EM;this.A7(aArg
);B.gv++;},_Done:function(){this.__proto__=null;B.gv--;},_ReInit:function(){},_Mark:
function(E){var A;if((A=this.T)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.G$
)&&((A=A[0])._cycle!=E))A._Mark(A._cycle=E);if((A=this.G_)&&((A=A[0])._cycle!=E)
)A._Mark(A._cycle=E);if((A=this.G9)&&((A=A[0])._cycle!=E))A._Mark(A._cycle=E);if((
A=this.P)&&(A._cycle!=E))A._Mark(A._cycle=E);},P:null,_cycle:0,_observers:null,_className:
"Core::KeyPressHandler"};D.HC={BR:null,EJ:0,FG:B.qx,_Init:function(aArg){this.__proto__=
D.HC;B.gv++;},_Done:function(){this.__proto__=null;B.gv--;},_ReInit:function(){}
,_Mark:function(E){var A;if((A=this.BR)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=
this.P)&&(A._cycle!=E))A._Mark(A._cycle=E);},P:null,_cycle:0,_observers:null,_className:
"Core::CursorHit"};D.HK={A5:null,_Init:function(aArg){this.__proto__=D.HK;B.gv++;
},_Done:function(){this.__proto__=null;B.gv--;},_ReInit:function(){},_Mark:function(
E){var A;if((A=this.A5)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.P)&&(A._cycle
!=E))A._Mark(A._cycle=E);},P:null,_cycle:0,_observers:null,_className:"Core::ModalContext"
};D.GL={DK:null,CG:B.qy,Aj:B.qy,isEmpty:false,_Init:function(aArg){this.__proto__=
D.GL;B.gv++;},_Done:function(){this.__proto__=null;B.gv--;},_ReInit:function(){}
,_Mark:function(E){var A;if((A=this.DK)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=
this.P)&&(A._cycle!=E))A._Mark(A._cycle=E);},P:null,_cycle:0,_observers:null,_className:
"Core::LayoutContext"};D.HE={A5:null,_Init:function(aArg){this.__proto__=D.HE;B.
gv++;},_Done:function(){this.__proto__=null;B.gv--;},_ReInit:function(){},_Mark:
function(E){var A;if((A=this.A5)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.P
)&&(A._cycle!=E))A._Mark(A._cycle=E);},P:null,_cycle:0,_observers:null,_className:
"Core::DialogContext"};D.H7={Gj:null,A4:null,_Init:function(aArg){this.__proto__=
D.H7;B.gv++;},_Done:function(){this.__proto__=null;B.gv--;},_ReInit:function(){}
,_Mark:function(E){var A;if((A=this.Gj)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=
this.A4)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.P)&&(A._cycle!=E))A._Mark(
A._cycle=E);},P:null,_cycle:0,_observers:null,_className:"Core::TaskQueue"};D.H6={
_Init:function(aArg){this.__proto__=D.H6;B.gv++;},_Done:function(){this.__proto__=
null;B.gv--;},_ReInit:function(){},_Mark:function(E){var A;if((A=this.P)&&(A._cycle
!=E))A._Mark(A._cycle=E);},P:null,_cycle:0,_observers:null,_className:"Core::Task"
};D.Cf={resource:null,BE:function(){this.resource=null;},A7:function(aArg){this.
resource=aArg;},_Init:function(aArg){this.__proto__=D.Cf;this.A7(aArg);B.gv++;},
_Done:function(){this.BE();this.__proto__=null;B.gv--;},_ReInit:function(){},_Mark:
function(E){var A;if((A=this.P)&&(A._cycle!=E))A._Mark(A._cycle=E);},P:null,_cycle:
0,_observers:null,_className:"Core::Resource"};D.Timer={ET:null,timer:null,Bi:0,
Period:1000,GD:0,Dg:false,BE:function(){var tmp=this.timer;if(!!tmp)tmp.DestroyTimer(
);this.timer=null;},GA:function(aBegin,aPeriod){if(aBegin<0)aBegin=0;if(aPeriod<
0)aPeriod=0;var tmp=this.timer;if(!tmp&&((aBegin>0)||(aPeriod>0)))tmp=B.sL(this,
this.Trigger);if(!!tmp){tmp.ResetTimer();tmp.StartTimer(aBegin,aPeriod);}this.timer=
tmp;},HO:function(C){if(C<0)C=0;if(C===this.Period)return;this.Period=C;if(this.
Dg)this.GA(this.GD,C);},EP:function(C){if(C===this.Dg)return;this.Dg=C;if(C)this.
GA(this.GD,this.Period);else this.GA(0,0);this.Bi=this.EL();},EL:function(){var ticksCount=
0;ticksCount=((new Date).getTime()-B.qt)|0;return ticksCount;},Trigger:function(
){var A;this.Bi=this.EL();if(!this.Period)this.EP(false);(A=this.ET)?A[1].call(A[
0],this):null;},_Init:function(aArg){this.__proto__=D.Timer;B.gv++;},_Done:function(
){this.BE();this.__proto__=null;B.gv--;},_ReInit:function(){},_Mark:function(E){
var A;if((A=this.ET)&&((A=A[0])._cycle!=E))A._Mark(A._cycle=E);if((A=this.P)&&(A.
_cycle!=E))A._Mark(A._cycle=E);},P:null,_cycle:0,_observers:null,_className:"Core::Timer"
};D.Kb={Kc:0x1,Jy:0x2,JF:0x4,J9:0x8,Dg:0x10,J4:0x20,JG:0x40,JN:0x80,JE:0x100,JI:
0x200,JD:0x400,JT:0x800,EW:0x1000,J$:0x2000,JR:0x4000,JS:0x8000,JC:0x10000,JQ:0x20000
,J3:0x40000};D.AC={JU:0x1,JV:0x2,Jo:0x4,Jp:0x8,Jq:0x10,Jn:0x20};D.EK={JO:0,J6:1,
Jz:2,JJ:3,JX:4,J7:5,J8:6,JA:7,JB:8,JL:9,JK:10,JZ:11,JY:12};D.KeyCode={NoKey:0,Ok:
1,Exit:2,Menu:3,Up:4,Down:5,Left:6,Right:7,PageUp:8,PageDown:9,Key0:10,Key1:11,Key2:
12,Key3:13,Key4:14,Key5:15,Key6:16,Key7:17,Key8:18,Key9:19,Red:20,Green:21,Blue:
22,Yellow:23,White:24,Magenta:25,F1:26,F2:27,F3:28,F4:29,F5:30,F6:31,F7:32,F8:33
,F9:34,F10:35,ChannelUp:36,ChannelDown:37,Display:38,SkipPrev:39,SkipNext:40,Home:
41,End:42,Insert:43,Delete:44,Clear:45,VolumeUp:46,VolumeDown:47,Show:48,Hide:49
,Play:50,Pause:51,Record:52,Stop:53,Rev:54,Fwd:55,SlowRev:56,SlowFwd:57,SkipBwd:
58,SkipFwd:59,Repeat:60,Eject:61,Help:62,TV:63,DVD:64,VCR:65,EPG:66,OSD:67,Text:
68,PIP:69,Audio:70,Clock:71,Timer:72,Navigation:73,Karaoke:74,Game:75,Subtitle:76
,Zoom:77,Index:78,Info:79,Power:80,Setup:81,Angle:82,Mode:83,Mute:84,User0:85,User1:
86,User2:87,User3:88,User4:89,User5:90,User6:91,User7:92,User8:93,User9:94,User10:
95,User11:96,User12:97,User13:98,User14:99,User15:100,User16:101,User17:102,User18:
103,User19:104,KeyA:105,KeyB:106,KeyC:107,KeyD:108,KeyE:109,KeyF:110,KeyG:111,KeyH:
112,KeyI:113,KeyJ:114,KeyK:115,KeyL:116,KeyM:117,KeyN:118,KeyO:119,KeyP:120,KeyQ:
121,KeyR:122,KeyS:123,KeyT:124,KeyU:125,KeyV:126,KeyW:127,KeyX:128,KeyY:129,KeyZ:
130,Space:131,Plus:132,Minus:133,Multiply:134,Divide:135,Equals:136,Period:137,Comma:
138,Colon:139,Semicolon:140,AlphaKeys:141,AlphaOrDigitKeys:142,DigitKeys:143,HexDigitKeys:
144,CharacterKeys:145,ControlKeys:146,CursorKeys:147,AnyKey:148,Enter:149,Escape:
150,Backspace:151,Tab:152,CtrlKeyA:153,CtrlKeyB:154,CtrlKeyC:155,CtrlKeyD:156,CtrlKeyE:
157,CtrlKeyF:158,CtrlKeyG:159,CtrlKeyH:160,CtrlKeyI:161,CtrlKeyJ:162,CtrlKeyK:163
,CtrlKeyL:164,CtrlKeyM:165,CtrlKeyN:166,CtrlKeyO:167,CtrlKeyP:168,CtrlKeyQ:169,CtrlKeyR:
170,CtrlKeyS:171,CtrlKeyT:172,CtrlKeyU:173,CtrlKeyV:174,CtrlKeyW:175,CtrlKeyX:176
,CtrlKeyY:177,CtrlKeyZ:178,CtrlSpace:179,CtrlKey0:180,CtrlKey1:181,CtrlKey2:182,
CtrlKey3:183,CtrlKey4:184,CtrlKey5:185,CtrlKey6:186,CtrlKey7:187,CtrlKey8:188,CtrlKey9:
189,CtrlF1:190,CtrlF2:191,CtrlF3:192,CtrlF4:193,CtrlF5:194,CtrlF6:195,CtrlF7:196
,CtrlF8:197,CtrlF9:198,CtrlF10:199,CtrlEnter:200,CtrlEscape:201,CtrlUp:202,CtrlDown:
203,CtrlLeft:204,CtrlRight:205,CtrlPageUp:206,CtrlPageDown:207,CtrlBackspace:208
,CtrlInsert:209,CtrlDelete:210,CtrlHome:211,CtrlEnd:212,CtrlTab:213,CtrlShiftKeyA:
214,CtrlShiftKeyB:215,CtrlShiftKeyC:216,CtrlShiftKeyD:217,CtrlShiftKeyE:218,CtrlShiftKeyF:
219,CtrlShiftKeyG:220,CtrlShiftKeyH:221,CtrlShiftKeyI:222,CtrlShiftKeyJ:223,CtrlShiftKeyK:
224,CtrlShiftKeyL:225,CtrlShiftKeyM:226,CtrlShiftKeyN:227,CtrlShiftKeyO:228,CtrlShiftKeyP:
229,CtrlShiftKeyQ:230,CtrlShiftKeyR:231,CtrlShiftKeyS:232,CtrlShiftKeyT:233,CtrlShiftKeyU:
234,CtrlShiftKeyV:235,CtrlShiftKeyW:236,CtrlShiftKeyX:237,CtrlShiftKeyY:238,CtrlShiftKeyZ:
239,CtrlShiftSpace:240,CtrlShiftKey0:241,CtrlShiftKey1:242,CtrlShiftKey2:243,CtrlShiftKey3:
244,CtrlShiftKey4:245,CtrlShiftKey5:246,CtrlShiftKey6:247,CtrlShiftKey7:248,CtrlShiftKey8:
249,CtrlShiftKey9:250,CtrlShiftF1:251,CtrlShiftF2:252,CtrlShiftF3:253,CtrlShiftF4:
254,CtrlShiftF5:255,CtrlShiftF6:256,CtrlShiftF7:257,CtrlShiftF8:258,CtrlShiftF9:
259,CtrlShiftF10:260,CtrlShiftEnter:261,CtrlShiftEscape:262,CtrlShiftUp:263,CtrlShiftDown:
264,CtrlShiftLeft:265,CtrlShiftRight:266,CtrlShiftPageUp:267,CtrlShiftPageDown:268
,CtrlShiftBackspace:269,CtrlShiftInsert:270,CtrlShiftDelete:271,CtrlShiftHome:272
,CtrlShiftEnd:273,CtrlShiftTab:274,AltF1:275,AltF2:276,AltF3:277,AltF4:278,AltF5:
279,AltF6:280,AltF7:281,AltF8:282,AltF9:283,AltF10:284,AltEnter:285,AltEscape:286
,AltUp:287,AltDown:288,AltLeft:289,AltRight:290,AltPageUp:291,AltPageDown:292,AltBackspace:
293,AltInsert:294,AltDelete:295,AltHome:296,AltEnd:297,AltTab:298,AltShiftF1:299
,AltShiftF2:300,AltShiftF3:301,AltShiftF4:302,AltShiftF5:303,AltShiftF6:304,AltShiftF7:
305,AltShiftF8:306,AltShiftF9:307,AltShiftF10:308,AltShiftEnter:309,AltShiftEscape:
310,AltShiftUp:311,AltShiftDown:312,AltShiftLeft:313,AltShiftRight:314,AltShiftPageUp:
315,AltShiftPageDown:316,AltShiftBackspace:317,AltShiftInsert:318,AltShiftDelete:
319,AltShiftHome:320,AltShiftEnd:321,AltShiftTab:322,ShiftF1:323,ShiftF2:324,ShiftF3:
325,ShiftF4:326,ShiftF5:327,ShiftF6:328,ShiftF7:329,ShiftF8:330,ShiftF9:331,ShiftF10:
332,ShiftEnter:333,ShiftEscape:334,ShiftUp:335,ShiftDown:336,ShiftLeft:337,ShiftRight:
338,ShiftPageUp:339,ShiftPageDown:340,ShiftBackspace:341,ShiftInsert:342,ShiftDelete:
343,ShiftHome:344,ShiftEnd:345,ShiftTab:346};D.JW={Kg:0x1,Kd:0x2,Ke:0x4,Kf:0x8,JM:
0x10,JH:0x20};
D._Init=function(){D.AN.__proto__=D.BR;D.Ac.__proto__=D.AN;D.Root.__proto__=D.Ac;
D.KeyEvent.__proto__=D.Event;D.Fv.__proto__=D.Event;D.Fu.__proto__=D.Event;D.Fw.
__proto__=D.Event;D.D6.__proto__=D.AN;};D.An=function(E){};return D;})();

/* Embedded Wizard */