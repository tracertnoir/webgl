/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.Core)throw new Error("The unit file 'Core.js' included twice!");EmWiApp.
Core=(function(){var A=EmWiApp;var E={};
var Ac=[0,0];var Au=[0,0,0,0];var Cr="The view does not belong to this group";var
Fo="No view to restack";var C6="View is not in this group";var Hl="No view to remove";
var Hm="No view to add";var Hn="View already in a group";var Ho="Recursive invalidate during active update cycle.";
var Hp="The KeyPressHandler is embedded within an object not being derived "+"from Core::Group.";
E.Ch={U:null,P:null,L:null,AJ:null,F:0x103,BH:0,AK:0x14,Gy:function(Ad,I8){},JJ:function(
C){if(this.BH===C)return;this.BH=C;if(!!this.L){var CR=this.U;var A5=0;while(!!CR&&(
C>CR.BH)){CR=CR.U;A5=A5+1;}CR=this.P;while(!!CR&&(C<CR.BH)){CR=CR.P;A5=A5-1;}if(
!!A5)this.L.JO(this,A5);}},Fb:function(C){var B;var A5=C^this.AK;if(!A5)return;this.
AK=C;if(!!this.AJ&&!((this.F&0x400)===0x400)){this.L.F=this.L.F|0x5000;A.lq([B=this.
L,B.Bl],this);this.L.AN([0,0,(B=this.L.N)[2]-B[0],B[3]-B[1]]);}if(!!this.AJ&&((this.
F&0x400)===0x400)){this.AJ.EU.F=this.AJ.EU.F|0x1000;this.L.F=this.L.F|0x4000;A.lq([
B=this.L,B.Bl],this);}},BU:function(AA,aClip,aOffset,AG,aBlend){},AU:function(W){
return null;},Do:function(Ae,K,Bw,Hq,Hv){return null;},GO:function(Ad,Dy){return Ac;
},Ia:function(aOffset,I7){},GetExtent:function(){return Au;},A3:function(CK,Dx){
var B;if(((this.F&0x200)===0x200))CK=CK&~0x400;var HN=(this.F&~Dx)|CK;var C$=HN^
this.F;this.F=HN;if(!!this.L&&!!(C$&0x14)){var Je=((this.F&0x14)===0x14);if(Je&&
!this.L.Bs)this.L.Ef(this);if(!Je&&(this.L.Bs===this))this.L.Ef(this.L.H6(this,0x14
));}if(!!this.L&&!!(C$&0x403))this.L.AN(this.GetExtent());if(((!!this.AJ&&!!this.
L)&&((HN&0x400)===0x400))&&((C$&0x1)===0x1)){this.F=this.F|0x800;this.L.F=this.L.
F|0x4000;A.lq([B=this.L,B.Bl],this);}if(!!this.L&&((C$&0x400)===0x400)){this.AJ=
null;this.F=this.F|0x800;this.L.F=this.L.F|0x4000;A.lq([B=this.L,B.Bl],this);}},
_Init:function(aArg){this.__proto__=E.Ch;A.gv++;},_Done:function(){this.__proto__=
null;A.gv--;},_ReInit:function(){},_Mark:function(D){var B;if((B=this.U)&&(B._cycle
!=D))B._Mark(B._cycle=D);if((B=this.P)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=
this.L)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.AJ)&&(B._cycle!=D))B._Mark(
B._cycle=D);if((B=this.M)&&(B._cycle!=D))B._Mark(B._cycle=D);},M:null,_cycle:0,_observers:
null,_className:"Core::View"};E.AV={N:A.qy,Gy:function(Ad,I8){var AQ=A._NewObject(
E.H_,0);AQ.Dc=this.N;AQ.Aq=Ad;AQ.EU=I8;this.AJ=AQ;},GO:function(Ad,Dy){var B;var
BO=this.AK;var AQ=this.AJ;var As=AQ.Dc[0];var At=AQ.Dc[1];var Ah=AQ.Dc[2];var Ai=
AQ.Dc[3];var Db=[Ad[2]-Ad[0],Ad[3]-Ad[1]];var Be=Ah-As;var Bc=Ai-At;if(!Dy){var EX=[(
B=AQ.Aq)[2]-B[0],B[3]-B[1]];As=As-AQ.Aq[0];At=At-AQ.Aq[1];if(EX[0]!==Db[0]){var Ct=((
BO&0x4)===0x4);var Cu=((BO&0x8)===0x8);var FH=((BO&0x1)===0x1);if(!Ct&&(FH||!Cu)
)As=((As*Db[0])/EX[0])|0;if(!Cu&&(FH||!Ct)){Ah=Ah-AQ.Aq[0];Ah=((Ah*Db[0])/EX[0])|
0;Ah=Ah-Db[0];}else Ah=Ah-AQ.Aq[2];As=As+Ad[0];Ah=Ah+Ad[2];if(!FH){if(Ct&&!Cu)Ah=
As+Be;else if(!Ct&&Cu)As=Ah-Be;else{As=As+((((Ah-As)-Be)/2)|0);Ah=As+Be;}}}else{
Ah=Ah-AQ.Aq[2];As=As+Ad[0];Ah=Ah+Ad[2];}if(EX[1]!==Db[1]){var Cv=((BO&0x10)===0x10
);var Cs=((BO&0x20)===0x20);var FI=((BO&0x2)===0x2);if(!Cv&&(FI||!Cs))At=((At*Db[
1])/EX[1])|0;if(!Cs&&(FI||!Cv)){Ai=Ai-AQ.Aq[1];Ai=((Ai*Db[1])/EX[1])|0;Ai=Ai-Db[
1];}else Ai=Ai-AQ.Aq[3];At=At+Ad[1];Ai=Ai+Ad[3];if(!FI){if(Cv&&!Cs)Ai=At+Bc;else
if(!Cv&&Cs)At=Ai-Bc;else{At=At+((((Ai-At)-Bc)/2)|0);Ai=At+Bc;}}}else{Ai=Ai-AQ.Aq[
3];At=At+Ad[1];Ai=Ai+Ad[3];}}else{switch(Dy){case 3:{As=Ad[0];Ah=As+Be;}break;case
4:{Ah=Ad[2];As=Ah-Be;}break;case 1:{At=Ad[1];Ai=At+Bc;}break;case 2:{Ai=Ad[3];At=
Ai-Bc;}break;default:;}if((Dy===3)||(Dy===4)){var Cv=((BO&0x10)===0x10);var Cs=((
BO&0x20)===0x20);var FI=((BO&0x2)===0x2);if(FI){At=Ad[1];Ai=Ad[3];}else if(Cv&&!
Cs){At=Ad[1];Ai=At+Bc;}else if(Cs&&!Cv){Ai=Ad[3];At=Ai-Bc;}else{At=Ad[1]+((((Ad[
3]-Ad[1])-Bc)/2)|0);Ai=At+Bc;}}if((Dy===1)||(Dy===2)){var Ct=((BO&0x4)===0x4);var
Cu=((BO&0x8)===0x8);var FH=((BO&0x1)===0x1);if(FH){As=Ad[0];Ah=Ad[2];}else if(Ct&&
!Cu){As=Ad[0];Ah=As+Be;}else if(Cu&&!Ct){Ah=Ad[2];As=Ah-Be;}else{As=Ad[0]+((((Ad[
2]-Ad[0])-Be)/2)|0);Ah=As+Be;}}}AQ.isEmpty=(As>=Ah)||(At>=Ai);if(((this.F&0x100)===
0x100)){this.N=[As,At,Ah,Ai];}else{this.O([As,At,Ah,Ai]);this.AJ=AQ;}return[Ah-As
,Ai-At];},Ia:function(aOffset,I7){if(I7)this.N=A.tz(this.N,aOffset);else this.O(
A.tz(this.N,aOffset));},GetExtent:function(){return this.N;},O:function(C){var B;
if(A.tm(C,this.N))return;if(!!this.L&&((this.F&0x1)===0x1))this.L.AN(this.N);this.
AJ=null;this.N=C;if(!!this.L&&((this.F&0x1)===0x1))this.L.AN(this.N);if((!!this.
L&&((this.F&0x400)===0x400))&&!((this.L.F&0x2000)===0x2000)){this.F=this.F|0x800;
this.L.F=this.L.F|0x4000;A.lq([B=this.L,B.Bl],this);}},_Init:function(aArg){E.Ch.
_Init.call(this,aArg);this.__proto__=E.AV;},_className:"Core::RectView"};E.Z={Ba:
null,AS:null,GA:null,Bq:null,Da:null,DE:null,Bs:null,Gc:255,BU:function(AA,aClip
,aOffset,AG,aBlend){var B;AG=((AG+1)*this.Gc)>>8;aBlend=aBlend&&((this.F&0x2)===
0x2);if(!this.Bq)this.LG(AA,aClip,A.tx(aOffset,this.N.slice(0,2)),AG,aBlend);else{
var A4=255|(255<<8)|(255<<16)|((AG&0xFF)<<24);this.Bq.Update();AA.Js(aClip,this.
Bq,0,A.tz(this.N,aOffset),Ac,A4,A4,A4,A4,aBlend);}},Do:function(Ae,K,Bw,Hq,Hv){var
B;var G=this.AS;var DF=null;var T=Au;var Ay=null;var HM=!!this.DE&&(!!this.DE.HB||
!!this.DE.Ba);if(((B=A.il(Ae,this.N))[0]>=B[2])||(B[1]>=B[3]))return null;Ae=A.ty(
Ae,this.N.slice(0,2));while(!!G){if(((G.F&0x400)===0x400)&&!Ay){Ay=G.P;while(!!Ay&&
!((Ay.F&0x200)===0x200))Ay=Ay.P;if(!!Ay)T=A.il(Ae,Ay.GetExtent());else T=Au;}if(
Ay===G){Ay=null;T=Au;}if((((((G.F&0x8)===0x8)&&((G.F&0x10)===0x10))&&!((G.F&0x40000
)===0x40000))&&!((G.F&0x20000)===0x20000))&&(!((G.F&0x10000)===0x10000)||((this.
Da.Bb===G)&&!HM))){var Dc=G.GetExtent();var Gu=Hq;var DD=null;if(Gu===G)Gu=null;
if(((G.F&0x400)===0x400)){if(!(((B=A.il(Dc,T))[0]>=B[2])||(B[1]>=B[3])))DD=G.Do(
T,K,Bw,Gu,Hv);}else{if(!(((B=A.il(Dc,Ae))[0]>=B[2])||(B[1]>=B[3]))||(Hq===G))DD=
G.Do(Ae,K,Bw,Gu,Hv);}G=G.P;if(!!DD){if(!DF||((DD.FS<DF.FS)&&(DD.FS>=0)))DF=DD;if(
!DD.FS)G=null;}}else G=G.P;}return DF;},A3:function(CK,Dx){var B;var LI=this.F;E.
AV.A3.call(this,CK,Dx);var C$=this.F^LI;if(!!this.Bs&&((C$&0x40)===0x40)){if(((this.
F&0x40)===0x40))this.Bs.A3(0x40,0x0);else this.Bs.A3(0x0,0x40);}if(!!this.Da&&((
C$&0x40)===0x40)){if(((this.F&0x40)===0x40)&&((this.Da.Bb.F&0x14)===0x14))this.Da.
Bb.A3(0x40,0x0);else this.Da.Bb.A3(0x0,0x40);}if(!!C$){this.F=this.F|0x8000;A.lq([
this,this.Bl],this);}},O:function(C){var B;if(A.tm(C,this.N))return;var Dh=[(B=this.
N)[2]-B[0],B[3]-B[1]];var GE=[C[2]-C[0],C[3]-C[1]];var DJ=!A.tl(Dh,GE);if(DJ&&!!
this.Bq){this.Bq.G9(GE);A.qw(this,0);A.qw(this.Bq,0);}E.AV.O.call(this,C);if((DJ&&(
Dh[0]>0))&&(Dh[1]>0)){var Aq=[].concat(Ac,Dh);var G=this.Ba;var Fz=0x14;while(!!
G){if((!G.AJ&&(G.AK!==Fz))&&!((G.F&0x400)===0x400))G.Gy(Aq,null);G=G.U;}}if(DJ){
this.F=this.F|0x5000;A.lq([this,this.Bl],this);}},HT:function(W){var Jg=(E.KeyEvent.
isPrototypeOf(W)?W:null);var BN=this.GA;if(!Jg)return null;while(!!BN&&(!BN.DP||
!BN.AU(Jg)))BN=BN.U;return BN;},LG:function(AA,aClip,aOffset,AG,aBlend){var B;var
G=this.Ba;var Jc=Au;var Jm=true;while(!!G){if(((G.F&0x200)===0x200)){var Jl=(E.Fc.
isPrototypeOf(G)?G:null);Jc=A.il(aClip,A.tz(Jl.N,aOffset));Jm=((Jl.F&0x1)===0x1);
}if(((G.F&0x1)===0x1)){if(((G.F&0x400)===0x400)){if(Jm){var T=A.il(A.tz(G.GetExtent(
),aOffset),Jc);if(!((T[0]>=T[2])||(T[1]>=T[3])))G.BU(AA,T,aOffset,AG,aBlend);}}else{
var T=A.il(A.tz(G.GetExtent(),aOffset),aClip);if(!((T[0]>=T[2])||(T[1]>=T[3])))G.
BU(AA,T,aOffset,AG,aBlend);}}G=G.U;}},LK:function(){var B;var HH=((this.F&0x1000
)===0x1000);var CN=[0,0,(B=this.N)[2]-B[0],B[3]-B[1]];var BL=false;var Cl=Au;var
AH=Au;var BM=Ac;var ER=0;var ES=0;var EQ=0;var A6=0;var G=this.AS;var Ay=null;var
Fz=0x14;var De=null;while(!!G){if(((G.F&0x800)===0x800)){BL=true;G.F=G.F&~0x800;
}if(BL&&((G.F&0x200)===0x200)){BL=false;if(!!(E.Fc.isPrototypeOf(G)?G:null).FV)G.
F=G.F|0x1000;}G=G.P;}BL=false;G=this.Ba;if(HH){this.F=this.F&~0x1000;HH=!((CN[0]>=
CN[2])||(CN[1]>=CN[3]));}this.F=this.F|0x2000;while(!!G){if(!De&&(EQ!==A6)){var Cp=
G;var GH=0;var FL=Cl[2]-Cl[0];var Fu=Cl[3]-Cl[1];var Gr=0;var DM=Ac;do{if(((Cp.F&
0x200)===0x200))Cp=null;else if(((Cp.F&0x401)===0x401)){DM=[(B=Cp.GetExtent())[2
]-B[0],B[3]-B[1]];if((A6===3)||(A6===4))FL=FL-DM[0];if((A6===1)||(A6===2))Fu=Fu-
DM[1];if(!De||((FL>=0)&&(Fu>=0))){De=Cp;Cp=Cp.U;if((A6===3)||(A6===4)){FL=FL-ER;
if(DM[1]>GH)GH=DM[1];}if((A6===1)||(A6===2)){Fu=Fu-ES;if(DM[0]>Gr)Gr=DM[0];}}else
Cp=null;}else Cp=Cp.U;}while(!!Cp);if(!De)De=Ay;AH=Cl;switch(EQ){case 9:case 11:
AH=[].concat(AH.slice(0,3),AH[1]+GH);break;case 10:case 12:AH=A.t3(AH,AH[3]-GH);
break;case 5:case 7:AH=A.t1(AH,AH[0]+Gr);break;case 6:case 8:AH=[].concat(AH[2]-
Gr,AH.slice(1,4));break;default:;}}if(((G.F&0x400)===0x400)){if(!!G.AJ&&(G.AJ.EU
!==Ay))G.AJ=null;if((!G.AJ&&BL)&&((G.AK!==Fz)||!!A6))G.Gy(AH,Ay);}if(!!G.AJ){if(
HH&&!((G.F&0x400)===0x400))G.GO(CN,0);if(BL&&((G.F&0x400)===0x400)){var GK=G.GO(
A.tz(AH,BM),A6);if(((G.F&0x1)===0x1)){var Bk=Ac;switch(A6){case 3:Bk=[GK[0]+ER,Bk[
1]];break;case 4:Bk=[-GK[0]-ER,Bk[1]];break;case 1:Bk=[Bk[0],GK[1]+ES];break;case
2:Bk=[Bk[0],-GK[1]-ES];break;default:;}BM=A.tx(BM,Bk);}}}if(((G.F&0x200)===0x200
)){if(BL)A.lq(Ay.Cq,Ay);BL=((G.F&0x1000)===0x1000);Ay=(E.Fc.isPrototypeOf(G)?G:null
);if(BL){G.F=G.F&~0x1000;Cl=A.tz(Ay.N,Ay.Ff);AH=Cl;BM=Ac;EQ=Ay.FV;A6=EQ;ER=Ay.Space+
Ay.JQ;ES=Ay.Space+Ay.JS;BL=!((Cl[0]>=Cl[2])||(Cl[1]>=Cl[3]));De=null;switch(EQ){
case 9:case 10:A6=3;break;case 11:case 12:A6=4;break;case 5:case 6:A6=1;break;case
7:case 8:A6=2;break;default:;}}if(BL){this.AN(Ay.N);}}if(G===De){switch(EQ){case
9:case 11:BM=[0,(BM[1]+(AH[3]-AH[1]))+ES];break;case 10:case 12:BM=[0,(BM[1]-(AH[
3]-AH[1]))-ES];break;case 5:case 7:BM=[(BM[0]+(AH[2]-AH[0]))+ER,0];break;case 6:
case 8:BM=[(BM[0]-(AH[2]-AH[0]))-ER,0];break;default:;}De=null;}G=G.U;}if(BL)A.lq(
Ay.Cq,Ay);this.F=this.F&~0x2000;this.Gf([CN[2]-CN[0],CN[3]-CN[1]]);},Bl:function(
Cn){var B;var LM=((this.F&0x1000)===0x1000);if(((this.F&0x4000)===0x4000)){this.
F=this.F&~0x4000;this.LK();}if(((this.F&0x8000)===0x8000)||LM){this.F=this.F&~0x8000;
this.Fm(this.F);}},Ef:function(C){var B;if(!!C&&(C.L!==this))throw new Error(Cr);
if(!!C&&!((C.F&0x14)===0x14))C=null;if(!!C&&((C.F&0x10000)===0x10000))C=null;if(
C===this.Bs)return;if(!!this.Bs)this.Bs.A3(0x0,0x60);this.Bs=C;if(!!C){if(((this.
F&0x40)===0x40))C.A3(0x60,0x0);else C.A3(0x20,0x0);}},H$:function(Hu){var tmp=this;
while(!!tmp){Hu=A.tw(Hu,tmp.N.slice(0,2));tmp=tmp.L;}return Hu;},DispatchEvent:function(
W){var B;var G=this.Bs;var S=(E.Z.isPrototypeOf(G)?G:null);var X=null;var HM=!!this.
DE&&(!!this.DE.HB||!!this.DE.Ba);if(!!G&&((((G.F&0x10000)===0x10000)||((G.F&0x40000
)===0x40000))||((G.F&0x20000)===0x20000))){G=null;S=null;}if(!!this.Da&&!HM)X=this.
Da.Bb.DispatchEvent(W);if(!X&&!!S)X=S.DispatchEvent(W);else if(!X&&!!G)X=G.AU(W);
if(!X)X=this.AU(W);if(!X)X=this.HT(W);return X;},BroadcastEventAtPosition:function(
W,I9,Bh){var B;var G=this.AS;var X=null;while(!!G&&!X){if((!Bh||((B=Bh)&&((G.F&B
)===B)))&&A.qu(G.GetExtent(),I9)){var S=(E.Z.isPrototypeOf(G)?G:null);if(!!S)X=S.
BroadcastEventAtPosition(W,A.tw(I9,S.N.slice(0,2)),Bh);else X=G.AU(W);}G=G.P;}if(
!X)X=this.AU(W);return X;},BroadcastEvent:function(W,Bh){var B;var G=this.AS;var
X=null;while(!!G&&!X){if(!Bh||((B=Bh)&&((G.F&B)===B))){var S=(E.Z.isPrototypeOf(
G)?G:null);if(!!S)X=S.BroadcastEvent(W,Bh);else X=G.AU(W);}G=G.P;}if(!X)X=this.AU(
W);if(!X)X=this.HT(W);return X;},Gf:function(aSize){},Fm:function(Gn){},Dr:function(
){this.F=this.F|0x8000;A.lq([this,this.Bl],this);},AN:function(Ae){var B;var S=this;
while(!!S&&!((Ae[0]>=Ae[2])||(Ae[1]>=Ae[3]))){var Dz=S.Bq;if(!S.L&&(S!==this)){S.
AN(Ae);return;}if(!!Dz){var HG=false;var LH=Dz.BD;if(HG)Dz.BD=[0,0,(B=S.N)[2]-B[
0],B[3]-B[1]];else Dz.BD=A.qR(Dz.BD,Ae);if(!A.tm(LH,Dz.BD)){A.qw(S,0);A.qw(Dz,0);
}}if(!((S.F&0x1)===0x1))return;Ae=A.il(A.tz(Ae,S.N.slice(0,2)),S.N);S=S.L;}},Bf:
function(aArg){this.Dr();},H6:function(J,Bh){var B;if(!J||(J.L!==this))return null;
var Dg=J.U;var Dj=J.P;var FE=0x10000;if(((Bh&0x10000)===0x10000))FE=0x0;while(!!
Dg||!!Dj){if((!!Dg&&(!Bh||((B=Bh)&&((Dg.F&B)===B))))&&(!FE||!((B=FE)&&((Dg.F&B)===
B))))return Dg;if((!!Dj&&(!Bh||((B=Bh)&&((Dj.F&B)===B))))&&(!FE||!((B=FE)&&((Dj.
F&B)===B))))return Dj;if(!!Dg)Dg=Dg.U;if(!!Dj)Dj=Dj.P;}return null;},JO:function(
J,Bv){var B;if(!J)throw new Error(Fo);if(J.L!==this)throw new Error(C6);var CL=J;
var Ax=J;var DK=J.BH;while(((Bv>0)&&!!CL.U)&&(CL.U.BH<=DK)){CL=CL.U;Bv=Bv-1;}while(((
Bv<0)&&!!Ax.P)&&(Ax.P.BH>=DK)){Ax=Ax.P;Bv=Bv+1;}if((CL===J)&&(Ax===J))return;if(((
J.F&0x401)===0x401)){if(!!J.P&&!!J.AJ)J.P.F=J.P.F|0x800;J.F=J.F|0x800;this.F=this.
F|0x4000;A.lq([this,this.Bl],this);}if(((J.F&0x200)===0x200)){if(!!J.P)J.P.F=J.P.
F|0x800;J.F=J.F|0x800;this.F=this.F|0x4000;A.lq([this,this.Bl],this);}if(!!J.P)J.
P.U=J.U;if(!!J.U)J.U.P=J.P;if(this.Ba===J)this.Ba=J.U;if(this.AS===J)this.AS=J.P;
if(CL!==J){J.U=CL.U;J.P=CL;CL.U=J;if(!!J.U)J.U.P=J;}if(Ax!==J){J.U=Ax;J.P=Ax.P;Ax.
P=J;if(!!J.P)J.P.U=J;}if(!J.U)this.AS=J;if(!J.P)this.Ba=J;if(((J.F&0x1)===0x1))this.
AN(J.GetExtent());},IX:function(J){var B;if(!J)throw new Error(Hl);if(J.L!==this
)throw new Error(C6);if((((J.F&0x401)===0x401)&&!!J.P)&&!!J.AJ){J.P.F=J.P.F|0x800;
this.F=this.F|0x4000;A.lq([this,this.Bl],this);}if(((J.F&0x200)===0x200)){if(!!J.
P)J.P.F=J.P.F|0x800;this.F=this.F|0x4000;A.lq([this,this.Bl],this);}J.AJ=null;if(
this.Bs===J)this.Ef(this.H6(J,0x14));if(!!J.P)J.P.U=J.U;if(!!J.U)J.U.P=J.P;if(this.
Ba===J)this.Ba=J.U;if(this.AS===J)this.AS=J.P;J.L=null;J.U=null;J.P=null;if(((J.
F&0x1)===0x1))this.AN(J.GetExtent());},V:function(J,Bv){var B;if(!J)throw new Error(
Hm);if(!!J.L)throw new Error(Hn);var Ax=null;var DK=J.BH;if(((Bv<0)&&!!this.AS)&&(
this.AS.BH>=DK)){Ax=this.AS;Bv=Bv+1;}while((((Bv<0)&&!!Ax)&&!!Ax.P)&&(Ax.P.BH>=DK
)){Ax=Ax.P;Bv=Bv+1;}if((!Ax&&!!this.AS)&&(this.AS.BH>DK))Ax=this.AS;while((!!Ax&&
!!Ax.P)&&(Ax.P.BH>DK))Ax=Ax.P;if(!Ax){J.L=this;J.P=this.AS;if(!!this.AS)this.AS.
U=J;if(!this.Ba)this.Ba=J;this.AS=J;}else{J.L=this;J.P=Ax.P;J.U=Ax;Ax.P=J;if(!!J.
P)J.P.U=J;else this.Ba=J;}if(((J.F&0x1)===0x1))this.AN(J.GetExtent());if(((!this.
Bs&&((J.F&0x4)===0x4))&&((J.F&0x10)===0x10))&&!((J.F&0x10000)===0x10000))this.Ef(
J);if(((J.F&0x401)===0x401)){J.F=J.F|0x800;this.F=this.F|0x4000;A.lq([this,this.
Bl],this);}if(((J.F&0x200)===0x200)){J.F=J.F|0x800;this.F=this.F|0x4000;A.lq([this
,this.Bl],this);}},_Init:function(aArg){E.AV._Init.call(this,aArg);this.__proto__=
E.Z;this.F=0x1F;this.Bf(aArg);},_Mark:function(D){var B;E.AV._Mark.call(this,D);
if((B=this.Ba)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.AS)&&(B._cycle!=D))
B._Mark(B._cycle=D);if((B=this.GA)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.
Bq)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.Da)&&(B._cycle!=D))B._Mark(B._cycle=
D);if((B=this.DE)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.Bs)&&(B._cycle!=
D))B._Mark(B._cycle=D);},_className:"Core::Group"};E.Root={A9:null,CP:null,Cj:null
,AL:A.tA(10,null,null),EP:null,Bu:null,CM:null,FO:0,Hx:0,Af:0,AX:A.tA(10,0,null)
,Gt:A.tA(10,A.qy,null),Ck:A.tA(10,0,null),C_:A.tA(10,A.qx,null),Fw:A.tA(10,0,null
),DB:A.tA(10,A.qx,null),CA:A.tA(10,A.qx,null),CB:A.tA(10,A.qx,null),C9:A.tA(10,A.
qx,null),DC:0,Gx:0,Gw:0,GC:A.tA(3,A.qy,null),Jj:0,AZ:A.tA(4,0,null),AF:A.tA(4,A.
qy,null),AB:0,FR:8,Ju:250,Dd:0,CO:0,HI:true,GB:false,BU:function(AA,aClip,aOffset
,AG,aBlend){var fullScreenUpdate=false;fullScreenUpdate=A.jI;if(!fullScreenUpdate
)AA.FT(aClip,A.tz(A.tz(aClip,aOffset),this.N.slice(0,2)),0x00000000,0x00000000,0x00000000
,0x00000000,false);E.Z.BU.call(this,AA,aClip,aOffset,AG,aBlend);},A3:function(CK
,Dx){var B;E.Z.A3.call(this,CK,Dx);if(!this.L&&(((CK&0x1)===0x1)||((Dx&0x1)===0x1
)))this.AN([0,0,(B=this.N)[2]-B[0],B[3]-B[1]]);if(!this.L&&(((CK&0x2)===0x2)||((
Dx&0x2)===0x2)))this.AN([0,0,(B=this.N)[2]-B[0],B[3]-B[1]]);},Ef:function(C){if((
C!==this.Bu)||!C)E.Z.Ef.call(this,C);},DispatchEvent:function(W){if((this.Hx>0)&&
!!(E.KeyEvent.isPrototypeOf(W)?W:null))return null;if(!!W){W.E_=!!this.Af;if(!!this.
Af)W.Bt=this.Af;}var X=null;if(!!this.Bu){X=this.Bu.DispatchEvent(W);if(!!X){this.
Af=0;return X;}}if(!!this.CP){X=this.CP.Bb.DispatchEvent(W);if(!X)X=this.AU(W);if(
!X)X=this.HT(W);this.Af=0;return X;}X=E.Z.DispatchEvent.call(this,W);this.Af=0;return X;
},BroadcastEvent:function(W,Bh){if(!!W){W.E_=!!this.Af;if(!!this.Af)W.Bt=this.Af;
}var X=E.Z.BroadcastEvent.call(this,W,Bh);this.Af=0;return X;},AN:function(Ae){var
B;if(this.FO>0)throw new Error(Ho);if(!!this.Bq&&!this.L){if(((B=this.Bq.BD)[0]>=
B[2])||(B[1]>=B[3])){A.qw(this,0);A.qw(this.Bq,0);}var HG=false;if(HG)this.Bq.BD=[
0,0,(B=this.N)[2]-B[0],B[3]-B[1]];else this.Bq.BD=A.qR(this.Bq.BD,Ae);}var fullScreenUpdate=
false;fullScreenUpdate=A.jI;if(fullScreenUpdate)Ae=[0,0,(B=this.N)[2]-B[0],B[3]-
B[1]];if(!!this.L){E.Z.AN.call(this,Ae);return;}Ae=A.il(A.tz(Ae,this.N.slice(0,2
)),this.N);if((Ae[0]>=Ae[2])||(Ae[1]>=Ae[3]))return;var I;for(I=0;I<this.AB;I=I+
1)if(!(((B=A.il(this.AF.Get(I),Ae))[0]>=B[2])||(B[1]>=B[3]))){this.AF.Set(I,A.qR(
this.AF.Get(I),Ae));this.AZ.Set(I,A.s9(this.AF.Get(I)));return;}if(this.AB<3){this.
AF.Set(this.AB,Ae);this.AZ.Set(this.AB,A.s9(Ae));this.AB=this.AB+1;return;}var Ar;
var A8;var FA=0;var FB=0;var I$=2147483647;this.AF.Set(this.AB,Ae);this.AZ.Set(this.
AB,A.s9(Ae));for(Ar=0;Ar<=this.AB;Ar=Ar+1)for(A8=Ar+1;A8<=this.AB;A8=A8+1){var GL=
A.s9(A.qR(this.AF.Get(Ar),this.AF.Get(A8)));var Jn=((GL<<8)/(this.AZ.Get(Ar)+this.
AZ.Get(A8)))|0;if(Jn<I$){I$=Jn;FA=Ar;FB=A8;}}this.AF.Set(FA,A.qR(this.AF.Get(FA)
,this.AF.Get(FB)));this.AZ.Set(FA,A.s9(this.AF.Get(FA)));if(FB!==this.AB){this.AF.
Set(FB,this.AF.Get(this.AB));this.AZ.Set(FB,this.AZ.Get(this.AB));}},LE:function(
){var AP=A._NewObject(E.GW,0);AP.E_=!!this.Af;if(!!this.Af)AP.Bt=this.Af;return AP;
},Fv:function(){var AP=A._NewObject(E.GU,0);AP.E_=!!this.Af;if(!!this.Af)AP.Bt=this.
Af;return AP;},Gs:function(){var AP=A._NewObject(E.GV,0);AP.E_=!!this.Af;if(!!this.
Af)AP.Bt=this.Af;return AP;},LF:function(Cn){var I;var DF=false;for(I=0;I<10;I=I+
1)if(!!this.AL.Get(I)){var AY=this.CB.Get(I);var S=this.AL.Get(I).L;while(!!S&&(
S!==this)){AY=A.tw(AY,S.N.slice(0,2));S=S.L;}if(!S&&(this.AL.Get(I)!==this)){var
tmp=this.AL.Get(I);this.DC=I;this.AL.Set(I,null);tmp.AU(this.Fv().InitializeUp(I
,this.DB.Get(I),this.C_.Get(I),this.Ck.Get(I),this.AX.Get(I)+1,this.CA.Get(I),false
,this.CB.Get(I),this.C9.Get(I)));if(tmp===this.Cj)this.Cj=null;this.BroadcastEvent(
this.Gs().InitializeUp(I,this.AX.Get(I)+1,false,tmp,this.CB.Get(I)),0x18);}else{
this.Ck.Set(I,(this.CM.Bt-this.Fw.Get(I))|0);if(this.Ck.Get(I)<10)this.Ck.Set(I,
10);this.DC=I;this.AL.Get(I).AU(this.Fv().InitializeHold(I,AY,this.C_.Get(I),this.
Ck.Get(I),this.AX.Get(I)+1,this.CA.Get(I),this.CB.Get(I),this.C9.Get(I)));DF=true;
}}if(!DF)this.CM.F_(false);},GetFPS:function(){var ticksCount=0;var Jf=0;ticksCount=((
new Date).getTime()-A.qt)|0;if(!!this.Gx&&(ticksCount>this.Gx))Jf=((this.Gw*1000
)/((ticksCount-this.Gx)|0))|0;this.Gw=0;this.Gx=ticksCount;return Jf;},Update:function(
){var B;if(!this.EP){this.EP=A._NewObject(A.Graphics.Canvas,0);this.EP.G9([(B=this.
N)[2]-B[0],B[3]-B[1]]);}this.EP.Update();return this.UpdateGE20(this.EP);},UpdateGE20:
function(AA){if(!this.BeginUpdate())return Au;var CE=this.UpdateCanvas(AA,Ac);this.
EndUpdate();return CE;},EndUpdate:function(){if(this.AB>0){this.Gw=this.Gw+1;this.
AB=0;}},UpdateCanvas:function(AA,aOffset){var B;var CE=Au;var LC=[].concat(aOffset
,A.tx(AA.FrameSize,aOffset));var I;var Ar=this.AB;this.FO=this.FO+1;for(I=0;(I<Ar
)&&(I<4);I=I+1){if(this.AZ.Get(I)>0){this.BU(AA,A.ty(this.AF.Get(I),aOffset),[-aOffset[
0],-aOffset[1]],255,true);CE=A.qR(CE,A.il(LC,this.AF.Get(I)));}else Ar=Ar+1;}this.
FO=this.FO-1;if(!((CE[0]>=CE[2])||(CE[1]>=CE[3])))return A.ty(CE,aOffset);else return CE;
},GetUpdateRegion:function(Gm){var I;var Ar=this.AB;if(Gm<0)return Au;for(I=0;(I<
Ar)&&(I<4);I=I+1){if(!this.AZ.Get(I)){Ar=Ar+1;Gm=Gm+1;}else if(I===Gm)return this.
AF.Get(I);}return Au;},BeginUpdate:function(){var LJ=true;var fullScreenUpdate=false;
var I;if((!LJ&&!fullScreenUpdate)&&(this.AB>0)){var Jq=A.tA(3,A.qy,null);var HY=
this.AB;for(I=0;I<HY;I=I+1)Jq.Set(I,this.AF.Get(I));for(I=0;I<this.Jj;I=I+1)this.
AN(this.GC.Get(I));for(I=0;I<HY;I=I+1)this.GC.Set(I,Jq.Get(I));this.Jj=HY;}var Ar;
var A8;for(Ar=0;Ar<(this.AB-1);Ar=Ar+1)if(this.AZ.Get(Ar)>0)for(A8=Ar+1;A8<this.
AB;A8=A8+1)if(this.AZ.Get(A8)>0){var GL=A.s9(A.qR(this.AF.Get(Ar),this.AF.Get(A8
)));if(((GL-this.AZ.Get(Ar))-this.AZ.Get(A8))<0){this.AF.Set(Ar,A.qR(this.AF.Get(
Ar),this.AF.Get(A8)));this.AZ.Set(Ar,GL);this.AZ.Set(A8,0);}}for(I=this.AB-1;I>=
0;I=I-1)if(!this.AZ.Get(I))this.AB=this.AB-1;return this.AB;},DoesNeedUpdate:function(
){if(this.AB>0)return true;return false;},Initialize:function(aSize){this.O([].concat(
Ac,aSize));if(this.HI)this.F=this.F|0x60;else this.F=this.F|0x20;this.AN(this.N);
return this;},SetRootFocus:function(Hs){if(Hs===this.HI)return false;this.HI=Hs;
if(!Hs){if(!!this.Bu)this.Bu.A3(0x0,0x40);if(!!this.CP)this.CP.Bb.A3(0x0,0x40);else
this.A3(0x0,0x40);}else{if(!!this.CP)this.CP.Bb.A3(0x40,0x0);else this.A3(0x40,0x0
);if(!!this.Bu)this.Bu.A3(0x40,0x0);}return true;},SetUserInputTimestamp:function(
LB){this.Af=LB;},DriveKeyboardHitting:function(Aw,Dw,Bp){var B;var HU=!!this.A9;
if(!!this.A9&&((!Bp||(this.Dd!==Aw))||(this.CO!==Dw))){var AP=null;var G=(E.Ch.isPrototypeOf(
B=this.A9)?B:null);var BN=(E.FY.isPrototypeOf(B=this.A9)?B:null);if(!!this.Dd)AP=
A._NewObject(E.KeyEvent,0).Initialize(this.Dd,false);if(this.CO!==0x00)AP=A._NewObject(
E.KeyEvent,0).Initialize2(this.CO,false);if(!!BN)BN.AU(AP);else if(!!G)G.AU(AP);
this.Dd=0;this.CO=0x00;this.A9=null;}if(!!this.A9){var AP=null;var G=(E.Ch.isPrototypeOf(
B=this.A9)?B:null);var BN=(E.FY.isPrototypeOf(B=this.A9)?B:null);if(!!Aw)AP=A._NewObject(
E.KeyEvent,0).Initialize(Aw,true);if(this.CO!==0x00)AP=A._NewObject(E.KeyEvent,0
).Initialize2(Dw,true);if(!!BN)BN.AU(AP);else if(!!G)G.AU(AP);}if(this.GB&&((!Bp||(
this.Dd!==Aw))||(this.CO!==Dw))){this.Dd=0;this.CO=0x00;this.GB=false;}if((!this.
A9&&Bp)&&(this.Hx>0)){this.Dd=Aw;this.CO=Dw;this.GB=true;}if((!this.A9&&Bp)&&!this.
GB){if(!!Aw)this.A9=this.DispatchEvent(A._NewObject(E.KeyEvent,0).Initialize(Aw,
true));if(Dw!==0x00)this.A9=this.DispatchEvent(A._NewObject(E.KeyEvent,0).Initialize2(
Dw,true));if(!(E.FY.isPrototypeOf(B=this.A9)?B:null)&&!(E.Ch.isPrototypeOf(B=this.
A9)?B:null))this.A9=null;this.Dd=Aw;this.CO=Dw;HU=HU||!!this.A9;}this.Af=0;return HU;
},DriveCursorMovement:function(AD){return this.DriveMultiTouchMovement(this.DC,AD
);},DriveMultiTouchMovement:function(K,AD){if((K<0)||(K>9)){this.Af=0;return false;
}var FF=A.tw(AD,this.CB.Get(K));this.CB.Set(K,AD);if(!this.AL.Get(K)||A.tl(FF,Ac
)){this.Af=0;return false;}var AY=AD;var S=this.AL.Get(K).L;while(!!S&&(S!==this
)){AY=A.tw(AY,S.N.slice(0,2));S=S.L;}if(!S&&(this.AL.Get(K)!==this)){var tmp=this.
AL.Get(K);this.DC=K;this.AL.Set(K,null);tmp.AU(this.Fv().InitializeUp(K,this.DB.
Get(K),this.C_.Get(K),this.Ck.Get(K),this.AX.Get(K)+1,this.CA.Get(K),false,this.
CB.Get(K),this.C9.Get(K)));if(tmp===this.Cj)this.Cj=null;this.BroadcastEvent(this.
Gs().InitializeUp(K,this.AX.Get(K)+1,false,tmp,AD),0x18);}else{this.DB.Set(K,AY);
this.DC=K;this.AL.Get(K).AU(this.LE().Initialize(K,AY,this.C_.Get(K),FF,this.Ck.
Get(K),this.AX.Get(K)+1,this.CA.Get(K),AD,this.C9.Get(K)));}this.Af=0;return true;
},DriveCursorHitting:function(Bp,K,AD){return this.DriveMultiTouchHitting(Bp,K,AD
);},DriveMultiTouchHitting:function(Bp,K,AD){var B;if((K<0)||(K>9)){this.Af=0;return false;
}var ticksCount=this.Af;var Fx=[].concat([-this.FR,-this.FR],[this.FR+1,this.FR+
1]);if(!ticksCount){ticksCount=((new Date).getTime()-A.qt)|0;}var LL=this.Af;this.
DriveMultiTouchMovement(K,AD);AD=this.CB.Get(K);this.Af=LL;if(Bp)this.C9.Set(K,AD
);if((Bp&&!this.AL.Get(K))&&!this.Hx){var CC=null;var AY=AD;if(A.qu(this.Gt.Get(
K),AD)&&((ticksCount-this.Fw.Get(K))<=(((B=this.Ju)<0)?B+0x100000000:B)))this.AX.
Set(K,this.AX.Get(K)+1);else this.AX.Set(K,0);this.Gt.Set(K,A.tz(Fx,AD));this.Fw.
Set(K,ticksCount);if((!!this.Bu&&!!this.Bu.L)&&((this.Bu.F&0x18)===0x18)){var T=
A.tz(Fx,this.Bu.L.H$(AD));CC=this.Bu.Do(T,K,this.AX.Get(K)+1,null,0x0);}if(!CC){
if(!!this.Cj&&!!this.Cj.L){if(((this.Cj.F&0x8)===0x8)&&((this.Cj.F&0x10)===0x10)
){var T=A.tz(Fx,this.Cj.L.H$(AD));CC=this.Cj.Do(T,K,this.AX.Get(K)+1,null,0x0);}
}else if(!!this.CP)CC=this.Do(A.tz(Fx,AD),K,this.AX.Get(K)+1,this.CP.Bb,0x0);else
CC=this.Do(A.tz(Fx,AD),K,this.AX.Get(K)+1,null,0x0);}if(!!CC){this.BroadcastEvent(
this.Gs().InitializeDown(K,this.AX.Get(K)+1,false,CC.Ch,AD),0x18);this.AL.Set(K,
CC.Ch);this.CA.Set(K,CC.G5);}else{this.AL.Set(K,null);this.CA.Set(K,Ac);this.Af=
0;return false;}var S=CC.Ch.L;while(!!S&&(S!==this)){AY=A.tw(AY,S.N.slice(0,2));
S=S.L;}this.C_.Set(K,AY);this.DB.Set(K,AY);this.Ck.Set(K,0);this.CM.F_(true);this.
DC=K;this.AL.Get(K).AU(this.Fv().InitializeDown(K,AY,this.AX.Get(K)+1,this.CA.Get(
K),false,AD));this.Af=0;return true;}if(!Bp&&!!this.AL.Get(K)){var AY=AD;var S=this.
AL.Get(K).L;while(!!S&&(S!==this)){AY=A.tw(AY,S.N.slice(0,2));S=S.L;}if(!S)AY=this.
DB.Get(K);this.DC=K;var tmp=this.AL.Get(K);this.AL.Set(K,null);tmp.AU(this.Fv().
InitializeUp(K,AY,this.C_.Get(K),this.Ck.Get(K),this.AX.Get(K)+1,this.CA.Get(K),
false,AD,this.C9.Get(K)));this.BroadcastEvent(this.Gs().InitializeUp(K,this.AX.Get(
K)+1,false,tmp,AD),0x18);this.Af=0;return true;}this.Af=0;return false;},_Init:function(
aArg){E.Z._Init.call(this,aArg);E.Timer._Init.call(this.CM={M:this},0);(this.AL=[
]).__proto__=E.Root.AL;(this.AX=[]).__proto__=E.Root.AX;(this.Gt=[]).__proto__=E.
Root.Gt;(this.Ck=[]).__proto__=E.Root.Ck;(this.C_=[]).__proto__=E.Root.C_;(this.
Fw=[]).__proto__=E.Root.Fw;(this.DB=[]).__proto__=E.Root.DB;(this.CA=[]).__proto__=
E.Root.CA;(this.CB=[]).__proto__=E.Root.CB;(this.C9=[]).__proto__=E.Root.C9;(this.
GC=[]).__proto__=E.Root.GC;(this.AZ=[]).__proto__=E.Root.AZ;(this.AF=[]).__proto__=
E.Root.AF;this.__proto__=E.Root;this.F=0x7F;this.CM.JI(50);this.CM.Gb=[this,this.
LF];},_Done:function(){this.__proto__=E.Z;this.CM._Done();E.Z._Done.call(this);}
,_ReInit:function(){E.Z._ReInit.call(this);this.CM._ReInit();},_Mark:function(D){
var B;E.Z._Mark.call(this,D);if((B=this.A9)&&(B._cycle!=D))B._Mark(B._cycle=D);if((
B=this.CP)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.Cj)&&(B._cycle!=D))B._Mark(
B._cycle=D);A.ts(this.AL,D);if((B=this.EP)&&(B._cycle!=D))B._Mark(B._cycle=D);if((
B=this.Bu)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.CM)._cycle!=D)B._Mark(B.
_cycle=D);},_className:"Core::Root"};E.Event={Bt:0,E_:false,FX:function(){var ticksCount=
0;ticksCount=((new Date).getTime()-A.qt)|0;return ticksCount;},Bf:function(aArg){
this.Bt=this.FX();},_Init:function(aArg){this.__proto__=E.Event;this.Bf(aArg);A.
gv++;},_Done:function(){this.__proto__=null;A.gv--;},_ReInit:function(){},_Mark:
function(D){var B;if((B=this.M)&&(B._cycle!=D))B._Mark(B._cycle=D);},M:null,_cycle:
0,_observers:null,_className:"Core::Event"};E.KeyEvent={Az:0,Y:0,Down:false,Initialize2:
function(Aw,Bp){this.Az=0;this.Y=Aw;this.Down=Bp;if((Aw>=0x30)&&(Aw<=0x39))this.
Az=(10+Aw)-48;if((Aw>=0x41)&&(Aw<=0x5A))this.Az=(105+Aw)-65;if((Aw>=0x61)&&(Aw<=
0x7A))this.Az=(105+Aw)-97;if(Aw===0x20)this.Az=131;if(!this.Az)switch(Aw){case 0x2B:
this.Az=132;break;case 0x2D:this.Az=133;break;case 0x2A:this.Az=134;break;case 0x2F:
this.Az=135;break;case 0x3D:this.Az=136;break;case 0x2E:this.Az=137;break;case 0x2C:
this.Az=138;break;case 0x3A:this.Az=139;break;case 0x3B:this.Az=140;break;default:;
}return this;},Initialize:function(Aw,Bp){this.Az=Aw;this.Down=Bp;this.Y=0x00;var
Hz=Aw-10;var Hy=Aw-105;if((Hz>=0)&&(Hz<=9))this.Y=(48+Hz)&0xFFFF;if((Hy>=0)&&(Hy<=
25))this.Y=(65+Hy)&0xFFFF;if(Aw===131)this.Y=0x20;if(this.Y===0x00)switch(Aw){case
132:this.Y=0x2B;break;case 133:this.Y=0x2D;break;case 134:this.Y=0x2A;break;case
135:this.Y=0x2F;break;case 136:this.Y=0x3D;break;case 137:this.Y=0x2E;break;case
138:this.Y=0x2C;break;case 139:this.Y=0x3A;break;case 140:this.Y=0x3B;break;default:;
}return this;},JD:function(I6){switch(I6){case 141:return((this.Y>=0x41)&&(this.
Y<=0x5A))||((this.Y>=0x61)&&(this.Y<=0x7A));case 142:return(((this.Y>=0x41)&&(this.
Y<=0x5A))||((this.Y>=0x61)&&(this.Y<=0x7A)))||((this.Y>=0x30)&&(this.Y<=0x39));case
143:return(this.Y>=0x30)&&(this.Y<=0x39);case 144:return(((this.Y>=0x41)&&(this.
Y<=0x46))||((this.Y>=0x61)&&(this.Y<=0x66)))||((this.Y>=0x30)&&(this.Y<=0x39));case
145:return this.Y!==0x00;case 146:return(this.Y===0x00)&&!!this.Az;case 147:return(((
this.Az===6)||(this.Az===7))||(this.Az===4))||(this.Az===5);case 148:return(this.
Y!==0x00)||!!this.Az;default:;}return I6===this.Az;},_Init:function(aArg){E.Event.
_Init.call(this,aArg);this.__proto__=E.KeyEvent;},_className:"Core::KeyEvent"};E.
GV={Ha:null,CZ:A.qx,C0:0,CY:0,Down:false,E1:false,InitializeUp:function(K,Bw,Dv,
Hw,BK){this.Down=false;this.CY=K;this.C0=Bw;this.CZ=BK;this.Ha=Hw;this.E1=Dv;return this;
},InitializeDown:function(K,Bw,Dv,Hw,BK){this.Down=true;this.CY=K;this.C0=Bw;this.
CZ=BK;this.Ha=Hw;this.E1=Dv;return this;},_Init:function(aArg){E.Event._Init.call(
this,aArg);this.__proto__=E.GV;},_Mark:function(D){var B;E.Event._Mark.call(this
,D);if((B=this.Ha)&&(B._cycle!=D))B._Mark(B._cycle=D);},_className:"Core::CursorGrabEvent"
};E.GU={E6:A.qx,CZ:A.qx,C0:0,E8:0,E7:A.qx,E2:A.qx,CY:0,Down:false,E1:false,InitializeHold:
function(K,C7,Fq,Fr,Bw,Ci,BK,Fp){this.Down=true;this.CY=K;this.E2=A.tx(C7,Ci);this.
E7=A.tx(Fq,Ci);this.E8=Fr;this.C0=Bw;this.CZ=BK;this.E6=Fp;return this;},InitializeUp:
function(K,C7,Fq,Fr,Bw,Ci,Dv,BK,Fp){this.Down=false;this.CY=K;this.E2=A.tx(C7,Ci
);this.E7=A.tx(Fq,Ci);this.E8=Fr;this.C0=Bw;this.E1=Dv;this.CZ=BK;this.E6=Fp;return this;
},InitializeDown:function(K,C7,Bw,Ci,Dv,BK){this.Down=true;this.CY=K;this.E2=A.tx(
C7,Ci);this.E7=A.tx(C7,Ci);this.E8=0;this.C0=Bw;this.E1=Dv;this.CZ=BK;this.E6=BK;
return this;},_Init:function(aArg){E.Event._Init.call(this,aArg);this.__proto__=
E.GU;},_className:"Core::CursorEvent"};E.GW={E6:A.qx,CZ:A.qx,C0:0,E8:0,G5:A.qx,E7:
A.qx,E2:A.qx,CY:0,Initialize:function(K,C7,Fq,aOffset,Fr,LA,Ci,BK,Fp){this.CY=K;
this.E2=A.tx(C7,Ci);this.E7=A.tx(Fq,Ci);this.G5=aOffset;this.E8=Fr;this.C0=LA;this.
CZ=BK;this.E6=Fp;return this;},_Init:function(aArg){E.Event._Init.call(this,aArg
);this.__proto__=E.GW;},_className:"Core::DragEvent"};E.Fc={Cq:null,Ff:A.qx,JS:0
,JQ:0,Space:0,FV:0,BU:function(AA,aClip,aOffset,AG,aBlend){},O:function(C){var B;
if(A.tm(C,this.N))return;var Dh=[(B=this.N)[2]-B[0],B[3]-B[1]];var GE=[C[2]-C[0]
,C[3]-C[1]];var DJ=!A.tl(Dh,GE);var FF=A.tw(C.slice(0,2),this.N.slice(0,2));if(!
A.tl(FF,Ac)&&!DJ){var G=this.U;while(!!G&&!((G.F&0x200)===0x200)){if(((G.F&0x400
)===0x400)){var tmp=((G.F&0x100)===0x100);G.Ia(FF,tmp);}G=G.U;}A.lq(this.Cq,this
);}if((DJ&&(Dh[0]>0))&&(Dh[1]>0)){var Aq=A.tz(this.N,this.Ff);var G=this.U;var Fz=
0x14;while(!!G&&!((G.F&0x200)===0x200)){if(((G.F&0x400)===0x400)){if(!!G.AJ&&(G.
AJ.EU!==this))G.AJ=null;if(!G.AJ&&((G.AK!==Fz)||!!this.FV))G.Gy(Aq,this);}G=G.U;
}A.lq(this.Cq,this);}E.AV.O.call(this,C);if(!!this.L&&DJ){this.F=this.F|0x1000;if(
!((this.L.F&0x2000)===0x2000)){this.L.F=this.L.F|0x4000;A.lq([B=this.L,B.Bl],this
);}}},_Init:function(aArg){E.AV._Init.call(this,aArg);this.__proto__=E.Fc;this.F=
0x203;},_Mark:function(D){var B;E.AV._Mark.call(this,D);if((B=this.Cq)&&((B=B[0]
)._cycle!=D))B._Mark(B._cycle=D);},_className:"Core::Outline"};E.FY={U:null,IL:null
,IK:null,IJ:null,DI:0,Bt:0,IY:0,Jy:148,Az:0,Y:0,DP:true,Down:false,G$:false,FQ:false
,AU:function(W){var B;if(!!W&&W.JD(this.Jy)){this.Down=W.Down;this.Az=W.Az;this.
Y=W.Y;this.Bt=W.Bt;this.FQ=false;if(W.Down){this.IY=this.DI;this.G$=this.DI>0;if(
this.G$)(B=this.IJ)?B[1].call(B[0],this):null;else(B=this.IK)?B[1].call(B[0],this
):null;if(!this.FQ)this.DI=this.DI+1;return!this.FQ;}if(!W.Down){this.G$=this.DI>
1;this.IY=this.DI-1;this.DI=0;(B=this.IL)?B[1].call(B[0],this):null;return!this.
FQ;}}return false;},Bf:function(aArg){var B;var Bb=(E.Z.isPrototypeOf(B=this.M)?
B:null);if(!Bb)throw new Error(Hp);this.U=Bb.GA;Bb.GA=this;},_Init:function(aArg
){this.__proto__=E.FY;this.Bf(aArg);A.gv++;},_Done:function(){this.__proto__=null;
A.gv--;},_ReInit:function(){},_Mark:function(D){var B;if((B=this.U)&&(B._cycle!=
D))B._Mark(B._cycle=D);if((B=this.IL)&&((B=B[0])._cycle!=D))B._Mark(B._cycle=D);
if((B=this.IK)&&((B=B[0])._cycle!=D))B._Mark(B._cycle=D);if((B=this.IJ)&&((B=B[0
])._cycle!=D))B._Mark(B._cycle=D);if((B=this.M)&&(B._cycle!=D))B._Mark(B._cycle=
D);},M:null,_cycle:0,_observers:null,_className:"Core::KeyPressHandler"};E.Jt={Ch:
null,FS:0,G5:A.qx,_Init:function(aArg){this.__proto__=E.Jt;A.gv++;},_Done:function(
){this.__proto__=null;A.gv--;},_ReInit:function(){},_Mark:function(D){var B;if((
B=this.Ch)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.M)&&(B._cycle!=D))B._Mark(
B._cycle=D);},M:null,_cycle:0,_observers:null,_className:"Core::CursorHit"};E.JE={
Bb:null,_Init:function(aArg){this.__proto__=E.JE;A.gv++;},_Done:function(){this.
__proto__=null;A.gv--;},_ReInit:function(){},_Mark:function(D){var B;if((B=this.
Bb)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.M)&&(B._cycle!=D))B._Mark(B._cycle=
D);},M:null,_cycle:0,_observers:null,_className:"Core::ModalContext"};E.H_={EU:null
,Dc:A.qy,Aq:A.qy,isEmpty:false,_Init:function(aArg){this.__proto__=E.H_;A.gv++;}
,_Done:function(){this.__proto__=null;A.gv--;},_ReInit:function(){},_Mark:function(
D){var B;if((B=this.EU)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.M)&&(B._cycle
!=D))B._Mark(B._cycle=D);},M:null,_cycle:0,_observers:null,_className:"Core::LayoutContext"
};E.Jv={Bb:null,_Init:function(aArg){this.__proto__=E.Jv;A.gv++;},_Done:function(
){this.__proto__=null;A.gv--;},_ReInit:function(){},_Mark:function(D){var B;if((
B=this.Bb)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.M)&&(B._cycle!=D))B._Mark(
B._cycle=D);},M:null,_cycle:0,_observers:null,_className:"Core::DialogContext"};
E.JU={HB:null,Ba:null,_Init:function(aArg){this.__proto__=E.JU;A.gv++;},_Done:function(
){this.__proto__=null;A.gv--;},_ReInit:function(){},_Mark:function(D){var B;if((
B=this.HB)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.Ba)&&(B._cycle!=D))B._Mark(
B._cycle=D);if((B=this.M)&&(B._cycle!=D))B._Mark(B._cycle=D);},M:null,_cycle:0,_observers:
null,_className:"Core::TaskQueue"};E.JT={_Init:function(aArg){this.__proto__=E.JT;
A.gv++;},_Done:function(){this.__proto__=null;A.gv--;},_ReInit:function(){},_Mark:
function(D){var B;if((B=this.M)&&(B._cycle!=D))B._Mark(B._cycle=D);},M:null,_cycle:
0,_observers:null,_className:"Core::Task"};E.CI={resource:null,BT:function(){this.
resource=null;},Bf:function(aArg){this.resource=aArg;},_Init:function(aArg){this.
__proto__=E.CI;this.Bf(aArg);A.gv++;},_Done:function(){this.BT();this.__proto__=
null;A.gv--;},_ReInit:function(){},_Mark:function(D){var B;if((B=this.M)&&(B._cycle
!=D))B._Mark(B._cycle=D);},M:null,_cycle:0,_observers:null,_className:"Core::Resource"
};E.Timer={Gb:null,timer:null,Bt:0,Period:1000,H0:0,DP:false,BT:function(){var tmp=
this.timer;if(!!tmp)tmp.DestroyTimer();this.timer=null;},HW:function(aBegin,aPeriod
){if(aBegin<0)aBegin=0;if(aPeriod<0)aPeriod=0;var tmp=this.timer;if(!tmp&&((aBegin>
0)||(aPeriod>0)))tmp=A.sL(this,this.Trigger);if(!!tmp){tmp.ResetTimer();tmp.StartTimer(
aBegin,aPeriod);}this.timer=tmp;},JI:function(C){if(C<0)C=0;if(C===this.Period)return;
this.Period=C;if(this.DP)this.HW(this.H0,C);},F_:function(C){if(C===this.DP)return;
this.DP=C;if(C)this.HW(this.H0,this.Period);else this.HW(0,0);this.Bt=this.FX();
},FX:function(){var ticksCount=0;ticksCount=((new Date).getTime()-A.qt)|0;return ticksCount;
},Trigger:function(){var B;this.Bt=this.FX();if(!this.Period)this.F_(false);(B=this.
Gb)?B[1].call(B[0],this):null;},_Init:function(aArg){this.__proto__=E.Timer;A.gv++;
},_Done:function(){this.BT();this.__proto__=null;A.gv--;},_ReInit:function(){},_Mark:
function(D){var B;if((B=this.Gb)&&((B=B[0])._cycle!=D))B._Mark(B._cycle=D);if((B=
this.M)&&(B._cycle!=D))B._Mark(B._cycle=D);},M:null,_cycle:0,_observers:null,_className:
"Core::Timer"};E.MK={ML:0x1,L3:0x2,Ma:0x4,MG:0x8,DP:0x10,MA:0x20,Mb:0x40,Mj:0x80
,L$:0x100,Me:0x200,L_:0x400,Mp:0x800,Gf:0x1000,MI:0x2000,Mn:0x4000,Mo:0x8000,L8:
0x10000,Mm:0x20000,Mz:0x40000};E.AK={Mq:0x1,Mr:0x2,LT:0x4,LU:0x8,LV:0x10,LS:0x20
};E.FV={Mk:0,MD:1,L5:2,Mf:3,Mt:4,ME:5,MF:6,L6:7,L7:8,Mh:9,Mg:10,Mv:11,Mu:12};E.KeyCode={
NoKey:0,Ok:1,Exit:2,Menu:3,Up:4,Down:5,Left:6,Right:7,PageUp:8,PageDown:9,Key0:10
,Key1:11,Key2:12,Key3:13,Key4:14,Key5:15,Key6:16,Key7:17,Key8:18,Key9:19,Red:20,
Green:21,Blue:22,Yellow:23,White:24,Magenta:25,F1:26,F2:27,F3:28,F4:29,F5:30,F6:
31,F7:32,F8:33,F9:34,F10:35,ChannelUp:36,ChannelDown:37,Display:38,SkipPrev:39,SkipNext:
40,Home:41,End:42,Insert:43,Delete:44,Clear:45,VolumeUp:46,VolumeDown:47,Show:48
,Hide:49,Play:50,Pause:51,Record:52,Stop:53,Rev:54,Fwd:55,SlowRev:56,SlowFwd:57,
SkipBwd:58,SkipFwd:59,Repeat:60,Eject:61,Help:62,TV:63,DVD:64,VCR:65,EPG:66,OSD:
67,Text:68,PIP:69,Audio:70,Clock:71,Timer:72,Navigation:73,Karaoke:74,Game:75,Subtitle:
76,Zoom:77,Index:78,Info:79,Power:80,Setup:81,Angle:82,Mode:83,Mute:84,User0:85,
User1:86,User2:87,User3:88,User4:89,User5:90,User6:91,User7:92,User8:93,User9:94
,User10:95,User11:96,User12:97,User13:98,User14:99,User15:100,User16:101,User17:
102,User18:103,User19:104,KeyA:105,KeyB:106,KeyC:107,KeyD:108,KeyE:109,KeyF:110,
KeyG:111,KeyH:112,KeyI:113,KeyJ:114,KeyK:115,KeyL:116,KeyM:117,KeyN:118,KeyO:119
,KeyP:120,KeyQ:121,KeyR:122,KeyS:123,KeyT:124,KeyU:125,KeyV:126,KeyW:127,KeyX:128
,KeyY:129,KeyZ:130,Space:131,Plus:132,Minus:133,Multiply:134,Divide:135,Equals:136
,Period:137,Comma:138,Colon:139,Semicolon:140,AlphaKeys:141,AlphaOrDigitKeys:142
,DigitKeys:143,HexDigitKeys:144,CharacterKeys:145,ControlKeys:146,CursorKeys:147
,AnyKey:148,Enter:149,Escape:150,Backspace:151,Tab:152,CtrlKeyA:153,CtrlKeyB:154
,CtrlKeyC:155,CtrlKeyD:156,CtrlKeyE:157,CtrlKeyF:158,CtrlKeyG:159,CtrlKeyH:160,CtrlKeyI:
161,CtrlKeyJ:162,CtrlKeyK:163,CtrlKeyL:164,CtrlKeyM:165,CtrlKeyN:166,CtrlKeyO:167
,CtrlKeyP:168,CtrlKeyQ:169,CtrlKeyR:170,CtrlKeyS:171,CtrlKeyT:172,CtrlKeyU:173,CtrlKeyV:
174,CtrlKeyW:175,CtrlKeyX:176,CtrlKeyY:177,CtrlKeyZ:178,CtrlSpace:179,CtrlKey0:180
,CtrlKey1:181,CtrlKey2:182,CtrlKey3:183,CtrlKey4:184,CtrlKey5:185,CtrlKey6:186,CtrlKey7:
187,CtrlKey8:188,CtrlKey9:189,CtrlF1:190,CtrlF2:191,CtrlF3:192,CtrlF4:193,CtrlF5:
194,CtrlF6:195,CtrlF7:196,CtrlF8:197,CtrlF9:198,CtrlF10:199,CtrlEnter:200,CtrlEscape:
201,CtrlUp:202,CtrlDown:203,CtrlLeft:204,CtrlRight:205,CtrlPageUp:206,CtrlPageDown:
207,CtrlBackspace:208,CtrlInsert:209,CtrlDelete:210,CtrlHome:211,CtrlEnd:212,CtrlTab:
213,CtrlShiftKeyA:214,CtrlShiftKeyB:215,CtrlShiftKeyC:216,CtrlShiftKeyD:217,CtrlShiftKeyE:
218,CtrlShiftKeyF:219,CtrlShiftKeyG:220,CtrlShiftKeyH:221,CtrlShiftKeyI:222,CtrlShiftKeyJ:
223,CtrlShiftKeyK:224,CtrlShiftKeyL:225,CtrlShiftKeyM:226,CtrlShiftKeyN:227,CtrlShiftKeyO:
228,CtrlShiftKeyP:229,CtrlShiftKeyQ:230,CtrlShiftKeyR:231,CtrlShiftKeyS:232,CtrlShiftKeyT:
233,CtrlShiftKeyU:234,CtrlShiftKeyV:235,CtrlShiftKeyW:236,CtrlShiftKeyX:237,CtrlShiftKeyY:
238,CtrlShiftKeyZ:239,CtrlShiftSpace:240,CtrlShiftKey0:241,CtrlShiftKey1:242,CtrlShiftKey2:
243,CtrlShiftKey3:244,CtrlShiftKey4:245,CtrlShiftKey5:246,CtrlShiftKey6:247,CtrlShiftKey7:
248,CtrlShiftKey8:249,CtrlShiftKey9:250,CtrlShiftF1:251,CtrlShiftF2:252,CtrlShiftF3:
253,CtrlShiftF4:254,CtrlShiftF5:255,CtrlShiftF6:256,CtrlShiftF7:257,CtrlShiftF8:
258,CtrlShiftF9:259,CtrlShiftF10:260,CtrlShiftEnter:261,CtrlShiftEscape:262,CtrlShiftUp:
263,CtrlShiftDown:264,CtrlShiftLeft:265,CtrlShiftRight:266,CtrlShiftPageUp:267,CtrlShiftPageDown:
268,CtrlShiftBackspace:269,CtrlShiftInsert:270,CtrlShiftDelete:271,CtrlShiftHome:
272,CtrlShiftEnd:273,CtrlShiftTab:274,AltF1:275,AltF2:276,AltF3:277,AltF4:278,AltF5:
279,AltF6:280,AltF7:281,AltF8:282,AltF9:283,AltF10:284,AltEnter:285,AltEscape:286
,AltUp:287,AltDown:288,AltLeft:289,AltRight:290,AltPageUp:291,AltPageDown:292,AltBackspace:
293,AltInsert:294,AltDelete:295,AltHome:296,AltEnd:297,AltTab:298,AltShiftF1:299
,AltShiftF2:300,AltShiftF3:301,AltShiftF4:302,AltShiftF5:303,AltShiftF6:304,AltShiftF7:
305,AltShiftF8:306,AltShiftF9:307,AltShiftF10:308,AltShiftEnter:309,AltShiftEscape:
310,AltShiftUp:311,AltShiftDown:312,AltShiftLeft:313,AltShiftRight:314,AltShiftPageUp:
315,AltShiftPageDown:316,AltShiftBackspace:317,AltShiftInsert:318,AltShiftDelete:
319,AltShiftHome:320,AltShiftEnd:321,AltShiftTab:322,ShiftF1:323,ShiftF2:324,ShiftF3:
325,ShiftF4:326,ShiftF5:327,ShiftF6:328,ShiftF7:329,ShiftF8:330,ShiftF9:331,ShiftF10:
332,ShiftEnter:333,ShiftEscape:334,ShiftUp:335,ShiftDown:336,ShiftLeft:337,ShiftRight:
338,ShiftPageUp:339,ShiftPageDown:340,ShiftBackspace:341,ShiftInsert:342,ShiftDelete:
343,ShiftHome:344,ShiftEnd:345,ShiftTab:346};E.Ms={MP:0x1,MM:0x2,MN:0x4,MO:0x8,Mi:
0x10,Mc:0x20};
E._Init=function(){E.AV.__proto__=E.Ch;E.Z.__proto__=E.AV;E.Root.__proto__=E.Z;E.
KeyEvent.__proto__=E.Event;E.GV.__proto__=E.Event;E.GU.__proto__=E.Event;E.GW.__proto__=
E.Event;E.Fc.__proto__=E.AV;};E.Av=function(D){};return E;})();

/* Embedded Wizard */