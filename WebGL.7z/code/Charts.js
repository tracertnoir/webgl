/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.uo)throw new Error("The unit file 'Charts.js' included twice!");EmWiApp.
uo=(function(){var A=EmWiApp;var E={};
var Ab=[20,10];var At=[0,0,360,240];
E.Record={T:null,I7:0,H4:0xFFFFFFFF,_Init:function(aArg){this.__proto__=E.Record;
A.gv++;},_Done:function(){this.__proto__=null;A.gv--;},_ReInit:function(){},_Mark:
function(D){var B;if((B=this.T)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.L)&&(
B._cycle!=D))B._Mark(B._cycle=D);},L:null,_cycle:0,_observers:null,_className:"Charts::Record"
};E.AN={Ew:null,EA:null,BE:10,Hd:0,H3:function(){this.Ew=null;this.EA=null;this.
BE=0;this.Hd=0;},Ak:function(Jc,K7){var BB=null;BB=A._NewObject(E.Record,0);BB.I7=
Jc;BB.H4=K7;if(!this.Ew){this.Ew=BB;this.EA=BB;this.BE=1;}else{this.EA.T=BB;this.
EA=BB;this.BE=this.BE+1;}this.Hd=this.Hd+Jc;},_Init:function(aArg){this.__proto__=
E.AN;A.gv++;},_Done:function(){this.__proto__=null;A.gv--;},_ReInit:function(){}
,_Mark:function(D){var B;if((B=this.Ew)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=
this.EA)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.L)&&(B._cycle!=D))B._Mark(
B._cycle=D);},L:null,_cycle:0,_observers:null,_className:"Charts::RecordList"};E.
Bm={Ge:null,BF:null,CR:null,EN:Ab,Gx:100,JF:0xFF3F5F00,DN:5,JV:0,Jv:0,H1:0,BU:function(
Az,aClip,aOffset,AF,aBlend){var B;var FW=0;var HR=0;var HS=0;var HT=0;var HE=(this.
M[0]+aOffset[0])+this.EN[0];var FM=(this.M[1]+aOffset[1])+this.EN[1];var Bx;var DY=
this.JF;var Ga;var BS;var Be=((B=this.M)[2]-B[0])-(this.EN[0]*2);var Bc=((B=this.
M)[3]-B[1])-(this.EN[1]*2);var Dl=this.JV;var C7=this.Jv;var DK;var CD=(((AF+1)*
this.Fp)>>8)+1;aBlend=aBlend&&((this.F&0x2)===0x2);if(CD<256)DY=(DY&0x00FFFFFF)|((((((
DY>>24)&0xFF)*CD)>>8)&0xFF)<<24);A.Core.Y.BU.call(this,Az,aClip,aOffset,AF,aBlend
);if((this.DN>0)&&(((DY>>24)&0xFF)>0)){var H;for(H=0;H<this.DN;H=H+1){if(this.DN>
1)BS=(((H*Bc)/(this.DN-1))|0)+FM;else BS=FM+Bc;Az.JB(aClip,[HE,BS],[HE+Be,BS],DY
,DY,aBlend);}}if(!this.BF||(this.BF.BE<1))return;if(!C7){if(!Dl)DK=(Be/2)|0;else
DK=(this.BF.BE-1)*Dl;C7=((Be-DK)/this.BF.BE)|0;if(C7<1)C7=1;}if(!Dl){DK=this.BF.
BE*C7;if(this.BF.BE>1)Dl=((Be-DK)/(this.BF.BE-1))|0;if(Dl<0)Dl=0;}DK=(this.BF.BE
*C7)+((this.BF.BE-1)*Dl);Ga=((Be-DK)/2)|0;var BB=this.BF.Ew;while(!!BB){FW=HE+Ga;
HR=(FM+Bc)-(((BB.I7*Bc)/this.Gx)|0);HS=FW+C7;HT=FM+Bc;Bx=BB.H4;if(CD<256)Bx=(Bx&
0x00FFFFFF)|((((((Bx>>24)&0xFF)*CD)>>8)&0xFF)<<24);if(((Bx>>24)&0xFF)>0){if(!!this.
Ge&&(this.H1>=0))Az.JA(aClip,this.Ge,this.H1,[FW,HR,HS,HT],0x1F,Bx,Bx,Bx,Bx,aBlend
);else Az.EZ(aClip,[FW,HR,HS,HT],Bx,Bx,Bx,Bx,aBlend);}Ga=(Ga+C7)+Dl;BB=BB.T;}},IQ:
function(C){var B;if(C<1)C=1;if(C===this.Gx)return;this.Gx=C;this.AM([0,0,(B=this.
M)[2]-B[0],B[3]-B[1]]);},IR:function(C){var B;if(C<0)C=0;if(C>10)C=10;if(C===this.
DN)return;this.DN=C;this.AM([0,0,(B=this.M)[2]-B[0],B[3]-B[1]]);},IS:function(C){
var B;this.BF=C;this.Dp();this.AM([0,0,(B=this.M)[2]-B[0],B[3]-B[1]]);},_Init:function(
aArg){A.Core.Y._Init.call(this,aArg);A.un.BG._Init.call(this.CR={L:this},0);this.
__proto__=E.Bm;this.N(At);this.CR.Ec(0x3F);this.CR.N(At);this.CR.DO(0xFF202020);
this.U(this.CR,0);},_Done:function(){this.__proto__=A.Core.Y;this.CR._Done();A.Core.
Y._Done.call(this);},_ReInit:function(){A.Core.Y._ReInit.call(this);this.CR._ReInit(
);},_Mark:function(D){var B;A.Core.Y._Mark.call(this,D);if((B=this.Ge)&&(B._cycle
!=D))B._Mark(B._cycle=D);if((B=this.BF)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=
this.CR)._cycle!=D)B._Mark(B._cycle=D);},_className:"Charts::BarChart"};
E._Init=function(){E.Bm.__proto__=A.Core.Y;};E.Au=function(D){};return E;})();

/* Embedded Wizard */