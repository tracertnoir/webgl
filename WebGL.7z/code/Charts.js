/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.uo)throw new Error("The unit file 'Charts.js' included twice!");EmWiApp.
uo=(function(){var A=EmWiApp;var E={};
var Ac=[20,10];var Au=[0,0,360,240];
E.Record={U:null,I3:0,H2:0xFFFFFFFF,_Init:function(aArg){this.__proto__=E.Record;
A.gv++;},_Done:function(){this.__proto__=null;A.gv--;},_ReInit:function(){},_Mark:
function(D){var B;if((B=this.U)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.M)&&(
B._cycle!=D))B._Mark(B._cycle=D);},M:null,_cycle:0,_observers:null,_className:"Charts::Record"
};E.AO={Fy:null,FC:null,BE:10,Hb:0,H1:function(){this.Fy=null;this.FC=null;this.
BE=0;this.Hb=0;},Al:function(I_,Lz){var BB=null;BB=A._NewObject(E.Record,0);BB.I3=
I_;BB.H2=Lz;if(!this.Fy){this.Fy=BB;this.FC=BB;this.BE=1;}else{this.FC.U=BB;this.
FC=BB;this.BE=this.BE+1;}this.Hb=this.Hb+I_;},_Init:function(aArg){this.__proto__=
E.AO;A.gv++;},_Done:function(){this.__proto__=null;A.gv--;},_ReInit:function(){}
,_Mark:function(D){var B;if((B=this.Fy)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=
this.FC)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.M)&&(B._cycle!=D))B._Mark(
B._cycle=D);},M:null,_cycle:0,_observers:null,_className:"Charts::RecordList"};E.
Bm={GQ:null,BF:null,CS:null,FP:Ac,G4:100,JB:0xFF3F5F00,D6:5,JR:0,Jr:0,HZ:0,BU:function(
AA,aClip,aOffset,AG,aBlend){var B;var GF=0;var HP=0;var HQ=0;var HR=0;var HC=(this.
N[0]+aOffset[0])+this.FP[0];var Gv=(this.N[1]+aOffset[1])+this.FP[1];var Bx;var ET=
this.JB;var GM;var BS;var Be=((B=this.N)[2]-B[0])-(this.FP[0]*2);var Bc=((B=this.
N)[3]-B[1])-(this.FP[1]*2);var Dm=this.JR;var C8=this.Jr;var DL;var CD=(((AG+1)*
this.Gc)>>8)+1;aBlend=aBlend&&((this.F&0x2)===0x2);if(CD<256)ET=(ET&0x00FFFFFF)|((((((
ET>>24)&0xFF)*CD)>>8)&0xFF)<<24);A.Core.Z.BU.call(this,AA,aClip,aOffset,AG,aBlend
);if((this.D6>0)&&(((ET>>24)&0xFF)>0)){var I;for(I=0;I<this.D6;I=I+1){if(this.D6>
1)BS=(((I*Bc)/(this.D6-1))|0)+Gv;else BS=Gv+Bc;AA.Jx(aClip,[HC,BS],[HC+Be,BS],ET
,ET,aBlend);}}if(!this.BF||(this.BF.BE<1))return;if(!C8){if(!Dm)DL=(Be/2)|0;else
DL=(this.BF.BE-1)*Dm;C8=((Be-DL)/this.BF.BE)|0;if(C8<1)C8=1;}if(!Dm){DL=this.BF.
BE*C8;if(this.BF.BE>1)Dm=((Be-DL)/(this.BF.BE-1))|0;if(Dm<0)Dm=0;}DL=(this.BF.BE
*C8)+((this.BF.BE-1)*Dm);GM=((Be-DL)/2)|0;var BB=this.BF.Fy;while(!!BB){GF=HC+GM;
HP=(Gv+Bc)-(((BB.I3*Bc)/this.G4)|0);HQ=GF+C8;HR=Gv+Bc;Bx=BB.H2;if(CD<256)Bx=(Bx&
0x00FFFFFF)|((((((Bx>>24)&0xFF)*CD)>>8)&0xFF)<<24);if(((Bx>>24)&0xFF)>0){if(!!this.
GQ&&(this.HZ>=0))AA.Jw(aClip,this.GQ,this.HZ,[GF,HP,HQ,HR],0x1F,Bx,Bx,Bx,Bx,aBlend
);else AA.FT(aClip,[GF,HP,HQ,HR],Bx,Bx,Bx,Bx,aBlend);}GM=(GM+C8)+Dm;BB=BB.U;}},IM:
function(C){var B;if(C<1)C=1;if(C===this.G4)return;this.G4=C;this.AN([0,0,(B=this.
N)[2]-B[0],B[3]-B[1]]);},IN:function(C){var B;if(C<0)C=0;if(C>10)C=10;if(C===this.
D6)return;this.D6=C;this.AN([0,0,(B=this.N)[2]-B[0],B[3]-B[1]]);},IO:function(C){
var B;this.BF=C;this.Dr();this.AN([0,0,(B=this.N)[2]-B[0],B[3]-B[1]]);},_Init:function(
aArg){A.Core.Z._Init.call(this,aArg);A.un.BG._Init.call(this.CS={M:this},0);this.
__proto__=E.Bm;this.O(Au);this.CS.Fb(0x3F);this.CS.O(Au);this.CS.D7(0xFF202020);
this.V(this.CS,0);},_Done:function(){this.__proto__=A.Core.Z;this.CS._Done();A.Core.
Z._Done.call(this);},_ReInit:function(){A.Core.Z._ReInit.call(this);this.CS._ReInit(
);},_Mark:function(D){var B;A.Core.Z._Mark.call(this,D);if((B=this.GQ)&&(B._cycle
!=D))B._Mark(B._cycle=D);if((B=this.BF)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=
this.CS)._cycle!=D)B._Mark(B._cycle=D);},_className:"Charts::BarChart"};
E._Init=function(){E.Bm.__proto__=A.Core.Z;};E.Av=function(D){};return E;})();

/* Embedded Wizard */