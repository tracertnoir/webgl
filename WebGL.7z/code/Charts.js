/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.uo)throw new Error("The unit file 'Charts.js' included twice!");EmWiApp.
uo=(function(){var B=EmWiApp;var D={};
var Z=[20,10];var An=[0,0,360,240];
D.Record={S:null,HK:0,Hb:0xFFFFFFFF,_Init:function(aArg){this.__proto__=D.Record;
B.gv++;},_Done:function(){this.__proto__=null;B.gv--;},_ReInit:function(){},_Mark:
function(E){var A;if((A=this.S)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.O)&&(
A._cycle!=E))A._Mark(A._cycle=E);},O:null,_cycle:0,_observers:null,_className:"Charts::Record"
};D.AH={EH:null,EL:null,By:10,Gm:0,H$:function(){this.EH=null;this.EL=null;this.
By=0;this.Gm=0;},Bv:function(HR,JO){var Bt=null;Bt=B._NewObject(D.Record,0);Bt.HK=
HR;Bt.Hb=JO;if(!this.EH){this.EH=Bt;this.EL=Bt;this.By=1;}else{this.EL.S=Bt;this.
EL=Bt;this.By=this.By+1;}this.Gm=this.Gm+HR;},_Init:function(aArg){this.__proto__=
D.AH;B.gv++;},_Done:function(){this.__proto__=null;B.gv--;},_ReInit:function(){}
,_Mark:function(E){var A;if((A=this.EH)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=
this.EL)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.O)&&(A._cycle!=E))A._Mark(
A._cycle=E);},O:null,_cycle:0,_observers:null,_className:"Charts::RecordList"};D.
Bw={FP:null,BD:null,CA:null,EY:Z,Ga:100,Ij:0xFF3F5F00,E7:5,IJ:0,H_:0,G$:0,BS:function(
Au,aClip,aOffset,AA,aBlend){var A;var FE=0;var G1=0;var G2=0;var G3=0;var GO=(this.
M[0]+aOffset[0])+this.EY[0];var Fu=(this.M[1]+aOffset[1])+this.EY[1];var Bp;var D6=
this.Ij;var FL;var BQ;var A9=((A=this.M)[2]-A[0])-(this.EY[0]*2);var A7=((A=this.
M)[3]-A[1])-(this.EY[1]*2);var C5=this.IJ;var CP=this.H_;var Dr;var Cm=(((AA+1)*
this.Fc)>>8)+1;aBlend=aBlend&&((this.F&0x2)===0x2);if(Cm<256)D6=(D6&0x00FFFFFF)|((((((
D6>>24)&0xFF)*Cm)>>8)&0xFF)<<24);B.Core.X.BS.call(this,Au,aClip,aOffset,AA,aBlend
);if((this.E7>0)&&(((D6>>24)&0xFF)>0)){var H;for(H=0;H<this.E7;H=H+1){if(this.E7>
1)BQ=(((H*A7)/(this.E7-1))|0)+Fu;else BQ=Fu+A7;Au.If(aClip,[GO,BQ],[GO+A9,BQ],D6
,D6,aBlend);}}if(!this.BD||(this.BD.By<1))return;if(!CP){if(!C5)Dr=(A9/2)|0;else
Dr=(this.BD.By-1)*C5;CP=((A9-Dr)/this.BD.By)|0;if(CP<1)CP=1;}if(!C5){Dr=this.BD.
By*CP;if(this.BD.By>1)C5=((A9-Dr)/(this.BD.By-1))|0;if(C5<0)C5=0;}Dr=(this.BD.By
*CP)+((this.BD.By-1)*C5);FL=((A9-Dr)/2)|0;var Bt=this.BD.EH;while(!!Bt){FE=GO+FL;
G1=(Fu+A7)-(((Bt.HK*A7)/this.Ga)|0);G2=FE+CP;G3=Fu+A7;Bp=Bt.Hb;if(Cm<256)Bp=(Bp&
0x00FFFFFF)|((((((Bp>>24)&0xFF)*Cm)>>8)&0xFF)<<24);if(((Bp>>24)&0xFF)>0){if(!!this.
FP&&(this.G$>=0))Au.Ie(aClip,this.FP,this.G$,[FE,G1,G2,G3],0x1F,Bp,Bp,Bp,Bp,aBlend
);else Au.E3(aClip,[FE,G1,G2,G3],Bp,Bp,Bp,Bp,aBlend);}FL=(FL+CP)+C5;Bt=Bt.S;}},Iq:
function(C){var A;if(C<1)C=1;if(C===this.Ga)return;this.Ga=C;this.AG([0,0,(A=this.
M)[2]-A[0],A[3]-A[1]]);},Is:function(C){var A;this.BD=C;this.C9();this.AG([0,0,(
A=this.M)[2]-A[0],A[3]-A[1]]);},_Init:function(aArg){B.Core.X._Init.call(this,aArg
);B.un.BE._Init.call(this.CA={O:this},0);this.__proto__=D.Bw;this.T(An);this.CA.
Eo(0x3F);this.CA.T(An);this.CA.Dy(0xFF202020);this.As(this.CA,0);},_Done:function(
){this.__proto__=B.Core.X;this.CA._Done();B.Core.X._Done.call(this);},_ReInit:function(
){B.Core.X._ReInit.call(this);this.CA._ReInit();},_Mark:function(E){var A;B.Core.
X._Mark.call(this,E);if((A=this.FP)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.
BD)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.CA)._cycle!=E)A._Mark(A._cycle=
E);},_className:"Charts::BarChart"};
D._Init=function(){D.Bw.__proto__=B.Core.X;};D.Ao=function(E){};return D;})();

/* Embedded Wizard */