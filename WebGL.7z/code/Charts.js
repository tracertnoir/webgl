/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.uo)throw new Error("The unit file 'Charts.js' included twice!");EmWiApp.
uo=(function(){var A=EmWiApp;var E={};
var Ab=[20,10];var At=[0,0,360,240];
E.Record={T:null,I3:0,H1:0xFFFFFFFF,_Init:function(aArg){this.__proto__=E.Record;
A.gv++;},_Done:function(){this.__proto__=null;A.gv--;},_ReInit:function(){},_Mark:
function(D){var B;if((B=this.T)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.L)&&(
B._cycle!=D))B._Mark(B._cycle=D);},L:null,_cycle:0,_observers:null,_className:"Charts::Record"
};E.AN={Ev:null,Ez:null,BE:10,Ha:0,H0:function(){this.Ev=null;this.Ez=null;this.
BE=0;this.Ha=0;},Ak:function(I_,K1){var BB=null;BB=A._NewObject(E.Record,0);BB.I3=
I_;BB.H1=K1;if(!this.Ev){this.Ev=BB;this.Ez=BB;this.BE=1;}else{this.Ez.T=BB;this.
Ez=BB;this.BE=this.BE+1;}this.Ha=this.Ha+I_;},_Init:function(aArg){this.__proto__=
E.AN;A.gv++;},_Done:function(){this.__proto__=null;A.gv--;},_ReInit:function(){}
,_Mark:function(D){var B;if((B=this.Ev)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=
this.Ez)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.L)&&(B._cycle!=D))B._Mark(
B._cycle=D);},L:null,_cycle:0,_observers:null,_className:"Charts::RecordList"};E.
Bm={Gc:null,BF:null,CQ:null,EM:Ab,Gu:100,JB:0xFF3F5F00,DL:5,JR:0,Jr:0,HY:0,BU:function(
Az,aClip,aOffset,AF,aBlend){var B;var FU=0;var HO=0;var HP=0;var HQ=0;var HB=(this.
M[0]+aOffset[0])+this.EM[0];var FK=(this.M[1]+aOffset[1])+this.EM[1];var Bx;var DX=
this.JB;var F_;var BS;var Be=((B=this.M)[2]-B[0])-(this.EM[0]*2);var Bc=((B=this.
M)[3]-B[1])-(this.EM[1]*2);var Dj=this.JR;var C5=this.Jr;var DI;var CD=(((AF+1)*
this.Fn)>>8)+1;aBlend=aBlend&&((this.F&0x2)===0x2);if(CD<256)DX=(DX&0x00FFFFFF)|((((((
DX>>24)&0xFF)*CD)>>8)&0xFF)<<24);A.Core.Y.BU.call(this,Az,aClip,aOffset,AF,aBlend
);if((this.DL>0)&&(((DX>>24)&0xFF)>0)){var H;for(H=0;H<this.DL;H=H+1){if(this.DL>
1)BS=(((H*Bc)/(this.DL-1))|0)+FK;else BS=FK+Bc;Az.Jx(aClip,[HB,BS],[HB+Be,BS],DX
,DX,aBlend);}}if(!this.BF||(this.BF.BE<1))return;if(!C5){if(!Dj)DI=(Be/2)|0;else
DI=(this.BF.BE-1)*Dj;C5=((Be-DI)/this.BF.BE)|0;if(C5<1)C5=1;}if(!Dj){DI=this.BF.
BE*C5;if(this.BF.BE>1)Dj=((Be-DI)/(this.BF.BE-1))|0;if(Dj<0)Dj=0;}DI=(this.BF.BE
*C5)+((this.BF.BE-1)*Dj);F_=((Be-DI)/2)|0;var BB=this.BF.Ev;while(!!BB){FU=HB+F_;
HO=(FK+Bc)-(((BB.I3*Bc)/this.Gu)|0);HP=FU+C5;HQ=FK+Bc;Bx=BB.H1;if(CD<256)Bx=(Bx&
0x00FFFFFF)|((((((Bx>>24)&0xFF)*CD)>>8)&0xFF)<<24);if(((Bx>>24)&0xFF)>0){if(!!this.
Gc&&(this.HY>=0))Az.Jw(aClip,this.Gc,this.HY,[FU,HO,HP,HQ],0x1F,Bx,Bx,Bx,Bx,aBlend
);else Az.EY(aClip,[FU,HO,HP,HQ],Bx,Bx,Bx,Bx,aBlend);}F_=(F_+C5)+Dj;BB=BB.T;}},IM:
function(C){var B;if(C<1)C=1;if(C===this.Gu)return;this.Gu=C;this.AM([0,0,(B=this.
M)[2]-B[0],B[3]-B[1]]);},IN:function(C){var B;if(C<0)C=0;if(C>10)C=10;if(C===this.
DL)return;this.DL=C;this.AM([0,0,(B=this.M)[2]-B[0],B[3]-B[1]]);},IO:function(C){
var B;this.BF=C;this.Dn();this.AM([0,0,(B=this.M)[2]-B[0],B[3]-B[1]]);},_Init:function(
aArg){A.Core.Y._Init.call(this,aArg);A.un.BG._Init.call(this.CQ={L:this},0);this.
__proto__=E.Bm;this.N(At);this.CQ.Eb(0x3F);this.CQ.N(At);this.CQ.DM(0xFF202020);
this.U(this.CQ,0);},_Done:function(){this.__proto__=A.Core.Y;this.CQ._Done();A.Core.
Y._Done.call(this);},_ReInit:function(){A.Core.Y._ReInit.call(this);this.CQ._ReInit(
);},_Mark:function(D){var B;A.Core.Y._Mark.call(this,D);if((B=this.Gc)&&(B._cycle
!=D))B._Mark(B._cycle=D);if((B=this.BF)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=
this.CQ)._cycle!=D)B._Mark(B._cycle=D);},_className:"Charts::BarChart"};
E._Init=function(){E.Bm.__proto__=A.Core.Y;};E.Au=function(D){};return E;})();

/* Embedded Wizard */