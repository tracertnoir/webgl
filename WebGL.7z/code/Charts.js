/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.uo)throw new Error("The unit file 'Charts.js' included twice!");EmWiApp.
uo=(function(){var A=EmWiApp;var E={};
var Ac=[20,10];var At=[0,0,360,240];
E.Record={U:null,I2:0,H2:0xFFFFFFFF,_Init:function(aArg){this.__proto__=E.Record;
A.gv++;},_Done:function(){this.__proto__=null;A.gv--;},_ReInit:function(){},_Mark:
function(D){var B;if((B=this.U)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.M)&&(
B._cycle!=D))B._Mark(B._cycle=D);},M:null,_cycle:0,_observers:null,_className:"Charts::Record"
};E.AM={Fx:null,FB:null,BD:10,Hb:0,H1:function(){this.Fx=null;this.FB=null;this.
BD=0;this.Hb=0;},Al:function(I9,Ly){var BA=null;BA=A._NewObject(E.Record,0);BA.I2=
I9;BA.H2=Ly;if(!this.Fx){this.Fx=BA;this.FB=BA;this.BD=1;}else{this.FB.U=BA;this.
FB=BA;this.BD=this.BD+1;}this.Hb=this.Hb+I9;},_Init:function(aArg){this.__proto__=
E.AM;A.gv++;},_Done:function(){this.__proto__=null;A.gv--;},_ReInit:function(){}
,_Mark:function(D){var B;if((B=this.Fx)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=
this.FB)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.M)&&(B._cycle!=D))B._Mark(
B._cycle=D);},M:null,_cycle:0,_observers:null,_className:"Charts::RecordList"};E.
Bq={GQ:null,BF:null,CR:null,FO:Ac,G4:100,JA:0xFF3F5F00,FY:5,JQ:0,Jq:0,HZ:0,BU:function(
Az,aClip,aOffset,AF,aBlend){var B;var GF=0;var HP=0;var HQ=0;var HR=0;var HC=(this.
N[0]+aOffset[0])+this.FO[0];var Gv=(this.N[1]+aOffset[1])+this.FO[1];var Bw;var EC=
this.JA;var GM;var BS;var Bd=((B=this.N)[2]-B[0])-(this.FO[0]*2);var Bb=((B=this.
N)[3]-B[1])-(this.FO[1]*2);var Dm=this.JQ;var C8=this.Jq;var DL;var CD=(((AF+1)*
this.Gc)>>8)+1;aBlend=aBlend&&((this.F&0x2)===0x2);if(CD<256)EC=(EC&0x00FFFFFF)|((((((
EC>>24)&0xFF)*CD)>>8)&0xFF)<<24);A.Core.Z.BU.call(this,Az,aClip,aOffset,AF,aBlend
);if((this.FY>0)&&(((EC>>24)&0xFF)>0)){var I;for(I=0;I<this.FY;I=I+1){if(this.FY>
1)BS=(((I*Bb)/(this.FY-1))|0)+Gv;else BS=Gv+Bb;Az.Jw(aClip,[HC,BS],[HC+Bd,BS],EC
,EC,aBlend);}}if(!this.BF||(this.BF.BD<1))return;if(!C8){if(!Dm)DL=(Bd/2)|0;else
DL=(this.BF.BD-1)*Dm;C8=((Bd-DL)/this.BF.BD)|0;if(C8<1)C8=1;}if(!Dm){DL=this.BF.
BD*C8;if(this.BF.BD>1)Dm=((Bd-DL)/(this.BF.BD-1))|0;if(Dm<0)Dm=0;}DL=(this.BF.BD
*C8)+((this.BF.BD-1)*Dm);GM=((Bd-DL)/2)|0;var BA=this.BF.Fx;while(!!BA){GF=HC+GM;
HP=(Gv+Bb)-(((BA.I2*Bb)/this.G4)|0);HQ=GF+C8;HR=Gv+Bb;Bw=BA.H2;if(CD<256)Bw=(Bw&
0x00FFFFFF)|((((((Bw>>24)&0xFF)*CD)>>8)&0xFF)<<24);if(((Bw>>24)&0xFF)>0){if(!!this.
GQ&&(this.HZ>=0))Az.Jv(aClip,this.GQ,this.HZ,[GF,HP,HQ,HR],0x1F,Bw,Bw,Bw,Bw,aBlend
);else Az.FS(aClip,[GF,HP,HQ,HR],Bw,Bw,Bw,Bw,aBlend);}GM=(GM+C8)+Dm;BA=BA.U;}},IM:
function(C){var B;if(C<1)C=1;if(C===this.G4)return;this.G4=C;this.AN([0,0,(B=this.
N)[2]-B[0],B[3]-B[1]]);},IN:function(C){var B;this.BF=C;this.Dr();this.AN([0,0,(
B=this.N)[2]-B[0],B[3]-B[1]]);},_Init:function(aArg){A.Core.Z._Init.call(this,aArg
);A.un.BG._Init.call(this.CR={M:this},0);this.__proto__=E.Bq;this.O(At);this.CR.
Fa(0x3F);this.CR.O(At);this.CR.D6(0xFF202020);this.V(this.CR,0);},_Done:function(
){this.__proto__=A.Core.Z;this.CR._Done();A.Core.Z._Done.call(this);},_ReInit:function(
){A.Core.Z._ReInit.call(this);this.CR._ReInit();},_Mark:function(D){var B;A.Core.
Z._Mark.call(this,D);if((B=this.GQ)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.
BF)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.CR)._cycle!=D)B._Mark(B._cycle=
D);},_className:"Charts::BarChart"};
E._Init=function(){E.Bq.__proto__=A.Core.Z;};E.Au=function(D){};return E;})();

/* Embedded Wizard */