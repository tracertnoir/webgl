/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.Graphics)throw new Error("The unit file 'Graphics.js' included twice!"
);EmWiApp.Graphics=(function(){var B=EmWiApp;var D={};
var Y=[0,0];var Ax="Can not resize explicitly attached graphics engine bitmaps";var
BX=[0,0,0,0];var Ec="No graphics engine bitmap attached to this canvas";var CQ="The canvas is already initialized with a graphics engine bitmap";
D.Canvas={GJ:null,Bn:B.qy,Fr:0,Eh:false,Bz:function(){if(this.Eh)this.DetachBitmap(
);},A5:function(aArg){this.GI=true;},FB:function(C){if((C[0]<=0)||(C[1]<=0))C=Y;
if(B.tl(C,this.FrameSize))return;if(this.Eh)throw new Error(Ax);this.FrameSize=C;
this.DF=(((this.FrameSize[0]>0)&&(this.FrameSize[1]>0))&&(this.FrameDelay>0))&&(
this.NoOfFrames>1);if(!this.bitmap)return;var handle=this.bitmap;B.sW(handle);this.
bitmap=null;},Update:function(){var A;if((!this.bitmap&&(this.FrameSize[0]>0))&&(
this.FrameSize[1]>0)){var frameSize=this.FrameSize;var noOfFrames=this.NoOfFrames;
var frameDelay=this.FrameDelay;var handle=null;{handle=B.nc(B.ch,frameSize,frameDelay
,noOfFrames);}this.bitmap=handle;if(!this.bitmap){this.FrameSize=Y;this.FrameDelay=
0;this.NoOfFrames=1;}this.Bn=[].concat(Y,this.FrameSize);}if(!(((A=this.Bn)[0]>=
A[2])||(A[1]>=A[3]))){if((this.FrameSize[0]>0)&&(this.FrameSize[1]>0))(A=this.GJ
)?A[1].call(A[0],this):null;this.Bn=BX;}},DetachBitmap:function(){if(!this.Eh)throw new
Error(Ec);this.bitmap=null;this.Eh=false;this.FrameSize=Y;this.FrameDelay=0;this.
NoOfFrames=1;this.DF=false;return this;},AttachBitmap:function(aBitmap){if(!!this.
bitmap)throw new Error(CQ);if(!aBitmap)return this;this.bitmap=aBitmap;this.Eh=true;
var noOfFrames=1;var frameSize=Y;var frameDelay=0;{noOfFrames=aBitmap.NoOfFrames;
frameSize=aBitmap.FrameSize;frameDelay=aBitmap.FrameDelay;}this.NoOfFrames=noOfFrames;
this.FrameSize=frameSize;this.FrameDelay=frameDelay;this.DF=(this.FrameDelay>0)&&(
this.NoOfFrames>1);return this;},Gz:function(aClip,FV,aString,aOffset,aCount,aDstRect
,aSrcPos,aMinWidth,FX,aColorTL,aColorTR,aColorBR,aColorBL,aBlend){if(!this.bitmap
)this.Update();if(!this.bitmap)return;if(aOffset<0)aOffset=0;if((!FV||!FV.font)||((
aOffset>0)&&(aOffset>=aString.length)))return;var orient=0;if(FX===1)orient=90;else
if(FX===2)orient=180;else if(FX===3)orient=270;var dstFrameNo=this.Fr;var dstBitmap=
this.bitmap;var srcFont=FV.font;{B.nf(dstBitmap,srcFont,aString,aOffset,aCount,dstFrameNo
,aClip,aDstRect,aSrcPos,aMinWidth,orient,aColorTL,aColorTR,aColorBR,aColorBL,aBlend
);}},Hu:function(aClip,aBitmap,aFrameNr,aDstRect,aSrcPos,aColorTL,aColorTR,aColorBR
,aColorBL,aBlend){if(!this.bitmap)this.Update();if(!this.bitmap)return;if(((!aBitmap||
!aBitmap.bitmap)||(aFrameNr<0))||(aFrameNr>=aBitmap.NoOfFrames))return;var dstBitmap=
this.bitmap;var srcBitmap=aBitmap.bitmap;var dstFrameNr=this.Fr;{B.fF(dstBitmap,
srcBitmap,dstFrameNr,aFrameNr,aClip,aDstRect,aSrcPos,aColorTL,aColorTR,aColorBR,
aColorBL,aBlend);}},Fu:function(aClip,aDstRect,aColorTL,aColorTR,aColorBR,aColorBL
,aBlend){if(!this.bitmap)this.Update();if(!this.bitmap)return;var dstBitmap=this.
bitmap;var dstFrameNo=this.Fr;{B.hn(dstBitmap,dstFrameNo,aClip,aDstRect,aColorTL
,aColorTR,aColorBR,aColorBL,aBlend);}},_Init:function(aArg){B.uk.CK._Init.call(this
,aArg);this.__proto__=D.Canvas;this.A5(aArg);},_Done:function(){this.Bz();this.__proto__=
B.uk.CK;B.uk.CK._Done.call(this);},_Mark:function(E){var A;B.uk.CK._Mark.call(this
,E);if((A=this.GJ)&&((A=A[0])._cycle!=E))A._Mark(A._cycle=E);},_className:"Graphics::Canvas"
};
D._Init=function(){D.Canvas.__proto__=B.uk.CK;};D.Am=function(E){};return D;})();

/* Embedded Wizard */