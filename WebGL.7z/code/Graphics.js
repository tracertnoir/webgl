/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.Graphics)throw new Error("The unit file 'Graphics.js' included twice!"
);EmWiApp.Graphics=(function(){var A=EmWiApp;var E={};
var Ac=[0,0];var Au="Can not resize explicitly attached graphics engine bitmaps";
var Cr=[0,0,0,0];var Du="No graphics engine bitmap attached to this canvas";var EO=
"The canvas is already initialized with a graphics engine bitmap";
E.Canvas={Ic:null,BD:A.qy,E4:0,Ft:false,BT:function(){if(this.Ft)this.DetachBitmap(
);},Bf:function(aArg){this.Ib=true;},G9:function(C){if((C[0]<=0)||(C[1]<=0))C=Ac;
if(A.tl(C,this.FrameSize))return;if(this.Ft)throw new Error(Au);this.FrameSize=C;
this.E1=(((this.FrameSize[0]>0)&&(this.FrameSize[1]>0))&&(this.FrameDelay>0))&&(
this.NoOfFrames>1);if(!this.bitmap)return;var handle=this.bitmap;A.sW(handle);this.
bitmap=null;},Update:function(){var B;if((!this.bitmap&&(this.FrameSize[0]>0))&&(
this.FrameSize[1]>0)){var frameSize=this.FrameSize;var noOfFrames=this.NoOfFrames;
var frameDelay=this.FrameDelay;var handle=null;{handle=A.nc(A.ch,frameSize,frameDelay
,noOfFrames);}this.bitmap=handle;if(!this.bitmap){this.FrameSize=Ac;this.FrameDelay=
0;this.NoOfFrames=1;}this.BD=[].concat(Ac,this.FrameSize);}if(!(((B=this.BD)[0]>=
B[2])||(B[1]>=B[3]))){if((this.FrameSize[0]>0)&&(this.FrameSize[1]>0))(B=this.Ic
)?B[1].call(B[0],this):null;this.BD=Cr;}},DetachBitmap:function(){if(!this.Ft)throw new
Error(Du);this.bitmap=null;this.Ft=false;this.FrameSize=Ac;this.FrameDelay=0;this.
NoOfFrames=1;this.E1=false;return this;},AttachBitmap:function(aBitmap){if(!!this.
bitmap)throw new Error(EO);if(!aBitmap)return this;this.bitmap=aBitmap;this.Ft=true;
var noOfFrames=1;var frameSize=Ac;var frameDelay=0;{noOfFrames=aBitmap.NoOfFrames;
frameSize=aBitmap.FrameSize;frameDelay=aBitmap.FrameDelay;}this.NoOfFrames=noOfFrames;
this.FrameSize=frameSize;this.FrameDelay=frameDelay;this.E1=(this.FrameDelay>0)&&(
this.NoOfFrames>1);return this;},H4:function(aClip,Hr,aString,aOffset,aCount,aDstRect
,aSrcPos,aMinWidth,Ht,aColorTL,aColorTR,aColorBR,aColorBL,aBlend){if(!this.bitmap
)this.Update();if(!this.bitmap)return;if(aOffset<0)aOffset=0;if((!Hr||!Hr.font)||((
aOffset>0)&&(aOffset>=aString.length)))return;var orient=0;if(Ht===1)orient=90;else
if(Ht===2)orient=180;else if(Ht===3)orient=270;var dstFrameNo=this.E4;var dstBitmap=
this.bitmap;var srcFont=Hr.font;{A.nf(dstBitmap,srcFont,aString,aOffset,aCount,dstFrameNo
,aClip,aDstRect,aSrcPos,aMinWidth,orient,aColorTL,aColorTR,aColorBR,aColorBL,aBlend
);}},Jw:function(aClip,aBitmap,aFrameNr,aDstRect,EP,aColorTL,aColorTR,aColorBR,aColorBL
,aBlend){var B;if(!this.bitmap)this.Update();if(!this.bitmap)return;if((((!aBitmap||
!aBitmap.bitmap)||!EP)||(aFrameNr<0))||(aFrameNr>=aBitmap.NoOfFrames))return;var
dstBitmap=this.bitmap;var srcBitmap=aBitmap.bitmap;var dstFrameNo=this.E4;var srcRect=[
].concat(Ac,aBitmap.FrameSize);var left=((EP&0x1)===0x1);var top=((EP&0x2)===0x2
);var right=((EP&0x4)===0x4);var bottom=((EP&0x8)===0x8);var interior=((EP&0x10)===
0x10);{A.sQ(dstBitmap,srcBitmap,dstFrameNo,aFrameNr,aClip,aDstRect,srcRect,left,
top,right,bottom,interior,aColorTL,aColorTR,aColorBR,aColorBL,aBlend);}},Js:function(
aClip,aBitmap,aFrameNr,aDstRect,aSrcPos,aColorTL,aColorTR,aColorBR,aColorBL,aBlend
){if(!this.bitmap)this.Update();if(!this.bitmap)return;if(((!aBitmap||!aBitmap.bitmap
)||(aFrameNr<0))||(aFrameNr>=aBitmap.NoOfFrames))return;var dstBitmap=this.bitmap;
var srcBitmap=aBitmap.bitmap;var dstFrameNr=this.E4;{A.fF(dstBitmap,srcBitmap,dstFrameNr
,aFrameNr,aClip,aDstRect,aSrcPos,aColorTL,aColorTR,aColorBR,aColorBL,aBlend);}},
FT:function(aClip,aDstRect,aColorTL,aColorTR,aColorBR,aColorBL,aBlend){if(!this.
bitmap)this.Update();if(!this.bitmap)return;var dstBitmap=this.bitmap;var dstFrameNo=
this.E4;{A.hn(dstBitmap,dstFrameNo,aClip,aDstRect,aColorTL,aColorTR,aColorBR,aColorBL
,aBlend);}},Jx:function(aClip,aDstPos1,aDstPos2,aColor1,aColor2,aBlend){if(!this.
bitmap)this.Update();if(!this.bitmap)return;var dstBitmap=this.bitmap;var dstFrameNo=
this.E4;{A.sS(dstBitmap,dstFrameNo,aClip,aDstPos1,aDstPos2,aColor1,aColor2,aBlend
);}},_Init:function(aArg){A.ul.Dm._Init.call(this,aArg);this.__proto__=E.Canvas;
this.Bf(aArg);},_Done:function(){this.BT();this.__proto__=A.ul.Dm;A.ul.Dm._Done.
call(this);},_Mark:function(D){var B;A.ul.Dm._Mark.call(this,D);if((B=this.Ic)&&((
B=B[0])._cycle!=D))B._Mark(B._cycle=D);},_className:"Graphics::Canvas"};E.L8={Left:
0x1,MB:0x2,Right:0x4,L3:0x8,Mc:0x10};
E._Init=function(){E.Canvas.__proto__=A.ul.Dm;};E.Av=function(D){};return E;})();

/* Embedded Wizard */