/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiCompr_9_30;var EmWiApp;if(!EmWiCompr_9_30)throw new Error("The Embedded Wizard runtime environment file 'emwi_compr_9_30.js' isn't yet loaded!"
);if(EmWiApp)throw new Error("The application file '_project.js' included twice!"
);EmWiApp=(function(){var A={__proto__:EmWiCompr_9_30};
A.Default=0;
A.tS=[1200,768];A.m7=function(){return A.ia.GN;};A.sy="";A.lg=0;A.ue=0;A.hs=[];A.
_Init=function(){A.Core._Init();A.uq._Init();A.Graphics._Init();A.ul._Init();A.un.
_Init();A.ia._Init();A.um._Init();A.Device._Init();A.up._Init();A.ur._Init();A.ui.
_Init();A.uo._Init();A.uj._Init();A.uk._Init();this.__proto__._Init.apply(this,arguments
);};A.tQ=function(D){A.Core.Au(D);A.uq.Au(D);A.Graphics.Au(D);A.ul.Au(D);A.un.Au(
D);A.ia.Au(D);A.um.Au(D);A.Device.Au(D);A.up.Au(D);A.ur.Au(D);A.ui.Au(D);A.uo.Au(
D);A.uj.Au(D);A.uk.Au(D);};return A;})();

/* Embedded Wizard */