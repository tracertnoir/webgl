/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiCompr_9_30;var EmWiApp;if(!EmWiCompr_9_30)throw new Error("The Embedded Wizard runtime environment file 'emwi_compr_9_30.js' isn't yet loaded!"
);if(EmWiApp)throw new Error("The application file '_project.js' included twice!"
);EmWiApp=(function(){var B={__proto__:EmWiCompr_9_30};
B.Default=0;
B.tS=[1024,768];B.m7=function(){return B.ia.Fg;};B.sy="";B.lg=0;B.ue=0;B.hs=[];B.
_Init=function(){B.Core._Init();B.uq._Init();B.Graphics._Init();B.uk._Init();B.um.
_Init();B.ia._Init();B.ul._Init();B.Device._Init();B.uo._Init();B.ur._Init();B.un.
_Init();B.up._Init();B.ui._Init();B.uj._Init();this.__proto__._Init.apply(this,arguments
);};B.tQ=function(E){B.Core.Am(E);B.uq.Am(E);B.Graphics.Am(E);B.uk.Am(E);B.um.Am(
E);B.ia.Am(E);B.ul.Am(E);B.Device.Am(E);B.uo.Am(E);B.ur.Am(E);B.un.Am(E);B.up.Am(
E);B.ui.Am(E);B.uj.Am(E);};return B;})();

/* Embedded Wizard */