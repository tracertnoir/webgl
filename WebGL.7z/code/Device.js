/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.Device)throw new Error("The unit file 'Device.js' included twice!");
EmWiApp.Device=(function(){var B=EmWiApp;var D={};
var Z="Sorry, but this device is not able to ring the bell!";
D.Bc={DE:B.hm,D5:B.hm,D8:B.hm,D4:B.hm,DV:B.hm,D2:B.hm,Ec:B.hm,DW:0,DT:0,Cq:0,Cp:0
,GG:0,GE:0,DX:0,DU:0,D_:0,D$:0,Ea:0,Eb:0,EX:function(){if(this.K&&this.K.EX)return this.
K.EX.apply(this,arguments);else return this.I5.apply(this,arguments);},I5:function(
){B.uf("%s",Z);},EY:function(){if(this.K&&this.K.EY)return this.K.EY.apply(this,
arguments);else return this.I6.apply(this,arguments);},I6:function(){B.uf("%s",Z
);},Dw:function(C){if(this.K&&this.K.Dw)return this.K.Dw.apply(this,arguments);else
return this.IZ.apply(this,arguments);},IZ:function(C){if(this.DE===C)return;this.
DE=C;},G3:function(){return this.DE;},Du:function(C){if(this.K&&this.K.Du)return this.
K.Du.apply(this,arguments);else return this.IX.apply(this,arguments);},IX:function(
C){if(this.D5===C)return;this.D5=C;},G1:function(){return this.D5;},Dv:function(
C){if(this.K&&this.K.Dv)return this.K.Dv.apply(this,arguments);else return this.
IY.apply(this,arguments);},IY:function(C){if(this.D8===C)return;this.D8=C;},G2:function(
){return this.D8;},Dt:function(C){if(this.K&&this.K.Dt)return this.K.Dt.apply(this
,arguments);else return this.IW.apply(this,arguments);},IW:function(C){if(this.D4===
C)return;this.D4=C;},G0:function(){return this.D4;},Dm:function(C){if(this.K&&this.
K.Dm)return this.K.Dm.apply(this,arguments);else return this.IQ.apply(this,arguments
);},IQ:function(C){if(this.DV===C)return;this.DV=C;},GU:function(){return this.DV;
},Ds:function(C){if(this.K&&this.K.Ds)return this.K.Ds.apply(this,arguments);else
return this.IV.apply(this,arguments);},IV:function(C){if(this.D2===C)return;this.
D2=C;},GZ:function(){return this.D2;},DC:function(C){if(this.K&&this.K.DC)return this.
K.DC.apply(this,arguments);else return this.I4.apply(this,arguments);},I4:function(
C){if(this.Ec===C)return;this.Ec=C;},G8:function(){return this.Ec;},Dn:function(
C){if(this.K&&this.K.Dn)return this.K.Dn.apply(this,arguments);else return this.
IR.apply(this,arguments);},IR:function(C){if(this.DW===C)return;this.DW=C;},GV:function(
){return this.DW;},Di:function(C){if(this.K&&this.K.Di)return this.K.Di.apply(this
,arguments);else return this.IM.apply(this,arguments);},IM:function(C){if(this.DT===
C)return;this.DT=C;},GQ:function(){return this.DT;},Do:function(C){if(this.K&&this.
K.Do)return this.K.Do.apply(this,arguments);else return this.IS.apply(this,arguments
);},IS:function(C){if(this.Cq===C)return;this.Cq=C;},GW:function(){return this.Cq;
},Dj:function(C){if(this.K&&this.K.Dj)return this.K.Dj.apply(this,arguments);else
return this.IN.apply(this,arguments);},IN:function(C){if(this.Cp===C)return;this.
Cp=C;},GR:function(){return this.Cp;},Dp:function(C){if(this.K&&this.K.Dp)return this.
K.Dp.apply(this,arguments);else return this.IT.apply(this,arguments);},IT:function(
C){if(this.Cq===C)return;this.Cq=C;},GX:function(){return this.Cq;},Dk:function(
C){if(this.K&&this.K.Dk)return this.K.Dk.apply(this,arguments);else return this.
IO.apply(this,arguments);},IO:function(C){if(this.Cp===C)return;this.Cp=C;},GS:function(
){return this.Cp;},Dq:function(C){if(this.K&&this.K.Dq)return this.K.Dq.apply(this
,arguments);else return this.IU.apply(this,arguments);},IU:function(C){if(this.DX===
C)return;this.DX=C;},GY:function(){return this.DX;},Dl:function(C){if(this.K&&this.
K.Dl)return this.K.Dl.apply(this,arguments);else return this.IP.apply(this,arguments
);},IP:function(C){if(this.DU===C)return;this.DU=C;},GT:function(){return this.DU;
},Dy:function(C){if(this.K&&this.K.Dy)return this.K.Dy.apply(this,arguments);else
return this.I0.apply(this,arguments);},I0:function(C){if(this.D_===C)return;this.
D_=C;},G4:function(){return this.D_;},Dz:function(C){if(this.K&&this.K.Dz)return this.
K.Dz.apply(this,arguments);else return this.I1.apply(this,arguments);},I1:function(
C){if(this.D$===C)return;this.D$=C;},G5:function(){return this.D$;},DA:function(
C){if(this.K&&this.K.DA)return this.K.DA.apply(this,arguments);else return this.
I2.apply(this,arguments);},I2:function(C){if(this.Ea===C)return;this.Ea=C;},G6:function(
){return this.Ea;},DB:function(C){if(this.K&&this.K.DB)return this.K.DB.apply(this
,arguments);else return this.I3.apply(this,arguments);},I3:function(C){if(this.Eb===
C)return;this.Eb=C;},G7:function(){return this.Eb;},_Init:function(aArg){B.ul.Bc.
_Init.call(this,aArg);this.__proto__=D.Bc;var He=this._variants();if(He){this.K={
};He._Init.call(this,aArg);}},_Done:function(){if(this.K)this.K._Done.call(this);
this.__proto__=B.ul.Bc;B.ul.Bc._Done.call(this);},_ReInit:function(){B.ul.Bc._ReInit.
call(this);if(this.K)this.K._ReInit.call(this);},_Mark:function(E){B.ul.Bc._Mark.
call(this,E);if(this.K)this.K._Mark(E);},_variants:function(){return B.uo.Bc._variants(
);},K:null,_className:"Device::DeviceClass"};D.Device={_Init:function(){D.Bc._Init.
call(this,0);},_variants:function(){return this;},_this:null};
D._Init=function(){D.Bc.__proto__=B.ul.Bc;};D.An=function(E){var A;if((A=D.Device.
_this)&&(A._cycle!=E))A._Done(D.Device._this=null);};return D;})();

/* Embedded Wizard */