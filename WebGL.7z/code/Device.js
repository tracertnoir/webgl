/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.Device)throw new Error("The unit file 'Device.js' included twice!");
EmWiApp.Device=(function(){var A=EmWiApp;var E={};
var Ab="Sorry, but this device is not able to ring the bell!";
E.Bn={G9:A.hm,Gt:A.hm,G7:A.hm,Gq:A.hm,Gl:A.hm,Go:A.hm,G$:A.hm,EU:0,EP:0,EV:0,EQ:0
,EW:0,ER:0,EX:0,ES:0,Fp:0,Fq:0,Fr:0,Fs:0,E9:0,E_:0,E$:0,Fa:0,Fb:0,Fc:0,Fd:0,Fe:0
,E1:0,E2:0,E3:0,E4:0,E5:0,E6:0,E7:0,E8:0,Fw:function(){if(this.AW&&this.AW.Fw)return this.
AW.Fw.apply(this,arguments);else return this.KZ.apply(this,arguments);},KZ:function(
){A.uf("%s",Ab);},Fx:function(){if(this.AW&&this.AW.Fx)return this.AW.Fx.apply(this
,arguments);else return this.K0.apply(this,arguments);},K0:function(){A.uf("%s",
Ab);},G0:function(C){if(this.G9===C)return;this.G9=C;A.tG([this,this.ID,this.G0]
,0);},ID:function(){return this.G9;},GY:function(C){if(this.Gt===C)return;this.Gt=
C;A.tG([this,this.IB,this.GY],0);},IB:function(){return this.Gt;},GZ:function(C){
if(this.G7===C)return;this.G7=C;A.tG([this,this.IC,this.GZ],0);},IC:function(){return this.
G7;},GX:function(C){if(this.Gq===C)return;this.Gq=C;A.tG([this,this.IA,this.GX],
0);},IA:function(){return this.Gq;},GA:function(C){if(this.Gl===C)return;this.Gl=
C;A.tG([this,this.Ie,this.GA],0);},Ie:function(){return this.Gl;},GW:function(C){
if(this.Go===C)return;this.Go=C;A.tG([this,this.Iz,this.GW],0);},Iz:function(){return this.
Go;},G5:function(C){if(this.G$===C)return;this.G$=C;A.tG([this,this.II,this.G5],
0);},II:function(){return this.G$;},GB:function(C){if(this.EU===C)return;this.EU=
C;A.tG([this,this.If,this.GB],0);},If:function(){return this.EU;},Gw:function(C){
if(this.EP===C)return;this.EP=C;A.tG([this,this.Ia,this.Gw],0);},Ia:function(){return this.
EP;},GC:function(C){if(this.EV===C)return;this.EV=C;A.tG([this,this.Ig,this.GC],
0);},Ig:function(){return this.EV;},Gx:function(C){if(this.EQ===C)return;this.EQ=
C;A.tG([this,this.Ib,this.Gx],0);},Ib:function(){return this.EQ;},GD:function(C){
if(this.EW===C)return;this.EW=C;A.tG([this,this.Ih,this.GD],0);},Ih:function(){return this.
EW;},Gy:function(C){if(this.ER===C)return;this.ER=C;A.tG([this,this.Ic,this.Gy],
0);},Ic:function(){return this.ER;},GE:function(C){if(this.EX===C)return;this.EX=
C;A.tG([this,this.Ii,this.GE],0);},Ii:function(){return this.EX;},Gz:function(C){
if(this.ES===C)return;this.ES=C;A.tG([this,this.Id,this.Gz],0);},Id:function(){return this.
ES;},G1:function(C){if(this.Fp===C)return;this.Fp=C;A.tG([this,this.IE,this.G1],
0);},IE:function(){return this.Fp;},G2:function(C){if(this.Fq===C)return;this.Fq=
C;A.tG([this,this.IF,this.G2],0);},IF:function(){return this.Fq;},G3:function(C){
if(this.Fr===C)return;this.Fr=C;A.tG([this,this.IG,this.G3],0);},IG:function(){return this.
Fr;},G4:function(C){if(this.Fs===C)return;this.Fs=C;A.tG([this,this.IH,this.G4],
0);},IH:function(){return this.Fs;},GO:function(C){if(this.E9===C)return;this.E9=
C;A.tG([this,this.Ir,this.GO],0);},Ir:function(){return this.E9;},GP:function(C){
if(this.E_===C)return;this.E_=C;A.tG([this,this.Is,this.GP],0);},Is:function(){return this.
E_;},GQ:function(C){if(this.E$===C)return;this.E$=C;A.tG([this,this.It,this.GQ],
0);},It:function(){return this.E$;},GR:function(C){if(this.Fa===C)return;this.Fa=
C;A.tG([this,this.Iu,this.GR],0);},Iu:function(){return this.Fa;},GS:function(C){
if(this.Fb===C)return;this.Fb=C;A.tG([this,this.Iv,this.GS],0);},Iv:function(){return this.
Fb;},GT:function(C){if(this.Fc===C)return;this.Fc=C;A.tG([this,this.Iw,this.GT],
0);},Iw:function(){return this.Fc;},GU:function(C){if(this.Fd===C)return;this.Fd=
C;A.tG([this,this.Ix,this.GU],0);},Ix:function(){return this.Fd;},GV:function(C){
if(this.Fe===C)return;this.Fe=C;A.tG([this,this.Iy,this.GV],0);},Iy:function(){return this.
Fe;},GG:function(C){if(this.E1===C)return;this.E1=C;A.tG([this,this.Ij,this.GG],
0);},Ij:function(){return this.E1;},GH:function(C){if(this.E2===C)return;this.E2=
C;A.tG([this,this.Ik,this.GH],0);},Ik:function(){return this.E2;},GI:function(C){
if(this.E3===C)return;this.E3=C;A.tG([this,this.Il,this.GI],0);},Il:function(){return this.
E3;},GJ:function(C){if(this.E4===C)return;this.E4=C;A.tG([this,this.Im,this.GJ],
0);},Im:function(){return this.E4;},GK:function(C){if(this.E5===C)return;this.E5=
C;A.tG([this,this.In,this.GK],0);},In:function(){return this.E5;},GL:function(C){
if(this.E6===C)return;this.E6=C;A.tG([this,this.Io,this.GL],0);},Io:function(){return this.
E6;},GM:function(C){if(this.E7===C)return;this.E7=C;A.tG([this,this.Ip,this.GM],
0);},Ip:function(){return this.E7;},GN:function(C){if(this.E8===C)return;this.E8=
C;A.tG([this,this.Iq,this.GN],0);},Iq:function(){return this.E8;},_Init:function(
aArg){A.um.Bn._Init.call(this,aArg);this.__proto__=E.Bn;var I5=this._variants();
if(I5){this.AW={};I5._Init.call(this,aArg);}},_Done:function(){if(this.AW)this.AW.
_Done.call(this);this.__proto__=A.um.Bn;A.um.Bn._Done.call(this);},_ReInit:function(
){A.um.Bn._ReInit.call(this);if(this.AW)this.AW._ReInit.call(this);},_Mark:function(
D){A.um.Bn._Mark.call(this,D);if(this.AW)this.AW._Mark(D);},_variants:function(){
return A.up.Bn._variants();},AW:null,_className:"Device::DeviceClass"};E.Device={
_Init:function(){E.Bn._Init.call(this,0);},_variants:function(){return this;},_this:
null};
E._Init=function(){E.Bn.__proto__=A.um.Bn;};E.Au=function(D){var B;if((B=E.Device.
_this)&&(B._cycle!=D))B._Done(E.Device._this=null);};return E;})();

/* Embedded Wizard */