/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.Device)throw new Error("The unit file 'Device.js' included twice!");
EmWiApp.Device=(function(){var B=EmWiApp;var D={};
var Z="Sorry, but this device is not able to ring the bell!";
D.Bf={DV:B.hm,En:B.hm,Er:B.hm,Em:B.hm,Ef:B.hm,Ek:B.hm,Et:B.hm,Dw:0,Dt:0,Cp:0,Co:0
,He:0,Hc:0,Dx:0,Du:0,DW:0,DX:0,DY:0,DZ:0,Fg:function(){if(this.L&&this.L.Fg)return this.
L.Fg.apply(this,arguments);else return this.JM.apply(this,arguments);},JM:function(
){B.uf("%s",Z);},Fh:function(){if(this.L&&this.L.Fh)return this.L.Fh.apply(this,
arguments);else return this.JN.apply(this,arguments);},JN:function(){B.uf("%s",Z
);},DN:function(C){if(this.L&&this.L.DN)return this.L.DN.apply(this,arguments);else
return this.JG.apply(this,arguments);},JG:function(C){if(this.DV===C)return;this.
DV=C;},Hz:function(){return this.DV;},DL:function(C){if(this.L&&this.L.DL)return this.
L.DL.apply(this,arguments);else return this.JE.apply(this,arguments);},JE:function(
C){if(this.En===C)return;this.En=C;},Hx:function(){return this.En;},DM:function(
C){if(this.L&&this.L.DM)return this.L.DM.apply(this,arguments);else return this.
JF.apply(this,arguments);},JF:function(C){if(this.Er===C)return;this.Er=C;},Hy:function(
){return this.Er;},DK:function(C){if(this.L&&this.L.DK)return this.L.DK.apply(this
,arguments);else return this.JD.apply(this,arguments);},JD:function(C){if(this.Em===
C)return;this.Em=C;},Hw:function(){return this.Em;},DD:function(C){if(this.L&&this.
L.DD)return this.L.DD.apply(this,arguments);else return this.Jx.apply(this,arguments
);},Jx:function(C){if(this.Ef===C)return;this.Ef=C;},Hr:function(){return this.Ef;
},DJ:function(C){if(this.L&&this.L.DJ)return this.L.DJ.apply(this,arguments);else
return this.JC.apply(this,arguments);},JC:function(C){if(this.Ek===C)return;this.
Ek=C;},Hv:function(){return this.Ek;},DT:function(C){if(this.L&&this.L.DT)return this.
L.DT.apply(this,arguments);else return this.JL.apply(this,arguments);},JL:function(
C){if(this.Et===C)return;this.Et=C;},HE:function(){return this.Et;},DE:function(
C){if(this.L&&this.L.DE)return this.L.DE.apply(this,arguments);else return this.
Jy.apply(this,arguments);},Jy:function(C){if(this.Dw===C)return;this.Dw=C;},Hs:function(
){return this.Dw;},Dz:function(C){if(this.L&&this.L.Dz)return this.L.Dz.apply(this
,arguments);else return this.Jt.apply(this,arguments);},Jt:function(C){if(this.Dt===
C)return;this.Dt=C;},Ho:function(){return this.Dt;},DF:function(C){if(this.L&&this.
L.DF)return this.L.DF.apply(this,arguments);else return this.Jz.apply(this,arguments
);},Jz:function(C){if(this.Cp===C)return;this.Cp=C;},Ht:function(){return this.Cp;
},DA:function(C){if(this.L&&this.L.DA)return this.L.DA.apply(this,arguments);else
return this.Ju.apply(this,arguments);},Ju:function(C){if(this.Co===C)return;this.
Co=C;},Hp:function(){return this.Co;},DG:function(C){if(this.L&&this.L.DG)return this.
L.DG.apply(this,arguments);else return this.JA.apply(this,arguments);},JA:function(
C){if(this.Cp===C)return;this.Cp=C;},Gd:function(){return this.Cp;},DB:function(
C){if(this.L&&this.L.DB)return this.L.DB.apply(this,arguments);else return this.
Jv.apply(this,arguments);},Jv:function(C){if(this.Co===C)return;this.Co=C;},Gc:function(
){return this.Co;},DH:function(C){if(this.L&&this.L.DH)return this.L.DH.apply(this
,arguments);else return this.JB.apply(this,arguments);},JB:function(C){if(this.Dx===
C)return;this.Dx=C;},Hu:function(){return this.Dx;},DC:function(C){if(this.L&&this.
L.DC)return this.L.DC.apply(this,arguments);else return this.Jw.apply(this,arguments
);},Jw:function(C){if(this.Du===C)return;this.Du=C;},Hq:function(){return this.Du;
},DP:function(C){if(this.L&&this.L.DP)return this.L.DP.apply(this,arguments);else
return this.JH.apply(this,arguments);},JH:function(C){if(this.DW===C)return;this.
DW=C;},HA:function(){return this.DW;},DQ:function(C){if(this.L&&this.L.DQ)return this.
L.DQ.apply(this,arguments);else return this.JI.apply(this,arguments);},JI:function(
C){if(this.DX===C)return;this.DX=C;},HB:function(){return this.DX;},DR:function(
C){if(this.L&&this.L.DR)return this.L.DR.apply(this,arguments);else return this.
JJ.apply(this,arguments);},JJ:function(C){if(this.DY===C)return;this.DY=C;},HC:function(
){return this.DY;},DS:function(C){if(this.L&&this.L.DS)return this.L.DS.apply(this
,arguments);else return this.JK.apply(this,arguments);},JK:function(C){if(this.DZ===
C)return;this.DZ=C;},HD:function(){return this.DZ;},_Init:function(aArg){B.um.Bf.
_Init.call(this,aArg);this.__proto__=D.Bf;var HM=this._variants();if(HM){this.L={
};HM._Init.call(this,aArg);}},_Done:function(){if(this.L)this.L._Done.call(this);
this.__proto__=B.um.Bf;B.um.Bf._Done.call(this);},_ReInit:function(){B.um.Bf._ReInit.
call(this);if(this.L)this.L._ReInit.call(this);},_Mark:function(E){B.um.Bf._Mark.
call(this,E);if(this.L)this.L._Mark(E);},_variants:function(){return B.up.Bf._variants(
);},L:null,_className:"Device::DeviceClass"};D.Device={_Init:function(){D.Bf._Init.
call(this,0);},_variants:function(){return this;},_this:null};
D._Init=function(){D.Bf.__proto__=B.um.Bf;};D.Ao=function(E){var A;if((A=D.Device.
_this)&&(A._cycle!=E))A._Done(D.Device._this=null);};return D;})();

/* Embedded Wizard */