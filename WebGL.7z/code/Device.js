/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.Device)throw new Error("The unit file 'Device.js' included twice!");
EmWiApp.Device=(function(){var A=EmWiApp;var E={};
var Ac="Sorry, but this device is not able to ring the bell!";
E.Bl={EH:A.hm,E$:A.hm,Fd:A.hm,E_:A.hm,E3:A.hm,E8:A.hm,Fj:A.hm,DQ:0,DN:0,CG:0,CF:0
,H5:0,H3:0,DR:0,DO:0,EI:0,EJ:0,EK:0,EL:0,Dp:0,D0:0,D1:0,D2:0,D3:0,D4:0,D5:0,FV:0
,DS:0,DT:0,DU:0,DV:0,DW:0,DX:0,DY:0,DZ:0,Gh:function(){if(this.H&&this.H.Gh)return this.
H.Gh.apply(this,arguments);else return this.Lw.apply(this,arguments);},Lw:function(
){A.uf("%s",Ac);},Gi:function(){if(this.H&&this.H.Gi)return this.H.Gi.apply(this
,arguments);else return this.Lx.apply(this,arguments);},Lx:function(){A.uf("%s",
Ac);},Ez:function(C){if(this.H&&this.H.Ez)return this.H.Ez.apply(this,arguments);
else return this.Lq.apply(this,arguments);},Lq:function(C){if(this.EH===C)return;
this.EH=C;},ID:function(){return this.EH;},Ex:function(C){if(this.H&&this.H.Ex)return this.
H.Ex.apply(this,arguments);else return this.Lo.apply(this,arguments);},Lo:function(
C){if(this.E$===C)return;this.E$=C;},IB:function(){return this.E$;},Ey:function(
C){if(this.H&&this.H.Ey)return this.H.Ey.apply(this,arguments);else return this.
Lp.apply(this,arguments);},Lp:function(C){if(this.Fd===C)return;this.Fd=C;},IC:function(
){return this.Fd;},Ew:function(C){if(this.H&&this.H.Ew)return this.H.Ew.apply(this
,arguments);else return this.Ln.apply(this,arguments);},Ln:function(C){if(this.E_===
C)return;this.E_=C;},IA:function(){return this.E_;},D$:function(C){if(this.H&&this.
H.D$)return this.H.D$.apply(this,arguments);else return this.K3.apply(this,arguments
);},K3:function(C){if(this.E3===C)return;this.E3=C;},Ig:function(){return this.E3;
},Ev:function(C){if(this.H&&this.H.Ev)return this.H.Ev.apply(this,arguments);else
return this.Lm.apply(this,arguments);},Lm:function(C){if(this.E8===C)return;this.
E8=C;},Iz:function(){return this.E8;},EF:function(C){if(this.H&&this.H.EF)return this.
H.EF.apply(this,arguments);else return this.Lv.apply(this,arguments);},Lv:function(
C){if(this.Fj===C)return;this.Fj=C;},II:function(){return this.Fj;},Ea:function(
C){if(this.H&&this.H.Ea)return this.H.Ea.apply(this,arguments);else return this.
K4.apply(this,arguments);},K4:function(C){if(this.DQ===C)return;this.DQ=C;},Ih:function(
){return this.DQ;},D7:function(C){if(this.H&&this.H.D7)return this.H.D7.apply(this
,arguments);else return this.KZ.apply(this,arguments);},KZ:function(C){if(this.DN===
C)return;this.DN=C;},Id:function(){return this.DN;},Eb:function(C){if(this.H&&this.
H.Eb)return this.H.Eb.apply(this,arguments);else return this.K5.apply(this,arguments
);},K5:function(C){if(this.CG===C)return;this.CG=C;},Ii:function(){return this.CG;
},D8:function(C){if(this.H&&this.H.D8)return this.H.D8.apply(this,arguments);else
return this.K0.apply(this,arguments);},K0:function(C){if(this.CF===C)return;this.
CF=C;},Ie:function(){return this.CF;},Ec:function(C){if(this.H&&this.H.Ec)return this.
H.Ec.apply(this,arguments);else return this.K6.apply(this,arguments);},K6:function(
C){if(this.CG===C)return;this.CG=C;},G7:function(){return this.CG;},D9:function(
C){if(this.H&&this.H.D9)return this.H.D9.apply(this,arguments);else return this.
K1.apply(this,arguments);},K1:function(C){if(this.CF===C)return;this.CF=C;},G6:function(
){return this.CF;},Ed:function(C){if(this.H&&this.H.Ed)return this.H.Ed.apply(this
,arguments);else return this.K7.apply(this,arguments);},K7:function(C){if(this.DR===
C)return;this.DR=C;},Ij:function(){return this.DR;},D_:function(C){if(this.H&&this.
H.D_)return this.H.D_.apply(this,arguments);else return this.K2.apply(this,arguments
);},K2:function(C){if(this.DO===C)return;this.DO=C;},If:function(){return this.DO;
},EB:function(C){if(this.H&&this.H.EB)return this.H.EB.apply(this,arguments);else
return this.Lr.apply(this,arguments);},Lr:function(C){if(this.EI===C)return;this.
EI=C;},IE:function(){return this.EI;},EC:function(C){if(this.H&&this.H.EC)return this.
H.EC.apply(this,arguments);else return this.Ls.apply(this,arguments);},Ls:function(
C){if(this.EJ===C)return;this.EJ=C;},IF:function(){return this.EJ;},ED:function(
C){if(this.H&&this.H.ED)return this.H.ED.apply(this,arguments);else return this.
Lt.apply(this,arguments);},Lt:function(C){if(this.EK===C)return;this.EK=C;},IG:function(
){return this.EK;},EE:function(C){if(this.H&&this.H.EE)return this.H.EE.apply(this
,arguments);else return this.Lu.apply(this,arguments);},Lu:function(C){if(this.EL===
C)return;this.EL=C;},IH:function(){return this.EL;},En:function(C){if(this.H&&this.
H.En)return this.H.En.apply(this,arguments);else return this.Le.apply(this,arguments
);},Le:function(C){if(this.Dp===C)return;this.Dp=C;},Is:function(){return this.Dp;
},Eo:function(C){if(this.H&&this.H.Eo)return this.H.Eo.apply(this,arguments);else
return this.Lf.apply(this,arguments);},Lf:function(C){if(this.D0===C)return;this.
D0=C;},It:function(){return this.D0;},Ep:function(C){if(this.H&&this.H.Ep)return this.
H.Ep.apply(this,arguments);else return this.Lg.apply(this,arguments);},Lg:function(
C){if(this.D1===C)return;this.D1=C;},Iu:function(){return this.D1;},Eq:function(
C){if(this.H&&this.H.Eq)return this.H.Eq.apply(this,arguments);else return this.
Lh.apply(this,arguments);},Lh:function(C){if(this.D2===C)return;this.D2=C;},Iv:function(
){return this.D2;},Er:function(C){if(this.H&&this.H.Er)return this.H.Er.apply(this
,arguments);else return this.Li.apply(this,arguments);},Li:function(C){if(this.D3===
C)return;this.D3=C;},Iw:function(){return this.D3;},Es:function(C){if(this.H&&this.
H.Es)return this.H.Es.apply(this,arguments);else return this.Lj.apply(this,arguments
);},Lj:function(C){if(this.D4===C)return;this.D4=C;},Ix:function(){return this.D4;
},Et:function(C){if(this.H&&this.H.Et)return this.H.Et.apply(this,arguments);else
return this.Lk.apply(this,arguments);},Lk:function(C){if(this.D5===C)return;this.
D5=C;},Iy:function(){return this.D5;},Eu:function(C){if(this.H&&this.H.Eu)return this.
H.Eu.apply(this,arguments);else return this.Ll.apply(this,arguments);},Ll:function(
C){if(this.FV===C)return;this.FV=C;},G8:function(){return this.Dp;},Ef:function(
C){if(this.H&&this.H.Ef)return this.H.Ef.apply(this,arguments);else return this.
K8.apply(this,arguments);},K8:function(C){if(this.DS===C)return;this.DS=C;},Ik:function(
){return this.DS;},Eg:function(C){if(this.H&&this.H.Eg)return this.H.Eg.apply(this
,arguments);else return this.K9.apply(this,arguments);},K9:function(C){if(this.DT===
C)return;this.DT=C;},Il:function(){return this.DT;},Eh:function(C){if(this.H&&this.
H.Eh)return this.H.Eh.apply(this,arguments);else return this.K_.apply(this,arguments
);},K_:function(C){if(this.DU===C)return;this.DU=C;},Im:function(){return this.DU;
},Ei:function(C){if(this.H&&this.H.Ei)return this.H.Ei.apply(this,arguments);else
return this.K$.apply(this,arguments);},K$:function(C){if(this.DV===C)return;this.
DV=C;},In:function(){return this.DV;},Ej:function(C){if(this.H&&this.H.Ej)return this.
H.Ej.apply(this,arguments);else return this.La.apply(this,arguments);},La:function(
C){if(this.DW===C)return;this.DW=C;},Io:function(){return this.DW;},Ek:function(
C){if(this.H&&this.H.Ek)return this.H.Ek.apply(this,arguments);else return this.
Lb.apply(this,arguments);},Lb:function(C){if(this.DX===C)return;this.DX=C;},Ip:function(
){return this.DX;},El:function(C){if(this.H&&this.H.El)return this.H.El.apply(this
,arguments);else return this.Lc.apply(this,arguments);},Lc:function(C){if(this.DY===
C)return;this.DY=C;},Iq:function(){return this.DY;},Em:function(C){if(this.H&&this.
H.Em)return this.H.Em.apply(this,arguments);else return this.Ld.apply(this,arguments
);},Ld:function(C){if(this.DZ===C)return;this.DZ=C;},Ir:function(){return this.DZ;
},_Init:function(aArg){A.um.Bl._Init.call(this,aArg);this.__proto__=E.Bl;var I4=
this._variants();if(I4){this.H={};I4._Init.call(this,aArg);}},_Done:function(){if(
this.H)this.H._Done.call(this);this.__proto__=A.um.Bl;A.um.Bl._Done.call(this);}
,_ReInit:function(){A.um.Bl._ReInit.call(this);if(this.H)this.H._ReInit.call(this
);},_Mark:function(D){A.um.Bl._Mark.call(this,D);if(this.H)this.H._Mark(D);},_variants:
function(){return A.up.Bl._variants();},H:null,_className:"Device::DeviceClass"};
E.Device={_Init:function(){E.Bl._Init.call(this,0);},_variants:function(){return this;
},_this:null};
E._Init=function(){E.Bl.__proto__=A.um.Bl;};E.Au=function(D){var B;if((B=E.Device.
_this)&&(B._cycle!=D))B._Done(E.Device._this=null);};return E;})();

/* Embedded Wizard */