/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.Device)throw new Error("The unit file 'Device.js' included twice!");
EmWiApp.Device=(function(){var A=EmWiApp;var E={};
var Ab="Sorry, but this device is not able to ring the bell!";
E.Bn={Ha:A.hm,Gw:A.hm,G_:A.hm,Gt:A.hm,Go:A.hm,Gr:A.hm,Hc:A.hm,Gn:A.hm,EV:0,EQ:0,EW:
0,ER:0,EX:0,ES:0,EY:0,ET:0,Fr:0,Fs:0,Ft:0,Fu:0,E_:0,E$:0,Fa:0,Fb:0,Fc:0,Fd:0,Fe:
0,Ff:0,E2:0,E3:0,E4:0,E5:0,E6:0,E7:0,E8:0,E9:0,Fy:function(){if(this.AW&&this.AW.
Fy)return this.AW.Fy.apply(this,arguments);else return this.K5.apply(this,arguments
);},K5:function(){A.uf("%s",Ab);},Fz:function(){if(this.AW&&this.AW.Fz)return this.
AW.Fz.apply(this,arguments);else return this.K6.apply(this,arguments);},K6:function(
){A.uf("%s",Ab);},G4:function(C){if(this.Ha===C)return;this.Ha=C;A.tG([this,this.
IH,this.G4],0);},IH:function(){return this.Ha;},G2:function(C){if(this.Gw===C)return;
this.Gw=C;A.tG([this,this.IF,this.G2],0);},IF:function(){return this.Gw;},G3:function(
C){if(this.G_===C)return;this.G_=C;A.tG([this,this.IG,this.G3],0);},IG:function(
){return this.G_;},G1:function(C){if(this.Gt===C)return;this.Gt=C;A.tG([this,this.
IE,this.G1],0);},IE:function(){return this.Gt;},GE:function(C){if(this.Go===C)return;
this.Go=C;A.tG([this,this.Ii,this.GE],0);},Ii:function(){return this.Go;},G0:function(
C){if(this.Gr===C)return;this.Gr=C;A.tG([this,this.ID,this.G0],0);},ID:function(
){return this.Gr;},G9:function(C){if(this.Hc===C)return;this.Hc=C;A.tG([this,this.
IM,this.G9],0);},IM:function(){return this.Hc;},GF:function(C){if(this.EV===C)return;
this.EV=C;A.tG([this,this.Ij,this.GF],0);},Ij:function(){return this.EV;},Gz:function(
C){if(this.EQ===C)return;this.EQ=C;A.tG([this,this.Id,this.Gz],0);},Id:function(
){return this.EQ;},GG:function(C){if(this.EW===C)return;this.EW=C;A.tG([this,this.
Ik,this.GG],0);},Ik:function(){return this.EW;},GA:function(C){if(this.ER===C)return;
this.ER=C;A.tG([this,this.Ie,this.GA],0);},Ie:function(){return this.ER;},GH:function(
C){if(this.EX===C)return;this.EX=C;A.tG([this,this.Il,this.GH],0);},Il:function(
){return this.EX;},GB:function(C){if(this.ES===C)return;this.ES=C;A.tG([this,this.
If,this.GB],0);},If:function(){return this.ES;},GI:function(C){if(this.EY===C)return;
this.EY=C;A.tG([this,this.Im,this.GI],0);},Im:function(){return this.EY;},GC:function(
C){if(this.ET===C)return;this.ET=C;A.tG([this,this.Ig,this.GC],0);},Ig:function(
){return this.ET;},G5:function(C){if(this.Fr===C)return;this.Fr=C;A.tG([this,this.
II,this.G5],0);},II:function(){return this.Fr;},G6:function(C){if(this.Fs===C)return;
this.Fs=C;A.tG([this,this.IJ,this.G6],0);},IJ:function(){return this.Fs;},G7:function(
C){if(this.Ft===C)return;this.Ft=C;A.tG([this,this.IK,this.G7],0);},IK:function(
){return this.Ft;},G8:function(C){if(this.Fu===C)return;this.Fu=C;A.tG([this,this.
IL,this.G8],0);},IL:function(){return this.Fu;},GS:function(C){if(this.E_===C)return;
this.E_=C;A.tG([this,this.Iv,this.GS],0);},Iv:function(){return this.E_;},GT:function(
C){if(this.E$===C)return;this.E$=C;A.tG([this,this.Iw,this.GT],0);},Iw:function(
){return this.E$;},GU:function(C){if(this.Fa===C)return;this.Fa=C;A.tG([this,this.
Ix,this.GU],0);},Ix:function(){return this.Fa;},GV:function(C){if(this.Fb===C)return;
this.Fb=C;A.tG([this,this.Iy,this.GV],0);},Iy:function(){return this.Fb;},GW:function(
C){if(this.Fc===C)return;this.Fc=C;A.tG([this,this.Iz,this.GW],0);},Iz:function(
){return this.Fc;},GX:function(C){if(this.Fd===C)return;this.Fd=C;A.tG([this,this.
IA,this.GX],0);},IA:function(){return this.Fd;},GY:function(C){if(this.Fe===C)return;
this.Fe=C;A.tG([this,this.IB,this.GY],0);},IB:function(){return this.Fe;},GZ:function(
C){if(this.Ff===C)return;this.Ff=C;A.tG([this,this.IC,this.GZ],0);},IC:function(
){return this.Ff;},GK:function(C){if(this.E2===C)return;this.E2=C;A.tG([this,this.
In,this.GK],0);},In:function(){return this.E2;},GL:function(C){if(this.E3===C)return;
this.E3=C;A.tG([this,this.Io,this.GL],0);},Io:function(){return this.E3;},GM:function(
C){if(this.E4===C)return;this.E4=C;A.tG([this,this.Ip,this.GM],0);},Ip:function(
){return this.E4;},GN:function(C){if(this.E5===C)return;this.E5=C;A.tG([this,this.
Iq,this.GN],0);},Iq:function(){return this.E5;},GO:function(C){if(this.E6===C)return;
this.E6=C;A.tG([this,this.Ir,this.GO],0);},Ir:function(){return this.E6;},GP:function(
C){if(this.E7===C)return;this.E7=C;A.tG([this,this.Is,this.GP],0);},Is:function(
){return this.E7;},GQ:function(C){if(this.E8===C)return;this.E8=C;A.tG([this,this.
It,this.GQ],0);},It:function(){return this.E8;},GR:function(C){if(this.E9===C)return;
this.E9=C;A.tG([this,this.Iu,this.GR],0);},Iu:function(){return this.E9;},GD:function(
C){if(this.Gn===C)return;this.Gn=C;A.tG([this,this.Ih,this.GD],0);},Ih:function(
){return this.Gn;},_Init:function(aArg){A.um.Bn._Init.call(this,aArg);this.__proto__=
E.Bn;var I9=this._variants();if(I9){this.AW={};I9._Init.call(this,aArg);}},_Done:
function(){if(this.AW)this.AW._Done.call(this);this.__proto__=A.um.Bn;A.um.Bn._Done.
call(this);},_ReInit:function(){A.um.Bn._ReInit.call(this);if(this.AW)this.AW._ReInit.
call(this);},_Mark:function(D){A.um.Bn._Mark.call(this,D);if(this.AW)this.AW._Mark(
D);},_variants:function(){return A.up.Bn._variants();},AW:null,_className:"Device::DeviceClass"
};E.Device={_Init:function(){E.Bn._Init.call(this,0);},_variants:function(){return this;
},_this:null};
E._Init=function(){E.Bn.__proto__=A.um.Bn;};E.Au=function(D){var B;if((B=E.Device.
_this)&&(B._cycle!=D))B._Done(E.Device._this=null);};return E;})();

/* Embedded Wizard */