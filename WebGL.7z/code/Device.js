/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.Device)throw new Error("The unit file 'Device.js' included twice!");
EmWiApp.Device=(function(){var B=EmWiApp;var D={};
var Ac="Sorry, but this device is not able to ring the bell!";
D.A$={D4:B.hm,DF:B.hm,D1:B.hm,DE:B.hm,Dv:B.hm,DC:B.hm,D9:B.hm,Dw:0,Dt:0,Ck:0,Cj:0
,Gy:0,Gw:0,Dx:0,Du:0,D5:0,D6:0,D7:0,D8:0,EP:function(){if(this.J&&this.J.EP)return this.
J.EP.apply(this,arguments);else return this.IV.apply(this,arguments);},IV:function(
){B.uf("%s",Ac);},DT:function(C){if(this.J&&this.J.DT)return this.J.DT.apply(this
,arguments);else return this.IP.apply(this,arguments);},IP:function(C){if(this.D4===
C)return;this.D4=C;},GV:function(){return this.D4;},DR:function(C){if(this.J&&this.
J.DR)return this.J.DR.apply(this,arguments);else return this.IN.apply(this,arguments
);},IN:function(C){if(this.DF===C)return;this.DF=C;},GT:function(){return this.DF;
},DS:function(C){if(this.J&&this.J.DS)return this.J.DS.apply(this,arguments);else
return this.IO.apply(this,arguments);},IO:function(C){if(this.D1===C)return;this.
D1=C;},GU:function(){return this.D1;},DQ:function(C){if(this.J&&this.J.DQ)return this.
J.DQ.apply(this,arguments);else return this.IM.apply(this,arguments);},IM:function(
C){if(this.DE===C)return;this.DE=C;},GS:function(){return this.DE;},DK:function(
C){if(this.J&&this.J.DK)return this.J.DK.apply(this,arguments);else return this.
IG.apply(this,arguments);},IG:function(C){if(this.Dv===C)return;this.Dv=C;},GM:function(
){return this.Dv;},DP:function(C){if(this.J&&this.J.DP)return this.J.DP.apply(this
,arguments);else return this.IL.apply(this,arguments);},IL:function(C){if(this.DC===
C)return;this.DC=C;},GR:function(){return this.DC;},DY:function(C){if(this.J&&this.
J.DY)return this.J.DY.apply(this,arguments);else return this.IU.apply(this,arguments
);},IU:function(C){if(this.D9===C)return;this.D9=C;},G0:function(){return this.D9;
},DL:function(C){if(this.J&&this.J.DL)return this.J.DL.apply(this,arguments);else
return this.IH.apply(this,arguments);},IH:function(C){if(this.Dw===C)return;this.
Dw=C;},GN:function(){return this.Dw;},DG:function(C){if(this.J&&this.J.DG)return this.
J.DG.apply(this,arguments);else return this.IC.apply(this,arguments);},IC:function(
C){if(this.Dt===C)return;this.Dt=C;},GI:function(){return this.Dt;},DM:function(
C){if(this.J&&this.J.DM)return this.J.DM.apply(this,arguments);else return this.
II.apply(this,arguments);},II:function(C){if(this.Ck===C)return;this.Ck=C;},GO:function(
){return this.Ck;},DH:function(C){if(this.J&&this.J.DH)return this.J.DH.apply(this
,arguments);else return this.ID.apply(this,arguments);},ID:function(C){if(this.Cj===
C)return;this.Cj=C;},GJ:function(){return this.Cj;},DN:function(C){if(this.J&&this.
J.DN)return this.J.DN.apply(this,arguments);else return this.IJ.apply(this,arguments
);},IJ:function(C){if(this.Ck===C)return;this.Ck=C;},GP:function(){return this.Ck;
},DI:function(C){if(this.J&&this.J.DI)return this.J.DI.apply(this,arguments);else
return this.IE.apply(this,arguments);},IE:function(C){if(this.Cj===C)return;this.
Cj=C;},GK:function(){return this.Cj;},DO:function(C){if(this.J&&this.J.DO)return this.
J.DO.apply(this,arguments);else return this.IK.apply(this,arguments);},IK:function(
C){if(this.Dx===C)return;this.Dx=C;},GQ:function(){return this.Dx;},DJ:function(
C){if(this.J&&this.J.DJ)return this.J.DJ.apply(this,arguments);else return this.
IF.apply(this,arguments);},IF:function(C){if(this.Du===C)return;this.Du=C;},GL:function(
){return this.Du;},DU:function(C){if(this.J&&this.J.DU)return this.J.DU.apply(this
,arguments);else return this.IQ.apply(this,arguments);},IQ:function(C){if(this.D5===
C)return;this.D5=C;},GW:function(){return this.D5;},DV:function(C){if(this.J&&this.
J.DV)return this.J.DV.apply(this,arguments);else return this.IR.apply(this,arguments
);},IR:function(C){if(this.D6===C)return;this.D6=C;},GX:function(){return this.D6;
},DW:function(C){if(this.J&&this.J.DW)return this.J.DW.apply(this,arguments);else
return this.IS.apply(this,arguments);},IS:function(C){if(this.D7===C)return;this.
D7=C;},GY:function(){return this.D7;},DX:function(C){if(this.J&&this.J.DX)return this.
J.DX.apply(this,arguments);else return this.IT.apply(this,arguments);},IT:function(
C){if(this.D8===C)return;this.D8=C;},GZ:function(){return this.D8;},_Init:function(
aArg){B.ul.A$._Init.call(this,aArg);this.__proto__=D.A$;var G7=this._variants();
if(G7){this.J={};G7._Init.call(this,aArg);}},_Done:function(){if(this.J)this.J._Done.
call(this);this.__proto__=B.ul.A$;B.ul.A$._Done.call(this);},_ReInit:function(){
B.ul.A$._ReInit.call(this);if(this.J)this.J._ReInit.call(this);},_Mark:function(
E){B.ul.A$._Mark.call(this,E);if(this.J)this.J._Mark(E);},_variants:function(){return B.
uo.A$._variants();},J:null,_className:"Device::DeviceClass"};D.Device={_Init:function(
){D.A$._Init.call(this,0);},_variants:function(){return this;},_this:null};
D._Init=function(){D.A$.__proto__=B.ul.A$;};D.Am=function(E){var A;if((A=D.Device.
_this)&&(A._cycle!=E))A._Done(D.Device._this=null);};return D;})();

/* Embedded Wizard */