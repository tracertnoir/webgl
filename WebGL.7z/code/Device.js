/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.Device)throw new Error("The unit file 'Device.js' included twice!");
EmWiApp.Device=(function(){var B=EmWiApp;var D={};
var Y="Sorry, but this device is not able to ring the bell!";
D.A$={Ds:B.hm,DU:B.hm,D3:B.hm,DT:B.hm,DK:B.hm,DR:B.hm,D_:B.hm,DL:0,DI:0,Cl:0,Ck:0
,GA:0,Gy:0,DM:0,DJ:0,D6:0,D7:0,D8:0,D9:0,ES:function(){if(this.J&&this.J.ES)return this.
J.ES.apply(this,arguments);else return this.IZ.apply(this,arguments);},IZ:function(
){B.uf("%s",Y);},ET:function(){if(this.J&&this.J.ET)return this.J.ET.apply(this,
arguments);else return this.I0.apply(this,arguments);},I0:function(){B.uf("%s",Y
);},Do:function(C){if(this.J&&this.J.Do)return this.J.Do.apply(this,arguments);else
return this.IT.apply(this,arguments);},IT:function(C){if(this.Ds===C)return;this.
Ds=C;},GX:function(){return this.Ds;},Dm:function(C){if(this.J&&this.J.Dm)return this.
J.Dm.apply(this,arguments);else return this.IR.apply(this,arguments);},IR:function(
C){if(this.DU===C)return;this.DU=C;},GV:function(){return this.DU;},Dn:function(
C){if(this.J&&this.J.Dn)return this.J.Dn.apply(this,arguments);else return this.
IS.apply(this,arguments);},IS:function(C){if(this.D3===C)return;this.D3=C;},GW:function(
){return this.D3;},Dl:function(C){if(this.J&&this.J.Dl)return this.J.Dl.apply(this
,arguments);else return this.IQ.apply(this,arguments);},IQ:function(C){if(this.DT===
C)return;this.DT=C;},GU:function(){return this.DT;},Df:function(C){if(this.J&&this.
J.Df)return this.J.Df.apply(this,arguments);else return this.IK.apply(this,arguments
);},IK:function(C){if(this.DK===C)return;this.DK=C;},GO:function(){return this.DK;
},Dk:function(C){if(this.J&&this.J.Dk)return this.J.Dk.apply(this,arguments);else
return this.IP.apply(this,arguments);},IP:function(C){if(this.DR===C)return;this.
DR=C;},GT:function(){return this.DR;},Dq:function(C){if(this.J&&this.J.Dq)return this.
J.Dq.apply(this,arguments);else return this.IY.apply(this,arguments);},IY:function(
C){if(this.D_===C)return;this.D_=C;},G2:function(){return this.D_;},Dg:function(
C){if(this.J&&this.J.Dg)return this.J.Dg.apply(this,arguments);else return this.
IL.apply(this,arguments);},IL:function(C){if(this.DL===C)return;this.DL=C;},GP:function(
){return this.DL;},Dc:function(C){if(this.J&&this.J.Dc)return this.J.Dc.apply(this
,arguments);else return this.IG.apply(this,arguments);},IG:function(C){if(this.DI===
C)return;this.DI=C;},GK:function(){return this.DI;},Dh:function(C){if(this.J&&this.
J.Dh)return this.J.Dh.apply(this,arguments);else return this.IM.apply(this,arguments
);},IM:function(C){if(this.Cl===C)return;this.Cl=C;},GQ:function(){return this.Cl;
},Dd:function(C){if(this.J&&this.J.Dd)return this.J.Dd.apply(this,arguments);else
return this.IH.apply(this,arguments);},IH:function(C){if(this.Ck===C)return;this.
Ck=C;},GL:function(){return this.Ck;},Di:function(C){if(this.J&&this.J.Di)return this.
J.Di.apply(this,arguments);else return this.IN.apply(this,arguments);},IN:function(
C){if(this.Cl===C)return;this.Cl=C;},GR:function(){return this.Cl;},De:function(
C){if(this.J&&this.J.De)return this.J.De.apply(this,arguments);else return this.
II.apply(this,arguments);},II:function(C){if(this.Ck===C)return;this.Ck=C;},GM:function(
){return this.Ck;},DW:function(C){if(this.J&&this.J.DW)return this.J.DW.apply(this
,arguments);else return this.IO.apply(this,arguments);},IO:function(C){if(this.DM===
C)return;this.DM=C;},GS:function(){return this.DM;},DV:function(C){if(this.J&&this.
J.DV)return this.J.DV.apply(this,arguments);else return this.IJ.apply(this,arguments
);},IJ:function(C){if(this.DJ===C)return;this.DJ=C;},GN:function(){return this.DJ;
},DX:function(C){if(this.J&&this.J.DX)return this.J.DX.apply(this,arguments);else
return this.IU.apply(this,arguments);},IU:function(C){if(this.D6===C)return;this.
D6=C;},GY:function(){return this.D6;},DY:function(C){if(this.J&&this.J.DY)return this.
J.DY.apply(this,arguments);else return this.IV.apply(this,arguments);},IV:function(
C){if(this.D7===C)return;this.D7=C;},GZ:function(){return this.D7;},DZ:function(
C){if(this.J&&this.J.DZ)return this.J.DZ.apply(this,arguments);else return this.
IW.apply(this,arguments);},IW:function(C){if(this.D8===C)return;this.D8=C;},G0:function(
){return this.D8;},D0:function(C){if(this.J&&this.J.D0)return this.J.D0.apply(this
,arguments);else return this.IX.apply(this,arguments);},IX:function(C){if(this.D9===
C)return;this.D9=C;},G1:function(){return this.D9;},_Init:function(aArg){B.ul.A$.
_Init.call(this,aArg);this.__proto__=D.A$;var G9=this._variants();if(G9){this.J={
};G9._Init.call(this,aArg);}},_Done:function(){if(this.J)this.J._Done.call(this);
this.__proto__=B.ul.A$;B.ul.A$._Done.call(this);},_ReInit:function(){B.ul.A$._ReInit.
call(this);if(this.J)this.J._ReInit.call(this);},_Mark:function(E){B.ul.A$._Mark.
call(this,E);if(this.J)this.J._Mark(E);},_variants:function(){return B.uo.A$._variants(
);},J:null,_className:"Device::DeviceClass"};D.Device={_Init:function(){D.A$._Init.
call(this,0);},_variants:function(){return this;},_this:null};
D._Init=function(){D.A$.__proto__=B.ul.A$;};D.Am=function(E){var A;if((A=D.Device.
_this)&&(A._cycle!=E))A._Done(D.Device._this=null);};return D;})();

/* Embedded Wizard */