/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.un)throw new Error("The unit file 'Views.js' included twice!");EmWiApp.
un=(function(){var A=EmWiApp;var E={};
var Ac=[0,0];var At="\uFEFF";var Cr=[0,0,0,0];
E.BG={CS:0xFFFFFFFF,CT:0xFFFFFFFF,CW:0xFFFFFFFF,CV:0xFFFFFFFF,BU:function(Az,aClip
,aOffset,AF,aBlend){var B;aBlend=aBlend&&((this.F&0x2)===0x2);AF=AF+1;if(AF<256){
var Cy=this.CV;var Cz=this.CW;var Cw=this.CS;var Cx=this.CT;Cy=(Cy&0x00FFFFFF)|((((
AF*((Cy>>24)&0xFF))>>8)&0xFF)<<24);Cz=(Cz&0x00FFFFFF)|((((AF*((Cz>>24)&0xFF))>>8
)&0xFF)<<24);Cw=(Cw&0x00FFFFFF)|((((AF*((Cw>>24)&0xFF))>>8)&0xFF)<<24);Cx=(Cx&0x00FFFFFF
)|((((AF*((Cx>>24)&0xFF))>>8)&0xFF)<<24);Az.FS(aClip,A.tz(this.N,aOffset),Cy,Cz,
Cx,Cw,aBlend);}else Az.FS(aClip,A.tz(this.N,aOffset),this.CV,this.CW,this.CT,this.
CS,aBlend);},D6:function(C){var B;if((((C===this.CV)&&(C===this.CW))&&(C===this.
CS))&&(C===this.CT))return;this.CV=C;this.CW=C;this.CS=C;this.CT=C;if(!!this.L&&((
this.F&0x1)===0x1))this.L.AN(this.N);},_Init:function(aArg){A.Core.AU._Init.call(
this,aArg);this.__proto__=E.BG;},_className:"Views::Rectangle"};E.Text={AB:null,
Cb:null,Aj:A.hm,String:A.hm,Bh:null,BB:A.qx,Fc:0,Dt:0,CS:0xFFFFFFFF,CT:0xFFFFFFFF
,CW:0xFFFFFFFF,CV:0xFFFFFFFF,Du:0,Fe:A.qx,EY:0x12,Gc:255,EG:0,Gl:false,GP:false,
GX:false,GY:false,Bp:false,BU:function(Az,aClip,aOffset,AF,aBlend){var B;if((this.
Aj===A.hm)||!this.AB)return;var Ag=this.EY;var orient=this.EG;var font=this.AB;var
AD=A.tz(this.N,aOffset);var Cy=this.CV;var Cz=this.CW;var Cx=this.CT;var Cw=this.
CS;var CD=(((AF+1)*this.Gc)>>8)+1;var B9=this.Aj.charCodeAt(0)||0;var T=A.tz(this.
Dq(),aOffset);var Bj=[AD[0]-T[0],(AD[1]-T[1])-font.Ascent];if(B9<1)return;if(CD<
256){Cy=(Cy&0x00FFFFFF)|((((((Cy>>24)&0xFF)*CD)>>8)&0xFF)<<24);Cz=(Cz&0x00FFFFFF
)|((((((Cz>>24)&0xFF)*CD)>>8)&0xFF)<<24);Cx=(Cx&0x00FFFFFF)|((((((Cx>>24)&0xFF)*
CD)>>8)&0xFF)<<24);Cw=(Cw&0x00FFFFFF)|((((((Cw>>24)&0xFF)*CD)>>8)&0xFF)<<24);}if(((
Ag&0x80)===0x80)){if(this.G1())Ag=(Ag&~0x80)|0x4;else Ag=(Ag&~0x80)|0x1;}if(((B9===
1)&&!((Ag&0x40)===0x40))&&!orient){Az.H4(aClip,font,this.Aj,2,(this.Aj.charCodeAt(
1)||0)-1,AD,Bj,0,orient,Cy,Cz,Cx,Cw,true);return;}var leading=font.Leading;if(this.
Dt>0)leading=(this.Dt-font.Ascent)-font.Descent;var HX=(font.Ascent+font.Descent
)+leading;var Gp=aClip[1]-T[1];var Gq=aClip[3]-T[1];var Fr=T[2]-T[0];var BS=0;var
I=1;var A3=this.Aj.charCodeAt(I)||0;if(orient===1){Bj=[T[3]-AD[3],(AD[0]-T[0])-font.
Ascent];Gp=aClip[0]-T[0];Gq=aClip[2]-T[0];Fr=T[3]-T[1];}else if(orient===2){Bj=[
T[2]-AD[2],(T[3]-AD[3])-font.Ascent];Gp=T[3]-aClip[3];Gq=T[3]-aClip[1];}else if(
orient===3){Bj=[AD[1]-T[1],(T[2]-AD[2])-font.Ascent];Gp=T[2]-aClip[2];Gq=T[2]-aClip[
0];Fr=T[3]-T[1];}while(((BS+HX)<Gp)&&(A3>0)){I=I+A3;BS=BS+HX;A3=this.Aj.charCodeAt(
I)||0;}while((BS<Gq)&&(A3>0)){var DG=A.tw(Bj,[0,BS]);var Jo=0;var Gz=false;if(((((
Ag&0x40)===0x40)&&((this.Aj.charCodeAt((I+A3)-1)||0)!==0x0A))&&((this.Aj.charCodeAt(
I+1)||0)!==0x0A))&&((this.Aj.charCodeAt(I+A3)||0)!==0x00))Gz=true;if(Gz&&!!(Ag&0x6
)){var Jn=I+A3;var I$=this.Aj.indexOf(String.fromCharCode(0x20),I+1);var Ja=this.
Aj.indexOf(String.fromCharCode(0xA0),I+1);if(((I$<0)||(I$>=Jn))&&((Ja<0)||(Ja>=Jn
)))Gz=false;}if(Gz)Jo=Fr;else if(((Ag&0x4)===0x4))DG=[(DG[0]-Fr)+font.E4(this.Aj
,I+1,A3-1),DG[1]];else if(((Ag&0x2)===0x2))DG=[(DG[0]-((Fr/2)|0))+((font.E4(this.
Aj,I+1,A3-1)/2)|0),DG[1]];Az.H4(aClip,font,this.Aj,I+1,A3-1,AD,DG,Jo,orient,Cy,Cz
,Cx,Cw,true);I=I+A3;BS=BS+HX;A3=this.Aj.charCodeAt(I)||0;}},O:function(C){var B;
if(A.tm(C,this.N))return;var HV=false;if(!this.EG||(this.EG===2))HV=((B=this.N)[
2]-B[0])!==(C[2]-C[0]);else HV=((B=this.N)[3]-B[1])!==(C[3]-C[1]);if((((HV&&!this.
Du)&&this.Gl)&&this.Bp)&&!((this.F&0x2000)===0x2000)){this.Aj=A.hm;this.Bp=false;
A.lq([this,this.EU],this);}if(((this.GX&&this.Bp)&&!A.tl([(B=this.N)[2]-B[0],B[3
]-B[1]],[C[2]-C[0],C[3]-C[1]]))&&!((this.F&0x2000)===0x2000)){this.Aj=A.hm;this.
Bp=false;A.lq([this,this.EU],this);}A.Core.AU.O.call(this,C);A.lq([this,this.HS]
,this);},BT:function(){if(!!this.Bh){this.HF(this.Bh);this.Bh=null;}},HF:function(
aBidi){if(!aBidi)return;A.ng(aBidi);},LC:function(aSize){var bidi=null;bidi=A.qk(
aSize);return bidi;},HS:function(B_){A.lq(this.Cb,this);},EU:function(B_){A.lq([
this,this.GG],this);},GG:function(B_){var B;if(this.Bp)return;var orient=this.EG;
var width=(B=this.N)[2]-B[0];var height=(B=this.N)[3]-B[1];var Bz=-1;if((orient===
1)||(orient===3)){width=height;height=(B=this.N)[2]-B[0];}if(this.Gl){if(this.Du>
0)Bz=this.Du;else if(!this.GP)Bz=width-(this.Fc*2);else Bz=width;if(Bz<0)Bz=1;}if(
!!this.Bh){this.HF(this.Bh);this.Bh=null;}this.Bp=true;if((this.String!==A.hm)&&
!!this.AB){var length=this.String.length;if(this.GY)this.Bh=this.LC(length);this.
Aj=this.AB.JM(this.String,0,Bz,length,this.Bh);if(!!this.Bh&&!this.JB()){this.HF(
this.Bh);this.Bh=null;}}else this.Aj=A.hm;this.BB=Ac;if(((this.GX&&(this.Aj!==A.
hm))&&!this.GP)&&!!this.AB){var Ag=this.EY;var font=this.AB;var leading=font.Leading;
var Ak=this.Aj;var GJ=this.G1();if(((Ag&0x80)===0x80)){if(GJ)Ag=(Ag&~0x80)|0x4;else
Ag=(Ag&~0x80)|0x1;}if(this.Dt>0)leading=(this.Dt-font.Ascent)-font.Descent;var FI=(
font.Ascent+font.Descent)+leading;var B9=Ak.charCodeAt(0)||0;var Df=((height+leading
)/FI)|0;var HA=false;var Go=false;if(Df<=0)Df=1;if(B9>Df){var BQ=0;var FJ=0;var GI=
B9-1;var AH=0;var AQ=Ak.length;var tmp=A.hm;if(((Ag&0x20)===0x20))FJ=B9-Df;else if(((
Ag&0x10)===0x10)){FJ=((B9-Df)/2)|0;GI=(FJ+Df)-1;}else GI=Df-1;HA=FJ>0;Go=GI<(B9-
1);for(AH=1;BQ<FJ;BQ=BQ+1)AH=AH+(Ak.charCodeAt(AH)||0);if(Go)for(AQ=AH;BQ<GI;BQ=
BQ+1)AQ=AQ+(Ak.charCodeAt(AQ)||0);if(HA){var A0=Ak.charCodeAt(AH)||0;tmp=(At+A.t9(
Ak,AH,A0))+At;tmp=A.t4(tmp,0,(A0+2)&0xFFFF);AH=AH+A0;if((tmp.charCodeAt(A0)||0)===
0x0A){tmp=A.t4(tmp,A0,0xFEFF);tmp=A.t4(tmp,A0+1,0x0A);}if((tmp.charCodeAt(2)||0)===
0x0A){tmp=A.t4(tmp,2,0xFEFF);tmp=A.t4(tmp,1,0x0A);}else tmp=A.t4(tmp,1,0xFEFF);}
tmp=tmp+A.t9(Ak,AH,AQ-AH);if(Go&&(AQ>=AH)){var A0=Ak.charCodeAt(AQ)||0;var A_=(At+
A.t9(Ak,AQ,A0))+At;A_=A.t4(A_,0,(A0+2)&0xFFFF);A_=A.t4(A_,1,0xFEFF);if((A_.charCodeAt(
A0)||0)===0x0A){A_=A.t4(A_,A0,0xFEFF);A_=A.t4(A_,A0+1,0x0A);}if((A_.charCodeAt(2
)||0)===0x0A){A_=A.t4(A_,2,0xFEFF);A_=A.t4(A_,1,0x0A);}else A_=A.t4(A_,1,0xFEFF);
tmp=tmp+A_;}Ak=String.fromCharCode(Df&0xFFFF)+tmp;}var BQ=0;var A6=1;var GD=width-(
this.Fc*2);if(this.Gl&&(this.Du>0))GD=this.Du;B9=Ak.charCodeAt(0)||0;for(;BQ<B9;
BQ=BQ+1){var Dk=HA&&!BQ;var Dl=Go&&(BQ===(B9-1));var Bx=false;var By=false;var EV=
GJ;if((GJ&&Dk)&&!Dl){Dk=false;Dl=true;}else if((GJ&&Dl)&&!Dk){Dl=false;Dk=true;}
var FL=A6+1;var A0=Ak.charCodeAt(A6)||0;var AH=FL;var AQ=(FL+A0)-2;var HJ=-1;var
HK=-1;if(!this.Gl&&(font.E4(Ak,FL,A0-1)>GD)){if(((Ag&0x4)===0x4))Bx=true;else if(((
Ag&0x2)===0x2)){Bx=true;By=true;}else By=true;}if((Ak.charCodeAt(AH)||0)===0x0A)
AH=AH+1;if((Ak.charCodeAt(AQ)||0)===0x0A)AQ=AQ-1;while(Bx&&((Ak.charCodeAt(AH)||
0)===0xFEFF))AH=AH+1;while(By&&((Ak.charCodeAt(AQ)||0)===0xFEFF))AQ=AQ-1;Bx=Bx&&
!Dl;By=By&&!Dk;while((((Bx||By)||Dk)||Dl)&&(AH<AQ)){if((Bx&&(EV||!By))||Dk){if(HJ>
0)Ak=A.t4(Ak,HJ,0xFEFF);Ak=A.t4(Ak,AH,0x2026);HJ=AH;AH=AH+1;EV=!EV;Dk=false;if(font.
E4(Ak,FL,A0-1)<=GD){Bx=false;By=false;}else Bx=Bx||!By;}if((By&&(!EV||!Bx))||Dl){
if(HK>0)Ak=A.t4(Ak,HK,0xFEFF);Ak=A.t4(Ak,AQ,0x2026);HK=AQ;AQ=AQ-1;EV=!EV;Dl=false;
if(font.E4(Ak,FL,A0-1)<=GD){Bx=false;By=false;}else By=By||!Bx;}}A6=A6+A0;}this.
BB=[font.H9(Ak),((Ak.charCodeAt(0)||0)*FI)-leading];this.Aj=Ak;}if(this.GP&&(this.
Aj!==A.hm)){var CP=[this.Fc,0];if((orient===1)||(orient===3)){CP=[CP[0],CP[0]];CP=[
0,CP[1]];}this.F=this.F|0x2000;this.O(A.ty(A.th(this.Dq(),CP),this.Fe));this.F=this.
F&~0x2000;}if(!!this.L&&((this.F&0x1)===0x1))this.L.AN(this.N);A.lq([this,this.HS
],this);},JG:function(C){if(C===this.GY)return;this.GY=C;this.Aj=A.hm;this.Bp=false;
A.lq([this,this.EU],this);},Ga:function(C){if(A.to(C,this.Cb))return;this.Cb=C;if(
!this.Du||!!C)this.F=this.F&~0x100;else this.F=this.F|0x100;},FZ:function(C){var
B;if(C===this.EY)return;this.EY=C;if(!!this.L&&((this.F&0x1)===0x1))this.L.AN(this.
N);if(this.GX){this.Aj=A.hm;this.Bp=false;A.lq([this,this.EU],this);}if(this.Bp)
A.lq([this,this.HS],this);},EA:function(C){if(C===this.String)return;this.String=
C;this.Aj=A.hm;this.Bp=false;A.lq([this,this.EU],this);},F$:function(C){if(C===this.
AB)return;this.AB=C;this.Aj=A.hm;this.Bp=false;A.lq([this,this.EU],this);},D6:function(
C){var B;if((((C===this.CV)&&(C===this.CW))&&(C===this.CS))&&(C===this.CT))return;
this.CV=C;this.CW=C;this.CS=C;this.CT=C;if(!!this.L&&((this.F&0x1)===0x1))this.L.
AN(this.N);},G1:function(){if(!this.Bp)this.GG(this);if(!this.Bh)return false;var
result=false;var bidi=this.Bh;result=A.qj(bidi);return result;},JB:function(){if(
!this.Bp)this.GG(this);if(!this.Bh)return false;var result=false;var bidi=this.Bh;
result=A.sD(bidi);return result;},Dq:function(){var B;if((this.String===A.hm)||!
this.AB)return Cr;if(!this.Bp)this.GG(this);if(this.Aj===A.hm)return Cr;var leading=
this.AB.Leading;var FI=(this.AB.Ascent+this.AB.Descent)+this.AB.Leading;if(this.
Dt>0){leading=(this.Dt-this.AB.Ascent)-this.AB.Descent;FI=this.Dt;}if(A.tl(this.
BB,Ac))this.BB=[this.AB.H9(this.Aj),this.BB[1]];this.BB=[this.BB[0],((this.Aj.charCodeAt(
0)||0)*FI)-leading];var Ag=this.EY;var orient=this.EG;var Ap=this.N;var CP=this.
Fc;var width=Ap[2]-Ap[0];var height=Ap[3]-Ap[1];if((orient===1)||(orient===3)){width=
height;height=Ap[2]-Ap[0];}var AD=[CP,0,width-CP,height];var Ab=[].concat(AD.slice(
0,2),A.tx(AD.slice(0,2),this.BB));if(((Ag&0x80)===0x80)){if(this.G1())Ag=(Ag&~0x80
)|0x4;else Ag=(Ag&~0x80)|0x1;}if(((Ag&0x40)===0x40)){var Bz=this.Du;if(Bz<=0)Bz=
width-(this.Fc*2);if(Bz<0)Bz=0;if(Bz>(Ab[2]-Ab[0]))Ab=A.tZ(Ab,Bz);}if((Ab[2]-Ab[
0])!==(AD[2]-AD[0])){if(((Ag&0x4)===0x4))Ab=A.t0(Ab,AD[2]-(Ab[2]-Ab[0]));else if(((
Ag&0x2)===0x2))Ab=A.t0(Ab,(AD[0]+(((AD[2]-AD[0])/2)|0))-(((Ab[2]-Ab[0])/2)|0));}
if((Ab[3]-Ab[1])!==(AD[3]-AD[1])){if(((Ag&0x20)===0x20))Ab=A.t2(Ab,AD[3]-(Ab[3]-
Ab[1]));else if(((Ag&0x10)===0x10))Ab=A.t2(Ab,(AD[1]+(((AD[3]-AD[1])/2)|0))-(((Ab[
3]-Ab[1])/2)|0));}if(!orient)Ab=A.tz(Ab,Ap.slice(0,2));else if(orient===1){var Di=[
Ap[0]+Ab[1],Ap[3]-Ab[2]];Ab=[].concat(Di,A.tx(Di,[this.BB[1],this.BB[0]]));}else
if(orient===2){var Di=[Ap[2]-Ab[2],Ap[3]-Ab[3]];Ab=[].concat(Di,A.tx(Di,this.BB)
);}else if(orient===3){var Di=[Ap[2]-Ab[3],Ap[1]+Ab[0]];Ab=[].concat(Di,A.tx(Di,[
this.BB[1],this.BB[0]]));}return A.tz(Ab,this.Fe);},_Init:function(aArg){A.Core.
AU._Init.call(this,aArg);this.__proto__=E.Text;},_Done:function(){this.BT();this.
__proto__=A.Core.AU;A.Core.AU._Done.call(this);},_Mark:function(D){var B;A.Core.
AU._Mark.call(this,D);if((B=this.AB)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.
Cb)&&((B=B[0])._cycle!=D))B._Mark(B._cycle=D);},_className:"Views::Text"};E.MA={
LP:0x1,LN:0x2,LQ:0x4,L1:0x8,L0:0x10,LZ:0x20,LO:0x40,LM:0x80};E.EG={Mk:0,Mx:1,Mv:
2,Mw:3};
E._Init=function(){E.BG.__proto__=A.Core.AU;E.Text.__proto__=A.Core.AU;};E.Au=function(
D){};return E;})();

/* Embedded Wizard */