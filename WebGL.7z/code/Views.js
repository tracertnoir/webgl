/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.um)throw new Error("The unit file 'Views.js' included twice!");EmWiApp.
um=(function(){var B=EmWiApp;var D={};
var Y=[0,0];var Ax="\uFEFF";var BX=[0,0,0,0];
D.BA={C8:0xFFFFFFFF,C9:0xFFFFFFFF,C$:0xFFFFFFFF,C_:0xFFFFFFFF,Cb:function(AD,aClip
,aOffset,AE,aBlend){var A;aBlend=aBlend&&((this.F&0x2)===0x2);AE=AE+1;if(AE<256){
var B4=this.C_;var B5=this.C$;var B2=this.C8;var B3=this.C9;B4=(B4&0x00FFFFFF)|((((
AE*((B4>>24)&0xFF))>>8)&0xFF)<<24);B5=(B5&0x00FFFFFF)|((((AE*((B5>>24)&0xFF))>>8
)&0xFF)<<24);B2=(B2&0x00FFFFFF)|((((AE*((B2>>24)&0xFF))>>8)&0xFF)<<24);B3=(B3&0x00FFFFFF
)|((((AE*((B3>>24)&0xFF))>>8)&0xFF)<<24);AD.Fu(aClip,B.tz(this.M,aOffset),B4,B5,
B3,B2,aBlend);}else AD.Fu(aClip,B.tz(this.M,aOffset),this.C_,this.C$,this.C9,this.
C8,aBlend);},_Init:function(aArg){B.Core.AL._Init.call(this,aArg);this.__proto__=
D.BA;},_className:"Views::Rectangle"};D.Text={Aw:null,BK:null,Af:B.hm,String:B.hm
,A8:null,Bl:B.qx,D2:0,CO:0,C8:0xFFFFFFFF,C9:0xFFFFFFFF,C$:0xFFFFFFFF,C_:0xFFFFFFFF
,CP:0,D4:B.qx,DE:0x12,FD:255,Dr:0,EW:false,Fm:false,Fs:false,Ft:false,Bc:false,Cb:
function(AD,aClip,aOffset,AE,aBlend){var A;if((this.Af===B.hm)||!this.Aw)return;
var Ac=this.DE;var orient=this.Dr;var font=this.Aw;var At=B.tz(this.M,aOffset);var
B4=this.C_;var B5=this.C$;var B3=this.C9;var B2=this.C8;var Es=(((AE+1)*this.FD)>>
8)+1;var BG=this.Af.charCodeAt(0)||0;var Q=B.tz(this.CM(),aOffset);var A_=[At[0]-
Q[0],(At[1]-Q[1])-font.Ascent];if(BG<1)return;if(Es<256){B4=(B4&0x00FFFFFF)|((((((
B4>>24)&0xFF)*Es)>>8)&0xFF)<<24);B5=(B5&0x00FFFFFF)|((((((B5>>24)&0xFF)*Es)>>8)&
0xFF)<<24);B3=(B3&0x00FFFFFF)|((((((B3>>24)&0xFF)*Es)>>8)&0xFF)<<24);B2=(B2&0x00FFFFFF
)|((((((B2>>24)&0xFF)*Es)>>8)&0xFF)<<24);}if(((Ac&0x80)===0x80)){if(this.Fx())Ac=(
Ac&~0x80)|0x4;else Ac=(Ac&~0x80)|0x1;}if(((BG===1)&&!((Ac&0x40)===0x40))&&!orient
){AD.Gz(aClip,font,this.Af,2,(this.Af.charCodeAt(1)||0)-1,At,A_,0,orient,B4,B5,B3
,B2,true);return;}var leading=font.Leading;if(this.CO>0)leading=(this.CO-font.Ascent
)-font.Descent;var Gv=(font.Ascent+font.Descent)+leading;var E0=aClip[1]-Q[1];var
E1=aClip[3]-Q[1];var Eg=Q[2]-Q[0];var C7=0;var H=1;var AV=this.Af.charCodeAt(H)||
0;if(orient===1){A_=[Q[3]-At[3],(At[0]-Q[0])-font.Ascent];E0=aClip[0]-Q[0];E1=aClip[
2]-Q[0];Eg=Q[3]-Q[1];}else if(orient===2){A_=[Q[2]-At[2],(Q[3]-At[3])-font.Ascent
];E0=Q[3]-aClip[3];E1=Q[3]-aClip[1];}else if(orient===3){A_=[At[1]-Q[1],(Q[2]-At[
2])-font.Ascent];E0=Q[2]-aClip[2];E1=Q[2]-aClip[0];Eg=Q[3]-Q[1];}while(((C7+Gv)<
E0)&&(AV>0)){H=H+AV;C7=C7+Gv;AV=this.Af.charCodeAt(H)||0;}while((C7<E1)&&(AV>0)){
var C2=B.tw(A_,[0,C7]);var Hs=0;var E9=false;if(((((Ac&0x40)===0x40)&&((this.Af.
charCodeAt((H+AV)-1)||0)!==0x0A))&&((this.Af.charCodeAt(H+1)||0)!==0x0A))&&((this.
Af.charCodeAt(H+AV)||0)!==0x00))E9=true;if(E9&&!!(Ac&0x6)){var Hr=H+AV;var Hd=this.
Af.indexOf(String.fromCharCode(0x20),H+1);var He=this.Af.indexOf(String.fromCharCode(
0xA0),H+1);if(((Hd<0)||(Hd>=Hr))&&((He<0)||(He>=Hr)))E9=false;}if(E9)Hs=Eg;else if(((
Ac&0x4)===0x4))C2=[(C2[0]-Eg)+font.DN(this.Af,H+1,AV-1),C2[1]];else if(((Ac&0x2)===
0x2))C2=[(C2[0]-((Eg/2)|0))+((font.DN(this.Af,H+1,AV-1)/2)|0),C2[1]];AD.Gz(aClip
,font,this.Af,H+1,AV-1,At,C2,Hs,orient,B4,B5,B3,B2,true);H=H+AV;C7=C7+Gv;AV=this.
Af.charCodeAt(H)||0;}},S:function(C){var A;if(B.tm(C,this.M))return;var Gt=false;
if(!this.Dr||(this.Dr===2))Gt=((A=this.M)[2]-A[0])!==(C[2]-C[0]);else Gt=((A=this.
M)[3]-A[1])!==(C[3]-C[1]);if((((Gt&&!this.CP)&&this.EW)&&this.Bc)&&!((this.F&0x2000
)===0x2000)){this.Af=B.hm;this.Bc=false;B.lq([this,this.DA],this);}if(((this.Fs&&
this.Bc)&&!B.tl([(A=this.M)[2]-A[0],A[3]-A[1]],[C[2]-C[0],C[3]-C[1]]))&&!((this.
F&0x2000)===0x2000)){this.Af=B.hm;this.Bc=false;B.lq([this,this.DA],this);}B.Core.
AL.S.call(this,C);B.lq([this,this.Gq],this);},Bz:function(){if(!!this.A8){this.Gf(
this.A8);this.A8=null;}},Gf:function(aBidi){if(!aBidi)return;B.ng(aBidi);},I4:function(
aSize){var bidi=null;bidi=B.qk(aSize);return bidi;},Gq:function(BH){B.lq(this.BK
,this);},DA:function(BH){B.lq([this,this.Fd],this);},Fd:function(BH){var A;if(this.
Bc)return;var orient=this.Dr;var width=(A=this.M)[2]-A[0];var height=(A=this.M)[
3]-A[1];var Bk=-1;if((orient===1)||(orient===3)){width=height;height=(A=this.M)[
2]-A[0];}if(this.EW){if(this.CP>0)Bk=this.CP;else if(!this.Fm)Bk=width-(this.D2*
2);else Bk=width;if(Bk<0)Bk=1;}if(!!this.A8){this.Gf(this.A8);this.A8=null;}this.
Bc=true;if((this.String!==B.hm)&&!!this.Aw){var length=this.String.length;if(this.
Ft)this.A8=this.I4(length);this.Af=this.Aw.HV(this.String,0,Bk,length,this.A8);if(
!!this.A8&&!this.HD()){this.Gf(this.A8);this.A8=null;}}else this.Af=B.hm;this.Bl=
Y;if(((this.Fs&&(this.Af!==B.hm))&&!this.Fm)&&!!this.Aw){var Ac=this.DE;var font=
this.Aw;var leading=font.Leading;var Ag=this.Af;var Fg=this.Fx();if(((Ac&0x80)===
0x80)){if(Fg)Ac=(Ac&~0x80)|0x4;else Ac=(Ac&~0x80)|0x1;}if(this.CO>0)leading=(this.
CO-font.Ascent)-font.Descent;var Ev=(font.Ascent+font.Descent)+leading;var BG=Ag.
charCodeAt(0)||0;var CD=((height+leading)/Ev)|0;var Gb=false;var EZ=false;if(CD<=
0)CD=1;if(BG>CD){var Bx=0;var Ew=0;var Ff=BG-1;var Az=0;var AI=Ag.length;var tmp=
B.hm;if(((Ac&0x20)===0x20))Ew=BG-CD;else if(((Ac&0x10)===0x10)){Ew=((BG-CD)/2)|0;
Ff=(Ew+CD)-1;}else Ff=CD-1;Gb=Ew>0;EZ=Ff<(BG-1);for(Az=1;Bx<Ew;Bx=Bx+1)Az=Az+(Ag.
charCodeAt(Az)||0);if(EZ)for(AI=Az;Bx<Ff;Bx=Bx+1)AI=AI+(Ag.charCodeAt(AI)||0);if(
Gb){var AQ=Ag.charCodeAt(Az)||0;tmp=(Ax+B.t9(Ag,Az,AQ))+Ax;tmp=B.t4(tmp,0,(AQ+2)&
0xFFFF);Az=Az+AQ;if((tmp.charCodeAt(AQ)||0)===0x0A){tmp=B.t4(tmp,AQ,0xFEFF);tmp=
B.t4(tmp,AQ+1,0x0A);}if((tmp.charCodeAt(2)||0)===0x0A){tmp=B.t4(tmp,2,0xFEFF);tmp=
B.t4(tmp,1,0x0A);}else tmp=B.t4(tmp,1,0xFEFF);}tmp=tmp+B.t9(Ag,Az,AI-Az);if(EZ&&(
AI>=Az)){var AQ=Ag.charCodeAt(AI)||0;var A2=(Ax+B.t9(Ag,AI,AQ))+Ax;A2=B.t4(A2,0,(
AQ+2)&0xFFFF);A2=B.t4(A2,1,0xFEFF);if((A2.charCodeAt(AQ)||0)===0x0A){A2=B.t4(A2,
AQ,0xFEFF);A2=B.t4(A2,AQ+1,0x0A);}if((A2.charCodeAt(2)||0)===0x0A){A2=B.t4(A2,2,
0xFEFF);A2=B.t4(A2,1,0x0A);}else A2=B.t4(A2,1,0xFEFF);tmp=tmp+A2;}Ag=String.fromCharCode(
CD&0xFFFF)+tmp;}var Bx=0;var AX=1;var Fb=width-(this.D2*2);if(this.EW&&(this.CP>
0))Fb=this.CP;BG=Ag.charCodeAt(0)||0;for(;Bx<BG;Bx=Bx+1){var CI=Gb&&!Bx;var CJ=EZ&&(
Bx===(BG-1));var Bh=false;var Bi=false;var DB=Fg;if((Fg&&CI)&&!CJ){CI=false;CJ=true;
}else if((Fg&&CJ)&&!CI){CJ=false;CI=true;}var Ey=AX+1;var AQ=Ag.charCodeAt(AX)||
0;var Az=Ey;var AI=(Ey+AQ)-2;var Gj=-1;var Gk=-1;if(!this.EW&&(font.DN(Ag,Ey,AQ-
1)>Fb)){if(((Ac&0x4)===0x4))Bh=true;else if(((Ac&0x2)===0x2)){Bh=true;Bi=true;}else
Bi=true;}if((Ag.charCodeAt(Az)||0)===0x0A)Az=Az+1;if((Ag.charCodeAt(AI)||0)===0x0A
)AI=AI-1;while(Bh&&((Ag.charCodeAt(Az)||0)===0xFEFF))Az=Az+1;while(Bi&&((Ag.charCodeAt(
AI)||0)===0xFEFF))AI=AI-1;Bh=Bh&&!CJ;Bi=Bi&&!CI;while((((Bh||Bi)||CI)||CJ)&&(Az<
AI)){if((Bh&&(DB||!Bi))||CI){if(Gj>0)Ag=B.t4(Ag,Gj,0xFEFF);Ag=B.t4(Ag,Az,0x2026);
Gj=Az;Az=Az+1;DB=!DB;CI=false;if(font.DN(Ag,Ey,AQ-1)<=Fb){Bh=false;Bi=false;}else
Bh=Bh||!Bi;}if((Bi&&(!DB||!Bh))||CJ){if(Gk>0)Ag=B.t4(Ag,Gk,0xFEFF);Ag=B.t4(Ag,AI
,0x2026);Gk=AI;AI=AI-1;DB=!DB;CJ=false;if(font.DN(Ag,Ey,AQ-1)<=Fb){Bh=false;Bi=false;
}else Bi=Bi||!Bh;}}AX=AX+AQ;}this.Bl=[font.GE(Ag),((Ag.charCodeAt(0)||0)*Ev)-leading
];this.Af=Ag;}if(this.Fm&&(this.Af!==B.hm)){var Cj=[this.D2,0];if((orient===1)||(
orient===3)){Cj=[Cj[0],Cj[0]];Cj=[0,Cj[1]];}this.F=this.F|0x2000;this.S(B.ty(B.th(
this.CM(),Cj),this.D4));this.F=this.F&~0x2000;}if(!!this.K&&((this.F&0x1)===0x1)
)this.K.AT(this.M);B.lq([this,this.Gq],this);},HI:function(C){if(C===this.Ft)return;
this.Ft=C;this.Af=B.hm;this.Bc=false;B.lq([this,this.DA],this);},EN:function(C){
if(B.to(C,this.BK))return;this.BK=C;if(!this.CP||!!C)this.F=this.F&~0x100;else this.
F=this.F|0x100;},EI:function(C){var A;if(C===this.DE)return;this.DE=C;if(!!this.
K&&((this.F&0x1)===0x1))this.K.AT(this.M);if(this.Fs){this.Af=B.hm;this.Bc=false;
B.lq([this,this.DA],this);}if(this.Bc)B.lq([this,this.Gq],this);},Dp:function(C){
if(C===this.String)return;this.String=C;this.Af=B.hm;this.Bc=false;B.lq([this,this.
DA],this);},EL:function(C){if(C===this.Aw)return;this.Aw=C;this.Af=B.hm;this.Bc=
false;B.lq([this,this.DA],this);},EJ:function(C){var A;if((((C===this.C_)&&(C===
this.C$))&&(C===this.C8))&&(C===this.C9))return;this.C_=C;this.C$=C;this.C8=C;this.
C9=C;if(!!this.K&&((this.F&0x1)===0x1))this.K.AT(this.M);},Fx:function(){if(!this.
Bc)this.Fd(this);if(!this.A8)return false;var result=false;var bidi=this.A8;result=
B.qj(bidi);return result;},HD:function(){if(!this.Bc)this.Fd(this);if(!this.A8)return false;
var result=false;var bidi=this.A8;result=B.sD(bidi);return result;},CM:function(
){var A;if((this.String===B.hm)||!this.Aw)return BX;if(!this.Bc)this.Fd(this);if(
this.Af===B.hm)return BX;var leading=this.Aw.Leading;var Ev=(this.Aw.Ascent+this.
Aw.Descent)+this.Aw.Leading;if(this.CO>0){leading=(this.CO-this.Aw.Ascent)-this.
Aw.Descent;Ev=this.CO;}if(B.tl(this.Bl,Y))this.Bl=[this.Aw.GE(this.Af),this.Bl[1
]];this.Bl=[this.Bl[0],((this.Af.charCodeAt(0)||0)*Ev)-leading];var Ac=this.DE;var
orient=this.Dr;var Ai=this.M;var Cj=this.D2;var width=Ai[2]-Ai[0];var height=Ai[
3]-Ai[1];if((orient===1)||(orient===3)){width=height;height=Ai[2]-Ai[0];}var At=[
Cj,0,width-Cj,height];var V=[].concat(At.slice(0,2),B.tx(At.slice(0,2),this.Bl));
if(((Ac&0x80)===0x80)){if(this.Fx())Ac=(Ac&~0x80)|0x4;else Ac=(Ac&~0x80)|0x1;}if(((
Ac&0x40)===0x40)){var Bk=this.CP;if(Bk<=0)Bk=width-(this.D2*2);if(Bk<0)Bk=0;if(Bk>(
V[2]-V[0]))V=B.tZ(V,Bk);}if((V[2]-V[0])!==(At[2]-At[0])){if(((Ac&0x4)===0x4))V=B.
t0(V,At[2]-(V[2]-V[0]));else if(((Ac&0x2)===0x2))V=B.t0(V,(At[0]+(((At[2]-At[0])
/2)|0))-(((V[2]-V[0])/2)|0));}if((V[3]-V[1])!==(At[3]-At[1])){if(((Ac&0x20)===0x20
))V=B.t2(V,At[3]-(V[3]-V[1]));else if(((Ac&0x10)===0x10))V=B.t2(V,(At[1]+(((At[3
]-At[1])/2)|0))-(((V[3]-V[1])/2)|0));}if(!orient)V=B.tz(V,Ai.slice(0,2));else if(
orient===1){var CG=[Ai[0]+V[1],Ai[3]-V[2]];V=[].concat(CG,B.tx(CG,[this.Bl[1],this.
Bl[0]]));}else if(orient===2){var CG=[Ai[2]-V[2],Ai[3]-V[3]];V=[].concat(CG,B.tx(
CG,this.Bl));}else if(orient===3){var CG=[Ai[2]-V[3],Ai[1]+V[0]];V=[].concat(CG,
B.tx(CG,[this.Bl[1],this.Bl[0]]));}return B.tz(V,this.D4);},_Init:function(aArg){
B.Core.AL._Init.call(this,aArg);this.__proto__=D.Text;},_Done:function(){this.Bz(
);this.__proto__=B.Core.AL;B.Core.AL._Done.call(this);},_Mark:function(E){var A;
B.Core.AL._Mark.call(this,E);if((A=this.Aw)&&(A._cycle!=E))A._Mark(A._cycle=E);if((
A=this.BK)&&((A=A[0])._cycle!=E))A._Mark(A._cycle=E);},_className:"Views::Text"};
D.JZ={Jf:0x1,Jd:0x2,Jg:0x4,Jr:0x8,Jq:0x10,Jp:0x20,Je:0x40,Jc:0x80};D.Dr={JJ:0,JW:
1,JU:2,JV:3};
D._Init=function(){D.BA.__proto__=B.Core.AL;D.Text.__proto__=B.Core.AL;};D.Am=function(
E){};return D;})();

/* Embedded Wizard */