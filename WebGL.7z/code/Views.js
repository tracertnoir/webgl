/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.un)throw new Error("The unit file 'Views.js' included twice!");EmWiApp.
un=(function(){var B=EmWiApp;var D={};
var Z=[0,0];var An="\uFEFF";var Ca=[0,0,0,0];
D.BE={CB:0xFFFFFFFF,CC:0xFFFFFFFF,CE:0xFFFFFFFF,CD:0xFFFFFFFF,BS:function(Au,aClip
,aOffset,AA,aBlend){var A;aBlend=aBlend&&((this.F&0x2)===0x2);AA=AA+1;if(AA<256){
var Ch=this.CD;var Ci=this.CE;var Cf=this.CB;var Cg=this.CC;Ch=(Ch&0x00FFFFFF)|((((
AA*((Ch>>24)&0xFF))>>8)&0xFF)<<24);Ci=(Ci&0x00FFFFFF)|((((AA*((Ci>>24)&0xFF))>>8
)&0xFF)<<24);Cf=(Cf&0x00FFFFFF)|((((AA*((Cf>>24)&0xFF))>>8)&0xFF)<<24);Cg=(Cg&0x00FFFFFF
)|((((AA*((Cg>>24)&0xFF))>>8)&0xFF)<<24);Au.E3(aClip,B.tz(this.M,aOffset),Ch,Ci,
Cg,Cf,aBlend);}else Au.E3(aClip,B.tz(this.M,aOffset),this.CD,this.CE,this.CC,this.
CB,aBlend);},Dy:function(C){var A;if((((C===this.CD)&&(C===this.CE))&&(C===this.
CB))&&(C===this.CC))return;this.CD=C;this.CE=C;this.CB=C;this.CC=C;if(!!this.K&&((
this.F&0x1)===0x1))this.K.AG(this.M);},_Init:function(aArg){B.Core.AP._Init.call(
this,aArg);this.__proto__=D.BE;},_className:"Views::Rectangle"};D.Text={Az:null,
B$:null,Ag:B.hm,String:B.hm,Bb:null,Bu:B.qx,Eq:0,C$:0,CB:0xFFFFFFFF,CC:0xFFFFFFFF
,CE:0xFFFFFFFF,CD:0xFFFFFFFF,Da:0,Es:B.qx,Ea:0x12,Fc:255,DU:0,Fk:false,FO:false,
FW:false,FX:false,Bj:false,BS:function(Au,aClip,aOffset,AA,aBlend){var A;if((this.
Ag===B.hm)||!this.Az)return;var Ad=this.Ea;var orient=this.DU;var font=this.Az;var
Ax=B.tz(this.M,aOffset);var Ch=this.CD;var Ci=this.CE;var Cg=this.CC;var Cf=this.
CB;var Cm=(((AA+1)*this.Fc)>>8)+1;var B7=this.Ag.charCodeAt(0)||0;var R=B.tz(this.
C8(),aOffset);var Bd=[Ax[0]-R[0],(Ax[1]-R[1])-font.Ascent];if(B7<1)return;if(Cm<
256){Ch=(Ch&0x00FFFFFF)|((((((Ch>>24)&0xFF)*Cm)>>8)&0xFF)<<24);Ci=(Ci&0x00FFFFFF
)|((((((Ci>>24)&0xFF)*Cm)>>8)&0xFF)<<24);Cg=(Cg&0x00FFFFFF)|((((((Cg>>24)&0xFF)*
Cm)>>8)&0xFF)<<24);Cf=(Cf&0x00FFFFFF)|((((((Cf>>24)&0xFF)*Cm)>>8)&0xFF)<<24);}if(((
Ad&0x80)===0x80)){if(this.F0())Ad=(Ad&~0x80)|0x4;else Ad=(Ad&~0x80)|0x1;}if(((B7===
1)&&!((Ad&0x40)===0x40))&&!orient){Au.Hd(aClip,font,this.Ag,2,(this.Ag.charCodeAt(
1)||0)-1,Ax,Bd,0,orient,Ch,Ci,Cg,Cf,true);return;}var leading=font.Leading;if(this.
C$>0)leading=(this.C$-font.Ascent)-font.Descent;var G9=(font.Ascent+font.Descent
)+leading;var Fo=aClip[1]-R[1];var Fp=aClip[3]-R[1];var EB=R[2]-R[0];var BQ=0;var
H=1;var AX=this.Ag.charCodeAt(H)||0;if(orient===1){Bd=[R[3]-Ax[3],(Ax[0]-R[0])-font.
Ascent];Fo=aClip[0]-R[0];Fp=aClip[2]-R[0];EB=R[3]-R[1];}else if(orient===2){Bd=[
R[2]-Ax[2],(R[3]-Ax[3])-font.Ascent];Fo=R[3]-aClip[3];Fp=R[3]-aClip[1];}else if(
orient===3){Bd=[Ax[1]-R[1],(R[2]-Ax[2])-font.Ascent];Fo=R[2]-aClip[2];Fp=R[2]-aClip[
0];EB=R[3]-R[1];}while(((BQ+G9)<Fo)&&(AX>0)){H=H+AX;BQ=BQ+G9;AX=this.Ag.charCodeAt(
H)||0;}while((BQ<Fp)&&(AX>0)){var Dm=B.tw(Bd,[0,BQ]);var H8=0;var Fy=false;if(((((
Ad&0x40)===0x40)&&((this.Ag.charCodeAt((H+AX)-1)||0)!==0x0A))&&((this.Ag.charCodeAt(
H+1)||0)!==0x0A))&&((this.Ag.charCodeAt(H+AX)||0)!==0x00))Fy=true;if(Fy&&!!(Ad&0x6
)){var H7=H+AX;var HT=this.Ag.indexOf(String.fromCharCode(0x20),H+1);var HU=this.
Ag.indexOf(String.fromCharCode(0xA0),H+1);if(((HT<0)||(HT>=H7))&&((HU<0)||(HU>=H7
)))Fy=false;}if(Fy)H8=EB;else if(((Ad&0x4)===0x4))Dm=[(Dm[0]-EB)+font.Eg(this.Ag
,H+1,AX-1),Dm[1]];else if(((Ad&0x2)===0x2))Dm=[(Dm[0]-((EB/2)|0))+((font.Eg(this.
Ag,H+1,AX-1)/2)|0),Dm[1]];Au.Hd(aClip,font,this.Ag,H+1,AX-1,Ax,Dm,H8,orient,Ch,Ci
,Cg,Cf,true);H=H+AX;BQ=BQ+G9;AX=this.Ag.charCodeAt(H)||0;}},T:function(C){var A;
if(B.tm(C,this.M))return;var G7=false;if(!this.DU||(this.DU===2))G7=((A=this.M)[
2]-A[0])!==(C[2]-C[0]);else G7=((A=this.M)[3]-A[1])!==(C[3]-C[1]);if((((G7&&!this.
Da)&&this.Fk)&&this.Bj)&&!((this.F&0x2000)===0x2000)){this.Ag=B.hm;this.Bj=false;
B.lq([this,this.D8],this);}if(((this.FW&&this.Bj)&&!B.tl([(A=this.M)[2]-A[0],A[3
]-A[1]],[C[2]-C[0],C[3]-C[1]]))&&!((this.F&0x2000)===0x2000)){this.Ag=B.hm;this.
Bj=false;B.lq([this,this.D8],this);}B.Core.AP.T.call(this,C);B.lq([this,this.G4]
,this);},BR:function(){if(!!this.Bb){this.GR(this.Bb);this.Bb=null;}},GR:function(
aBidi){if(!aBidi)return;B.ng(aBidi);},JS:function(aSize){var bidi=null;bidi=B.qk(
aSize);return bidi;},G4:function(B8){B.lq(this.B$,this);},D8:function(B8){B.lq([
this,this.FF],this);},FF:function(B8){var A;if(this.Bj)return;var orient=this.DU;
var width=(A=this.M)[2]-A[0];var height=(A=this.M)[3]-A[1];var Bs=-1;if((orient===
1)||(orient===3)){width=height;height=(A=this.M)[2]-A[0];}if(this.Fk){if(this.Da>
0)Bs=this.Da;else if(!this.FO)Bs=width-(this.Eq*2);else Bs=width;if(Bs<0)Bs=1;}if(
!!this.Bb){this.GR(this.Bb);this.Bb=null;}this.Bj=true;if((this.String!==B.hm)&&
!!this.Az){var length=this.String.length;if(this.FX)this.Bb=this.JS(length);this.
Ag=this.Az.IF(this.String,0,Bs,length,this.Bb);if(!!this.Bb&&!this.Ik()){this.GR(
this.Bb);this.Bb=null;}}else this.Ag=B.hm;this.Bu=Z;if(((this.FW&&(this.Ag!==B.hm
))&&!this.FO)&&!!this.Az){var Ad=this.Ea;var font=this.Az;var leading=font.Leading;
var Ah=this.Ag;var FI=this.F0();if(((Ad&0x80)===0x80)){if(FI)Ad=(Ad&~0x80)|0x4;else
Ad=(Ad&~0x80)|0x1;}if(this.C$>0)leading=(this.C$-font.Ascent)-font.Descent;var ES=(
font.Ascent+font.Descent)+leading;var B7=Ah.charCodeAt(0)||0;var CY=((height+leading
)/ES)|0;var GM=false;var Fn=false;if(CY<=0)CY=1;if(B7>CY){var BO=0;var ET=0;var FH=
B7-1;var AC=0;var AL=Ah.length;var tmp=B.hm;if(((Ad&0x20)===0x20))ET=B7-CY;else if(((
Ad&0x10)===0x10)){ET=((B7-CY)/2)|0;FH=(ET+CY)-1;}else FH=CY-1;GM=ET>0;Fn=FH<(B7-
1);for(AC=1;BO<ET;BO=BO+1)AC=AC+(Ah.charCodeAt(AC)||0);if(Fn)for(AL=AC;BO<FH;BO=
BO+1)AL=AL+(Ah.charCodeAt(AL)||0);if(GM){var AU=Ah.charCodeAt(AC)||0;tmp=(An+B.t9(
Ah,AC,AU))+An;tmp=B.t4(tmp,0,(AU+2)&0xFFFF);AC=AC+AU;if((tmp.charCodeAt(AU)||0)===
0x0A){tmp=B.t4(tmp,AU,0xFEFF);tmp=B.t4(tmp,AU+1,0x0A);}if((tmp.charCodeAt(2)||0)===
0x0A){tmp=B.t4(tmp,2,0xFEFF);tmp=B.t4(tmp,1,0x0A);}else tmp=B.t4(tmp,1,0xFEFF);}
tmp=tmp+B.t9(Ah,AC,AL-AC);if(Fn&&(AL>=AC)){var AU=Ah.charCodeAt(AL)||0;var A4=(An+
B.t9(Ah,AL,AU))+An;A4=B.t4(A4,0,(AU+2)&0xFFFF);A4=B.t4(A4,1,0xFEFF);if((A4.charCodeAt(
AU)||0)===0x0A){A4=B.t4(A4,AU,0xFEFF);A4=B.t4(A4,AU+1,0x0A);}if((A4.charCodeAt(2
)||0)===0x0A){A4=B.t4(A4,2,0xFEFF);A4=B.t4(A4,1,0x0A);}else A4=B.t4(A4,1,0xFEFF);
tmp=tmp+A4;}Ah=String.fromCharCode(CY&0xFFFF)+tmp;}var BO=0;var A0=1;var FC=width-(
this.Eq*2);if(this.Fk&&(this.Da>0))FC=this.Da;B7=Ah.charCodeAt(0)||0;for(;BO<B7;
BO=BO+1){var C3=GM&&!BO;var C4=Fn&&(BO===(B7-1));var Bq=false;var Br=false;var D9=
FI;if((FI&&C3)&&!C4){C3=false;C4=true;}else if((FI&&C4)&&!C3){C4=false;C3=true;}
var EV=A0+1;var AU=Ah.charCodeAt(A0)||0;var AC=EV;var AL=(EV+AU)-2;var GV=-1;var
GW=-1;if(!this.Fk&&(font.Eg(Ah,EV,AU-1)>FC)){if(((Ad&0x4)===0x4))Bq=true;else if(((
Ad&0x2)===0x2)){Bq=true;Br=true;}else Br=true;}if((Ah.charCodeAt(AC)||0)===0x0A)
AC=AC+1;if((Ah.charCodeAt(AL)||0)===0x0A)AL=AL-1;while(Bq&&((Ah.charCodeAt(AC)||
0)===0xFEFF))AC=AC+1;while(Br&&((Ah.charCodeAt(AL)||0)===0xFEFF))AL=AL-1;Bq=Bq&&
!C4;Br=Br&&!C3;while((((Bq||Br)||C3)||C4)&&(AC<AL)){if((Bq&&(D9||!Br))||C3){if(GV>
0)Ah=B.t4(Ah,GV,0xFEFF);Ah=B.t4(Ah,AC,0x2026);GV=AC;AC=AC+1;D9=!D9;C3=false;if(font.
Eg(Ah,EV,AU-1)<=FC){Bq=false;Br=false;}else Bq=Bq||!Br;}if((Br&&(!D9||!Bq))||C4){
if(GW>0)Ah=B.t4(Ah,GW,0xFEFF);Ah=B.t4(Ah,AL,0x2026);GW=AL;AL=AL-1;D9=!D9;C4=false;
if(font.Eg(Ah,EV,AU-1)<=FC){Bq=false;Br=false;}else Br=Br||!Bq;}}A0=A0+AU;}this.
Bu=[font.Hi(Ah),((Ah.charCodeAt(0)||0)*ES)-leading];this.Ag=Ah;}if(this.FO&&(this.
Ag!==B.hm)){var Cy=[this.Eq,0];if((orient===1)||(orient===3)){Cy=[Cy[0],Cy[0]];Cy=[
0,Cy[1]];}this.F=this.F|0x2000;this.T(B.ty(B.th(this.C8(),Cy),this.Es));this.F=this.
F&~0x2000;}if(!!this.K&&((this.F&0x1)===0x1))this.K.AG(this.M);B.lq([this,this.G4
],this);},Ip:function(C){if(C===this.FX)return;this.FX=C;this.Ag=B.hm;this.Bj=false;
B.lq([this,this.D8],this);},Fa:function(C){if(B.to(C,this.B$))return;this.B$=C;if(
!this.Da||!!C)this.F=this.F&~0x100;else this.F=this.F|0x100;},E8:function(C){var
A;if(C===this.Ea)return;this.Ea=C;if(!!this.K&&((this.F&0x1)===0x1))this.K.AG(this.
M);if(this.FW){this.Ag=B.hm;this.Bj=false;B.lq([this,this.D8],this);}if(this.Bj)
B.lq([this,this.G4],this);},DO:function(C){if(C===this.String)return;this.String=
C;this.Ag=B.hm;this.Bj=false;B.lq([this,this.D8],this);},E$:function(C){if(C===this.
Az)return;this.Az=C;this.Ag=B.hm;this.Bj=false;B.lq([this,this.D8],this);},Dy:function(
C){var A;if((((C===this.CD)&&(C===this.CE))&&(C===this.CB))&&(C===this.CC))return;
this.CD=C;this.CE=C;this.CB=C;this.CC=C;if(!!this.K&&((this.F&0x1)===0x1))this.K.
AG(this.M);},F0:function(){if(!this.Bj)this.FF(this);if(!this.Bb)return false;var
result=false;var bidi=this.Bb;result=B.qj(bidi);return result;},Ik:function(){if(
!this.Bj)this.FF(this);if(!this.Bb)return false;var result=false;var bidi=this.Bb;
result=B.sD(bidi);return result;},C8:function(){var A;if((this.String===B.hm)||!
this.Az)return Ca;if(!this.Bj)this.FF(this);if(this.Ag===B.hm)return Ca;var leading=
this.Az.Leading;var ES=(this.Az.Ascent+this.Az.Descent)+this.Az.Leading;if(this.
C$>0){leading=(this.C$-this.Az.Ascent)-this.Az.Descent;ES=this.C$;}if(B.tl(this.
Bu,Z))this.Bu=[this.Az.Hi(this.Ag),this.Bu[1]];this.Bu=[this.Bu[0],((this.Ag.charCodeAt(
0)||0)*ES)-leading];var Ad=this.Ea;var orient=this.DU;var Aj=this.M;var Cy=this.
Eq;var width=Aj[2]-Aj[0];var height=Aj[3]-Aj[1];if((orient===1)||(orient===3)){width=
height;height=Aj[2]-Aj[0];}var Ax=[Cy,0,width-Cy,height];var Y=[].concat(Ax.slice(
0,2),B.tx(Ax.slice(0,2),this.Bu));if(((Ad&0x80)===0x80)){if(this.F0())Ad=(Ad&~0x80
)|0x4;else Ad=(Ad&~0x80)|0x1;}if(((Ad&0x40)===0x40)){var Bs=this.Da;if(Bs<=0)Bs=
width-(this.Eq*2);if(Bs<0)Bs=0;if(Bs>(Y[2]-Y[0]))Y=B.tZ(Y,Bs);}if((Y[2]-Y[0])!==(
Ax[2]-Ax[0])){if(((Ad&0x4)===0x4))Y=B.t0(Y,Ax[2]-(Y[2]-Y[0]));else if(((Ad&0x2)===
0x2))Y=B.t0(Y,(Ax[0]+(((Ax[2]-Ax[0])/2)|0))-(((Y[2]-Y[0])/2)|0));}if((Y[3]-Y[1])
!==(Ax[3]-Ax[1])){if(((Ad&0x20)===0x20))Y=B.t2(Y,Ax[3]-(Y[3]-Y[1]));else if(((Ad&
0x10)===0x10))Y=B.t2(Y,(Ax[1]+(((Ax[3]-Ax[1])/2)|0))-(((Y[3]-Y[1])/2)|0));}if(!orient
)Y=B.tz(Y,Aj.slice(0,2));else if(orient===1){var C1=[Aj[0]+Y[1],Aj[3]-Y[2]];Y=[].
concat(C1,B.tx(C1,[this.Bu[1],this.Bu[0]]));}else if(orient===2){var C1=[Aj[2]-Y[
2],Aj[3]-Y[3]];Y=[].concat(C1,B.tx(C1,this.Bu));}else if(orient===3){var C1=[Aj[
2]-Y[3],Aj[1]+Y[0]];Y=[].concat(C1,B.tx(C1,[this.Bu[1],this.Bu[0]]));}return B.tz(
Y,this.Es);},_Init:function(aArg){B.Core.AP._Init.call(this,aArg);this.__proto__=
D.Text;},_Done:function(){this.BR();this.__proto__=B.Core.AP;B.Core.AP._Done.call(
this);},_Mark:function(E){var A;B.Core.AP._Mark.call(this,E);if((A=this.Az)&&(A.
_cycle!=E))A._Mark(A._cycle=E);if((A=this.B$)&&((A=A[0])._cycle!=E))A._Mark(A._cycle=
E);},_className:"Views::Text"};D.KQ={J5:0x1,J3:0x2,J6:0x4,Kf:0x8,Ke:0x10,Kd:0x20
,J4:0x40,J2:0x80};D.DU={KA:0,KN:1,KL:2,KM:3};
D._Init=function(){D.BE.__proto__=B.Core.AP;D.Text.__proto__=B.Core.AP;};D.Ao=function(
E){};return D;})();

/* Embedded Wizard */