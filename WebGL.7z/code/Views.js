/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.un)throw new Error("The unit file 'Views.js' included twice!");EmWiApp.
un=(function(){var A=EmWiApp;var E={};
var Ac=[0,0];var Au="\uFEFF";var Cr=[0,0,0,0];
E.BG={CT:0xFFFFFFFF,CU:0xFFFFFFFF,CX:0xFFFFFFFF,CW:0xFFFFFFFF,BU:function(AA,aClip
,aOffset,AG,aBlend){var B;aBlend=aBlend&&((this.F&0x2)===0x2);AG=AG+1;if(AG<256){
var Cy=this.CW;var Cz=this.CX;var Cw=this.CT;var Cx=this.CU;Cy=(Cy&0x00FFFFFF)|((((
AG*((Cy>>24)&0xFF))>>8)&0xFF)<<24);Cz=(Cz&0x00FFFFFF)|((((AG*((Cz>>24)&0xFF))>>8
)&0xFF)<<24);Cw=(Cw&0x00FFFFFF)|((((AG*((Cw>>24)&0xFF))>>8)&0xFF)<<24);Cx=(Cx&0x00FFFFFF
)|((((AG*((Cx>>24)&0xFF))>>8)&0xFF)<<24);AA.FT(aClip,A.tz(this.N,aOffset),Cy,Cz,
Cx,Cw,aBlend);}else AA.FT(aClip,A.tz(this.N,aOffset),this.CW,this.CX,this.CU,this.
CT,aBlend);},D7:function(C){var B;if((((C===this.CW)&&(C===this.CX))&&(C===this.
CT))&&(C===this.CU))return;this.CW=C;this.CX=C;this.CT=C;this.CU=C;if(!!this.L&&((
this.F&0x1)===0x1))this.L.AN(this.N);},_Init:function(aArg){A.Core.AV._Init.call(
this,aArg);this.__proto__=E.BG;},_className:"Views::Rectangle"};E.Text={AC:null,
Cq:null,Aj:A.hm,String:A.hm,Bi:null,BC:A.qx,Fe:0,Ds:0,CT:0xFFFFFFFF,CU:0xFFFFFFFF
,CX:0xFFFFFFFF,CW:0xFFFFFFFF,Dt:0,Fg:A.qx,E0:0x12,Gc:255,EH:0,Gl:false,GP:false,
GX:false,GY:false,Br:false,BU:function(AA,aClip,aOffset,AG,aBlend){var B;if((this.
Aj===A.hm)||!this.AC)return;var Ag=this.E0;var orient=this.EH;var font=this.AC;var
AE=A.tz(this.N,aOffset);var Cy=this.CW;var Cz=this.CX;var Cx=this.CU;var Cw=this.
CT;var CD=(((AG+1)*this.Gc)>>8)+1;var Cm=this.Aj.charCodeAt(0)||0;var T=A.tz(this.
Dp(),aOffset);var Bk=[AE[0]-T[0],(AE[1]-T[1])-font.Ascent];if(Cm<1)return;if(CD<
256){Cy=(Cy&0x00FFFFFF)|((((((Cy>>24)&0xFF)*CD)>>8)&0xFF)<<24);Cz=(Cz&0x00FFFFFF
)|((((((Cz>>24)&0xFF)*CD)>>8)&0xFF)<<24);Cx=(Cx&0x00FFFFFF)|((((((Cx>>24)&0xFF)*
CD)>>8)&0xFF)<<24);Cw=(Cw&0x00FFFFFF)|((((((Cw>>24)&0xFF)*CD)>>8)&0xFF)<<24);}if(((
Ag&0x80)===0x80)){if(this.G1())Ag=(Ag&~0x80)|0x4;else Ag=(Ag&~0x80)|0x1;}if(((Cm===
1)&&!((Ag&0x40)===0x40))&&!orient){AA.H4(aClip,font,this.Aj,2,(this.Aj.charCodeAt(
1)||0)-1,AE,Bk,0,orient,Cy,Cz,Cx,Cw,true);return;}var leading=font.Leading;if(this.
Ds>0)leading=(this.Ds-font.Ascent)-font.Descent;var HX=(font.Ascent+font.Descent
)+leading;var Gp=aClip[1]-T[1];var Gq=aClip[3]-T[1];var Fs=T[2]-T[0];var BS=0;var
I=1;var A4=this.Aj.charCodeAt(I)||0;if(orient===1){Bk=[T[3]-AE[3],(AE[0]-T[0])-font.
Ascent];Gp=aClip[0]-T[0];Gq=aClip[2]-T[0];Fs=T[3]-T[1];}else if(orient===2){Bk=[
T[2]-AE[2],(T[3]-AE[3])-font.Ascent];Gp=T[3]-aClip[3];Gq=T[3]-aClip[1];}else if(
orient===3){Bk=[AE[1]-T[1],(T[2]-AE[2])-font.Ascent];Gp=T[2]-aClip[2];Gq=T[2]-aClip[
0];Fs=T[3]-T[1];}while(((BS+HX)<Gp)&&(A4>0)){I=I+A4;BS=BS+HX;A4=this.Aj.charCodeAt(
I)||0;}while((BS<Gq)&&(A4>0)){var DG=A.tw(Bk,[0,BS]);var Jp=0;var Gz=false;if(((((
Ag&0x40)===0x40)&&((this.Aj.charCodeAt((I+A4)-1)||0)!==0x0A))&&((this.Aj.charCodeAt(
I+1)||0)!==0x0A))&&((this.Aj.charCodeAt(I+A4)||0)!==0x00))Gz=true;if(Gz&&!!(Ag&0x6
)){var Jo=I+A4;var Ja=this.Aj.indexOf(String.fromCharCode(0x20),I+1);var Jb=this.
Aj.indexOf(String.fromCharCode(0xA0),I+1);if(((Ja<0)||(Ja>=Jo))&&((Jb<0)||(Jb>=Jo
)))Gz=false;}if(Gz)Jp=Fs;else if(((Ag&0x4)===0x4))DG=[(DG[0]-Fs)+font.E6(this.Aj
,I+1,A4-1),DG[1]];else if(((Ag&0x2)===0x2))DG=[(DG[0]-((Fs/2)|0))+((font.E6(this.
Aj,I+1,A4-1)/2)|0),DG[1]];AA.H4(aClip,font,this.Aj,I+1,A4-1,AE,DG,Jp,orient,Cy,Cz
,Cx,Cw,true);I=I+A4;BS=BS+HX;A4=this.Aj.charCodeAt(I)||0;}},O:function(C){var B;
if(A.tm(C,this.N))return;var HV=false;if(!this.EH||(this.EH===2))HV=((B=this.N)[
2]-B[0])!==(C[2]-C[0]);else HV=((B=this.N)[3]-B[1])!==(C[3]-C[1]);if((((HV&&!this.
Dt)&&this.Gl)&&this.Br)&&!((this.F&0x2000)===0x2000)){this.Aj=A.hm;this.Br=false;
A.lq([this,this.EW],this);}if(((this.GX&&this.Br)&&!A.tl([(B=this.N)[2]-B[0],B[3
]-B[1]],[C[2]-C[0],C[3]-C[1]]))&&!((this.F&0x2000)===0x2000)){this.Aj=A.hm;this.
Br=false;A.lq([this,this.EW],this);}A.Core.AV.O.call(this,C);A.lq([this,this.HS]
,this);},BT:function(){if(!!this.Bi){this.HF(this.Bi);this.Bi=null;}},HF:function(
aBidi){if(!aBidi)return;A.ng(aBidi);},LC:function(aSize){var bidi=null;bidi=A.qk(
aSize);return bidi;},HS:function(Cn){A.lq(this.Cq,this);},EW:function(Cn){A.lq([
this,this.GG],this);},GG:function(Cn){var B;if(this.Br)return;var orient=this.EH;
var width=(B=this.N)[2]-B[0];var height=(B=this.N)[3]-B[1];var BA=-1;if((orient===
1)||(orient===3)){width=height;height=(B=this.N)[2]-B[0];}if(this.Gl){if(this.Dt>
0)BA=this.Dt;else if(!this.GP)BA=width-(this.Fe*2);else BA=width;if(BA<0)BA=1;}if(
!!this.Bi){this.HF(this.Bi);this.Bi=null;}this.Br=true;if((this.String!==A.hm)&&
!!this.AC){var length=this.String.length;if(this.GY)this.Bi=this.LC(length);this.
Aj=this.AC.JN(this.String,0,BA,length,this.Bi);if(!!this.Bi&&!this.JC()){this.HF(
this.Bi);this.Bi=null;}}else this.Aj=A.hm;this.BC=Ac;if(((this.GX&&(this.Aj!==A.
hm))&&!this.GP)&&!!this.AC){var Ag=this.E0;var font=this.AC;var leading=font.Leading;
var Ak=this.Aj;var GJ=this.G1();if(((Ag&0x80)===0x80)){if(GJ)Ag=(Ag&~0x80)|0x4;else
Ag=(Ag&~0x80)|0x1;}if(this.Ds>0)leading=(this.Ds-font.Ascent)-font.Descent;var FJ=(
font.Ascent+font.Descent)+leading;var Cm=Ak.charCodeAt(0)||0;var De=((height+leading
)/FJ)|0;var HA=false;var Go=false;if(De<=0)De=1;if(Cm>De){var BQ=0;var FK=0;var GI=
Cm-1;var AI=0;var AR=Ak.length;var tmp=A.hm;if(((Ag&0x20)===0x20))FK=Cm-De;else if(((
Ag&0x10)===0x10)){FK=((Cm-De)/2)|0;GI=(FK+De)-1;}else GI=De-1;HA=FK>0;Go=GI<(Cm-
1);for(AI=1;BQ<FK;BQ=BQ+1)AI=AI+(Ak.charCodeAt(AI)||0);if(Go)for(AR=AI;BQ<GI;BQ=
BQ+1)AR=AR+(Ak.charCodeAt(AR)||0);if(HA){var A1=Ak.charCodeAt(AI)||0;tmp=(Au+A.t9(
Ak,AI,A1))+Au;tmp=A.t4(tmp,0,(A1+2)&0xFFFF);AI=AI+A1;if((tmp.charCodeAt(A1)||0)===
0x0A){tmp=A.t4(tmp,A1,0xFEFF);tmp=A.t4(tmp,A1+1,0x0A);}if((tmp.charCodeAt(2)||0)===
0x0A){tmp=A.t4(tmp,2,0xFEFF);tmp=A.t4(tmp,1,0x0A);}else tmp=A.t4(tmp,1,0xFEFF);}
tmp=tmp+A.t9(Ak,AI,AR-AI);if(Go&&(AR>=AI)){var A1=Ak.charCodeAt(AR)||0;var A$=(Au+
A.t9(Ak,AR,A1))+Au;A$=A.t4(A$,0,(A1+2)&0xFFFF);A$=A.t4(A$,1,0xFEFF);if((A$.charCodeAt(
A1)||0)===0x0A){A$=A.t4(A$,A1,0xFEFF);A$=A.t4(A$,A1+1,0x0A);}if((A$.charCodeAt(2
)||0)===0x0A){A$=A.t4(A$,2,0xFEFF);A$=A.t4(A$,1,0x0A);}else A$=A.t4(A$,1,0xFEFF);
tmp=tmp+A$;}Ak=String.fromCharCode(De&0xFFFF)+tmp;}var BQ=0;var A7=1;var GD=width-(
this.Fe*2);if(this.Gl&&(this.Dt>0))GD=this.Dt;Cm=Ak.charCodeAt(0)||0;for(;BQ<Cm;
BQ=BQ+1){var Dj=HA&&!BQ;var Dk=Go&&(BQ===(Cm-1));var By=false;var Bz=false;var EX=
GJ;if((GJ&&Dj)&&!Dk){Dj=false;Dk=true;}else if((GJ&&Dk)&&!Dj){Dk=false;Dj=true;}
var FM=A7+1;var A1=Ak.charCodeAt(A7)||0;var AI=FM;var AR=(FM+A1)-2;var HJ=-1;var
HK=-1;if(!this.Gl&&(font.E6(Ak,FM,A1-1)>GD)){if(((Ag&0x4)===0x4))By=true;else if(((
Ag&0x2)===0x2)){By=true;Bz=true;}else Bz=true;}if((Ak.charCodeAt(AI)||0)===0x0A)
AI=AI+1;if((Ak.charCodeAt(AR)||0)===0x0A)AR=AR-1;while(By&&((Ak.charCodeAt(AI)||
0)===0xFEFF))AI=AI+1;while(Bz&&((Ak.charCodeAt(AR)||0)===0xFEFF))AR=AR-1;By=By&&
!Dk;Bz=Bz&&!Dj;while((((By||Bz)||Dj)||Dk)&&(AI<AR)){if((By&&(EX||!Bz))||Dj){if(HJ>
0)Ak=A.t4(Ak,HJ,0xFEFF);Ak=A.t4(Ak,AI,0x2026);HJ=AI;AI=AI+1;EX=!EX;Dj=false;if(font.
E6(Ak,FM,A1-1)<=GD){By=false;Bz=false;}else By=By||!Bz;}if((Bz&&(!EX||!By))||Dk){
if(HK>0)Ak=A.t4(Ak,HK,0xFEFF);Ak=A.t4(Ak,AR,0x2026);HK=AR;AR=AR-1;EX=!EX;Dk=false;
if(font.E6(Ak,FM,A1-1)<=GD){By=false;Bz=false;}else Bz=Bz||!By;}}A7=A7+A1;}this.
BC=[font.H9(Ak),((Ak.charCodeAt(0)||0)*FJ)-leading];this.Aj=Ak;}if(this.GP&&(this.
Aj!==A.hm)){var CQ=[this.Fe,0];if((orient===1)||(orient===3)){CQ=[CQ[0],CQ[0]];CQ=[
0,CQ[1]];}this.F=this.F|0x2000;this.O(A.ty(A.th(this.Dp(),CQ),this.Fg));this.F=this.
F&~0x2000;}if(!!this.L&&((this.F&0x1)===0x1))this.L.AN(this.N);A.lq([this,this.HS
],this);},JH:function(C){if(C===this.GY)return;this.GY=C;this.Aj=A.hm;this.Br=false;
A.lq([this,this.EW],this);},Ga:function(C){if(A.to(C,this.Cq))return;this.Cq=C;if(
!this.Dt||!!C)this.F=this.F&~0x100;else this.F=this.F|0x100;},FZ:function(C){var
B;if(C===this.E0)return;this.E0=C;if(!!this.L&&((this.F&0x1)===0x1))this.L.AN(this.
N);if(this.GX){this.Aj=A.hm;this.Br=false;A.lq([this,this.EW],this);}if(this.Br)
A.lq([this,this.HS],this);},EB:function(C){if(C===this.String)return;this.String=
C;this.Aj=A.hm;this.Br=false;A.lq([this,this.EW],this);},F$:function(C){if(C===this.
AC)return;this.AC=C;this.Aj=A.hm;this.Br=false;A.lq([this,this.EW],this);},D7:function(
C){var B;if((((C===this.CW)&&(C===this.CX))&&(C===this.CT))&&(C===this.CU))return;
this.CW=C;this.CX=C;this.CT=C;this.CU=C;if(!!this.L&&((this.F&0x1)===0x1))this.L.
AN(this.N);},G1:function(){if(!this.Br)this.GG(this);if(!this.Bi)return false;var
result=false;var bidi=this.Bi;result=A.qj(bidi);return result;},JC:function(){if(
!this.Br)this.GG(this);if(!this.Bi)return false;var result=false;var bidi=this.Bi;
result=A.sD(bidi);return result;},Dp:function(){var B;if((this.String===A.hm)||!
this.AC)return Cr;if(!this.Br)this.GG(this);if(this.Aj===A.hm)return Cr;var leading=
this.AC.Leading;var FJ=(this.AC.Ascent+this.AC.Descent)+this.AC.Leading;if(this.
Ds>0){leading=(this.Ds-this.AC.Ascent)-this.AC.Descent;FJ=this.Ds;}if(A.tl(this.
BC,Ac))this.BC=[this.AC.H9(this.Aj),this.BC[1]];this.BC=[this.BC[0],((this.Aj.charCodeAt(
0)||0)*FJ)-leading];var Ag=this.E0;var orient=this.EH;var Aq=this.N;var CQ=this.
Fe;var width=Aq[2]-Aq[0];var height=Aq[3]-Aq[1];if((orient===1)||(orient===3)){width=
height;height=Aq[2]-Aq[0];}var AE=[CQ,0,width-CQ,height];var Ab=[].concat(AE.slice(
0,2),A.tx(AE.slice(0,2),this.BC));if(((Ag&0x80)===0x80)){if(this.G1())Ag=(Ag&~0x80
)|0x4;else Ag=(Ag&~0x80)|0x1;}if(((Ag&0x40)===0x40)){var BA=this.Dt;if(BA<=0)BA=
width-(this.Fe*2);if(BA<0)BA=0;if(BA>(Ab[2]-Ab[0]))Ab=A.tZ(Ab,BA);}if((Ab[2]-Ab[
0])!==(AE[2]-AE[0])){if(((Ag&0x4)===0x4))Ab=A.t0(Ab,AE[2]-(Ab[2]-Ab[0]));else if(((
Ag&0x2)===0x2))Ab=A.t0(Ab,(AE[0]+(((AE[2]-AE[0])/2)|0))-(((Ab[2]-Ab[0])/2)|0));}
if((Ab[3]-Ab[1])!==(AE[3]-AE[1])){if(((Ag&0x20)===0x20))Ab=A.t2(Ab,AE[3]-(Ab[3]-
Ab[1]));else if(((Ag&0x10)===0x10))Ab=A.t2(Ab,(AE[1]+(((AE[3]-AE[1])/2)|0))-(((Ab[
3]-Ab[1])/2)|0));}if(!orient)Ab=A.tz(Ab,Aq.slice(0,2));else if(orient===1){var Dh=[
Aq[0]+Ab[1],Aq[3]-Ab[2]];Ab=[].concat(Dh,A.tx(Dh,[this.BC[1],this.BC[0]]));}else
if(orient===2){var Dh=[Aq[2]-Ab[2],Aq[3]-Ab[3]];Ab=[].concat(Dh,A.tx(Dh,this.BC)
);}else if(orient===3){var Dh=[Aq[2]-Ab[3],Aq[1]+Ab[0]];Ab=[].concat(Dh,A.tx(Dh,[
this.BC[1],this.BC[0]]));}return A.tz(Ab,this.Fg);},_Init:function(aArg){A.Core.
AV._Init.call(this,aArg);this.__proto__=E.Text;},_Done:function(){this.BT();this.
__proto__=A.Core.AV;A.Core.AV._Done.call(this);},_Mark:function(D){var B;A.Core.
AV._Mark.call(this,D);if((B=this.AC)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.
Cq)&&((B=B[0])._cycle!=D))B._Mark(B._cycle=D);},_className:"Views::Text"};E.MA={
LP:0x1,LN:0x2,LQ:0x4,L1:0x8,L0:0x10,LZ:0x20,LO:0x40,LM:0x80};E.EH={Mk:0,Mx:1,Mv:
2,Mw:3};
E._Init=function(){E.BG.__proto__=A.Core.AV;E.Text.__proto__=A.Core.AV;};E.Av=function(
D){};return E;})();

/* Embedded Wizard */