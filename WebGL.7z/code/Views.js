/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.un)throw new Error("The unit file 'Views.js' included twice!");EmWiApp.
un=(function(){var A=EmWiApp;var E={};
var Ab=[0,0];var At="\uFEFF";var Cr=[0,0,0,0];
E.BG={CS:0xFFFFFFFF,CT:0xFFFFFFFF,CW:0xFFFFFFFF,CV:0xFFFFFFFF,BU:function(Az,aClip
,aOffset,AF,aBlend){var B;aBlend=aBlend&&((this.F&0x2)===0x2);AF=AF+1;if(AF<256){
var Cy=this.CV;var Cz=this.CW;var Cw=this.CS;var Cx=this.CT;Cy=(Cy&0x00FFFFFF)|((((
AF*((Cy>>24)&0xFF))>>8)&0xFF)<<24);Cz=(Cz&0x00FFFFFF)|((((AF*((Cz>>24)&0xFF))>>8
)&0xFF)<<24);Cw=(Cw&0x00FFFFFF)|((((AF*((Cw>>24)&0xFF))>>8)&0xFF)<<24);Cx=(Cx&0x00FFFFFF
)|((((AF*((Cx>>24)&0xFF))>>8)&0xFF)<<24);Az.EZ(aClip,A.tz(this.M,aOffset),Cy,Cz,
Cx,Cw,aBlend);}else Az.EZ(aClip,A.tz(this.M,aOffset),this.CV,this.CW,this.CT,this.
CS,aBlend);},DO:function(C){var B;if((((C===this.CV)&&(C===this.CW))&&(C===this.
CS))&&(C===this.CT))return;this.CV=C;this.CW=C;this.CS=C;this.CT=C;if(!!this.K&&((
this.F&0x1)===0x1))this.K.AM(this.M);},_Init:function(aArg){A.Core.AV._Init.call(
this,aArg);this.__proto__=E.BG;},_className:"Views::Rectangle"};E.Text={AB:null,
Cq:null,Ai:A.hm,String:A.hm,Bi:null,BC:A.qx,Ee:0,Dq:0,CS:0xFFFFFFFF,CT:0xFFFFFFFF
,CW:0xFFFFFFFF,CV:0xFFFFFFFF,Dr:0,Ef:A.qx,D4:0x12,Fp:255,DR:0,FC:false,Gd:false,
Gl:false,Gm:false,Br:false,BU:function(Az,aClip,aOffset,AF,aBlend){var B;if((this.
Ai===A.hm)||!this.AB)return;var Af=this.D4;var orient=this.DR;var font=this.AB;var
AD=A.tz(this.M,aOffset);var Cy=this.CV;var Cz=this.CW;var Cx=this.CT;var Cw=this.
CS;var CD=(((AF+1)*this.Fp)>>8)+1;var Cm=this.Ai.charCodeAt(0)||0;var S=A.tz(this.
Do(),aOffset);var Bk=[AD[0]-S[0],(AD[1]-S[1])-font.Ascent];if(Cm<1)return;if(CD<
256){Cy=(Cy&0x00FFFFFF)|((((((Cy>>24)&0xFF)*CD)>>8)&0xFF)<<24);Cz=(Cz&0x00FFFFFF
)|((((((Cz>>24)&0xFF)*CD)>>8)&0xFF)<<24);Cx=(Cx&0x00FFFFFF)|((((((Cx>>24)&0xFF)*
CD)>>8)&0xFF)<<24);Cw=(Cw&0x00FFFFFF)|((((((Cw>>24)&0xFF)*CD)>>8)&0xFF)<<24);}if(((
Af&0x80)===0x80)){if(this.Gs())Af=(Af&~0x80)|0x4;else Af=(Af&~0x80)|0x1;}if(((Cm===
1)&&!((Af&0x40)===0x40))&&!orient){Az.H5(aClip,font,this.Ai,2,(this.Ai.charCodeAt(
1)||0)-1,AD,Bk,0,orient,Cy,Cz,Cx,Cw,true);return;}var leading=font.Leading;if(this.
Dq>0)leading=(this.Dq-font.Ascent)-font.Descent;var HZ=(font.Ascent+font.Descent
)+leading;var FG=aClip[1]-S[1];var FH=aClip[3]-S[1];var Eq=S[2]-S[0];var BS=0;var
H=1;var A4=this.Ai.charCodeAt(H)||0;if(orient===1){Bk=[S[3]-AD[3],(AD[0]-S[0])-font.
Ascent];FG=aClip[0]-S[0];FH=aClip[2]-S[0];Eq=S[3]-S[1];}else if(orient===2){Bk=[
S[2]-AD[2],(S[3]-AD[3])-font.Ascent];FG=S[3]-aClip[3];FH=S[3]-aClip[1];}else if(
orient===3){Bk=[AD[1]-S[1],(S[2]-AD[2])-font.Ascent];FG=S[2]-aClip[2];FH=S[2]-aClip[
0];Eq=S[3]-S[1];}while(((BS+HZ)<FG)&&(A4>0)){H=H+A4;BS=BS+HZ;A4=this.Ai.charCodeAt(
H)||0;}while((BS<FH)&&(A4>0)){var DF=A.tw(Bk,[0,BS]);var Jt=0;var FQ=false;if(((((
Af&0x40)===0x40)&&((this.Ai.charCodeAt((H+A4)-1)||0)!==0x0A))&&((this.Ai.charCodeAt(
H+1)||0)!==0x0A))&&((this.Ai.charCodeAt(H+A4)||0)!==0x00))FQ=true;if(FQ&&!!(Af&0x6
)){var Js=H+A4;var Je=this.Ai.indexOf(String.fromCharCode(0x20),H+1);var Jf=this.
Ai.indexOf(String.fromCharCode(0xA0),H+1);if(((Je<0)||(Je>=Js))&&((Jf<0)||(Jf>=Js
)))FQ=false;}if(FQ)Jt=Eq;else if(((Af&0x4)===0x4))DF=[(DF[0]-Eq)+font.D9(this.Ai
,H+1,A4-1),DF[1]];else if(((Af&0x2)===0x2))DF=[(DF[0]-((Eq/2)|0))+((font.D9(this.
Ai,H+1,A4-1)/2)|0),DF[1]];Az.H5(aClip,font,this.Ai,H+1,A4-1,AD,DF,Jt,orient,Cy,Cz
,Cx,Cw,true);H=H+A4;BS=BS+HZ;A4=this.Ai.charCodeAt(H)||0;}},N:function(C){var B;
if(A.tm(C,this.M))return;var HX=false;if(!this.DR||(this.DR===2))HX=((B=this.M)[
2]-B[0])!==(C[2]-C[0]);else HX=((B=this.M)[3]-B[1])!==(C[3]-C[1]);if((((HX&&!this.
Dr)&&this.FC)&&this.Br)&&!((this.F&0x2000)===0x2000)){this.Ai=A.hm;this.Br=false;
A.lq([this,this.D0],this);}if(((this.Gl&&this.Br)&&!A.tl([(B=this.M)[2]-B[0],B[3
]-B[1]],[C[2]-C[0],C[3]-C[1]]))&&!((this.F&0x2000)===0x2000)){this.Ai=A.hm;this.
Br=false;A.lq([this,this.D0],this);}A.Core.AV.N.call(this,C);A.lq([this,this.HU]
,this);},BT:function(){if(!!this.Bi){this.HH(this.Bi);this.Bi=null;}},HH:function(
aBidi){if(!aBidi)return;A.ng(aBidi);},K$:function(aSize){var bidi=null;bidi=A.qk(
aSize);return bidi;},HU:function(Cn){A.lq(this.Cq,this);},D0:function(Cn){A.lq([
this,this.FX],this);},FX:function(Cn){var B;if(this.Br)return;var orient=this.DR;
var width=(B=this.M)[2]-B[0];var height=(B=this.M)[3]-B[1];var BA=-1;if((orient===
1)||(orient===3)){width=height;height=(B=this.M)[2]-B[0];}if(this.FC){if(this.Dr>
0)BA=this.Dr;else if(!this.Gd)BA=width-(this.Ee*2);else BA=width;if(BA<0)BA=1;}if(
!!this.Bi){this.HH(this.Bi);this.Bi=null;}this.Br=true;if((this.String!==A.hm)&&
!!this.AB){var length=this.String.length;if(this.Gm)this.Bi=this.K$(length);this.
Ai=this.AB.JR(this.String,0,BA,length,this.Bi);if(!!this.Bi&&!this.JG()){this.HH(
this.Bi);this.Bi=null;}}else this.Ai=A.hm;this.BC=Ab;if(((this.Gl&&(this.Ai!==A.
hm))&&!this.Gd)&&!!this.AB){var Af=this.D4;var font=this.AB;var leading=font.Leading;
var Aj=this.Ai;var F0=this.Gs();if(((Af&0x80)===0x80)){if(F0)Af=(Af&~0x80)|0x4;else
Af=(Af&~0x80)|0x1;}if(this.Dq>0)leading=(this.Dq-font.Ascent)-font.Descent;var EH=(
font.Ascent+font.Descent)+leading;var Cm=Aj.charCodeAt(0)||0;var De=((height+leading
)/EH)|0;var HC=false;var FF=false;if(De<=0)De=1;if(Cm>De){var BQ=0;var EI=0;var FZ=
Cm-1;var AH=0;var AR=Aj.length;var tmp=A.hm;if(((Af&0x20)===0x20))EI=Cm-De;else if(((
Af&0x10)===0x10)){EI=((Cm-De)/2)|0;FZ=(EI+De)-1;}else FZ=De-1;HC=EI>0;FF=FZ<(Cm-
1);for(AH=1;BQ<EI;BQ=BQ+1)AH=AH+(Aj.charCodeAt(AH)||0);if(FF)for(AR=AH;BQ<FZ;BQ=
BQ+1)AR=AR+(Aj.charCodeAt(AR)||0);if(HC){var A1=Aj.charCodeAt(AH)||0;tmp=(At+A.t9(
Aj,AH,A1))+At;tmp=A.t4(tmp,0,(A1+2)&0xFFFF);AH=AH+A1;if((tmp.charCodeAt(A1)||0)===
0x0A){tmp=A.t4(tmp,A1,0xFEFF);tmp=A.t4(tmp,A1+1,0x0A);}if((tmp.charCodeAt(2)||0)===
0x0A){tmp=A.t4(tmp,2,0xFEFF);tmp=A.t4(tmp,1,0x0A);}else tmp=A.t4(tmp,1,0xFEFF);}
tmp=tmp+A.t9(Aj,AH,AR-AH);if(FF&&(AR>=AH)){var A1=Aj.charCodeAt(AR)||0;var A$=(At+
A.t9(Aj,AR,A1))+At;A$=A.t4(A$,0,(A1+2)&0xFFFF);A$=A.t4(A$,1,0xFEFF);if((A$.charCodeAt(
A1)||0)===0x0A){A$=A.t4(A$,A1,0xFEFF);A$=A.t4(A$,A1+1,0x0A);}if((A$.charCodeAt(2
)||0)===0x0A){A$=A.t4(A$,2,0xFEFF);A$=A.t4(A$,1,0x0A);}else A$=A.t4(A$,1,0xFEFF);
tmp=tmp+A$;}Aj=String.fromCharCode(De&0xFFFF)+tmp;}var BQ=0;var A7=1;var FU=width-(
this.Ee*2);if(this.FC&&(this.Dr>0))FU=this.Dr;Cm=Aj.charCodeAt(0)||0;for(;BQ<Cm;
BQ=BQ+1){var Dj=HC&&!BQ;var Dk=FF&&(BQ===(Cm-1));var By=false;var Bz=false;var D1=
F0;if((F0&&Dj)&&!Dk){Dj=false;Dk=true;}else if((F0&&Dk)&&!Dj){Dk=false;Dj=true;}
var EK=A7+1;var A1=Aj.charCodeAt(A7)||0;var AH=EK;var AR=(EK+A1)-2;var HL=-1;var
HM=-1;if(!this.FC&&(font.D9(Aj,EK,A1-1)>FU)){if(((Af&0x4)===0x4))By=true;else if(((
Af&0x2)===0x2)){By=true;Bz=true;}else Bz=true;}if((Aj.charCodeAt(AH)||0)===0x0A)
AH=AH+1;if((Aj.charCodeAt(AR)||0)===0x0A)AR=AR-1;while(By&&((Aj.charCodeAt(AH)||
0)===0xFEFF))AH=AH+1;while(Bz&&((Aj.charCodeAt(AR)||0)===0xFEFF))AR=AR-1;By=By&&
!Dk;Bz=Bz&&!Dj;while((((By||Bz)||Dj)||Dk)&&(AH<AR)){if((By&&(D1||!Bz))||Dj){if(HL>
0)Aj=A.t4(Aj,HL,0xFEFF);Aj=A.t4(Aj,AH,0x2026);HL=AH;AH=AH+1;D1=!D1;Dj=false;if(font.
D9(Aj,EK,A1-1)<=FU){By=false;Bz=false;}else By=By||!Bz;}if((Bz&&(!D1||!By))||Dk){
if(HM>0)Aj=A.t4(Aj,HM,0xFEFF);Aj=A.t4(Aj,AR,0x2026);HM=AR;AR=AR-1;D1=!D1;Dk=false;
if(font.D9(Aj,EK,A1-1)<=FU){By=false;Bz=false;}else Bz=Bz||!By;}}A7=A7+A1;}this.
BC=[font.H9(Aj),((Aj.charCodeAt(0)||0)*EH)-leading];this.Ai=Aj;}if(this.Gd&&(this.
Ai!==A.hm)){var CP=[this.Ee,0];if((orient===1)||(orient===3)){CP=[CP[0],CP[0]];CP=[
0,CP[1]];}this.F=this.F|0x2000;this.N(A.ty(A.th(this.Do(),CP),this.Ef));this.F=this.
F&~0x2000;}if(!!this.K&&((this.F&0x1)===0x1))this.K.AM(this.M);A.lq([this,this.HU
],this);},JL:function(C){if(C===this.Gm)return;this.Gm=C;this.Ai=A.hm;this.Br=false;
A.lq([this,this.D0],this);},Fm:function(C){if(A.to(C,this.Cq))return;this.Cq=C;if(
!this.Dr||!!C)this.F=this.F&~0x100;else this.F=this.F|0x100;},Fi:function(C){var
B;if(C===this.D4)return;this.D4=C;if(!!this.K&&((this.F&0x1)===0x1))this.K.AM(this.
M);if(this.Gl){this.Ai=A.hm;this.Br=false;A.lq([this,this.D0],this);}if(this.Br)
A.lq([this,this.HU],this);},DQ:function(C){if(C===this.String)return;this.String=
C;this.Ai=A.hm;this.Br=false;A.lq([this,this.D0],this);},Fl:function(C){if(C===this.
AB)return;this.AB=C;this.Ai=A.hm;this.Br=false;A.lq([this,this.D0],this);},DO:function(
C){var B;if((((C===this.CV)&&(C===this.CW))&&(C===this.CS))&&(C===this.CT))return;
this.CV=C;this.CW=C;this.CS=C;this.CT=C;if(!!this.K&&((this.F&0x1)===0x1))this.K.
AM(this.M);},Gs:function(){if(!this.Br)this.FX(this);if(!this.Bi)return false;var
result=false;var bidi=this.Bi;result=A.qj(bidi);return result;},JG:function(){if(
!this.Br)this.FX(this);if(!this.Bi)return false;var result=false;var bidi=this.Bi;
result=A.sD(bidi);return result;},Do:function(){var B;if((this.String===A.hm)||!
this.AB)return Cr;if(!this.Br)this.FX(this);if(this.Ai===A.hm)return Cr;var leading=
this.AB.Leading;var EH=(this.AB.Ascent+this.AB.Descent)+this.AB.Leading;if(this.
Dq>0){leading=(this.Dq-this.AB.Ascent)-this.AB.Descent;EH=this.Dq;}if(A.tl(this.
BC,Ab))this.BC=[this.AB.H9(this.Ai),this.BC[1]];this.BC=[this.BC[0],((this.Ai.charCodeAt(
0)||0)*EH)-leading];var Af=this.D4;var orient=this.DR;var Ap=this.M;var CP=this.
Ee;var width=Ap[2]-Ap[0];var height=Ap[3]-Ap[1];if((orient===1)||(orient===3)){width=
height;height=Ap[2]-Ap[0];}var AD=[CP,0,width-CP,height];var Aa=[].concat(AD.slice(
0,2),A.tx(AD.slice(0,2),this.BC));if(((Af&0x80)===0x80)){if(this.Gs())Af=(Af&~0x80
)|0x4;else Af=(Af&~0x80)|0x1;}if(((Af&0x40)===0x40)){var BA=this.Dr;if(BA<=0)BA=
width-(this.Ee*2);if(BA<0)BA=0;if(BA>(Aa[2]-Aa[0]))Aa=A.tZ(Aa,BA);}if((Aa[2]-Aa[
0])!==(AD[2]-AD[0])){if(((Af&0x4)===0x4))Aa=A.t0(Aa,AD[2]-(Aa[2]-Aa[0]));else if(((
Af&0x2)===0x2))Aa=A.t0(Aa,(AD[0]+(((AD[2]-AD[0])/2)|0))-(((Aa[2]-Aa[0])/2)|0));}
if((Aa[3]-Aa[1])!==(AD[3]-AD[1])){if(((Af&0x20)===0x20))Aa=A.t2(Aa,AD[3]-(Aa[3]-
Aa[1]));else if(((Af&0x10)===0x10))Aa=A.t2(Aa,(AD[1]+(((AD[3]-AD[1])/2)|0))-(((Aa[
3]-Aa[1])/2)|0));}if(!orient)Aa=A.tz(Aa,Ap.slice(0,2));else if(orient===1){var Dh=[
Ap[0]+Aa[1],Ap[3]-Aa[2]];Aa=[].concat(Dh,A.tx(Dh,[this.BC[1],this.BC[0]]));}else
if(orient===2){var Dh=[Ap[2]-Aa[2],Ap[3]-Aa[3]];Aa=[].concat(Dh,A.tx(Dh,this.BC)
);}else if(orient===3){var Dh=[Ap[2]-Aa[3],Ap[1]+Aa[0]];Aa=[].concat(Dh,A.tx(Dh,[
this.BC[1],this.BC[0]]));}return A.tz(Aa,this.Ef);},_Init:function(aArg){A.Core.
AV._Init.call(this,aArg);this.__proto__=E.Text;},_Done:function(){this.BT();this.
__proto__=A.Core.AV;A.Core.AV._Done.call(this);},_Mark:function(D){var B;A.Core.
AV._Mark.call(this,D);if((B=this.AB)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.
Cq)&&((B=B[0])._cycle!=D))B._Mark(B._cycle=D);},_className:"Views::Text"};E.L9={
Lm:0x1,Lk:0x2,Ln:0x4,Ly:0x8,Lx:0x10,Lw:0x20,Ll:0x40,Lj:0x80};E.DR={LT:0,L6:1,L4:
2,L5:3};
E._Init=function(){E.BG.__proto__=A.Core.AV;E.Text.__proto__=A.Core.AV;};E.Au=function(
D){};return E;})();

/* Embedded Wizard */