/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.un)throw new Error("The unit file 'Views.js' included twice!");EmWiApp.
un=(function(){var A=EmWiApp;var E={};
var Ab=[0,0];var At="\uFEFF";var Cr=[0,0,0,0];
E.BG={CR:0xFFFFFFFF,CS:0xFFFFFFFF,CV:0xFFFFFFFF,CU:0xFFFFFFFF,BU:function(Az,aClip
,aOffset,AF,aBlend){var B;aBlend=aBlend&&((this.F&0x2)===0x2);AF=AF+1;if(AF<256){
var Cy=this.CU;var Cz=this.CV;var Cw=this.CR;var Cx=this.CS;Cy=(Cy&0x00FFFFFF)|((((
AF*((Cy>>24)&0xFF))>>8)&0xFF)<<24);Cz=(Cz&0x00FFFFFF)|((((AF*((Cz>>24)&0xFF))>>8
)&0xFF)<<24);Cw=(Cw&0x00FFFFFF)|((((AF*((Cw>>24)&0xFF))>>8)&0xFF)<<24);Cx=(Cx&0x00FFFFFF
)|((((AF*((Cx>>24)&0xFF))>>8)&0xFF)<<24);Az.EY(aClip,A.tz(this.M,aOffset),Cy,Cz,
Cx,Cw,aBlend);}else Az.EY(aClip,A.tz(this.M,aOffset),this.CU,this.CV,this.CS,this.
CR,aBlend);},DM:function(C){var B;if((((C===this.CU)&&(C===this.CV))&&(C===this.
CR))&&(C===this.CS))return;this.CU=C;this.CV=C;this.CR=C;this.CS=C;if(!!this.K&&((
this.F&0x1)===0x1))this.K.AM(this.M);},_Init:function(aArg){A.Core.AU._Init.call(
this,aArg);this.__proto__=E.BG;},_className:"Views::Rectangle"};E.Text={AB:null,
Cq:null,Ai:A.hm,String:A.hm,Bi:null,BC:A.qx,Ed:0,Dp:0,CR:0xFFFFFFFF,CS:0xFFFFFFFF
,CV:0xFFFFFFFF,CU:0xFFFFFFFF,Dq:0,Ee:A.qx,D3:0x12,Fn:255,DP:0,FA:false,Gb:false,
Gj:false,Gk:false,Br:false,BU:function(Az,aClip,aOffset,AF,aBlend){var B;if((this.
Ai===A.hm)||!this.AB)return;var Af=this.D3;var orient=this.DP;var font=this.AB;var
AD=A.tz(this.M,aOffset);var Cy=this.CU;var Cz=this.CV;var Cx=this.CS;var Cw=this.
CR;var CD=(((AF+1)*this.Fn)>>8)+1;var Cm=this.Ai.charCodeAt(0)||0;var S=A.tz(this.
Dm(),aOffset);var Bk=[AD[0]-S[0],(AD[1]-S[1])-font.Ascent];if(Cm<1)return;if(CD<
256){Cy=(Cy&0x00FFFFFF)|((((((Cy>>24)&0xFF)*CD)>>8)&0xFF)<<24);Cz=(Cz&0x00FFFFFF
)|((((((Cz>>24)&0xFF)*CD)>>8)&0xFF)<<24);Cx=(Cx&0x00FFFFFF)|((((((Cx>>24)&0xFF)*
CD)>>8)&0xFF)<<24);Cw=(Cw&0x00FFFFFF)|((((((Cw>>24)&0xFF)*CD)>>8)&0xFF)<<24);}if(((
Af&0x80)===0x80)){if(this.Gp())Af=(Af&~0x80)|0x4;else Af=(Af&~0x80)|0x1;}if(((Cm===
1)&&!((Af&0x40)===0x40))&&!orient){Az.H2(aClip,font,this.Ai,2,(this.Ai.charCodeAt(
1)||0)-1,AD,Bk,0,orient,Cy,Cz,Cx,Cw,true);return;}var leading=font.Leading;if(this.
Dp>0)leading=(this.Dp-font.Ascent)-font.Descent;var HW=(font.Ascent+font.Descent
)+leading;var FE=aClip[1]-S[1];var FF=aClip[3]-S[1];var Ep=S[2]-S[0];var BS=0;var
H=1;var A4=this.Ai.charCodeAt(H)||0;if(orient===1){Bk=[S[3]-AD[3],(AD[0]-S[0])-font.
Ascent];FE=aClip[0]-S[0];FF=aClip[2]-S[0];Ep=S[3]-S[1];}else if(orient===2){Bk=[
S[2]-AD[2],(S[3]-AD[3])-font.Ascent];FE=S[3]-aClip[3];FF=S[3]-aClip[1];}else if(
orient===3){Bk=[AD[1]-S[1],(S[2]-AD[2])-font.Ascent];FE=S[2]-aClip[2];FF=S[2]-aClip[
0];Ep=S[3]-S[1];}while(((BS+HW)<FE)&&(A4>0)){H=H+A4;BS=BS+HW;A4=this.Ai.charCodeAt(
H)||0;}while((BS<FF)&&(A4>0)){var DD=A.tw(Bk,[0,BS]);var Jp=0;var FO=false;if(((((
Af&0x40)===0x40)&&((this.Ai.charCodeAt((H+A4)-1)||0)!==0x0A))&&((this.Ai.charCodeAt(
H+1)||0)!==0x0A))&&((this.Ai.charCodeAt(H+A4)||0)!==0x00))FO=true;if(FO&&!!(Af&0x6
)){var Jo=H+A4;var Ja=this.Ai.indexOf(String.fromCharCode(0x20),H+1);var Jb=this.
Ai.indexOf(String.fromCharCode(0xA0),H+1);if(((Ja<0)||(Ja>=Jo))&&((Jb<0)||(Jb>=Jo
)))FO=false;}if(FO)Jp=Ep;else if(((Af&0x4)===0x4))DD=[(DD[0]-Ep)+font.D8(this.Ai
,H+1,A4-1),DD[1]];else if(((Af&0x2)===0x2))DD=[(DD[0]-((Ep/2)|0))+((font.D8(this.
Ai,H+1,A4-1)/2)|0),DD[1]];Az.H2(aClip,font,this.Ai,H+1,A4-1,AD,DD,Jp,orient,Cy,Cz
,Cx,Cw,true);H=H+A4;BS=BS+HW;A4=this.Ai.charCodeAt(H)||0;}},N:function(C){var B;
if(A.tm(C,this.M))return;var HU=false;if(!this.DP||(this.DP===2))HU=((B=this.M)[
2]-B[0])!==(C[2]-C[0]);else HU=((B=this.M)[3]-B[1])!==(C[3]-C[1]);if((((HU&&!this.
Dq)&&this.FA)&&this.Br)&&!((this.F&0x2000)===0x2000)){this.Ai=A.hm;this.Br=false;
A.lq([this,this.DZ],this);}if(((this.Gj&&this.Br)&&!A.tl([(B=this.M)[2]-B[0],B[3
]-B[1]],[C[2]-C[0],C[3]-C[1]]))&&!((this.F&0x2000)===0x2000)){this.Ai=A.hm;this.
Br=false;A.lq([this,this.DZ],this);}A.Core.AU.N.call(this,C);A.lq([this,this.HR]
,this);},BT:function(){if(!!this.Bi){this.HE(this.Bi);this.Bi=null;}},HE:function(
aBidi){if(!aBidi)return;A.ng(aBidi);},K5:function(aSize){var bidi=null;bidi=A.qk(
aSize);return bidi;},HR:function(Cn){A.lq(this.Cq,this);},DZ:function(Cn){A.lq([
this,this.FV],this);},FV:function(Cn){var B;if(this.Br)return;var orient=this.DP;
var width=(B=this.M)[2]-B[0];var height=(B=this.M)[3]-B[1];var BA=-1;if((orient===
1)||(orient===3)){width=height;height=(B=this.M)[2]-B[0];}if(this.FA){if(this.Dq>
0)BA=this.Dq;else if(!this.Gb)BA=width-(this.Ed*2);else BA=width;if(BA<0)BA=1;}if(
!!this.Bi){this.HE(this.Bi);this.Bi=null;}this.Br=true;if((this.String!==A.hm)&&
!!this.AB){var length=this.String.length;if(this.Gk)this.Bi=this.K5(length);this.
Ai=this.AB.JN(this.String,0,BA,length,this.Bi);if(!!this.Bi&&!this.JC()){this.HE(
this.Bi);this.Bi=null;}}else this.Ai=A.hm;this.BC=Ab;if(((this.Gj&&(this.Ai!==A.
hm))&&!this.Gb)&&!!this.AB){var Af=this.D3;var font=this.AB;var leading=font.Leading;
var Aj=this.Ai;var FY=this.Gp();if(((Af&0x80)===0x80)){if(FY)Af=(Af&~0x80)|0x4;else
Af=(Af&~0x80)|0x1;}if(this.Dp>0)leading=(this.Dp-font.Ascent)-font.Descent;var EG=(
font.Ascent+font.Descent)+leading;var Cm=Aj.charCodeAt(0)||0;var Dc=((height+leading
)/EG)|0;var Hz=false;var FD=false;if(Dc<=0)Dc=1;if(Cm>Dc){var BQ=0;var EH=0;var FX=
Cm-1;var AH=0;var AQ=Aj.length;var tmp=A.hm;if(((Af&0x20)===0x20))EH=Cm-Dc;else if(((
Af&0x10)===0x10)){EH=((Cm-Dc)/2)|0;FX=(EH+Dc)-1;}else FX=Dc-1;Hz=EH>0;FD=FX<(Cm-
1);for(AH=1;BQ<EH;BQ=BQ+1)AH=AH+(Aj.charCodeAt(AH)||0);if(FD)for(AQ=AH;BQ<FX;BQ=
BQ+1)AQ=AQ+(Aj.charCodeAt(AQ)||0);if(Hz){var A1=Aj.charCodeAt(AH)||0;tmp=(At+A.t9(
Aj,AH,A1))+At;tmp=A.t4(tmp,0,(A1+2)&0xFFFF);AH=AH+A1;if((tmp.charCodeAt(A1)||0)===
0x0A){tmp=A.t4(tmp,A1,0xFEFF);tmp=A.t4(tmp,A1+1,0x0A);}if((tmp.charCodeAt(2)||0)===
0x0A){tmp=A.t4(tmp,2,0xFEFF);tmp=A.t4(tmp,1,0x0A);}else tmp=A.t4(tmp,1,0xFEFF);}
tmp=tmp+A.t9(Aj,AH,AQ-AH);if(FD&&(AQ>=AH)){var A1=Aj.charCodeAt(AQ)||0;var A$=(At+
A.t9(Aj,AQ,A1))+At;A$=A.t4(A$,0,(A1+2)&0xFFFF);A$=A.t4(A$,1,0xFEFF);if((A$.charCodeAt(
A1)||0)===0x0A){A$=A.t4(A$,A1,0xFEFF);A$=A.t4(A$,A1+1,0x0A);}if((A$.charCodeAt(2
)||0)===0x0A){A$=A.t4(A$,2,0xFEFF);A$=A.t4(A$,1,0x0A);}else A$=A.t4(A$,1,0xFEFF);
tmp=tmp+A$;}Aj=String.fromCharCode(Dc&0xFFFF)+tmp;}var BQ=0;var A7=1;var FS=width-(
this.Ed*2);if(this.FA&&(this.Dq>0))FS=this.Dq;Cm=Aj.charCodeAt(0)||0;for(;BQ<Cm;
BQ=BQ+1){var Dh=Hz&&!BQ;var Di=FD&&(BQ===(Cm-1));var By=false;var Bz=false;var D0=
FY;if((FY&&Dh)&&!Di){Dh=false;Di=true;}else if((FY&&Di)&&!Dh){Di=false;Dh=true;}
var EJ=A7+1;var A1=Aj.charCodeAt(A7)||0;var AH=EJ;var AQ=(EJ+A1)-2;var HI=-1;var
HJ=-1;if(!this.FA&&(font.D8(Aj,EJ,A1-1)>FS)){if(((Af&0x4)===0x4))By=true;else if(((
Af&0x2)===0x2)){By=true;Bz=true;}else Bz=true;}if((Aj.charCodeAt(AH)||0)===0x0A)
AH=AH+1;if((Aj.charCodeAt(AQ)||0)===0x0A)AQ=AQ-1;while(By&&((Aj.charCodeAt(AH)||
0)===0xFEFF))AH=AH+1;while(Bz&&((Aj.charCodeAt(AQ)||0)===0xFEFF))AQ=AQ-1;By=By&&
!Di;Bz=Bz&&!Dh;while((((By||Bz)||Dh)||Di)&&(AH<AQ)){if((By&&(D0||!Bz))||Dh){if(HI>
0)Aj=A.t4(Aj,HI,0xFEFF);Aj=A.t4(Aj,AH,0x2026);HI=AH;AH=AH+1;D0=!D0;Dh=false;if(font.
D8(Aj,EJ,A1-1)<=FS){By=false;Bz=false;}else By=By||!Bz;}if((Bz&&(!D0||!By))||Di){
if(HJ>0)Aj=A.t4(Aj,HJ,0xFEFF);Aj=A.t4(Aj,AQ,0x2026);HJ=AQ;AQ=AQ-1;D0=!D0;Di=false;
if(font.D8(Aj,EJ,A1-1)<=FS){By=false;Bz=false;}else Bz=Bz||!By;}}A7=A7+A1;}this.
BC=[font.H6(Aj),((Aj.charCodeAt(0)||0)*EG)-leading];this.Ai=Aj;}if(this.Gb&&(this.
Ai!==A.hm)){var CO=[this.Ed,0];if((orient===1)||(orient===3)){CO=[CO[0],CO[0]];CO=[
0,CO[1]];}this.F=this.F|0x2000;this.N(A.ty(A.th(this.Dm(),CO),this.Ee));this.F=this.
F&~0x2000;}if(!!this.K&&((this.F&0x1)===0x1))this.K.AM(this.M);A.lq([this,this.HR
],this);},JH:function(C){if(C===this.Gk)return;this.Gk=C;this.Ai=A.hm;this.Br=false;
A.lq([this,this.DZ],this);},Fl:function(C){if(A.to(C,this.Cq))return;this.Cq=C;if(
!this.Dq||!!C)this.F=this.F&~0x100;else this.F=this.F|0x100;},Fh:function(C){var
B;if(C===this.D3)return;this.D3=C;if(!!this.K&&((this.F&0x1)===0x1))this.K.AM(this.
M);if(this.Gj){this.Ai=A.hm;this.Br=false;A.lq([this,this.DZ],this);}if(this.Br)
A.lq([this,this.HR],this);},DO:function(C){if(C===this.String)return;this.String=
C;this.Ai=A.hm;this.Br=false;A.lq([this,this.DZ],this);},Fk:function(C){if(C===this.
AB)return;this.AB=C;this.Ai=A.hm;this.Br=false;A.lq([this,this.DZ],this);},DM:function(
C){var B;if((((C===this.CU)&&(C===this.CV))&&(C===this.CR))&&(C===this.CS))return;
this.CU=C;this.CV=C;this.CR=C;this.CS=C;if(!!this.K&&((this.F&0x1)===0x1))this.K.
AM(this.M);},Gp:function(){if(!this.Br)this.FV(this);if(!this.Bi)return false;var
result=false;var bidi=this.Bi;result=A.qj(bidi);return result;},JC:function(){if(
!this.Br)this.FV(this);if(!this.Bi)return false;var result=false;var bidi=this.Bi;
result=A.sD(bidi);return result;},Dm:function(){var B;if((this.String===A.hm)||!
this.AB)return Cr;if(!this.Br)this.FV(this);if(this.Ai===A.hm)return Cr;var leading=
this.AB.Leading;var EG=(this.AB.Ascent+this.AB.Descent)+this.AB.Leading;if(this.
Dp>0){leading=(this.Dp-this.AB.Ascent)-this.AB.Descent;EG=this.Dp;}if(A.tl(this.
BC,Ab))this.BC=[this.AB.H6(this.Ai),this.BC[1]];this.BC=[this.BC[0],((this.Ai.charCodeAt(
0)||0)*EG)-leading];var Af=this.D3;var orient=this.DP;var Ap=this.M;var CO=this.
Ed;var width=Ap[2]-Ap[0];var height=Ap[3]-Ap[1];if((orient===1)||(orient===3)){width=
height;height=Ap[2]-Ap[0];}var AD=[CO,0,width-CO,height];var Aa=[].concat(AD.slice(
0,2),A.tx(AD.slice(0,2),this.BC));if(((Af&0x80)===0x80)){if(this.Gp())Af=(Af&~0x80
)|0x4;else Af=(Af&~0x80)|0x1;}if(((Af&0x40)===0x40)){var BA=this.Dq;if(BA<=0)BA=
width-(this.Ed*2);if(BA<0)BA=0;if(BA>(Aa[2]-Aa[0]))Aa=A.tZ(Aa,BA);}if((Aa[2]-Aa[
0])!==(AD[2]-AD[0])){if(((Af&0x4)===0x4))Aa=A.t0(Aa,AD[2]-(Aa[2]-Aa[0]));else if(((
Af&0x2)===0x2))Aa=A.t0(Aa,(AD[0]+(((AD[2]-AD[0])/2)|0))-(((Aa[2]-Aa[0])/2)|0));}
if((Aa[3]-Aa[1])!==(AD[3]-AD[1])){if(((Af&0x20)===0x20))Aa=A.t2(Aa,AD[3]-(Aa[3]-
Aa[1]));else if(((Af&0x10)===0x10))Aa=A.t2(Aa,(AD[1]+(((AD[3]-AD[1])/2)|0))-(((Aa[
3]-Aa[1])/2)|0));}if(!orient)Aa=A.tz(Aa,Ap.slice(0,2));else if(orient===1){var Df=[
Ap[0]+Aa[1],Ap[3]-Aa[2]];Aa=[].concat(Df,A.tx(Df,[this.BC[1],this.BC[0]]));}else
if(orient===2){var Df=[Ap[2]-Aa[2],Ap[3]-Aa[3]];Aa=[].concat(Df,A.tx(Df,this.BC)
);}else if(orient===3){var Df=[Ap[2]-Aa[3],Ap[1]+Aa[0]];Aa=[].concat(Df,A.tx(Df,[
this.BC[1],this.BC[0]]));}return A.tz(Aa,this.Ee);},_Init:function(aArg){A.Core.
AU._Init.call(this,aArg);this.__proto__=E.Text;},_Done:function(){this.BT();this.
__proto__=A.Core.AU;A.Core.AU._Done.call(this);},_Mark:function(D){var B;A.Core.
AU._Mark.call(this,D);if((B=this.AB)&&(B._cycle!=D))B._Mark(B._cycle=D);if((B=this.
Cq)&&((B=B[0])._cycle!=D))B._Mark(B._cycle=D);},_className:"Views::Text"};E.L3={
Lg:0x1,Le:0x2,Lh:0x4,Ls:0x8,Lr:0x10,Lq:0x20,Lf:0x40,Ld:0x80};E.DP={LN:0,L0:1,LY:
2,LZ:3};
E._Init=function(){E.BG.__proto__=A.Core.AU;E.Text.__proto__=A.Core.AU;};E.Au=function(
D){};return E;})();

/* Embedded Wizard */