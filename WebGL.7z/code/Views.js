/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.um)throw new Error("The unit file 'Views.js' included twice!");EmWiApp.
um=(function(){var B=EmWiApp;var D={};
var Z=[0,0];var Ay="\uFEFF";var B1=[0,0,0,0];
D.BF={Dc:0xFFFFFFFF,Dd:0xFFFFFFFF,Df:0xFFFFFFFF,De:0xFFFFFFFF,Ce:function(AE,aClip
,aOffset,AF,aBlend){var A;aBlend=aBlend&&((this.F&0x2)===0x2);AF=AF+1;if(AF<256){
var B8=this.De;var B9=this.Df;var B6=this.Dc;var B7=this.Dd;B8=(B8&0x00FFFFFF)|((((
AF*((B8>>24)&0xFF))>>8)&0xFF)<<24);B9=(B9&0x00FFFFFF)|((((AF*((B9>>24)&0xFF))>>8
)&0xFF)<<24);B6=(B6&0x00FFFFFF)|((((AF*((B6>>24)&0xFF))>>8)&0xFF)<<24);B7=(B7&0x00FFFFFF
)|((((AF*((B7>>24)&0xFF))>>8)&0xFF)<<24);AE.FA(aClip,B.tz(this.M,aOffset),B8,B9,
B7,B6,aBlend);}else AE.FA(aClip,B.tz(this.M,aOffset),this.De,this.Df,this.Dd,this.
Dc,aBlend);},_Init:function(aArg){B.Core.AN._Init.call(this,aArg);this.__proto__=
D.BF;},_className:"Views::Rectangle"};D.Text={Ax:null,B0:null,Ag:B.hm,String:B.hm
,A_:null,Bp:B.qx,D7:0,CU:0,Dc:0xFFFFFFFF,Dd:0xFFFFFFFF,Df:0xFFFFFFFF,De:0xFFFFFFFF
,CV:0,D9:B.qx,DP:0x12,FJ:255,DD:0,E1:false,Fq:false,Fy:false,Fz:false,Bg:false,Ce:
function(AE,aClip,aOffset,AF,aBlend){var A;if((this.Ag===B.hm)||!this.Ax)return;
var Ad=this.DP;var orient=this.DD;var font=this.Ax;var Au=B.tz(this.M,aOffset);var
B8=this.De;var B9=this.Df;var B7=this.Dd;var B6=this.Dc;var Ex=(((AF+1)*this.FJ)>>
8)+1;var BW=this.Ag.charCodeAt(0)||0;var R=B.tz(this.CS(),aOffset);var Ba=[Au[0]-
R[0],(Au[1]-R[1])-font.Ascent];if(BW<1)return;if(Ex<256){B8=(B8&0x00FFFFFF)|((((((
B8>>24)&0xFF)*Ex)>>8)&0xFF)<<24);B9=(B9&0x00FFFFFF)|((((((B9>>24)&0xFF)*Ex)>>8)&
0xFF)<<24);B7=(B7&0x00FFFFFF)|((((((B7>>24)&0xFF)*Ex)>>8)&0xFF)<<24);B6=(B6&0x00FFFFFF
)|((((((B6>>24)&0xFF)*Ex)>>8)&0xFF)<<24);}if(((Ad&0x80)===0x80)){if(this.FD())Ad=(
Ad&~0x80)|0x4;else Ad=(Ad&~0x80)|0x1;}if(((BW===1)&&!((Ad&0x40)===0x40))&&!orient
){AE.GF(aClip,font,this.Ag,2,(this.Ag.charCodeAt(1)||0)-1,Au,Ba,0,orient,B8,B9,B7
,B6,true);return;}var leading=font.Leading;if(this.CU>0)leading=(this.CU-font.Ascent
)-font.Descent;var GB=(font.Ascent+font.Descent)+leading;var E5=aClip[1]-R[1];var
E6=aClip[3]-R[1];var Ek=R[2]-R[0];var Db=0;var I=1;var AW=this.Ag.charCodeAt(I)||
0;if(orient===1){Ba=[R[3]-Au[3],(Au[0]-R[0])-font.Ascent];E5=aClip[0]-R[0];E6=aClip[
2]-R[0];Ek=R[3]-R[1];}else if(orient===2){Ba=[R[2]-Au[2],(R[3]-Au[3])-font.Ascent
];E5=R[3]-aClip[3];E6=R[3]-aClip[1];}else if(orient===3){Ba=[Au[1]-R[1],(R[2]-Au[
2])-font.Ascent];E5=R[2]-aClip[2];E6=R[2]-aClip[0];Ek=R[3]-R[1];}while(((Db+GB)<
E5)&&(AW>0)){I=I+AW;Db=Db+GB;AW=this.Ag.charCodeAt(I)||0;}while((Db<E6)&&(AW>0)){
var C7=B.tw(Ba,[0,Db]);var Hz=0;var Fc=false;if(((((Ad&0x40)===0x40)&&((this.Ag.
charCodeAt((I+AW)-1)||0)!==0x0A))&&((this.Ag.charCodeAt(I+1)||0)!==0x0A))&&((this.
Ag.charCodeAt(I+AW)||0)!==0x00))Fc=true;if(Fc&&!!(Ad&0x6)){var Hy=I+AW;var Hk=this.
Ag.indexOf(String.fromCharCode(0x20),I+1);var Hl=this.Ag.indexOf(String.fromCharCode(
0xA0),I+1);if(((Hk<0)||(Hk>=Hy))&&((Hl<0)||(Hl>=Hy)))Fc=false;}if(Fc)Hz=Ek;else if(((
Ad&0x4)===0x4))C7=[(C7[0]-Ek)+font.DY(this.Ag,I+1,AW-1),C7[1]];else if(((Ad&0x2)===
0x2))C7=[(C7[0]-((Ek/2)|0))+((font.DY(this.Ag,I+1,AW-1)/2)|0),C7[1]];AE.GF(aClip
,font,this.Ag,I+1,AW-1,Au,C7,Hz,orient,B8,B9,B7,B6,true);I=I+AW;Db=Db+GB;AW=this.
Ag.charCodeAt(I)||0;}},U:function(C){var A;if(B.tm(C,this.M))return;var Gz=false;
if(!this.DD||(this.DD===2))Gz=((A=this.M)[2]-A[0])!==(C[2]-C[0]);else Gz=((A=this.
M)[3]-A[1])!==(C[3]-C[1]);if((((Gz&&!this.CV)&&this.E1)&&this.Bg)&&!((this.F&0x2000
)===0x2000)){this.Ag=B.hm;this.Bg=false;B.lq([this,this.DL],this);}if(((this.Fy&&
this.Bg)&&!B.tl([(A=this.M)[2]-A[0],A[3]-A[1]],[C[2]-C[0],C[3]-C[1]]))&&!((this.
F&0x2000)===0x2000)){this.Ag=B.hm;this.Bg=false;B.lq([this,this.DL],this);}B.Core.
AN.U.call(this,C);B.lq([this,this.Gw],this);},BE:function(){if(!!this.A_){this.Gm(
this.A_);this.A_=null;}},Gm:function(aBidi){if(!aBidi)return;B.ng(aBidi);},I_:function(
aSize){var bidi=null;bidi=B.qk(aSize);return bidi;},Gw:function(BX){B.lq(this.B0
,this);},DL:function(BX){B.lq([this,this.Fi],this);},Fi:function(BX){var A;if(this.
Bg)return;var orient=this.DD;var width=(A=this.M)[2]-A[0];var height=(A=this.M)[
3]-A[1];var Bo=-1;if((orient===1)||(orient===3)){width=height;height=(A=this.M)[
2]-A[0];}if(this.E1){if(this.CV>0)Bo=this.CV;else if(!this.Fq)Bo=width-(this.D7*
2);else Bo=width;if(Bo<0)Bo=1;}if(!!this.A_){this.Gm(this.A_);this.A_=null;}this.
Bg=true;if((this.String!==B.hm)&&!!this.Ax){var length=this.String.length;if(this.
Fz)this.A_=this.I_(length);this.Ag=this.Ax.H1(this.String,0,Bo,length,this.A_);if(
!!this.A_&&!this.HI()){this.Gm(this.A_);this.A_=null;}}else this.Ag=B.hm;this.Bp=
Z;if(((this.Fy&&(this.Ag!==B.hm))&&!this.Fq)&&!!this.Ax){var Ad=this.DP;var font=
this.Ax;var leading=font.Leading;var Ah=this.Ag;var Fl=this.FD();if(((Ad&0x80)===
0x80)){if(Fl)Ad=(Ad&~0x80)|0x4;else Ad=(Ad&~0x80)|0x1;}if(this.CU>0)leading=(this.
CU-font.Ascent)-font.Descent;var EA=(font.Ascent+font.Descent)+leading;var BW=Ah.
charCodeAt(0)||0;var CJ=((height+leading)/EA)|0;var Gi=false;var E4=false;if(CJ<=
0)CJ=1;if(BW>CJ){var BC=0;var EB=0;var Fk=BW-1;var AA=0;var AJ=Ah.length;var tmp=
B.hm;if(((Ad&0x20)===0x20))EB=BW-CJ;else if(((Ad&0x10)===0x10)){EB=((BW-CJ)/2)|0;
Fk=(EB+CJ)-1;}else Fk=CJ-1;Gi=EB>0;E4=Fk<(BW-1);for(AA=1;BC<EB;BC=BC+1)AA=AA+(Ah.
charCodeAt(AA)||0);if(E4)for(AJ=AA;BC<Fk;BC=BC+1)AJ=AJ+(Ah.charCodeAt(AJ)||0);if(
Gi){var AT=Ah.charCodeAt(AA)||0;tmp=(Ay+B.t9(Ah,AA,AT))+Ay;tmp=B.t4(tmp,0,(AT+2)&
0xFFFF);AA=AA+AT;if((tmp.charCodeAt(AT)||0)===0x0A){tmp=B.t4(tmp,AT,0xFEFF);tmp=
B.t4(tmp,AT+1,0x0A);}if((tmp.charCodeAt(2)||0)===0x0A){tmp=B.t4(tmp,2,0xFEFF);tmp=
B.t4(tmp,1,0x0A);}else tmp=B.t4(tmp,1,0xFEFF);}tmp=tmp+B.t9(Ah,AA,AJ-AA);if(E4&&(
AJ>=AA)){var AT=Ah.charCodeAt(AJ)||0;var A3=(Ay+B.t9(Ah,AJ,AT))+Ay;A3=B.t4(A3,0,(
AT+2)&0xFFFF);A3=B.t4(A3,1,0xFEFF);if((A3.charCodeAt(AT)||0)===0x0A){A3=B.t4(A3,
AT,0xFEFF);A3=B.t4(A3,AT+1,0x0A);}if((A3.charCodeAt(2)||0)===0x0A){A3=B.t4(A3,2,
0xFEFF);A3=B.t4(A3,1,0x0A);}else A3=B.t4(A3,1,0xFEFF);tmp=tmp+A3;}Ah=String.fromCharCode(
CJ&0xFFFF)+tmp;}var BC=0;var AZ=1;var Fg=width-(this.D7*2);if(this.E1&&(this.CV>
0))Fg=this.CV;BW=Ah.charCodeAt(0)||0;for(;BC<BW;BC=BC+1){var CO=Gi&&!BC;var CP=E4&&(
BC===(BW-1));var Bm=false;var Bn=false;var DM=Fl;if((Fl&&CO)&&!CP){CO=false;CP=true;
}else if((Fl&&CP)&&!CO){CP=false;CO=true;}var ED=AZ+1;var AT=Ah.charCodeAt(AZ)||
0;var AA=ED;var AJ=(ED+AT)-2;var Gq=-1;var Gr=-1;if(!this.E1&&(font.DY(Ah,ED,AT-
1)>Fg)){if(((Ad&0x4)===0x4))Bm=true;else if(((Ad&0x2)===0x2)){Bm=true;Bn=true;}else
Bn=true;}if((Ah.charCodeAt(AA)||0)===0x0A)AA=AA+1;if((Ah.charCodeAt(AJ)||0)===0x0A
)AJ=AJ-1;while(Bm&&((Ah.charCodeAt(AA)||0)===0xFEFF))AA=AA+1;while(Bn&&((Ah.charCodeAt(
AJ)||0)===0xFEFF))AJ=AJ-1;Bm=Bm&&!CP;Bn=Bn&&!CO;while((((Bm||Bn)||CO)||CP)&&(AA<
AJ)){if((Bm&&(DM||!Bn))||CO){if(Gq>0)Ah=B.t4(Ah,Gq,0xFEFF);Ah=B.t4(Ah,AA,0x2026);
Gq=AA;AA=AA+1;DM=!DM;CO=false;if(font.DY(Ah,ED,AT-1)<=Fg){Bm=false;Bn=false;}else
Bm=Bm||!Bn;}if((Bn&&(!DM||!Bm))||CP){if(Gr>0)Ah=B.t4(Ah,Gr,0xFEFF);Ah=B.t4(Ah,AJ
,0x2026);Gr=AJ;AJ=AJ-1;DM=!DM;CP=false;if(font.DY(Ah,ED,AT-1)<=Fg){Bm=false;Bn=false;
}else Bn=Bn||!Bm;}}AZ=AZ+AT;}this.Bp=[font.GK(Ah),((Ah.charCodeAt(0)||0)*EA)-leading
];this.Ag=Ah;}if(this.Fq&&(this.Ag!==B.hm)){var Cn=[this.D7,0];if((orient===1)||(
orient===3)){Cn=[Cn[0],Cn[0]];Cn=[0,Cn[1]];}this.F=this.F|0x2000;this.U(B.ty(B.th(
this.CS(),Cn),this.D9));this.F=this.F&~0x2000;}if(!!this.L&&((this.F&0x1)===0x1)
)this.L.AS(this.M);B.lq([this,this.Gw],this);},HN:function(C){if(C===this.Fz)return;
this.Fz=C;this.Ag=B.hm;this.Bg=false;B.lq([this,this.DL],this);},ES:function(C){
if(B.to(C,this.B0))return;this.B0=C;if(!this.CV||!!C)this.F=this.F&~0x100;else this.
F=this.F|0x100;},EN:function(C){var A;if(C===this.DP)return;this.DP=C;if(!!this.
L&&((this.F&0x1)===0x1))this.L.AS(this.M);if(this.Fy){this.Ag=B.hm;this.Bg=false;
B.lq([this,this.DL],this);}if(this.Bg)B.lq([this,this.Gw],this);},Dx:function(C){
if(C===this.String)return;this.String=C;this.Ag=B.hm;this.Bg=false;B.lq([this,this.
DL],this);},EQ:function(C){if(C===this.Ax)return;this.Ax=C;this.Ag=B.hm;this.Bg=
false;B.lq([this,this.DL],this);},EO:function(C){var A;if((((C===this.De)&&(C===
this.Df))&&(C===this.Dc))&&(C===this.Dd))return;this.De=C;this.Df=C;this.Dc=C;this.
Dd=C;if(!!this.L&&((this.F&0x1)===0x1))this.L.AS(this.M);},FD:function(){if(!this.
Bg)this.Fi(this);if(!this.A_)return false;var result=false;var bidi=this.A_;result=
B.qj(bidi);return result;},HI:function(){if(!this.Bg)this.Fi(this);if(!this.A_)return false;
var result=false;var bidi=this.A_;result=B.sD(bidi);return result;},CS:function(
){var A;if((this.String===B.hm)||!this.Ax)return B1;if(!this.Bg)this.Fi(this);if(
this.Ag===B.hm)return B1;var leading=this.Ax.Leading;var EA=(this.Ax.Ascent+this.
Ax.Descent)+this.Ax.Leading;if(this.CU>0){leading=(this.CU-this.Ax.Ascent)-this.
Ax.Descent;EA=this.CU;}if(B.tl(this.Bp,Z))this.Bp=[this.Ax.GK(this.Ag),this.Bp[1
]];this.Bp=[this.Bp[0],((this.Ag.charCodeAt(0)||0)*EA)-leading];var Ad=this.DP;var
orient=this.DD;var Aj=this.M;var Cn=this.D7;var width=Aj[2]-Aj[0];var height=Aj[
3]-Aj[1];if((orient===1)||(orient===3)){width=height;height=Aj[2]-Aj[0];}var Au=[
Cn,0,width-Cn,height];var X=[].concat(Au.slice(0,2),B.tx(Au.slice(0,2),this.Bp));
if(((Ad&0x80)===0x80)){if(this.FD())Ad=(Ad&~0x80)|0x4;else Ad=(Ad&~0x80)|0x1;}if(((
Ad&0x40)===0x40)){var Bo=this.CV;if(Bo<=0)Bo=width-(this.D7*2);if(Bo<0)Bo=0;if(Bo>(
X[2]-X[0]))X=B.tZ(X,Bo);}if((X[2]-X[0])!==(Au[2]-Au[0])){if(((Ad&0x4)===0x4))X=B.
t0(X,Au[2]-(X[2]-X[0]));else if(((Ad&0x2)===0x2))X=B.t0(X,(Au[0]+(((Au[2]-Au[0])
/2)|0))-(((X[2]-X[0])/2)|0));}if((X[3]-X[1])!==(Au[3]-Au[1])){if(((Ad&0x20)===0x20
))X=B.t2(X,Au[3]-(X[3]-X[1]));else if(((Ad&0x10)===0x10))X=B.t2(X,(Au[1]+(((Au[3
]-Au[1])/2)|0))-(((X[3]-X[1])/2)|0));}if(!orient)X=B.tz(X,Aj.slice(0,2));else if(
orient===1){var CM=[Aj[0]+X[1],Aj[3]-X[2]];X=[].concat(CM,B.tx(CM,[this.Bp[1],this.
Bp[0]]));}else if(orient===2){var CM=[Aj[2]-X[2],Aj[3]-X[3]];X=[].concat(CM,B.tx(
CM,this.Bp));}else if(orient===3){var CM=[Aj[2]-X[3],Aj[1]+X[0]];X=[].concat(CM,
B.tx(CM,[this.Bp[1],this.Bp[0]]));}return B.tz(X,this.D9);},_Init:function(aArg){
B.Core.AN._Init.call(this,aArg);this.__proto__=D.Text;},_Done:function(){this.BE(
);this.__proto__=B.Core.AN;B.Core.AN._Done.call(this);},_Mark:function(E){var A;
B.Core.AN._Mark.call(this,E);if((A=this.Ax)&&(A._cycle!=E))A._Mark(A._cycle=E);if((
A=this.B0)&&((A=A[0])._cycle!=E))A._Mark(A._cycle=E);},_className:"Views::Text"};
D.J5={Jl:0x1,Jj:0x2,Jm:0x4,Jx:0x8,Jw:0x10,Jv:0x20,Jk:0x40,Ji:0x80};D.DD={JP:0,J2:
1,J0:2,J1:3};
D._Init=function(){D.BF.__proto__=B.Core.AN;D.Text.__proto__=B.Core.AN;};D.An=function(
E){};return D;})();

/* Embedded Wizard */