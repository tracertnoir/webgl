/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.um)throw new Error("The unit file 'Views.js' included twice!");EmWiApp.
um=(function(){var B=EmWiApp;var D={};
var Ac=[0,0];var Ax="\uFEFF";var BV=[0,0,0,0];
D.BA={C7:0xFFFFFFFF,C8:0xFFFFFFFF,C_:0xFFFFFFFF,C9:0xFFFFFFFF,Ca:function(AD,aClip
,aOffset,AE,aBlend){var A;aBlend=aBlend&&((this.F&0x2)===0x2);AE=AE+1;if(AE<256){
var B2=this.C9;var B3=this.C_;var B0=this.C7;var B1=this.C8;B2=(B2&0x00FFFFFF)|((((
AE*((B2>>24)&0xFF))>>8)&0xFF)<<24);B3=(B3&0x00FFFFFF)|((((AE*((B3>>24)&0xFF))>>8
)&0xFF)<<24);B0=(B0&0x00FFFFFF)|((((AE*((B0>>24)&0xFF))>>8)&0xFF)<<24);B1=(B1&0x00FFFFFF
)|((((AE*((B1>>24)&0xFF))>>8)&0xFF)<<24);AD.Fq(aClip,B.tz(this.M,aOffset),B2,B3,
B1,B0,aBlend);}else AD.Fq(aClip,B.tz(this.M,aOffset),this.C9,this.C_,this.C8,this.
C7,aBlend);},_Init:function(aArg){B.Core.AL._Init.call(this,aArg);this.__proto__=
D.BA;},_className:"Views::Rectangle"};D.Text={Aw:null,BJ:null,Ag:B.hm,String:B.hm
,A8:null,Bl:B.qx,D0:0,CN:0,C7:0xFFFFFFFF,C8:0xFFFFFFFF,C_:0xFFFFFFFF,C9:0xFFFFFFFF
,CO:0,D2:B.qx,Dp:0x12,FB:255,Dd:0,ES:false,Fi:false,Fo:false,Fp:false,Bc:false,Ca:
function(AD,aClip,aOffset,AE,aBlend){var A;if((this.Ag===B.hm)||!this.Aw)return;
var Ad=this.Dp;var orient=this.Dd;var font=this.Aw;var At=B.tz(this.M,aOffset);var
B2=this.C9;var B3=this.C_;var B1=this.C8;var B0=this.C7;var Er=(((AE+1)*this.FB)>>
8)+1;var BG=this.Ag.charCodeAt(0)||0;var Q=B.tz(this.CL(),aOffset);var A_=[At[0]-
Q[0],(At[1]-Q[1])-font.Ascent];if(BG<1)return;if(Er<256){B2=(B2&0x00FFFFFF)|((((((
B2>>24)&0xFF)*Er)>>8)&0xFF)<<24);B3=(B3&0x00FFFFFF)|((((((B3>>24)&0xFF)*Er)>>8)&
0xFF)<<24);B1=(B1&0x00FFFFFF)|((((((B1>>24)&0xFF)*Er)>>8)&0xFF)<<24);B0=(B0&0x00FFFFFF
)|((((((B0>>24)&0xFF)*Er)>>8)&0xFF)<<24);}if(((Ad&0x80)===0x80)){if(this.Ft())Ad=(
Ad&~0x80)|0x4;else Ad=(Ad&~0x80)|0x1;}if(((BG===1)&&!((Ad&0x40)===0x40))&&!orient
){AD.Gx(aClip,font,this.Ag,2,(this.Ag.charCodeAt(1)||0)-1,At,A_,0,orient,B2,B3,B1
,B0,true);return;}var leading=font.Leading;if(this.CN>0)leading=(this.CN-font.Ascent
)-font.Descent;var Gt=(font.Ascent+font.Descent)+leading;var EW=aClip[1]-Q[1];var
EX=aClip[3]-Q[1];var Ef=Q[2]-Q[0];var C6=0;var H=1;var AV=this.Ag.charCodeAt(H)||
0;if(orient===1){A_=[Q[3]-At[3],(At[0]-Q[0])-font.Ascent];EW=aClip[0]-Q[0];EX=aClip[
2]-Q[0];Ef=Q[3]-Q[1];}else if(orient===2){A_=[Q[2]-At[2],(Q[3]-At[3])-font.Ascent
];EW=Q[3]-aClip[3];EX=Q[3]-aClip[1];}else if(orient===3){A_=[At[1]-Q[1],(Q[2]-At[
2])-font.Ascent];EW=Q[2]-aClip[2];EX=Q[2]-aClip[0];Ef=Q[3]-Q[1];}while(((C6+Gt)<
EW)&&(AV>0)){H=H+AV;C6=C6+Gt;AV=this.Ag.charCodeAt(H)||0;}while((C6<EX)&&(AV>0)){
var C1=B.tw(A_,[0,C6]);var Hq=0;var E5=false;if(((((Ad&0x40)===0x40)&&((this.Ag.
charCodeAt((H+AV)-1)||0)!==0x0A))&&((this.Ag.charCodeAt(H+1)||0)!==0x0A))&&((this.
Ag.charCodeAt(H+AV)||0)!==0x00))E5=true;if(E5&&!!(Ad&0x6)){var Hp=H+AV;var Hb=this.
Ag.indexOf(String.fromCharCode(0x20),H+1);var Hc=this.Ag.indexOf(String.fromCharCode(
0xA0),H+1);if(((Hb<0)||(Hb>=Hp))&&((Hc<0)||(Hc>=Hp)))E5=false;}if(E5)Hq=Ef;else if(((
Ad&0x4)===0x4))C1=[(C1[0]-Ef)+font.Dy(this.Ag,H+1,AV-1),C1[1]];else if(((Ad&0x2)===
0x2))C1=[(C1[0]-((Ef/2)|0))+((font.Dy(this.Ag,H+1,AV-1)/2)|0),C1[1]];AD.Gx(aClip
,font,this.Ag,H+1,AV-1,At,C1,Hq,orient,B2,B3,B1,B0,true);H=H+AV;C6=C6+Gt;AV=this.
Ag.charCodeAt(H)||0;}},S:function(C){var A;if(B.tm(C,this.M))return;var Gr=false;
if(!this.Dd||(this.Dd===2))Gr=((A=this.M)[2]-A[0])!==(C[2]-C[0]);else Gr=((A=this.
M)[3]-A[1])!==(C[3]-C[1]);if((((Gr&&!this.CO)&&this.ES)&&this.Bc)&&!((this.F&0x2000
)===0x2000)){this.Ag=B.hm;this.Bc=false;B.lq([this,this.Dl],this);}if(((this.Fo&&
this.Bc)&&!B.tl([(A=this.M)[2]-A[0],A[3]-A[1]],[C[2]-C[0],C[3]-C[1]]))&&!((this.
F&0x2000)===0x2000)){this.Ag=B.hm;this.Bc=false;B.lq([this,this.Dl],this);}B.Core.
AL.S.call(this,C);B.lq([this,this.Go],this);},Bz:function(){if(!!this.A8){this.Gd(
this.A8);this.A8=null;}},Gd:function(aBidi){if(!aBidi)return;B.ng(aBidi);},IZ:function(
aSize){var bidi=null;bidi=B.qk(aSize);return bidi;},Go:function(B9){B.lq(this.BJ
,this);},Dl:function(B9){B.lq([this,this.E$],this);},E$:function(B9){var A;if(this.
Bc)return;var orient=this.Dd;var width=(A=this.M)[2]-A[0];var height=(A=this.M)[
3]-A[1];var Bk=-1;if((orient===1)||(orient===3)){width=height;height=(A=this.M)[
2]-A[0];}if(this.ES){if(this.CO>0)Bk=this.CO;else if(!this.Fi)Bk=width-(this.D0*
2);else Bk=width;if(Bk<0)Bk=1;}if(!!this.A8){this.Gd(this.A8);this.A8=null;}this.
Bc=true;if((this.String!==B.hm)&&!!this.Aw){var length=this.String.length;if(this.
Fp)this.A8=this.IZ(length);this.Ag=this.Aw.HT(this.String,0,Bk,length,this.A8);if(
!!this.A8&&!this.HB()){this.Gd(this.A8);this.A8=null;}}else this.Ag=B.hm;this.Bl=
Ac;if(((this.Fo&&(this.Ag!==B.hm))&&!this.Fi)&&!!this.Aw){var Ad=this.Dp;var font=
this.Aw;var leading=font.Leading;var Ah=this.Ag;var Fc=this.Ft();if(((Ad&0x80)===
0x80)){if(Fc)Ad=(Ad&~0x80)|0x4;else Ad=(Ad&~0x80)|0x1;}if(this.CN>0)leading=(this.
CN-font.Ascent)-font.Descent;var Eu=(font.Ascent+font.Descent)+leading;var BG=Ah.
charCodeAt(0)||0;var CC=((height+leading)/Eu)|0;var F$=false;var EV=false;if(CC<=
0)CC=1;if(BG>CC){var Bx=0;var Ev=0;var Fb=BG-1;var Az=0;var AI=Ah.length;var tmp=
B.hm;if(((Ad&0x20)===0x20))Ev=BG-CC;else if(((Ad&0x10)===0x10)){Ev=((BG-CC)/2)|0;
Fb=(Ev+CC)-1;}else Fb=CC-1;F$=Ev>0;EV=Fb<(BG-1);for(Az=1;Bx<Ev;Bx=Bx+1)Az=Az+(Ah.
charCodeAt(Az)||0);if(EV)for(AI=Az;Bx<Fb;Bx=Bx+1)AI=AI+(Ah.charCodeAt(AI)||0);if(
F$){var AQ=Ah.charCodeAt(Az)||0;tmp=(Ax+B.t9(Ah,Az,AQ))+Ax;tmp=B.t4(tmp,0,(AQ+2)&
0xFFFF);Az=Az+AQ;if((tmp.charCodeAt(AQ)||0)===0x0A){tmp=B.t4(tmp,AQ,0xFEFF);tmp=
B.t4(tmp,AQ+1,0x0A);}if((tmp.charCodeAt(2)||0)===0x0A){tmp=B.t4(tmp,2,0xFEFF);tmp=
B.t4(tmp,1,0x0A);}else tmp=B.t4(tmp,1,0xFEFF);}tmp=tmp+B.t9(Ah,Az,AI-Az);if(EV&&(
AI>=Az)){var AQ=Ah.charCodeAt(AI)||0;var A2=(Ax+B.t9(Ah,AI,AQ))+Ax;A2=B.t4(A2,0,(
AQ+2)&0xFFFF);A2=B.t4(A2,1,0xFEFF);if((A2.charCodeAt(AQ)||0)===0x0A){A2=B.t4(A2,
AQ,0xFEFF);A2=B.t4(A2,AQ+1,0x0A);}if((A2.charCodeAt(2)||0)===0x0A){A2=B.t4(A2,2,
0xFEFF);A2=B.t4(A2,1,0x0A);}else A2=B.t4(A2,1,0xFEFF);tmp=tmp+A2;}Ah=String.fromCharCode(
CC&0xFFFF)+tmp;}var Bx=0;var AX=1;var E9=width-(this.D0*2);if(this.ES&&(this.CO>
0))E9=this.CO;BG=Ah.charCodeAt(0)||0;for(;Bx<BG;Bx=Bx+1){var CH=F$&&!Bx;var CI=EV&&(
Bx===(BG-1));var Bh=false;var Bi=false;var Dm=Fc;if((Fc&&CH)&&!CI){CH=false;CI=true;
}else if((Fc&&CI)&&!CH){CI=false;CH=true;}var Ex=AX+1;var AQ=Ah.charCodeAt(AX)||
0;var Az=Ex;var AI=(Ex+AQ)-2;var Gh=-1;var Gi=-1;if(!this.ES&&(font.Dy(Ah,Ex,AQ-
1)>E9)){if(((Ad&0x4)===0x4))Bh=true;else if(((Ad&0x2)===0x2)){Bh=true;Bi=true;}else
Bi=true;}if((Ah.charCodeAt(Az)||0)===0x0A)Az=Az+1;if((Ah.charCodeAt(AI)||0)===0x0A
)AI=AI-1;while(Bh&&((Ah.charCodeAt(Az)||0)===0xFEFF))Az=Az+1;while(Bi&&((Ah.charCodeAt(
AI)||0)===0xFEFF))AI=AI-1;Bh=Bh&&!CI;Bi=Bi&&!CH;while((((Bh||Bi)||CH)||CI)&&(Az<
AI)){if((Bh&&(Dm||!Bi))||CH){if(Gh>0)Ah=B.t4(Ah,Gh,0xFEFF);Ah=B.t4(Ah,Az,0x2026);
Gh=Az;Az=Az+1;Dm=!Dm;CH=false;if(font.Dy(Ah,Ex,AQ-1)<=E9){Bh=false;Bi=false;}else
Bh=Bh||!Bi;}if((Bi&&(!Dm||!Bh))||CI){if(Gi>0)Ah=B.t4(Ah,Gi,0xFEFF);Ah=B.t4(Ah,AI
,0x2026);Gi=AI;AI=AI-1;Dm=!Dm;CI=false;if(font.Dy(Ah,Ex,AQ-1)<=E9){Bh=false;Bi=false;
}else Bi=Bi||!Bh;}}AX=AX+AQ;}this.Bl=[font.GC(Ah),((Ah.charCodeAt(0)||0)*Eu)-leading
];this.Ag=Ah;}if(this.Fi&&(this.Ag!==B.hm)){var Ci=[this.D0,0];if((orient===1)||(
orient===3)){Ci=[Ci[0],Ci[0]];Ci=[0,Ci[1]];}this.F=this.F|0x2000;this.S(B.ty(B.th(
this.CL(),Ci),this.D2));this.F=this.F&~0x2000;}if(!!this.K&&((this.F&0x1)===0x1)
)this.K.AT(this.M);B.lq([this,this.Go],this);},HG:function(C){if(C===this.Fp)return;
this.Fp=C;this.Ag=B.hm;this.Bc=false;B.lq([this,this.Dl],this);},EL:function(C){
if(B.to(C,this.BJ))return;this.BJ=C;if(!this.CO||!!C)this.F=this.F&~0x100;else this.
F=this.F|0x100;},EH:function(C){var A;if(C===this.Dp)return;this.Dp=C;if(!!this.
K&&((this.F&0x1)===0x1))this.K.AT(this.M);if(this.Fo){this.Ag=B.hm;this.Bc=false;
B.lq([this,this.Dl],this);}if(this.Bc)B.lq([this,this.Go],this);},Dc:function(C){
if(C===this.String)return;this.String=C;this.Ag=B.hm;this.Bc=false;B.lq([this,this.
Dl],this);},EJ:function(C){if(C===this.Aw)return;this.Aw=C;this.Ag=B.hm;this.Bc=
false;B.lq([this,this.Dl],this);},EI:function(C){var A;if((((C===this.C9)&&(C===
this.C_))&&(C===this.C7))&&(C===this.C8))return;this.C9=C;this.C_=C;this.C7=C;this.
C8=C;if(!!this.K&&((this.F&0x1)===0x1))this.K.AT(this.M);},Ft:function(){if(!this.
Bc)this.E$(this);if(!this.A8)return false;var result=false;var bidi=this.A8;result=
B.qj(bidi);return result;},HB:function(){if(!this.Bc)this.E$(this);if(!this.A8)return false;
var result=false;var bidi=this.A8;result=B.sD(bidi);return result;},CL:function(
){var A;if((this.String===B.hm)||!this.Aw)return BV;if(!this.Bc)this.E$(this);if(
this.Ag===B.hm)return BV;var leading=this.Aw.Leading;var Eu=(this.Aw.Ascent+this.
Aw.Descent)+this.Aw.Leading;if(this.CN>0){leading=(this.CN-this.Aw.Ascent)-this.
Aw.Descent;Eu=this.CN;}if(B.tl(this.Bl,Ac))this.Bl=[this.Aw.GC(this.Ag),this.Bl[
1]];this.Bl=[this.Bl[0],((this.Ag.charCodeAt(0)||0)*Eu)-leading];var Ad=this.Dp;
var orient=this.Dd;var Ai=this.M;var Ci=this.D0;var width=Ai[2]-Ai[0];var height=
Ai[3]-Ai[1];if((orient===1)||(orient===3)){width=height;height=Ai[2]-Ai[0];}var At=[
Ci,0,width-Ci,height];var W=[].concat(At.slice(0,2),B.tx(At.slice(0,2),this.Bl));
if(((Ad&0x80)===0x80)){if(this.Ft())Ad=(Ad&~0x80)|0x4;else Ad=(Ad&~0x80)|0x1;}if(((
Ad&0x40)===0x40)){var Bk=this.CO;if(Bk<=0)Bk=width-(this.D0*2);if(Bk<0)Bk=0;if(Bk>(
W[2]-W[0]))W=B.tZ(W,Bk);}if((W[2]-W[0])!==(At[2]-At[0])){if(((Ad&0x4)===0x4))W=B.
t0(W,At[2]-(W[2]-W[0]));else if(((Ad&0x2)===0x2))W=B.t0(W,(At[0]+(((At[2]-At[0])
/2)|0))-(((W[2]-W[0])/2)|0));}if((W[3]-W[1])!==(At[3]-At[1])){if(((Ad&0x20)===0x20
))W=B.t2(W,At[3]-(W[3]-W[1]));else if(((Ad&0x10)===0x10))W=B.t2(W,(At[1]+(((At[3
]-At[1])/2)|0))-(((W[3]-W[1])/2)|0));}if(!orient)W=B.tz(W,Ai.slice(0,2));else if(
orient===1){var CF=[Ai[0]+W[1],Ai[3]-W[2]];W=[].concat(CF,B.tx(CF,[this.Bl[1],this.
Bl[0]]));}else if(orient===2){var CF=[Ai[2]-W[2],Ai[3]-W[3]];W=[].concat(CF,B.tx(
CF,this.Bl));}else if(orient===3){var CF=[Ai[2]-W[3],Ai[1]+W[0]];W=[].concat(CF,
B.tx(CF,[this.Bl[1],this.Bl[0]]));}return B.tz(W,this.D2);},_Init:function(aArg){
B.Core.AL._Init.call(this,aArg);this.__proto__=D.Text;},_Done:function(){this.Bz(
);this.__proto__=B.Core.AL;B.Core.AL._Done.call(this);},_Mark:function(E){var A;
B.Core.AL._Mark.call(this,E);if((A=this.Aw)&&(A._cycle!=E))A._Mark(A._cycle=E);if((
A=this.BJ)&&((A=A[0])._cycle!=E))A._Mark(A._cycle=E);},_className:"Views::Text"};
D.JU={Ja:0x1,I_:0x2,Jb:0x4,Jm:0x8,Jl:0x10,Jk:0x20,I$:0x40,I9:0x80};D.Dd={JE:0,JR:
1,JP:2,JQ:3};
D._Init=function(){D.BA.__proto__=B.Core.AL;D.Text.__proto__=B.Core.AL;};D.Am=function(
E){};return D;})();

/* Embedded Wizard */