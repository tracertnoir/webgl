/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var TutorialApplication;if(!TutorialApplication)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(TutorialApplication.Core)throw new Error("The unit file 'Core.js' included twice!"
);TutorialApplication.Core=(function(){var B=TutorialApplication;var C={};
var Ae=[0,0];var AJ=[0,0,0,0];var Cc="The view does not belong to this group";var
DH="No view to restack";var Di="View is not in this group";var DI="No view to remove";
var DJ="No view to add";var EN="View already in a group";var EO="Recursive invalidate during active update cycle.";
var EP="The KeyPressHandler is embedded within an object not being derived "+"from Core::Group.";
C.BL={Am:null,Z:null,F:null,Ar:null,E:0x103,DF:0,AG:0x14,EZ:function(T,FF){},GW:function(
value){var A;var Bk=value^this.AG;if(!Bk)return;this.AG=value;if(!!this.Ar&&!((this.
E&0x400)===0x400)){this.F.E=this.F.E|0x5000;B.lq([A=this.F,A.Bo],this);this.F.Ad([
0,0,(A=this.F.N)[2]-A[0],A[3]-A[1]]);}if(!!this.Ar&&((this.E&0x400)===0x400)){this.
Ar.DW.E=this.Ar.DW.E|0x1000;this.F.E=this.F.E|0x4000;B.lq([A=this.F,A.Bo],this);
}},Gx:function(){var V=this.F;while(!!V){var IA=(C.Root.isPrototypeOf(V)?V:null);
if(!!IA)return IA;V=V.F;}return null;},B6:function(At,aClip,aOffset,Aq,aBlend){}
,A6:function(Y){return null;},CU:function(Ab,K,BM,Ea,DN){return null;},Ff:function(
T,B2){return Ae;},GR:function(aOffset,FE){},GetExtent:function(){return AJ;},A_:
function(C3,DM){var A;if(((this.E&0x200)===0x200))C3=C3&~0x400;var HA=(this.E&~DM
)|C3;var Dl=HA^this.E;this.E=HA;if(!!this.F&&!!(Dl&0x14)){var Im=((this.E&0x14)===
0x14);if(Im&&!this.F.B7)this.F.D7(this);if(!Im&&(this.F.B7===this))this.F.D7(this.
F.HT(this,0x14));}if(!!this.F&&!!(Dl&0x403))this.F.Ad(this.GetExtent());if(((!!this.
Ar&&!!this.F)&&((HA&0x400)===0x400))&&((Dl&0x1)===0x1)){this.E=this.E|0x800;this.
F.E=this.F.E|0x4000;B.lq([A=this.F,A.Bo],this);}if(!!this.F&&((Dl&0x400)===0x400
)){this.Ar=null;this.E=this.E|0x800;this.F.E=this.F.E|0x4000;B.lq([A=this.F,A.Bo
],this);}},_Init:function(aArg){this.__proto__=C.BL;B.gv++;},_Done:function(){this.
__proto__=null;B.gv--;},_ReInit:function(){},_Mark:function(D){var A;if((A=this.
Am)&&(A._cycle!=D))A._Mark(A._cycle=D);if((A=this.Z)&&(A._cycle!=D))A._Mark(A._cycle=
D);if((A=this.F)&&(A._cycle!=D))A._Mark(A._cycle=D);if((A=this.Ar)&&(A._cycle!=D
))A._Mark(A._cycle=D);if((A=this.Af)&&(A._cycle!=D))A._Mark(A._cycle=D);},Af:null
,_cycle:0,_observers:null,_className:"Core::View"};C.EF={A8:B.qx,Bs:B.qx,A7:B.qx
,Br:B.qx,EZ:function(T,FF){var U=B._NewObject(C.Fs,0);this.Ar=null;U.BA=this.GetExtent(
);U.X=T;U.DW=FF;U.E5=this.Br;U.E6=this.A7;U.E7=this.Bs;U.E8=this.A8;this.Ar=U;},
Ff:function(T,B2){var A;var Az=this.AG;var U=(C.Fs.isPrototypeOf(A=this.Ar)?A:null
);var O=U.BA[0];var P=U.BA[1];var Q=U.BA[2];var R=U.BA[3];var Bz=[T[2]-T[0],T[3]-
T[1]];var Ao=Q-O;var Al=R-P;if(!B2){var Cj=[(A=U.X)[2]-A[0],A[3]-A[1]];O=O-U.X[0
];P=P-U.X[1];if(Cj[0]!==Bz[0]){var AY=((Az&0x4)===0x4);var AZ=((Az&0x8)===0x8);var
CG=((Az&0x1)===0x1);if(!AY&&(CG||!AZ))O=((O*Bz[0])/Cj[0])|0;if(!AZ&&(CG||!AY)){Q=
Q-U.X[0];Q=((Q*Bz[0])/Cj[0])|0;Q=Q-Bz[0];}else Q=Q-U.X[2];O=O+T[0];Q=Q+T[2];if(!
CG){if(AY&&!AZ)Q=O+Ao;else if(!AY&&AZ)O=Q-Ao;else{O=O+((((Q-O)-Ao)/2)|0);Q=O+Ao;
}}}else{Q=Q-U.X[2];O=O+T[0];Q=Q+T[2];}if(Cj[1]!==Bz[1]){var A0=((Az&0x10)===0x10
);var AX=((Az&0x20)===0x20);var CH=((Az&0x2)===0x2);if(!A0&&(CH||!AX))P=((P*Bz[1
])/Cj[1])|0;if(!AX&&(CH||!A0)){R=R-U.X[1];R=((R*Bz[1])/Cj[1])|0;R=R-Bz[1];}else R=
R-U.X[3];P=P+T[1];R=R+T[3];if(!CH){if(A0&&!AX)R=P+Al;else if(!A0&&AX)P=R-Al;else{
P=P+((((R-P)-Al)/2)|0);R=P+Al;}}}else{R=R-U.X[3];P=P+T[1];R=R+T[3];}}else{switch(
B2){case 3:{O=T[0];Q=O+Ao;}break;case 4:{Q=T[2];O=Q-Ao;}break;case 1:{P=T[1];R=P+
Al;}break;case 2:{R=T[3];P=R-Al;}break;default:;}if((B2===3)||(B2===4)){var A0=((
Az&0x10)===0x10);var AX=((Az&0x20)===0x20);var CH=((Az&0x2)===0x2);if(CH){P=T[1];
R=T[3];}else if(A0&&!AX){P=T[1];R=P+Al;}else if(AX&&!A0){R=T[3];P=R-Al;}else{P=T[
1]+((((T[3]-T[1])-Al)/2)|0);R=P+Al;}}if((B2===1)||(B2===2)){var AY=((Az&0x4)===0x4
);var AZ=((Az&0x8)===0x8);var CG=((Az&0x1)===0x1);if(CG){O=T[0];Q=T[2];}else if(
AY&&!AZ){O=T[0];Q=O+Ao;}else if(AZ&&!AY){Q=T[2];O=Q-Ao;}else{O=T[0]+((((T[2]-T[0
])-Ao)/2)|0);Q=O+Ao;}}}U.isEmpty=(O>=Q)||(P>=R);Ao=(Q-O)-1;Al=(R-P)-1;var C6=U.BA[
0];var C7=U.BA[1];var CQ=(U.BA[2]-C6)-1;var CP=(U.BA[3]-C7)-1;if(!CQ)CQ=1;if(!CP
)CP=1;if(((this.E&0x100)===0x100)){this.Br=[O+((((U.E5[0]-C6)*Ao)/CQ)|0),P+((((U.
E5[1]-C7)*Al)/CP)|0)];this.A7=[O+((((U.E6[0]-C6)*Ao)/CQ)|0),P+((((U.E6[1]-C7)*Al
)/CP)|0)];this.Bs=[O+((((U.E7[0]-C6)*Ao)/CQ)|0),P+((((U.E7[1]-C7)*Al)/CP)|0)];this.
A8=[O+((((U.E8[0]-C6)*Ao)/CQ)|0),P+((((U.E8[1]-C7)*Al)/CP)|0)];}else{this.GY([O+((((
U.E5[0]-C6)*Ao)/CQ)|0),P+((((U.E5[1]-C7)*Al)/CP)|0)]);this.GZ([O+((((U.E6[0]-C6)
*Ao)/CQ)|0),P+((((U.E6[1]-C7)*Al)/CP)|0)]);this.G0([O+((((U.E7[0]-C6)*Ao)/CQ)|0)
,P+((((U.E7[1]-C7)*Al)/CP)|0)]);this.G1([O+((((U.E8[0]-C6)*Ao)/CQ)|0),P+((((U.E8[
1]-C7)*Al)/CP)|0)]);this.Ar=U;}return[Ao+1,Al+1];},GR:function(aOffset,FE){if(FE
){this.Br=B.tx(this.Br,aOffset);this.A7=B.tx(this.A7,aOffset);this.Bs=B.tx(this.
Bs,aOffset);this.A8=B.tx(this.A8,aOffset);}else{this.GY(B.tx(this.Br,aOffset));this.
GZ(B.tx(this.A7,aOffset));this.G0(B.tx(this.Bs,aOffset));this.G1(B.tx(this.A8,aOffset
));}},GetExtent:function(){if(!!this.Ar&&this.Ar.isEmpty)return AJ;var O=this.Br[
0];var P=this.Br[1];var Q=this.Bs[0];var R=this.Bs[1];if((((this.A8[0]!==O)||(this.
A7[1]!==P))||(this.A7[0]!==Q))||(this.A8[1]!==R)){if(this.A7[0]<O)O=this.A7[0];if(
this.Bs[0]<O)O=this.Bs[0];if(this.A8[0]<O)O=this.A8[0];if(this.A7[1]<P)P=this.A7[
1];if(this.Bs[1]<P)P=this.Bs[1];if(this.A8[1]<P)P=this.A8[1];if(this.Br[0]>Q)Q=this.
Br[0];if(this.A7[0]>Q)Q=this.A7[0];if(this.A8[0]>Q)Q=this.A8[0];if(this.Br[1]>R)
R=this.Br[1];if(this.A7[1]>R)R=this.A7[1];if(this.A8[1]>R)R=this.A8[1];}else{var
tmp;if(Q<O){tmp=O;O=Q;Q=tmp;}if(R<P){tmp=P;P=R;R=tmp;}}return[O,P,Q+1,R+1];},G1:
function(value){var A;if(B.tl(value,this.A8))return;if(!!this.F&&((this.E&0x1)===
0x1))this.F.Ad(this.GetExtent());this.Ar=null;this.A8=value;if(!!this.F&&((this.
E&0x1)===0x1))this.F.Ad(this.GetExtent());if((!!this.F&&((this.E&0x400)===0x400)
)&&!((this.F.E&0x2000)===0x2000)){this.E=this.E|0x800;this.F.E=this.F.E|0x4000;B.
lq([A=this.F,A.Bo],this);}},G0:function(value){var A;if(B.tl(value,this.Bs))return;
if(!!this.F&&((this.E&0x1)===0x1))this.F.Ad(this.GetExtent());this.Ar=null;this.
Bs=value;if(!!this.F&&((this.E&0x1)===0x1))this.F.Ad(this.GetExtent());if((!!this.
F&&((this.E&0x400)===0x400))&&!((this.F.E&0x2000)===0x2000)){this.E=this.E|0x800;
this.F.E=this.F.E|0x4000;B.lq([A=this.F,A.Bo],this);}},GZ:function(value){var A;
if(B.tl(value,this.A7))return;if(!!this.F&&((this.E&0x1)===0x1))this.F.Ad(this.GetExtent(
));this.Ar=null;this.A7=value;if(!!this.F&&((this.E&0x1)===0x1))this.F.Ad(this.GetExtent(
));if((!!this.F&&((this.E&0x400)===0x400))&&!((this.F.E&0x2000)===0x2000)){this.
E=this.E|0x800;this.F.E=this.F.E|0x4000;B.lq([A=this.F,A.Bo],this);}},GY:function(
value){var A;if(B.tl(value,this.Br))return;if(!!this.F&&((this.E&0x1)===0x1))this.
F.Ad(this.GetExtent());this.Ar=null;this.Br=value;if(!!this.F&&((this.E&0x1)===0x1
))this.F.Ad(this.GetExtent());if((!!this.F&&((this.E&0x400)===0x400))&&!((this.F.
E&0x2000)===0x2000)){this.E=this.E|0x800;this.F.E=this.F.E|0x4000;B.lq([A=this.F
,A.Bo],this);}},GG:function(CB){var Av=B.tA(4,B.qx,null);var I=0;var Ay=3;var Hu=
false;var Hv=false;Av.Set(0,this.Br);Av.Set(1,this.A7);Av.Set(2,this.Bs);Av.Set(
3,this.A8);while(I<4){var IF=Av.Get(I)[0];var Gh=Av.Get(I)[1];var Kw=Av.Get(Ay)[
0];var HM=Av.Get(Ay)[1];if(((Gh>CB[1])!==(HM>CB[1]))||((Gh<CB[1])!==(HM<CB[1]))){
var IG=((((Kw-IF)*(CB[1]-Gh))/(HM-Gh))|0)+IF;if(CB[0]>IG)Hu=!Hu;if(CB[0]<IG)Hv=!
Hv;}Ay=I;I=I+1;}return Hu||Hv;},IZ:function(){return((((this.Br[0]===this.A8[0])&&(
this.A7[0]===this.Bs[0]))&&(this.Br[1]===this.A7[1]))&&(this.Bs[1]===this.A8[1])
)||((((this.Br[0]===this.A7[0])&&(this.Bs[0]===this.A8[0]))&&(this.Br[1]===this.
A8[1]))&&(this.A7[1]===this.Bs[1]));},_Init:function(aArg){C.BL._Init.call(this,
aArg);this.__proto__=C.EF;},_className:"Core::QuadView"};C.AH={N:B.qy,EZ:function(
T,FF){var U=B._NewObject(C.Fr,0);U.BA=this.N;U.X=T;U.DW=FF;this.Ar=U;},Ff:function(
T,B2){var A;var Az=this.AG;var U=this.Ar;var O=U.BA[0];var P=U.BA[1];var Q=U.BA[
2];var R=U.BA[3];var Bz=[T[2]-T[0],T[3]-T[1]];var Ao=Q-O;var Al=R-P;if(!B2){var Cj=[(
A=U.X)[2]-A[0],A[3]-A[1]];O=O-U.X[0];P=P-U.X[1];if(Cj[0]!==Bz[0]){var AY=((Az&0x4
)===0x4);var AZ=((Az&0x8)===0x8);var CG=((Az&0x1)===0x1);if(!AY&&(CG||!AZ))O=((O
*Bz[0])/Cj[0])|0;if(!AZ&&(CG||!AY)){Q=Q-U.X[0];Q=((Q*Bz[0])/Cj[0])|0;Q=Q-Bz[0];}
else Q=Q-U.X[2];O=O+T[0];Q=Q+T[2];if(!CG){if(AY&&!AZ)Q=O+Ao;else if(!AY&&AZ)O=Q-
Ao;else{O=O+((((Q-O)-Ao)/2)|0);Q=O+Ao;}}}else{Q=Q-U.X[2];O=O+T[0];Q=Q+T[2];}if(Cj[
1]!==Bz[1]){var A0=((Az&0x10)===0x10);var AX=((Az&0x20)===0x20);var CH=((Az&0x2)===
0x2);if(!A0&&(CH||!AX))P=((P*Bz[1])/Cj[1])|0;if(!AX&&(CH||!A0)){R=R-U.X[1];R=((R
*Bz[1])/Cj[1])|0;R=R-Bz[1];}else R=R-U.X[3];P=P+T[1];R=R+T[3];if(!CH){if(A0&&!AX
)R=P+Al;else if(!A0&&AX)P=R-Al;else{P=P+((((R-P)-Al)/2)|0);R=P+Al;}}}else{R=R-U.
X[3];P=P+T[1];R=R+T[3];}}else{switch(B2){case 3:{O=T[0];Q=O+Ao;}break;case 4:{Q=
T[2];O=Q-Ao;}break;case 1:{P=T[1];R=P+Al;}break;case 2:{R=T[3];P=R-Al;}break;default:;
}if((B2===3)||(B2===4)){var A0=((Az&0x10)===0x10);var AX=((Az&0x20)===0x20);var CH=((
Az&0x2)===0x2);if(CH){P=T[1];R=T[3];}else if(A0&&!AX){P=T[1];R=P+Al;}else if(AX&&
!A0){R=T[3];P=R-Al;}else{P=T[1]+((((T[3]-T[1])-Al)/2)|0);R=P+Al;}}if((B2===1)||(
B2===2)){var AY=((Az&0x4)===0x4);var AZ=((Az&0x8)===0x8);var CG=((Az&0x1)===0x1);
if(CG){O=T[0];Q=T[2];}else if(AY&&!AZ){O=T[0];Q=O+Ao;}else if(AZ&&!AY){Q=T[2];O=
Q-Ao;}else{O=T[0]+((((T[2]-T[0])-Ao)/2)|0);Q=O+Ao;}}}U.isEmpty=(O>=Q)||(P>=R);if(((
this.E&0x100)===0x100)){this.N=[O,P,Q,R];}else{this.Ak([O,P,Q,R]);this.Ar=U;}return[
Q-O,R-P];},GR:function(aOffset,FE){if(FE)this.N=B.tz(this.N,aOffset);else this.Ak(
B.tz(this.N,aOffset));},GetExtent:function(){return this.N;},Ak:function(value){
var A;if(B.tm(value,this.N))return;if(!!this.F&&((this.E&0x1)===0x1))this.F.Ad(this.
N);this.Ar=null;this.N=value;if(!!this.F&&((this.E&0x1)===0x1))this.F.Ad(this.N);
if((!!this.F&&((this.E&0x400)===0x400))&&!((this.F.E&0x2000)===0x2000)){this.E=this.
E|0x800;this.F.E=this.F.E|0x4000;B.lq([A=this.F,A.Bo],this);}},_Init:function(aArg
){C.BL._Init.call(this,aArg);this.__proto__=C.AH;},_className:"Core::RectView"};
C.Aj={B4:null,Bm:null,FV:null,B3:null,Dm:null,DS:null,B7:null,DC:255,B6:function(
At,aClip,aOffset,Aq,aBlend){var A;Aq=((Aq+1)*this.DC)>>8;aBlend=aBlend&&((this.E&
0x2)===0x2);if(!this.B3)this.Ki(At,aClip,B.tx(aOffset,this.N.slice(0,2)),Aq,aBlend
);else{var Bx=255|(255<<8)|(255<<16)|((Aq&0xFF)<<24);this.B3.Update();At.HN(aClip
,this.B3,0,B.tz(this.N,aOffset),Ae,Bx,Bx,Bx,Bx,aBlend);}},CU:function(Ab,K,BM,Ea
,DN){var A;var G=this.Bm;var DT=null;var S=AJ;var AL=null;var Hz=!!this.DS&&(!!this.
DS.Hp||!!this.DS.B4);if(((A=B.il(Ab,this.N))[0]>=A[2])||(A[1]>=A[3]))return null;
Ab=B.ty(Ab,this.N.slice(0,2));while(!!G){if(((G.E&0x400)===0x400)&&!AL){AL=G.Z;while(
!!AL&&!((AL.E&0x200)===0x200))AL=AL.Z;if(!!AL)S=B.il(Ab,AL.GetExtent());else S=AJ;
}if(AL===G){AL=null;S=AJ;}if((((((G.E&0x8)===0x8)&&((G.E&0x10)===0x10))&&!((G.E&
0x40000)===0x40000))&&!((G.E&0x20000)===0x20000))&&(!((G.E&0x10000)===0x10000)||((
this.Dm.BO===G)&&!Hz))){var BA=G.GetExtent();var FM=Ea;var DQ=null;if(FM===G)FM=
null;if(((G.E&0x400)===0x400)){if(!(((A=B.il(BA,S))[0]>=A[2])||(A[1]>=A[3])))DQ=
G.CU(S,K,BM,FM,DN);}else{if(!(((A=B.il(BA,Ab))[0]>=A[2])||(A[1]>=A[3]))||(Ea===G
))DQ=G.CU(Ab,K,BM,FM,DN);}G=G.Z;if(!!DQ){if(!DT||((DQ.Eo<DT.Eo)&&(DQ.Eo>=0)))DT=
DQ;if(!DQ.Eo)G=null;}}else G=G.Z;}return DT;},A_:function(C3,DM){var A;var Kk=this.
E;C.AH.A_.call(this,C3,DM);var Dl=this.E^Kk;if(!!this.B7&&((Dl&0x40)===0x40)){if(((
this.E&0x40)===0x40))this.B7.A_(0x40,0x0);else this.B7.A_(0x0,0x40);}if(!!this.Dm&&((
Dl&0x40)===0x40)){if(((this.E&0x40)===0x40)&&((this.Dm.BO.E&0x14)===0x14))this.Dm.
BO.A_(0x40,0x0);else this.Dm.BO.A_(0x0,0x40);}if(!!Dl){this.E=this.E|0x8000;B.lq([
this,this.Bo],this);}},Ak:function(value){var A;if(B.tm(value,this.N))return;var
Dr=[(A=this.N)[2]-A[0],A[3]-A[1]];var FZ=[value[2]-value[0],value[3]-value[1]];var
DZ=!B.tl(Dr,FZ);if(DZ&&!!this.B3){this.B3.GV(FZ);B.qw(this,0);B.qw(this.B3,0);}C.
AH.Ak.call(this,value);if((DZ&&(Dr[0]>0))&&(Dr[1]>0)){var X=[].concat(Ae,Dr);var
G=this.B4;var EY=0x14;while(!!G){if((!G.Ar&&(G.AG!==EY))&&!((G.E&0x400)===0x400)
)G.EZ(X,null);G=G.Am;}}if(DZ){this.E=this.E|0x5000;B.lq([this,this.Bo],this);}},
HG:function(Y){var Io=(C.KeyEvent.isPrototypeOf(Y)?Y:null);var Ct=this.FV;if(!Io
)return null;while(!!Ct&&(!Ct.Cn||!Ct.A6(Io)))Ct=Ct.Am;return Ct;},Ki:function(At
,aClip,aOffset,Aq,aBlend){var A;var G=this.B4;var Ik=AJ;var Iy=true;while(!!G){if(((
G.E&0x200)===0x200)){var Ix=(C.ED.isPrototypeOf(G)?G:null);Ik=B.il(aClip,B.tz(Ix.
N,aOffset));Iy=((Ix.E&0x1)===0x1);}if(((G.E&0x1)===0x1)){if(((G.E&0x400)===0x400
)){if(Iy){var S=B.il(B.tz(G.GetExtent(),aOffset),Ik);if(!((S[0]>=S[2])||(S[1]>=S[
3])))G.B6(At,S,aOffset,Aq,aBlend);}}else{var S=B.il(B.tz(G.GetExtent(),aOffset),
aClip);if(!((S[0]>=S[2])||(S[1]>=S[3])))G.B6(At,S,aOffset,Aq,aBlend);}}G=G.Am;}}
,Kt:function(){var A;var Hs=((this.E&0x1000)===0x1000);var C8=[0,0,(A=this.N)[2]-
A[0],A[3]-A[1]];var Cr=false;var CE=AJ;var A2=AJ;var Cs=Ae;var Ei=0;var Ej=0;var
Eh=0;var BB=0;var G=this.Bm;var AL=null;var EY=0x14;var Do=null;while(!!G){if(((
G.E&0x800)===0x800)){Cr=true;G.E=G.E&~0x800;}if(Cr&&((G.E&0x200)===0x200)){Cr=false;
if(!!(C.ED.isPrototypeOf(G)?G:null).Fm)G.E=G.E|0x1000;}G=G.Z;}Cr=false;G=this.B4;
if(Hs){this.E=this.E&~0x1000;Hs=!((C8[0]>=C8[2])||(C8[1]>=C8[3]));}this.E=this.E|
0x2000;while(!!G){if(!Do&&(Eh!==BB)){var CI=G;var Gb=0;var E$=CE[2]-CE[0];var EV=
CE[3]-CE[1];var FK=0;var D2=Ae;do{if(((CI.E&0x200)===0x200))CI=null;else if(((CI.
E&0x401)===0x401)){D2=[(A=CI.GetExtent())[2]-A[0],A[3]-A[1]];if((BB===3)||(BB===
4))E$=E$-D2[0];if((BB===1)||(BB===2))EV=EV-D2[1];if(!Do||((E$>=0)&&(EV>=0))){Do=
CI;CI=CI.Am;if((BB===3)||(BB===4)){E$=E$-Ei;if(D2[1]>Gb)Gb=D2[1];}if((BB===1)||(
BB===2)){EV=EV-Ej;if(D2[0]>FK)FK=D2[0];}}else CI=null;}else CI=CI.Am;}while(!!CI
);if(!Do)Do=AL;A2=CE;switch(Eh){case 9:case 11:A2=[].concat(A2.slice(0,3),A2[1]+
Gb);break;case 10:case 12:A2=B.t3(A2,A2[3]-Gb);break;case 5:case 7:A2=B.t1(A2,A2[
0]+FK);break;case 6:case 8:A2=[].concat(A2[2]-FK,A2.slice(1,4));break;default:;}
}if(((G.E&0x400)===0x400)){if(!!G.Ar&&(G.Ar.DW!==AL))G.Ar=null;if((!G.Ar&&Cr)&&((
G.AG!==EY)||!!BB))G.EZ(A2,AL);}if(!!G.Ar){if(Hs&&!((G.E&0x400)===0x400))G.Ff(C8,
0);if(Cr&&((G.E&0x400)===0x400)){var AO=G.Ff(B.tz(A2,Cs),BB);if(((G.E&0x1)===0x1
)){var BW=Ae;switch(BB){case 3:BW=[AO[0]+Ei,BW[1]];break;case 4:BW=[-AO[0]-Ei,BW[
1]];break;case 1:BW=[BW[0],AO[1]+Ej];break;case 2:BW=[BW[0],-AO[1]-Ej];break;default:;
}Cs=B.tx(Cs,BW);}}}if(((G.E&0x200)===0x200)){if(Cr)B.lq(AL.CL,AL);Cr=((G.E&0x1000
)===0x1000);AL=(C.ED.isPrototypeOf(G)?G:null);if(Cr){G.E=G.E&~0x1000;CE=B.tz(AL.
N,AL.C1);A2=CE;Cs=Ae;Eh=AL.Fm;BB=Eh;Ei=AL.Space+AL.JT;Ej=AL.Space+AL.JU;Cr=!((CE[
0]>=CE[2])||(CE[1]>=CE[3]));Do=null;switch(Eh){case 9:case 10:BB=3;break;case 11:
case 12:BB=4;break;case 5:case 6:BB=1;break;case 7:case 8:BB=2;break;default:;}}
if(Cr){this.Ad(AL.N);}}if(G===Do){switch(Eh){case 9:case 11:Cs=[0,(Cs[1]+(A2[3]-
A2[1]))+Ej];break;case 10:case 12:Cs=[0,(Cs[1]-(A2[3]-A2[1]))-Ej];break;case 5:case
7:Cs=[(Cs[0]+(A2[2]-A2[0]))+Ei,0];break;case 6:case 8:Cs=[(Cs[0]-(A2[2]-A2[0]))-
Ei,0];break;default:;}Do=null;}G=G.Am;}if(Cr)B.lq(AL.CL,AL);this.E=this.E&~0x2000;
this.Ic([C8[2]-C8[0],C8[3]-C8[1]]);},Bo:function(AV){var A;var Kv=((this.E&0x1000
)===0x1000);if(((this.E&0x4000)===0x4000)){this.E=this.E&~0x4000;this.Kt();}if(((
this.E&0x8000)===0x8000)||Kv){this.E=this.E&~0x8000;this.EL(this.E);}},D7:function(
value){var A;if(!!value&&(value.F!==this))throw new Error(Cc);if(!!value&&!((value.
E&0x14)===0x14))value=null;if(!!value&&((value.E&0x10000)===0x10000))value=null;
if(value===this.B7)return;if(!!this.B7)this.B7.A_(0x0,0x60);this.B7=value;if(!!value
){if(((this.E&0x40)===0x40))value.A_(0x60,0x0);else value.A_(0x20,0x0);}},GQ:function(
CB){var tmp=this;while(!!tmp){CB=B.tw(CB,tmp.N.slice(0,2));tmp=tmp.F;}return CB;
},DispatchEvent:function(Y){var A;var G=this.B7;var V=(C.Aj.isPrototypeOf(G)?G:null
);var Ag=null;var Hz=!!this.DS&&(!!this.DS.Hp||!!this.DS.B4);if(!!G&&((((G.E&0x10000
)===0x10000)||((G.E&0x40000)===0x40000))||((G.E&0x20000)===0x20000))){G=null;V=null;
}if(!!this.Dm&&!Hz)Ag=this.Dm.BO.DispatchEvent(Y);if(!Ag&&!!V)Ag=V.DispatchEvent(
Y);else if(!Ag&&!!G)Ag=G.A6(Y);if(!Ag)Ag=this.A6(Y);if(!Ag)Ag=this.HG(Y);return Ag;
},BroadcastEventAtPosition:function(Y,Ig,aFilter){var A;var G=this.Bm;var Ag=null;
while(!!G&&!Ag){if((!aFilter||((A=aFilter)&&((G.E&A)===A)))&&B.qu(G.GetExtent(),
Ig)){var V=(C.Aj.isPrototypeOf(G)?G:null);if(!!V)Ag=V.BroadcastEventAtPosition(Y
,B.tw(Ig,V.N.slice(0,2)),aFilter);else Ag=G.A6(Y);}G=G.Z;}if(!Ag)Ag=this.A6(Y);return Ag;
},BroadcastEvent:function(Y,aFilter){var A;var G=this.Bm;var Ag=null;while(!!G&&
!Ag){if(!aFilter||((A=aFilter)&&((G.E&A)===A))){var V=(C.Aj.isPrototypeOf(G)?G:null
);if(!!V)Ag=V.BroadcastEvent(Y,aFilter);else Ag=G.A6(Y);}G=G.Z;}if(!Ag)Ag=this.A6(
Y);if(!Ag)Ag=this.HG(Y);return Ag;},Ic:function(aSize){},EL:function(Ed){},B9:function(
){this.E=this.E|0x8000;B.lq([this,this.Bo],this);},Ad:function(Ab){var A;var V=this;
while(!!V&&!((Ab[0]>=Ab[2])||(Ab[1]>=Ab[3]))){var DO=V.B3;if(!V.F&&(V!==this)){V.
Ad(Ab);return;}if(!!DO){var Hr=false;var Kj=DO.Co;if(Hr)DO.Co=[0,0,(A=V.N)[2]-A[
0],A[3]-A[1]];else DO.Co=B.qR(DO.Co,Ab);if(!B.tm(Kj,DO.Co)){B.qw(V,0);B.qw(DO,0);
}}if(!((V.E&0x1)===0x1))return;Ab=B.il(B.tz(Ab,V.N.slice(0,2)),V.N);V=V.F;}},BR:
function(aArg){this.B9();},HT:function(L,aFilter){var A;if(!L||(L.F!==this))return null;
var Dq=L.Am;var Dt=L.Z;var E3=0x10000;if(((aFilter&0x10000)===0x10000))E3=0x0;while(
!!Dq||!!Dt){if((!!Dq&&(!aFilter||((A=aFilter)&&((Dq.E&A)===A))))&&(!E3||!((A=E3)&&((
Dq.E&A)===A))))return Dq;if((!!Dt&&(!aFilter||((A=aFilter)&&((Dt.E&A)===A))))&&(
!E3||!((A=E3)&&((Dt.E&A)===A))))return Dt;if(!!Dq)Dq=Dq.Am;if(!!Dt)Dt=Dt.Z;}return null;
},G6:function(L){var A;if(!L)throw new Error(DH);if(L.F!==this)throw new Error(Di
);if(!L.Am)return;var CN=this.Bm;var Em=L.DF;while(!!CN&&(CN.DF>Em))CN=CN.Z;if(((
CN===L)||!CN)||(CN.Am===L))return;if(((L.E&0x401)===0x401)){if(!!L.Z&&!!L.Ar)L.Z.
E=L.Z.E|0x800;L.E=L.E|0x800;this.E=this.E|0x4000;B.lq([this,this.Bo],this);}if(((
L.E&0x200)===0x200)){if(!!L.Z)L.Z.E=L.Z.E|0x800;this.E=this.E|0x4000;B.lq([this,
this.Bo],this);}if(!!L.Z)L.Z.Am=L.Am;else this.B4=L.Am;L.Am.Z=L.Z;L.Z=CN;L.Am=CN.
Am;CN.Am=L;if(!!L.Am)L.Am.Z=L;else this.Bm=L;if(((L.E&0x1)===0x1))this.Ad(L.GetExtent(
));},EG:function(L){var A;if(!L)throw new Error(DI);if(L.F!==this)throw new Error(
Di);if((((L.E&0x401)===0x401)&&!!L.Z)&&!!L.Ar){L.Z.E=L.Z.E|0x800;this.E=this.E|0x4000;
B.lq([this,this.Bo],this);}if(((L.E&0x200)===0x200)){if(!!L.Z)L.Z.E=L.Z.E|0x800;
this.E=this.E|0x4000;B.lq([this,this.Bo],this);}L.Ar=null;if(this.B7===L)this.D7(
this.HT(L,0x14));if(!!L.Z)L.Z.Am=L.Am;if(!!L.Am)L.Am.Z=L.Z;if(this.B4===L)this.B4=
L.Am;if(this.Bm===L)this.Bm=L.Z;L.F=null;L.Am=null;L.Z=null;if(((L.E&0x1)===0x1)
)this.Ad(L.GetExtent());},BQ:function(L,Ec){var A;if(!L)throw new Error(DJ);if(!
!L.F)throw new Error(EN);var Bw=null;var Em=L.DF;if(((Ec<0)&&!!this.Bm)&&(this.Bm.
DF>=Em)){Bw=this.Bm;Ec=Ec+1;}while((((Ec<0)&&!!Bw)&&!!Bw.Z)&&(Bw.Z.DF>=Em)){Bw=Bw.
Z;Ec=Ec+1;}if((!Bw&&!!this.Bm)&&(this.Bm.DF>Em))Bw=this.Bm;while((!!Bw&&!!Bw.Z)&&(
Bw.Z.DF>Em))Bw=Bw.Z;if(!Bw){L.F=this;L.Z=this.Bm;if(!!this.Bm)this.Bm.Am=L;if(!this.
B4)this.B4=L;this.Bm=L;}else{L.F=this;L.Z=Bw.Z;L.Am=Bw;Bw.Z=L;if(!!L.Z)L.Z.Am=L;
else this.B4=L;}if(((L.E&0x1)===0x1))this.Ad(L.GetExtent());if(((!this.B7&&((L.E&
0x4)===0x4))&&((L.E&0x10)===0x10))&&!((L.E&0x10000)===0x10000))this.D7(L);if(((L.
E&0x401)===0x401)){L.E=L.E|0x800;this.E=this.E|0x4000;B.lq([this,this.Bo],this);
}if(((L.E&0x200)===0x200)){L.E=L.E|0x800;this.E=this.E|0x4000;B.lq([this,this.Bo
],this);}},_Init:function(aArg){C.AH._Init.call(this,aArg);this.__proto__=C.Aj;this.
E=0x1F;this.BR(aArg);},_Mark:function(D){var A;C.AH._Mark.call(this,D);if((A=this.
B4)&&(A._cycle!=D))A._Mark(A._cycle=D);if((A=this.Bm)&&(A._cycle!=D))A._Mark(A._cycle=
D);if((A=this.FV)&&(A._cycle!=D))A._Mark(A._cycle=D);if((A=this.B3)&&(A._cycle!=
D))A._Mark(A._cycle=D);if((A=this.Dm)&&(A._cycle!=D))A._Mark(A._cycle=D);if((A=this.
DS)&&(A._cycle!=D))A._Mark(A._cycle=D);if((A=this.B7)&&(A._cycle!=D))A._Mark(A._cycle=
D);},_className:"Core::Group"};C.Root={BF:null,C_:null,CC:null,Au:B.tA(10,null,null
),Ee:null,B$:null,C5:null,Fd:0,Hl:0,Aw:0,A1:B.tA(10,0,null),FL:B.tA(10,B.qy,null
),Ch:B.tA(10,0,null),CO:B.tA(10,B.qx,null),Eg:B.tA(10,0,null),C4:B.tA(10,B.qx,null
),Cg:B.tA(10,B.qx,null),BN:B.tA(10,B.qx,null),CD:B.tA(10,B.qx,null),Ac:0,FP:0,FO:
0,FX:B.tA(3,B.qy,null),Iu:0,Bn:B.tA(4,0,null),AU:B.tA(4,B.qy,null),AN:0,Dd:8,IP:
250,Dn:0,C9:0,Ht:true,FW:false,Gx:function(){return this;},B6:function(At,aClip,
aOffset,Aq,aBlend){var fullScreenUpdate=false;fullScreenUpdate=B.jI;if(!fullScreenUpdate
)At.Gs(aClip,B.tz(B.tz(aClip,aOffset),this.N.slice(0,2)),0x00000000,0x00000000,0x00000000
,0x00000000,false);C.Aj.B6.call(this,At,aClip,aOffset,Aq,aBlend);},A_:function(C3
,DM){var A;C.Aj.A_.call(this,C3,DM);if(!this.F&&(((C3&0x1)===0x1)||((DM&0x1)===0x1
)))this.Ad([0,0,(A=this.N)[2]-A[0],A[3]-A[1]]);if(!this.F&&(((C3&0x2)===0x2)||((
DM&0x2)===0x2)))this.Ad([0,0,(A=this.N)[2]-A[0],A[3]-A[1]]);},D7:function(value){
if((value!==this.B$)||!value)C.Aj.D7.call(this,value);},DispatchEvent:function(Y
){if((this.Hl>0)&&!!(C.KeyEvent.isPrototypeOf(Y)?Y:null))return null;if(!!Y){Y.Ew=
!!this.Aw;if(!!this.Aw)Y.AI=this.Aw;}var Ag=null;if(!!this.B$){Ag=this.B$.DispatchEvent(
Y);if(!!Ag){this.Aw=0;return Ag;}}if(!!this.C_){Ag=this.C_.BO.DispatchEvent(Y);if(
!Ag)Ag=this.A6(Y);if(!Ag)Ag=this.HG(Y);this.Aw=0;return Ag;}Ag=C.Aj.DispatchEvent.
call(this,Y);this.Aw=0;return Ag;},BroadcastEvent:function(Y,aFilter){if(!!Y){Y.
Ew=!!this.Aw;if(!!this.Aw)Y.AI=this.Aw;}var Ag=C.Aj.BroadcastEvent.call(this,Y,aFilter
);this.Aw=0;return Ag;},Ad:function(Ab){var A;if(this.Fd>0)throw new Error(EO);if(
!!this.B3&&!this.F){if(((A=this.B3.Co)[0]>=A[2])||(A[1]>=A[3])){B.qw(this,0);B.qw(
this.B3,0);}var Hr=false;if(Hr)this.B3.Co=[0,0,(A=this.N)[2]-A[0],A[3]-A[1]];else
this.B3.Co=B.qR(this.B3.Co,Ab);}var fullScreenUpdate=false;fullScreenUpdate=B.jI;
if(fullScreenUpdate)Ab=[0,0,(A=this.N)[2]-A[0],A[3]-A[1]];if(!!this.F){C.Aj.Ad.call(
this,Ab);return;}Ab=B.il(B.tz(Ab,this.N.slice(0,2)),this.N);if((Ab[0]>=Ab[2])||(
Ab[1]>=Ab[3]))return;var I;for(I=0;I<this.AN;I=I+1)if(!(((A=B.il(this.AU.Get(I),
Ab))[0]>=A[2])||(A[1]>=A[3]))){this.AU.Set(I,B.qR(this.AU.Get(I),Ab));this.Bn.Set(
I,B.s9(this.AU.Get(I)));return;}if(this.AN<3){this.AU.Set(this.AN,Ab);this.Bn.Set(
this.AN,B.s9(Ab));this.AN=this.AN+1;return;}var Ay;var BE;var E0=0;var E1=0;var Ih=
2147483647;this.AU.Set(this.AN,Ab);this.Bn.Set(this.AN,B.s9(Ab));for(Ay=0;Ay<=this.
AN;Ay=Ay+1)for(BE=Ay+1;BE<=this.AN;BE=BE+1){var Gg=B.s9(B.qR(this.AU.Get(Ay),this.
AU.Get(BE)));var Iz=((Gg<<8)/(this.Bn.Get(Ay)+this.Bn.Get(BE)))|0;if(Iz<Ih){Ih=Iz;
E0=Ay;E1=BE;}}this.AU.Set(E0,B.qR(this.AU.Get(E0),this.AU.Get(E1)));this.Bn.Set(
E0,B.s9(this.AU.Get(E0)));if(E1!==this.AN){this.AU.Set(E1,this.AU.Get(this.AN));
this.Bn.Set(E1,this.Bn.Get(this.AN));}},Kg:function(){var Bf=B._NewObject(C.Fk,0
);Bf.Ew=!!this.Aw;if(!!this.Aw)Bf.AI=this.Aw;return Bf;},DP:function(){var Bf=B.
_NewObject(C.Fi,0);Bf.Ew=!!this.Aw;if(!!this.Aw)Bf.AI=this.Aw;return Bf;},Ef:function(
){var Bf=B._NewObject(C.Fj,0);Bf.Ew=!!this.Aw;if(!!this.Aw)Bf.AI=this.Aw;return Bf;
},Kh:function(AV){var I;var DT=false;for(I=0;I<10;I=I+1)if(!!this.Au.Get(I)){var
AT=this.BN.Get(I);var V=this.Au.Get(I).F;while(!!V&&(V!==this)){AT=B.tw(AT,V.N.slice(
0,2));V=V.F;}if(!V&&(this.Au.Get(I)!==this)){var tmp=this.Au.Get(I);this.Ac=I;this.
Au.Set(I,null);tmp.A6(this.DP().InitializeUp(I,this.C4.Get(I),this.CO.Get(I),this.
Ch.Get(I),this.A1.Get(I)+1,this.Cg.Get(I),false,this.BN.Get(I),this.CD.Get(I)));
if(tmp===this.CC)this.CC=null;this.BroadcastEvent(this.Ef().InitializeUp(I,this.
A1.Get(I)+1,false,tmp,this.BN.Get(I)),0x18);}else{this.Ch.Set(I,(this.C5.AI-this.
Eg.Get(I))|0);if(this.Ch.Get(I)<10)this.Ch.Set(I,10);this.Ac=I;this.Au.Get(I).A6(
this.DP().InitializeHold(I,AT,this.CO.Get(I),this.Ch.Get(I),this.A1.Get(I)+1,this.
Cg.Get(I),this.BN.Get(I),this.CD.Get(I)));DT=true;}}if(!DT)this.C5.Cp(false);},GetFPS:
function(){var ticksCount=0;var In=0;ticksCount=((new Date).getTime()-B.qt)|0;if(
!!this.FP&&(ticksCount>this.FP))In=((this.FO*1000)/((ticksCount-this.FP)|0))|0;this.
FO=0;this.FP=ticksCount;return In;},Update:function(){var A;if(!this.Ee){this.Ee=
B._NewObject(B.Graphics.Canvas,0);this.Ee.GV([(A=this.N)[2]-A[0],A[3]-A[1]]);}this.
Ee.Update();return this.UpdateGE20(this.Ee);},UpdateGE20:function(At){if(!this.BeginUpdate(
))return AJ;var CR=this.UpdateCanvas(At,Ae);this.EndUpdate();return CR;},EndUpdate:
function(){if(this.AN>0){this.FO=this.FO+1;this.AN=0;}},UpdateCanvas:function(At
,aOffset){var A;var CR=AJ;var Ke=[].concat(aOffset,B.tx(At.FrameSize,aOffset));var
I;var Ay=this.AN;this.Fd=this.Fd+1;for(I=0;(I<Ay)&&(I<4);I=I+1){if(this.Bn.Get(I
)>0){this.B6(At,B.ty(this.AU.Get(I),aOffset),[-aOffset[0],-aOffset[1]],255,true);
CR=B.qR(CR,B.il(Ke,this.AU.Get(I)));}else Ay=Ay+1;}this.Fd=this.Fd-1;if(!((CR[0]>=
CR[2])||(CR[1]>=CR[3])))return B.ty(CR,aOffset);else return CR;},GetUpdateRegion:
function(FG){var I;var Ay=this.AN;if(FG<0)return AJ;for(I=0;(I<Ay)&&(I<4);I=I+1){
if(!this.Bn.Get(I)){Ay=Ay+1;FG=FG+1;}else if(I===FG)return this.AU.Get(I);}return AJ;
},BeginUpdate:function(){var Ks=true;var fullScreenUpdate=false;var I;if((!Ks&&!
fullScreenUpdate)&&(this.AN>0)){var IE=B.tA(3,B.qy,null);var HL=this.AN;for(I=0;
I<HL;I=I+1)IE.Set(I,this.AU.Get(I));for(I=0;I<this.Iu;I=I+1)this.Ad(this.FX.Get(
I));for(I=0;I<HL;I=I+1)this.FX.Set(I,IE.Get(I));this.Iu=HL;}var Ay;var BE;for(Ay=
0;Ay<(this.AN-1);Ay=Ay+1)if(this.Bn.Get(Ay)>0)for(BE=Ay+1;BE<this.AN;BE=BE+1)if(
this.Bn.Get(BE)>0){var Gg=B.s9(B.qR(this.AU.Get(Ay),this.AU.Get(BE)));if(((Gg-this.
Bn.Get(Ay))-this.Bn.Get(BE))<0){this.AU.Set(Ay,B.qR(this.AU.Get(Ay),this.AU.Get(
BE)));this.Bn.Set(Ay,Gg);this.Bn.Set(BE,0);}}for(I=this.AN-1;I>=0;I=I-1)if(!this.
Bn.Get(I))this.AN=this.AN-1;return this.AN;},DoesNeedUpdate:function(){if(this.AN>
0)return true;return false;},Initialize:function(aSize){this.Ak([].concat(Ae,aSize
));if(this.Ht)this.E=this.E|0x60;else this.E=this.E|0x20;this.Ad(this.N);return this;
},SetRootFocus:function(Hi){if(Hi===this.Ht)return false;this.Ht=Hi;if(!Hi){if(!
!this.B$)this.B$.A_(0x0,0x40);if(!!this.C_)this.C_.BO.A_(0x0,0x40);else this.A_(
0x0,0x40);}else{if(!!this.C_)this.C_.BO.A_(0x40,0x0);else this.A_(0x40,0x0);if(!
!this.B$)this.B$.A_(0x40,0x0);}return true;},SetUserInputTimestamp:function(Kd){
this.Aw=Kd;},DriveKeyboardHitting:function(AK,DL,B1){var A;var HH=!!this.BF;if(!
!this.BF&&((!B1||(this.Dn!==AK))||(this.C9!==DL))){var Bf=null;var G=(C.BL.isPrototypeOf(
A=this.BF)?A:null);var Ct=(C.Ex.isPrototypeOf(A=this.BF)?A:null);if(!!this.Dn)Bf=
B._NewObject(C.KeyEvent,0).Initialize(this.Dn,false);if(this.C9!==0x00)Bf=B._NewObject(
C.KeyEvent,0).Initialize2(this.C9,false);if(!!Ct)Ct.A6(Bf);else if(!!G)G.A6(Bf);
this.Dn=0;this.C9=0x00;this.BF=null;}if(!!this.BF){var Bf=null;var G=(C.BL.isPrototypeOf(
A=this.BF)?A:null);var Ct=(C.Ex.isPrototypeOf(A=this.BF)?A:null);if(!!AK)Bf=B._NewObject(
C.KeyEvent,0).Initialize(AK,true);if(this.C9!==0x00)Bf=B._NewObject(C.KeyEvent,0
).Initialize2(DL,true);if(!!Ct)Ct.A6(Bf);else if(!!G)G.A6(Bf);}if(this.FW&&((!B1||(
this.Dn!==AK))||(this.C9!==DL))){this.Dn=0;this.C9=0x00;this.FW=false;}if((!this.
BF&&B1)&&(this.Hl>0)){this.Dn=AK;this.C9=DL;this.FW=true;}if((!this.BF&&B1)&&!this.
FW){if(!!AK)this.BF=this.DispatchEvent(B._NewObject(C.KeyEvent,0).Initialize(AK,
true));if(DL!==0x00)this.BF=this.DispatchEvent(B._NewObject(C.KeyEvent,0).Initialize2(
DL,true));if(!(C.Ex.isPrototypeOf(A=this.BF)?A:null)&&!(C.BL.isPrototypeOf(A=this.
BF)?A:null))this.BF=null;this.Dn=AK;this.C9=DL;HH=HH||!!this.BF;}this.Aw=0;return HH;
},DriveCursorMovement:function(AQ){return this.DriveMultiTouchMovement(this.Ac,AQ
);},DriveMultiTouchMovement:function(K,AQ){if((K<0)||(K>9)){this.Aw=0;return false;
}var BV=B.tw(AQ,this.BN.Get(K));this.BN.Set(K,AQ);if(!this.Au.Get(K)||B.tl(BV,Ae
)){this.Aw=0;return false;}var AT=AQ;var V=this.Au.Get(K).F;while(!!V&&(V!==this
)){AT=B.tw(AT,V.N.slice(0,2));V=V.F;}if(!V&&(this.Au.Get(K)!==this)){var tmp=this.
Au.Get(K);this.Ac=K;this.Au.Set(K,null);tmp.A6(this.DP().InitializeUp(K,this.C4.
Get(K),this.CO.Get(K),this.Ch.Get(K),this.A1.Get(K)+1,this.Cg.Get(K),false,this.
BN.Get(K),this.CD.Get(K)));if(tmp===this.CC)this.CC=null;this.BroadcastEvent(this.
Ef().InitializeUp(K,this.A1.Get(K)+1,false,tmp,AQ),0x18);}else{this.C4.Set(K,AT);
this.Ac=K;this.Au.Get(K).A6(this.Kg().Initialize(K,AT,this.CO.Get(K),BV,this.Ch.
Get(K),this.A1.Get(K)+1,this.Cg.Get(K),AQ,this.CD.Get(K)));}this.Aw=0;return true;
},DriveCursorHitting:function(B1,K,AQ){return this.DriveMultiTouchHitting(B1,K,AQ
);},DriveMultiTouchHitting:function(B1,K,AQ){var A;if((K<0)||(K>9)){this.Aw=0;return false;
}var ticksCount=this.Aw;var DR=[].concat([-this.Dd,-this.Dd],[this.Dd+1,this.Dd+
1]);if(!ticksCount){ticksCount=((new Date).getTime()-B.qt)|0;}var Ku=this.Aw;this.
DriveMultiTouchMovement(K,AQ);AQ=this.BN.Get(K);this.Aw=Ku;if(B1)this.CD.Set(K,AQ
);if((B1&&!this.Au.Get(K))&&!this.Hl){var BC=null;var AT=AQ;if(B.qu(this.FL.Get(
K),AQ)&&((ticksCount-this.Eg.Get(K))<=(((A=this.IP)<0)?A+0x100000000:A)))this.A1.
Set(K,this.A1.Get(K)+1);else this.A1.Set(K,0);this.FL.Set(K,B.tz(DR,AQ));this.Eg.
Set(K,ticksCount);if((!!this.B$&&!!this.B$.F)&&((this.B$.E&0x18)===0x18)){var S=
B.tz(DR,this.B$.F.GQ(AQ));BC=this.B$.CU(S,K,this.A1.Get(K)+1,null,0x0);}if(!BC){
if(!!this.CC&&!!this.CC.F){if(((this.CC.E&0x8)===0x8)&&((this.CC.E&0x10)===0x10)
){var S=B.tz(DR,this.CC.F.GQ(AQ));BC=this.CC.CU(S,K,this.A1.Get(K)+1,null,0x0);}
}else if(!!this.C_)BC=this.CU(B.tz(DR,AQ),K,this.A1.Get(K)+1,this.C_.BO,0x0);else
BC=this.CU(B.tz(DR,AQ),K,this.A1.Get(K)+1,null,0x0);}if(!!BC){this.BroadcastEvent(
this.Ef().InitializeDown(K,this.A1.Get(K)+1,false,BC.BL,AQ),0x18);this.Au.Set(K,
BC.BL);this.Cg.Set(K,BC.CY);}else{this.Au.Set(K,null);this.Cg.Set(K,Ae);this.Aw=
0;return false;}var V=BC.BL.F;while(!!V&&(V!==this)){AT=B.tw(AT,V.N.slice(0,2));
V=V.F;}this.CO.Set(K,AT);this.C4.Set(K,AT);this.Ch.Set(K,0);this.C5.Cp(true);this.
Ac=K;this.Au.Get(K).A6(this.DP().InitializeDown(K,AT,this.A1.Get(K)+1,this.Cg.Get(
K),false,AQ));this.Aw=0;return true;}if(!B1&&!!this.Au.Get(K)){var AT=AQ;var V=this.
Au.Get(K).F;while(!!V&&(V!==this)){AT=B.tw(AT,V.N.slice(0,2));V=V.F;}if(!V)AT=this.
C4.Get(K);this.Ac=K;var tmp=this.Au.Get(K);this.Au.Set(K,null);tmp.A6(this.DP().
InitializeUp(K,AT,this.CO.Get(K),this.Ch.Get(K),this.A1.Get(K)+1,this.Cg.Get(K),
false,AQ,this.CD.Get(K)));this.BroadcastEvent(this.Ef().InitializeUp(K,this.A1.Get(
K)+1,false,tmp,AQ),0x18);this.Aw=0;return true;}this.Aw=0;return false;},Ib:function(
CM,If,DN){var DR=[].concat([-this.Dd,-this.Dd],[this.Dd+1,this.Dd+1]);if(CM===this
)CM=null;if(!this.Au.Get(this.Ac))return;var BC;BC=this.CU(B.tz(DR,this.BN.Get(this.
Ac)),this.Ac,1,CM,DN);if(!!BC&&(this.Au.Get(this.Ac)!==BC.BL))this.HO(BC.BL,BC.CY
);if(!BC&&(this.Au.Get(this.Ac)!==If))this.HO(If,Ae);},HO:function(CM,Cd){if(!this.
Au.Get(this.Ac)||(this.Au.Get(this.Ac)===CM))return;var tmp=this.Au.Get(this.Ac);
this.Au.Set(this.Ac,null);tmp.A6(this.DP().InitializeUp(this.Ac,this.C4.Get(this.
Ac),this.CO.Get(this.Ac),this.Ch.Get(this.Ac),this.A1.Get(this.Ac)+1,this.Cg.Get(
this.Ac),true,this.BN.Get(this.Ac),this.CD.Get(this.Ac)));this.BroadcastEvent(this.
Ef().InitializeUp(this.Ac,this.A1.Get(this.Ac)+1,true,tmp,this.BN.Get(this.Ac)),
0x18);var AT=this.BN.Get(this.Ac);var V=null;if(!!CM)V=CM.F;while(!!V&&(V!==this
)){AT=B.tw(AT,V.N.slice(0,2));V=V.F;}if(!V&&(CM!==this)){this.Au.Set(this.Ac,null
);return;}this.BroadcastEvent(this.Ef().InitializeDown(this.Ac,this.A1.Get(this.
Ac)+1,true,CM,this.BN.Get(this.Ac)),0x18);var ticksCount=0;ticksCount=((new Date
).getTime()-B.qt)|0;this.Au.Set(this.Ac,CM);this.Cg.Set(this.Ac,Cd);this.CO.Set(
this.Ac,AT);this.C4.Set(this.Ac,AT);this.A1.Set(this.Ac,0);this.Ch.Set(this.Ac,0
);this.Eg.Set(this.Ac,ticksCount);this.CD.Set(this.Ac,this.BN.Get(this.Ac));this.
Au.Get(this.Ac).A6(this.DP().InitializeDown(this.Ac,AT,this.A1.Get(this.Ac)+1,this.
Cg.Get(this.Ac),true,this.CD.Get(this.Ac)));},_Init:function(aArg){C.Aj._Init.call(
this,aArg);C.Timer._Init.call(this.C5={Af:this},0);(this.Au=[]).__proto__=C.Root.
Au;(this.A1=[]).__proto__=C.Root.A1;(this.FL=[]).__proto__=C.Root.FL;(this.Ch=[]
).__proto__=C.Root.Ch;(this.CO=[]).__proto__=C.Root.CO;(this.Eg=[]).__proto__=C.
Root.Eg;(this.C4=[]).__proto__=C.Root.C4;(this.Cg=[]).__proto__=C.Root.Cg;(this.
BN=[]).__proto__=C.Root.BN;(this.CD=[]).__proto__=C.Root.CD;(this.FX=[]).__proto__=
C.Root.FX;(this.Bn=[]).__proto__=C.Root.Bn;(this.AU=[]).__proto__=C.Root.AU;this.
__proto__=C.Root;this.E=0x7F;this.C5.GX(50);this.C5.EC=[this,this.Kh];},_Done:function(
){this.__proto__=C.Aj;this.C5._Done();C.Aj._Done.call(this);},_ReInit:function(){
C.Aj._ReInit.call(this);this.C5._ReInit();},_Mark:function(D){var A;C.Aj._Mark.call(
this,D);if((A=this.BF)&&(A._cycle!=D))A._Mark(A._cycle=D);if((A=this.C_)&&(A._cycle
!=D))A._Mark(A._cycle=D);if((A=this.CC)&&(A._cycle!=D))A._Mark(A._cycle=D);B.ts(
this.Au,D);if((A=this.Ee)&&(A._cycle!=D))A._Mark(A._cycle=D);if((A=this.B$)&&(A.
_cycle!=D))A._Mark(A._cycle=D);if((A=this.C5)._cycle!=D)A._Mark(A._cycle=D);},_className:
"Core::Root"};C.Event={AI:0,Ew:false,Fn:function(){var ticksCount=0;ticksCount=((
new Date).getTime()-B.qt)|0;return ticksCount;},BR:function(aArg){this.AI=this.Fn(
);},_Init:function(aArg){this.__proto__=C.Event;this.BR(aArg);B.gv++;},_Done:function(
){this.__proto__=null;B.gv--;},_ReInit:function(){},_Mark:function(D){var A;if((
A=this.Af)&&(A._cycle!=D))A._Mark(A._cycle=D);},Af:null,_cycle:0,_observers:null
,_className:"Core::Event"};C.KeyEvent={AM:0,Ah:0,Down:false,Initialize2:function(
AK,B1){this.AM=0;this.Ah=AK;this.Down=B1;if((AK>=0x30)&&(AK<=0x39))this.AM=(10+AK
)-48;if((AK>=0x41)&&(AK<=0x5A))this.AM=(105+AK)-65;if((AK>=0x61)&&(AK<=0x7A))this.
AM=(105+AK)-97;if(AK===0x20)this.AM=131;if(!this.AM)switch(AK){case 0x2B:this.AM=
132;break;case 0x2D:this.AM=133;break;case 0x2A:this.AM=134;break;case 0x2F:this.
AM=135;break;case 0x3D:this.AM=136;break;case 0x2E:this.AM=137;break;case 0x2C:this.
AM=138;break;case 0x3A:this.AM=139;break;case 0x3B:this.AM=140;break;default:;}return this;
},Initialize:function(AK,B1){this.AM=AK;this.Down=B1;this.Ah=0x00;var Hn=AK-10;var
Hm=AK-105;if((Hn>=0)&&(Hn<=9))this.Ah=(48+Hn)&0xFFFF;if((Hm>=0)&&(Hm<=25))this.Ah=(
65+Hm)&0xFFFF;if(AK===131)this.Ah=0x20;if(this.Ah===0x00)switch(AK){case 132:this.
Ah=0x2B;break;case 133:this.Ah=0x2D;break;case 134:this.Ah=0x2A;break;case 135:this.
Ah=0x2F;break;case 136:this.Ah=0x3D;break;case 137:this.Ah=0x2E;break;case 138:this.
Ah=0x2C;break;case 139:this.Ah=0x3A;break;case 140:this.Ah=0x3B;break;default:;}
return this;},I4:function(Ie){switch(Ie){case 141:return((this.Ah>=0x41)&&(this.
Ah<=0x5A))||((this.Ah>=0x61)&&(this.Ah<=0x7A));case 142:return(((this.Ah>=0x41)&&(
this.Ah<=0x5A))||((this.Ah>=0x61)&&(this.Ah<=0x7A)))||((this.Ah>=0x30)&&(this.Ah<=
0x39));case 143:return(this.Ah>=0x30)&&(this.Ah<=0x39);case 144:return(((this.Ah>=
0x41)&&(this.Ah<=0x46))||((this.Ah>=0x61)&&(this.Ah<=0x66)))||((this.Ah>=0x30)&&(
this.Ah<=0x39));case 145:return this.Ah!==0x00;case 146:return(this.Ah===0x00)&&
!!this.AM;case 147:return(((this.AM===6)||(this.AM===7))||(this.AM===4))||(this.
AM===5);case 148:return(this.Ah!==0x00)||!!this.AM;default:;}return Ie===this.AM;
},_Init:function(aArg){C.Event._Init.call(this,aArg);this.__proto__=C.KeyEvent;}
,_className:"Core::KeyEvent"};C.Fj={FB:null,B8:B.qx,B_:0,Bp:0,Down:false,Cv:false
,InitializeUp:function(K,BM,DK,Hk,Cq){this.Down=false;this.Bp=K;this.B_=BM;this.
B8=Cq;this.FB=Hk;this.Cv=DK;return this;},InitializeDown:function(K,BM,DK,Hk,Cq){
this.Down=true;this.Bp=K;this.B_=BM;this.B8=Cq;this.FB=Hk;this.Cv=DK;return this;
},_Init:function(aArg){C.Event._Init.call(this,aArg);this.__proto__=C.Fj;},_Mark:
function(D){var A;C.Event._Mark.call(this,D);if((A=this.FB)&&(A._cycle!=D))A._Mark(
A._cycle=D);},_className:"Core::CursorGrabEvent"};C.Fi={CW:B.qx,B8:B.qx,B_:0,Bi:
0,CK:B.qx,Cm:B.qx,Bp:0,Down:false,Cv:false,InitializeHold:function(K,Dj,ER,ES,BM
,Cd,Cq,EQ){this.Down=true;this.Bp=K;this.Cm=B.tx(Dj,Cd);this.CK=B.tx(ER,Cd);this.
Bi=ES;this.B_=BM;this.B8=Cq;this.CW=EQ;return this;},InitializeUp:function(K,Dj,
ER,ES,BM,Cd,DK,Cq,EQ){this.Down=false;this.Bp=K;this.Cm=B.tx(Dj,Cd);this.CK=B.tx(
ER,Cd);this.Bi=ES;this.B_=BM;this.Cv=DK;this.B8=Cq;this.CW=EQ;return this;},InitializeDown:
function(K,Dj,BM,Cd,DK,Cq){this.Down=true;this.Bp=K;this.Cm=B.tx(Dj,Cd);this.CK=
B.tx(Dj,Cd);this.Bi=0;this.B_=BM;this.Cv=DK;this.B8=Cq;this.CW=Cq;return this;},
_Init:function(aArg){C.Event._Init.call(this,aArg);this.__proto__=C.Fi;},_className:
"Core::CursorEvent"};C.Fk={CW:B.qx,B8:B.qx,B_:0,Bi:0,CY:B.qx,CK:B.qx,Cm:B.qx,Bp:
0,Initialize:function(K,Dj,ER,aOffset,ES,Kc,Cd,Cq,EQ){this.Bp=K;this.Cm=B.tx(Dj,
Cd);this.CK=B.tx(ER,Cd);this.CY=aOffset;this.Bi=ES;this.B_=Kc;this.B8=Cq;this.CW=
EQ;return this;},_Init:function(aArg){C.Event._Init.call(this,aArg);this.__proto__=
C.Fk;},_className:"Core::DragEvent"};C.ED={CL:null,C1:B.qx,JU:0,JT:0,Space:0,Fm:
0,B6:function(At,aClip,aOffset,Aq,aBlend){},Ak:function(value){var A;if(B.tm(value
,this.N))return;var Dr=[(A=this.N)[2]-A[0],A[3]-A[1]];var FZ=[value[2]-value[0],
value[3]-value[1]];var DZ=!B.tl(Dr,FZ);var BV=B.tw(value.slice(0,2),this.N.slice(
0,2));if(!B.tl(BV,Ae)&&!DZ){var G=this.Am;while(!!G&&!((G.E&0x200)===0x200)){if(((
G.E&0x400)===0x400)){var tmp=((G.E&0x100)===0x100);G.GR(BV,tmp);}G=G.Am;}B.lq(this.
CL,this);}if((DZ&&(Dr[0]>0))&&(Dr[1]>0)){var X=B.tz(this.N,this.C1);var G=this.Am;
var EY=0x14;while(!!G&&!((G.E&0x200)===0x200)){if(((G.E&0x400)===0x400)){if(!!G.
Ar&&(G.Ar.DW!==this))G.Ar=null;if(!G.Ar&&((G.AG!==EY)||!!this.Fm))G.EZ(X,this);}
G=G.Am;}B.lq(this.CL,this);}C.AH.Ak.call(this,value);if(!!this.F&&DZ){this.E=this.
E|0x1000;if(!((this.F.E&0x2000)===0x2000)){this.F.E=this.F.E|0x4000;B.lq([A=this.
F,A.Bo],this);}}},_Init:function(aArg){C.AH._Init.call(this,aArg);this.__proto__=
C.ED;this.E=0x203;},_Mark:function(D){var A;C.AH._Mark.call(this,D);if((A=this.CL
)&&((A=A[0])._cycle!=D))A._Mark(A._cycle=D);},_className:"Core::Outline"};C.G7={
H3:null,DA:null,Dz:null,EA:null,CA:null,Cz:null,Gf:0,As:0,Bp:0,AI:0,B_:0,Bi:0,CY:
B.qx,CK:B.qx,Cm:B.qx,JP:1000,EH:8,Dg:0,H2:1,GP:-1,H1:1,I6:1,Gm:false,Down:false,
De:false,Cv:false,B6:function(At,aClip,aOffset,Aq,aBlend){},A6:function(Y){var A;
var Ap=(C.Fi.isPrototypeOf(Y)?Y:null);var AR=(C.Fk.isPrototypeOf(Y)?Y:null);var FQ=
this.De;var F0;var Ek;var ID;var Da;var Il;if(!Ap&&!AR)return null;F0=(!!Ap&&Ap.
Down)&&!Ap.Bi;Ek=(!!Ap&&Ap.Down)&&(Ap.Bi>0);ID=(!!Ap&&Ap.Down)&&(Ap.Bi>50);Da=!!
Ap&&!Ap.Down;Il=!!AR;if(!this.Gm){if((((this.Dg&0x20)===0x20)&&(this.As>0))&&(this.
As<33554432)){var FN=(C.Fj.isPrototypeOf(Y)?Y:null);if(((!!FN&&FN.Down)&&(FN.FB!==
this))&&B.qu(this.GetExtent(),this.F.GQ(FN.B8))){this.Gf=0x20;this.As=this.As|67108864;
return null;}}if(F0){var HB=0;var EX;this.As=this.As|(1<<Ap.Bp);for(EX=this.As&4095;
EX>0;EX=EX>>1)if(!!(EX&1))HB=HB+1;if(HB===this.H2)this.As=(this.As|16777216)|(4096<<
Ap.Bp);}if(Da)this.As=(this.As&~(1<<Ap.Bp))|33554432;if(ID&&(this.As<16777216))this.
As=this.As|67108864;if(Da&&Ap.Cv)this.As=this.As|67108864;if(Da&&!(this.As&4095)
)this.Gf=0x0;if(Da&&!(this.As&16777215))this.As=0;if(Ek&&(this.As>=67108864))this.
Gx().Ib(null,null,this.Gf);if((Ek&&!!(this.As&16777216))&&!!(this.As&33554432)){
Ek=false;Da=true;}if(!!Ap&&!(this.As&(4096<<Ap.Bp)))return this;if(!!AR&&!(this.
As&(4096<<AR.Bp)))return this;if(Da&&!(this.As&16777216))return this;if(((F0||Il
)||Ek)&&((this.As<16777216)||(this.As>=33554432)))return this;if(Da)this.As=this.
As&3758100479;if(Da&&!(this.As&16777215))this.As=0;}if(!!Ap){this.Down=F0||Ek;this.
De=this.GG(Ap.Cm);this.CK=Ap.CK;this.Cm=Ap.Cm;this.CY=Ae;this.Bi=Ap.Bi;this.B_=Ap.
B_;this.Cv=Ap.Cv;this.Bp=Ap.Bp;this.AI=Ap.AI;if(Ap.Down&&!Ap.Bi)FQ=false;}if(!!AR
){this.Down=true;this.De=this.GG(AR.Cm);this.CK=AR.CK;this.Cm=AR.Cm;this.CY=AR.CY;
this.Bi=AR.Bi;this.B_=AR.B_;this.Bp=AR.Bp;this.Cv=false;this.AI=AR.AI;(A=this.H3
)?A[1].call(A[0],this):null;}if((!!Ap&&this.Down)&&!this.Bi)(A=this.Cz)?A[1].call(
A[0],this):null;if((!!Ap&&this.Down)&&(this.Bi>0))(A=this.EA)?A[1].call(A[0],this
):null;if((this.Down&&this.De)&&!FQ)(A=this.Dz)?A[1].call(A[0],this):null;if(((this.
Down&&!this.De)&&FQ)||((!this.Down&&this.De)&&FQ))(A=this.DA)?A[1].call(A[0],this
):null;if(!!Ap&&!this.Down)(A=this.CA)?A[1].call(A[0],this):null;if(!!this.Dg){var
Du=0x0;if(((((this.Dg&0x10)===0x10)&&!!Ap)&&Ap.Down)&&(Ap.Bi>=this.JP))Du=0x10;if((((
this.Dg&0x1)===0x1)&&!!AR)&&((AR.B8[1]-AR.CW[1])<=-this.EH))Du=0x1;if((((this.Dg&
0x2)===0x2)&&!!AR)&&((AR.B8[1]-AR.CW[1])>=this.EH))Du=0x2;if((((this.Dg&0x4)===0x4
)&&!!AR)&&((AR.B8[0]-AR.CW[0])<=-this.EH))Du=0x4;if((((this.Dg&0x8)===0x8)&&!!AR
)&&((AR.B8[0]-AR.CW[0])>=this.EH))Du=0x8;if(!!Du){this.Gf=Du;this.Gx().Ib(null,this
,Du);}}return this;},CU:function(Ab,K,BM,Ea,DN){var A;if(!!Ea&&(Ea!==this))return null;
if((BM<this.I6)||(BM>this.H1))return null;if((this.GP>=0)&&(this.H2>1))return null;
if((this.GP>=0)&&(K!==this.GP))return null;if(!this.Gm&&(this.As>=33554432))return null;
if((!this.Gm&&(this.As>=16777216))&&!(this.As&(4096<<K)))return null;if(!!(DN&this.
Dg))return null;if(this.IZ()){var J=B.il(Ab,this.GetExtent());if(!((J[0]>=J[2])||(
J[1]>=J[3]))){var Dk=B.s_(Ab);var BV=Ae;if(Dk[0]<J[0])BV=[J[0]-Dk[0],BV[1]];if(Dk[
0]>=J[2])BV=[(J[2]-Dk[0])-1,BV[1]];if(Dk[1]<J[1])BV=[BV[0],J[1]-Dk[1]];if(Dk[1]>=
J[3])BV=[BV[0],(J[3]-Dk[1])-1];return B._NewObject(C.Gj,0).Initialize(this,BV);}
}else{var Av=B.tA(9,B.qx,null);var I;Av.Set(0,B.s_(Ab));Av.Set(1,Av.Get(0));Av.Set(
2,Av.Get(0));Av.Set(3,Av.Get(0));Av.Set(4,Av.Get(0));Av.Set(1,[Ab[0],Av.Get(1)[1
]]);Av.Set(2,[Av.Get(2)[0],Ab[1]]);Av.Set(3,[Ab[2],Av.Get(3)[1]]);Av.Set(4,[Av.Get(
4)[0],Ab[3]]);Av.Set(5,Ab.slice(0,2));Av.Set(6,[Ab[2],Ab[1]]);Av.Set(7,[Ab[0],Ab[
3]]);Av.Set(8,Ab.slice(2,4));for(I=0;I<9;I=I+1)if(this.GG(Av.Get(I)))return B._NewObject(
C.Gj,0).Initialize(this,B.tw(Av.Get(I),Av.Get(0)));}return null;},JA:function(value
){if(value<1)value=1;this.EH=value;},Jx:function(value){if(value<1)value=1;this.
H1=value;},Cp:function(value){if(value)this.A_(0x10,0x0);else this.A_(0x0,0x10);
},_Init:function(aArg){C.EF._Init.call(this,aArg);this.__proto__=C.G7;this.E=0x11B;
},_Mark:function(D){var A;C.EF._Mark.call(this,D);if((A=this.H3)&&((A=A[0])._cycle
!=D))A._Mark(A._cycle=D);if((A=this.DA)&&((A=A[0])._cycle!=D))A._Mark(A._cycle=D
);if((A=this.Dz)&&((A=A[0])._cycle!=D))A._Mark(A._cycle=D);if((A=this.EA)&&((A=A[
0])._cycle!=D))A._Mark(A._cycle=D);if((A=this.CA)&&((A=A[0])._cycle!=D))A._Mark(
A._cycle=D);if((A=this.Cz)&&((A=A[0])._cycle!=D))A._Mark(A._cycle=D);},_className:
"Core::SimpleTouchHandler"};C.Ex={Am:null,CA:null,Cz:null,EA:null,DX:0,AI:0,Ia:0
,Dy:148,AM:0,Ah:0,Cn:true,Down:false,G5:false,Fh:false,A6:function(Y){var A;if(!
!Y&&Y.I4(this.Dy)){this.Down=Y.Down;this.AM=Y.AM;this.Ah=Y.Ah;this.AI=Y.AI;this.
Fh=false;if(Y.Down){this.Ia=this.DX;this.G5=this.DX>0;if(this.G5)(A=this.EA)?A[1
].call(A[0],this):null;else(A=this.Cz)?A[1].call(A[0],this):null;if(!this.Fh)this.
DX=this.DX+1;return!this.Fh;}if(!Y.Down){this.G5=this.DX>1;this.Ia=this.DX-1;this.
DX=0;(A=this.CA)?A[1].call(A[0],this):null;return!this.Fh;}}return false;},BR:function(
aArg){var A;var BO=(C.Aj.isPrototypeOf(A=this.Af)?A:null);if(!BO)throw new Error(
EP);this.Am=BO.FV;BO.FV=this;},_Init:function(aArg){this.__proto__=C.Ex;this.BR(
aArg);B.gv++;},_Done:function(){this.__proto__=null;B.gv--;},_ReInit:function(){
},_Mark:function(D){var A;if((A=this.Am)&&(A._cycle!=D))A._Mark(A._cycle=D);if((
A=this.CA)&&((A=A[0])._cycle!=D))A._Mark(A._cycle=D);if((A=this.Cz)&&((A=A[0])._cycle
!=D))A._Mark(A._cycle=D);if((A=this.EA)&&((A=A[0])._cycle!=D))A._Mark(A._cycle=D
);if((A=this.Af)&&(A._cycle!=D))A._Mark(A._cycle=D);},Af:null,_cycle:0,_observers:
null,_className:"Core::KeyPressHandler"};C.Gj={BL:null,Eo:0,CY:B.qx,Initialize:function(
L,aOffset){this.BL=L;this.CY=aOffset;this.Eo=(aOffset[0]*aOffset[0])+(aOffset[1]
*aOffset[1]);return this;},_Init:function(aArg){this.__proto__=C.Gj;B.gv++;},_Done:
function(){this.__proto__=null;B.gv--;},_ReInit:function(){},_Mark:function(D){var
A;if((A=this.BL)&&(A._cycle!=D))A._Mark(A._cycle=D);if((A=this.Af)&&(A._cycle!=D
))A._Mark(A._cycle=D);},Af:null,_cycle:0,_observers:null,_className:"Core::CursorHit"
};C.I7={BO:null,_Init:function(aArg){this.__proto__=C.I7;B.gv++;},_Done:function(
){this.__proto__=null;B.gv--;},_ReInit:function(){},_Mark:function(D){var A;if((
A=this.BO)&&(A._cycle!=D))A._Mark(A._cycle=D);if((A=this.Af)&&(A._cycle!=D))A._Mark(
A._cycle=D);},Af:null,_cycle:0,_observers:null,_className:"Core::ModalContext"};
C.Fr={DW:null,BA:B.qy,X:B.qy,isEmpty:false,_Init:function(aArg){this.__proto__=C.
Fr;B.gv++;},_Done:function(){this.__proto__=null;B.gv--;},_ReInit:function(){},_Mark:
function(D){var A;if((A=this.DW)&&(A._cycle!=D))A._Mark(A._cycle=D);if((A=this.Af
)&&(A._cycle!=D))A._Mark(A._cycle=D);},Af:null,_cycle:0,_observers:null,_className:
"Core::LayoutContext"};C.Fs={E8:B.qx,E7:B.qx,E6:B.qx,E5:B.qx,_Init:function(aArg
){C.Fr._Init.call(this,aArg);this.__proto__=C.Fs;},_className:"Core::LayoutQuadContext"
};C.IQ={BO:null,_Init:function(aArg){this.__proto__=C.IQ;B.gv++;},_Done:function(
){this.__proto__=null;B.gv--;},_ReInit:function(){},_Mark:function(D){var A;if((
A=this.BO)&&(A._cycle!=D))A._Mark(A._cycle=D);if((A=this.Af)&&(A._cycle!=D))A._Mark(
A._cycle=D);},Af:null,_cycle:0,_observers:null,_className:"Core::DialogContext"};
C.JW={Hp:null,B4:null,_Init:function(aArg){this.__proto__=C.JW;B.gv++;},_Done:function(
){this.__proto__=null;B.gv--;},_ReInit:function(){},_Mark:function(D){var A;if((
A=this.Hp)&&(A._cycle!=D))A._Mark(A._cycle=D);if((A=this.B4)&&(A._cycle!=D))A._Mark(
A._cycle=D);if((A=this.Af)&&(A._cycle!=D))A._Mark(A._cycle=D);},Af:null,_cycle:0
,_observers:null,_className:"Core::TaskQueue"};C.JV={_Init:function(aArg){this.__proto__=
C.JV;B.gv++;},_Done:function(){this.__proto__=null;B.gv--;},_ReInit:function(){}
,_Mark:function(D){var A;if((A=this.Af)&&(A._cycle!=D))A._Mark(A._cycle=D);},Af:
null,_cycle:0,_observers:null,_className:"Core::Task"};C.C0={resource:null,Cx:function(
){this.resource=null;},BR:function(aArg){this.resource=aArg;},_Init:function(aArg
){this.__proto__=C.C0;this.BR(aArg);B.gv++;},_Done:function(){this.Cx();this.__proto__=
null;B.gv--;},_ReInit:function(){},_Mark:function(D){var A;if((A=this.Af)&&(A._cycle
!=D))A._Mark(A._cycle=D);},Af:null,_cycle:0,_observers:null,_className:"Core::Resource"
};C.Timer={EC:null,timer:null,AI:0,Period:1000,Fg:0,Cn:false,Cx:function(){var tmp=
this.timer;if(!!tmp)tmp.DestroyTimer();this.timer=null;},Ga:function(aBegin,aPeriod
){if(aBegin<0)aBegin=0;if(aPeriod<0)aPeriod=0;var tmp=this.timer;if(!tmp&&((aBegin>
0)||(aPeriod>0)))tmp=B.sL(this,this.Trigger);if(!!tmp){tmp.ResetTimer();tmp.StartTimer(
aBegin,aPeriod);}this.timer=tmp;},GX:function(value){if(value<0)value=0;if(value===
this.Period)return;this.Period=value;if(this.Cn)this.Ga(this.Fg,value);},GU:function(
value){if(value<0)value=0;if(value===this.Fg)return;this.Fg=value;if(this.Cn)this.
Ga(value,this.Period);},Cp:function(value){if(value===this.Cn)return;this.Cn=value;
if(value)this.Ga(this.Fg,this.Period);else this.Ga(0,0);this.AI=this.Fn();},Fn:function(
){var ticksCount=0;ticksCount=((new Date).getTime()-B.qt)|0;return ticksCount;},
Trigger:function(){var A;this.AI=this.Fn();if(!this.Period)this.Cp(false);(A=this.
EC)?A[1].call(A[0],this):null;},_Init:function(aArg){this.__proto__=C.Timer;B.gv++;
},_Done:function(){this.Cx();this.__proto__=null;B.gv--;},_ReInit:function(){},_Mark:
function(D){var A;if((A=this.EC)&&((A=A[0])._cycle!=D))A._Mark(A._cycle=D);if((A=
this.Af)&&(A._cycle!=D))A._Mark(A._cycle=D);},Af:null,_cycle:0,_observers:null,_className:
"Core::Timer"};C.Lr={Ls:0x1,KH:0x2,KP:0x4,Ln:0x8,Cn:0x10,Lg:0x20,KQ:0x40,KZ:0x80
,KO:0x100,KU:0x200,KN:0x400,K5:0x800,Ic:0x1000,Lp:0x2000,K3:0x4000,K4:0x8000,KM:
0x10000,K2:0x20000,Ld:0x40000};C.AG={K6:0x1,K7:0x2,KA:0x4,KB:0x8,KC:0x10,Kz:0x20
};C.Fm={K0:0,Lk:1,KJ:2,KV:3,K9:4,Ll:5,Lm:6,KK:7,KL:8,KX:9,KW:10,K$:11,K_:12};C.KeyCode={
NoKey:0,Ok:1,Exit:2,Menu:3,Up:4,Down:5,Left:6,Right:7,PageUp:8,PageDown:9,Key0:10
,Key1:11,Key2:12,Key3:13,Key4:14,Key5:15,Key6:16,Key7:17,Key8:18,Key9:19,Red:20,
Green:21,Blue:22,Yellow:23,White:24,Magenta:25,F1:26,F2:27,F3:28,F4:29,F5:30,F6:
31,F7:32,F8:33,F9:34,F10:35,ChannelUp:36,ChannelDown:37,Display:38,SkipPrev:39,SkipNext:
40,Home:41,End:42,Insert:43,Delete:44,Clear:45,VolumeUp:46,VolumeDown:47,Show:48
,Hide:49,Play:50,Pause:51,Record:52,Stop:53,Rev:54,Fwd:55,SlowRev:56,SlowFwd:57,
SkipBwd:58,SkipFwd:59,Repeat:60,Eject:61,Help:62,TV:63,DVD:64,VCR:65,EPG:66,OSD:
67,Text:68,PIP:69,Audio:70,Clock:71,Timer:72,Navigation:73,Karaoke:74,Game:75,Subtitle:
76,Zoom:77,Index:78,Info:79,Power:80,Setup:81,Angle:82,Mode:83,Mute:84,User0:85,
User1:86,User2:87,User3:88,User4:89,User5:90,User6:91,User7:92,User8:93,User9:94
,User10:95,User11:96,User12:97,User13:98,User14:99,User15:100,User16:101,User17:
102,User18:103,User19:104,KeyA:105,KeyB:106,KeyC:107,KeyD:108,KeyE:109,KeyF:110,
KeyG:111,KeyH:112,KeyI:113,KeyJ:114,KeyK:115,KeyL:116,KeyM:117,KeyN:118,KeyO:119
,KeyP:120,KeyQ:121,KeyR:122,KeyS:123,KeyT:124,KeyU:125,KeyV:126,KeyW:127,KeyX:128
,KeyY:129,KeyZ:130,Space:131,Plus:132,Minus:133,Multiply:134,Divide:135,Equals:136
,Period:137,Comma:138,Colon:139,Semicolon:140,AlphaKeys:141,AlphaOrDigitKeys:142
,DigitKeys:143,HexDigitKeys:144,CharacterKeys:145,ControlKeys:146,CursorKeys:147
,AnyKey:148,Enter:149,Escape:150,Backspace:151,Tab:152,CtrlKeyA:153,CtrlKeyB:154
,CtrlKeyC:155,CtrlKeyD:156,CtrlKeyE:157,CtrlKeyF:158,CtrlKeyG:159,CtrlKeyH:160,CtrlKeyI:
161,CtrlKeyJ:162,CtrlKeyK:163,CtrlKeyL:164,CtrlKeyM:165,CtrlKeyN:166,CtrlKeyO:167
,CtrlKeyP:168,CtrlKeyQ:169,CtrlKeyR:170,CtrlKeyS:171,CtrlKeyT:172,CtrlKeyU:173,CtrlKeyV:
174,CtrlKeyW:175,CtrlKeyX:176,CtrlKeyY:177,CtrlKeyZ:178,CtrlSpace:179,CtrlKey0:180
,CtrlKey1:181,CtrlKey2:182,CtrlKey3:183,CtrlKey4:184,CtrlKey5:185,CtrlKey6:186,CtrlKey7:
187,CtrlKey8:188,CtrlKey9:189,CtrlF1:190,CtrlF2:191,CtrlF3:192,CtrlF4:193,CtrlF5:
194,CtrlF6:195,CtrlF7:196,CtrlF8:197,CtrlF9:198,CtrlF10:199,CtrlEnter:200,CtrlEscape:
201,CtrlUp:202,CtrlDown:203,CtrlLeft:204,CtrlRight:205,CtrlPageUp:206,CtrlPageDown:
207,CtrlBackspace:208,CtrlInsert:209,CtrlDelete:210,CtrlHome:211,CtrlEnd:212,CtrlTab:
213,CtrlShiftKeyA:214,CtrlShiftKeyB:215,CtrlShiftKeyC:216,CtrlShiftKeyD:217,CtrlShiftKeyE:
218,CtrlShiftKeyF:219,CtrlShiftKeyG:220,CtrlShiftKeyH:221,CtrlShiftKeyI:222,CtrlShiftKeyJ:
223,CtrlShiftKeyK:224,CtrlShiftKeyL:225,CtrlShiftKeyM:226,CtrlShiftKeyN:227,CtrlShiftKeyO:
228,CtrlShiftKeyP:229,CtrlShiftKeyQ:230,CtrlShiftKeyR:231,CtrlShiftKeyS:232,CtrlShiftKeyT:
233,CtrlShiftKeyU:234,CtrlShiftKeyV:235,CtrlShiftKeyW:236,CtrlShiftKeyX:237,CtrlShiftKeyY:
238,CtrlShiftKeyZ:239,CtrlShiftSpace:240,CtrlShiftKey0:241,CtrlShiftKey1:242,CtrlShiftKey2:
243,CtrlShiftKey3:244,CtrlShiftKey4:245,CtrlShiftKey5:246,CtrlShiftKey6:247,CtrlShiftKey7:
248,CtrlShiftKey8:249,CtrlShiftKey9:250,CtrlShiftF1:251,CtrlShiftF2:252,CtrlShiftF3:
253,CtrlShiftF4:254,CtrlShiftF5:255,CtrlShiftF6:256,CtrlShiftF7:257,CtrlShiftF8:
258,CtrlShiftF9:259,CtrlShiftF10:260,CtrlShiftEnter:261,CtrlShiftEscape:262,CtrlShiftUp:
263,CtrlShiftDown:264,CtrlShiftLeft:265,CtrlShiftRight:266,CtrlShiftPageUp:267,CtrlShiftPageDown:
268,CtrlShiftBackspace:269,CtrlShiftInsert:270,CtrlShiftDelete:271,CtrlShiftHome:
272,CtrlShiftEnd:273,CtrlShiftTab:274,AltF1:275,AltF2:276,AltF3:277,AltF4:278,AltF5:
279,AltF6:280,AltF7:281,AltF8:282,AltF9:283,AltF10:284,AltEnter:285,AltEscape:286
,AltUp:287,AltDown:288,AltLeft:289,AltRight:290,AltPageUp:291,AltPageDown:292,AltBackspace:
293,AltInsert:294,AltDelete:295,AltHome:296,AltEnd:297,AltTab:298,AltShiftF1:299
,AltShiftF2:300,AltShiftF3:301,AltShiftF4:302,AltShiftF5:303,AltShiftF6:304,AltShiftF7:
305,AltShiftF8:306,AltShiftF9:307,AltShiftF10:308,AltShiftEnter:309,AltShiftEscape:
310,AltShiftUp:311,AltShiftDown:312,AltShiftLeft:313,AltShiftRight:314,AltShiftPageUp:
315,AltShiftPageDown:316,AltShiftBackspace:317,AltShiftInsert:318,AltShiftDelete:
319,AltShiftHome:320,AltShiftEnd:321,AltShiftTab:322,ShiftF1:323,ShiftF2:324,ShiftF3:
325,ShiftF4:326,ShiftF5:327,ShiftF6:328,ShiftF7:329,ShiftF8:330,ShiftF9:331,ShiftF10:
332,ShiftEnter:333,ShiftEscape:334,ShiftUp:335,ShiftDown:336,ShiftLeft:337,ShiftRight:
338,ShiftPageUp:339,ShiftPageDown:340,ShiftBackspace:341,ShiftInsert:342,ShiftDelete:
343,ShiftHome:344,ShiftEnd:345,ShiftTab:346};C.K8={Lw:0x1,Lt:0x2,Lu:0x4,Lv:0x8,KY:
0x10,KR:0x20};
C._Init=function(){C.EF.__proto__=C.BL;C.AH.__proto__=C.BL;C.Aj.__proto__=C.AH;C.
Root.__proto__=C.Aj;C.KeyEvent.__proto__=C.Event;C.Fj.__proto__=C.Event;C.Fi.__proto__=
C.Event;C.Fk.__proto__=C.Event;C.ED.__proto__=C.AH;C.G7.__proto__=C.EF;C.Fs.__proto__=
C.Fr;};C.Bd=function(D){};return C;})();

/* Embedded Wizard */