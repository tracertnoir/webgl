/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var TutorialApplication;if(!TutorialApplication)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(TutorialApplication.un)throw new Error("The unit file 'BrowserDevice.js' included twice!"
);TutorialApplication.un=(function(){var B=TutorialApplication;var C={};
var Ae="Show forecast command on browser device was called";
C.HP={EI:function(){var Kv;{doSend("GET_DATA");}this.D8(Kv);},FA:function(){B.uf(
"%s",Ae);window.open('https://www.cnn.com/weather','_self');},Fp:function(){{init_web(
);console.log("init_web...");}},D8:function(value){if(this.EJ===value)return;this.
EJ=value;B.tG([this,this.H5,this.D8],0);},_Init:function(aArg){var AP=this.AP;AP.
__proto__=C.HP;B.gv++;},_Done:function(){var AP=this.AP;AP.__proto__=null;B.gv--;
},_ReInit:function(){},_Mark:function(D){},_variants:function(){return this;},_className:
"BrowserDevice::DeviceClassBrowser"};var audioContext=new AudioContext();var eqDatas;
function beep(){var oscillatorNode=audioContext.createOscillator();var gainNode=
audioContext.createGain();oscillatorNode.connect(gainNode);oscillatorNode.frequency.
value=500;oscillatorNode.type="square";gainNode.connect(audioContext.destination
);gainNode.gain.value=1.5;oscillatorNode.start(audioContext.currentTime);oscillatorNode.
stop(audioContext.currentTime+0.2);}function init_web(){var wsUri="ws://"+Location.
hostname+":5080/";websocket=new WebSocket(wsUri);websocket.onopen=function(evt){
onOpen(evt)};websocket.onclose=function(evt){onClose(evt)};websocket.onmessage=function(
evt){onMessage(evt)};websocket.onerror=function(evt){onError(evt)};}function onOpen(
evt){console.log("onOpen");}function onClose(evt){console.log("onClose");}function
onMessage(evt){console.log("onMessage");console.log(evt.data);eqDatas=evt.data.split(
"^");}function onError(evt){console.log("onError");}function doSend(message){console.
log("doSend");if(websocket.readyState==1){websocket.send(message);}console.log(websocket.
readyState);}
C._Init=function(){};C.Bd=function(D){};return C;})();

/* Embedded Wizard */