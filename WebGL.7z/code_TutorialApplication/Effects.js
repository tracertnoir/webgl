/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var TutorialApplication;if(!TutorialApplication)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(TutorialApplication.um)throw new Error("The unit file 'Effects.js' included twice!"
);TutorialApplication.um=(function(){var B=TutorialApplication;var C={};

C.Gk={Trigger:function(){B.Core.Timer.Trigger.call(this);B.qw(this,0);},_Init:function(
aArg){B.Core.Timer._Init.call(this,aArg);this.__proto__=C.Gk;},_className:"Effects::EffectTimerClass"
};C.Fl={_Init:function(){C.Gk._Init.call(this,0);this.GX(15);this.Cp(true);},_variants:
function(){return this;},_this:null};
C._Init=function(){C.Gk.__proto__=B.Core.Timer;};C.Bd=function(D){var A;if((A=C.Fl.
_this)&&(A._cycle!=D))A._Done(C.Fl._this=null);};return C;})();

/* Embedded Wizard */