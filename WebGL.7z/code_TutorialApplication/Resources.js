/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var TutorialApplication;if(!TutorialApplication)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(TutorialApplication.ui)throw new Error("The unit file 'Resources.js' included twice!"
);TutorialApplication.ui=(function(){var B=TutorialApplication;var C={};
var Ae=[0,0];var AJ="The property \'FrameSize\' is READ ONLY.";
C.W={bitmap:null,FrameDelay:0,NoOfFrames:1,FrameSize:B.qx,B5:false,D5:false,Cx:function(
){if(!this.bitmap)return;var handle=this.bitmap;B.sW(handle);this.bitmap=null;this.
FrameSize=Ae;this.FrameDelay=0;this.NoOfFrames=1;this.B5=false;},BR:function(aArg
){if(!aArg)return;var handle=null;var noOfFrames=1;var frameSize=Ae;var frameDelay=
0;{var bmp=B.tp(aArg,this);if(bmp){noOfFrames=bmp.NoOfFrames;frameSize=bmp.FrameSize;
frameDelay=bmp.FrameDelay;}handle=bmp;}this.bitmap=handle;this.NoOfFrames=noOfFrames;
this.FrameSize=frameSize;this.FrameDelay=frameDelay;this.D5=true;this.B5=(!!this.
bitmap&&(this.FrameDelay>0))&&(this.NoOfFrames>1);},GV:function(value){throw new
Error(AJ);},Update:function(){},_Init:function(aArg){B.Core.C0._Init.call(this,aArg
);this.__proto__=C.W;this.BR(aArg);},_Done:function(){this.Cx();this.__proto__=B.
Core.C0;B.Core.C0._Done.call(this);},_className:"Resources::Bitmap"};C.A4={font:
null,Leading:0,Descent:0,Ascent:0,Cx:function(){if(!this.font)return;var handle=
this.font;B.sX(handle);this.font=null;this.Ascent=0;this.Descent=0;this.Leading=
0;},BR:function(aArg){if(!aArg)return;var handle=null;var ascent=0;var descent=0;
var leading=0;{var font=B.tr(aArg);if(font){ascent=font.Ascent;descent=font.Descent;
leading=font.Leading;}handle=font;}this.font=handle;this.Ascent=ascent;this.Descent=
descent;this.Leading=leading;},HW:function(aFlowString){if(!this.font)return 0;var
handle=this.font;var advance=0;advance=B.s2(handle,aFlowString);return advance;}
,JN:function(aString,aOffset,aWidth,aMaxNoOfRows,aBidi){if(aOffset<0)aOffset=0;if(
!this.font||((aOffset>0)&&(aOffset>=aString.length)))return B.hm;var handle=this.
font;var result=B.hm;result=B.tM(handle,aString,aOffset,aWidth,aMaxNoOfRows,aBidi
);return result;},Ev:function(aString,aOffset,aCount){if(aOffset<0)aOffset=0;if(
!this.font||((aOffset>0)&&(aOffset>=aString.length)))return 0;var handle=this.font;
var advance=0;advance=B.jJ(handle,aString,aOffset,aCount);return advance;},OnGetLeading:
function(){return this.Leading;},OnGetDescent:function(){return this.Descent;},OnGetAscent:
function(){return this.Ascent;},_Init:function(aArg){B.Core.C0._Init.call(this,aArg
);this.__proto__=C.A4;this.BR(aArg);},_Done:function(){this.Cx();this.__proto__=
B.Core.C0;B.Core.C0._Done.call(this);},_className:"Resources::Font"};C.Gu={_class:
function(){return C.A4;},0:{Data:function(){return B.ur;},Cache:[],_this:null}};
C.Eu={_class:function(){return C.A4;},0:{Data:function(){return B.uq;},Cache:[],
_this:null}};C.Gt={_class:function(){return C.A4;},0:{Data:function(){return B.up;
},Cache:[],_this:null}};
C._Init=function(){C.W.__proto__=B.Core.C0;C.A4.__proto__=B.Core.C0;};C.Bd=function(
D){var A;if((A=C.Gu[0]._this)&&(A._cycle!=D))A._Done(C.Gu[0]._this=null);if((A=C.
Eu[0]._this)&&(A._cycle!=D))A._Done(C.Eu[0]._this=null);if((A=C.Gt[0]._this)&&(A.
_cycle!=D))A._Done(C.Gt[0]._this=null);};return C;})();

/* Embedded Wizard */