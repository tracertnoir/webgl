/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var TutorialApplication;if(!TutorialApplication)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(TutorialApplication.Graphics)throw new Error("The unit file 'Graphics.js' included twice!"
);TutorialApplication.Graphics=(function(){var B=TutorialApplication;var C={};
var Ae=[0,0];var AJ="Can not resize explicitly attached graphics engine bitmaps";
var Cc=[0,0,0,0];var DH="No graphics engine bitmap attached to this canvas";var Di=
"The canvas is already initialized with a graphics engine bitmap";var DI="WarpBitmap() operation has been omitted due to the resulting area "+
"being wider or higher than 4069 pixel.";var DJ="ScaleBitmap() operation has been omitted due to the resulting area "+
"being wider or higher than 4069 pixel.";
C.Canvas={H4:null,Co:B.qy,Dx:0,EU:false,Cx:function(){if(this.EU)this.DetachBitmap(
);},BR:function(aArg){this.D5=true;},GV:function(value){if((value[0]<=0)||(value[
1]<=0))value=Ae;if(B.tl(value,this.FrameSize))return;if(this.EU)throw new Error(
AJ);this.FrameSize=value;this.B5=(((this.FrameSize[0]>0)&&(this.FrameSize[1]>0))&&(
this.FrameDelay>0))&&(this.NoOfFrames>1);if(!this.bitmap)return;var handle=this.
bitmap;B.sW(handle);this.bitmap=null;},Update:function(){var A;if((!this.bitmap&&(
this.FrameSize[0]>0))&&(this.FrameSize[1]>0)){var frameSize=this.FrameSize;var noOfFrames=
this.NoOfFrames;var frameDelay=this.FrameDelay;var handle=null;{handle=B.nc(B.ch
,frameSize,frameDelay,noOfFrames);}this.bitmap=handle;if(!this.bitmap){this.FrameSize=
Ae;this.FrameDelay=0;this.NoOfFrames=1;}this.Co=[].concat(Ae,this.FrameSize);}if(
!(((A=this.Co)[0]>=A[2])||(A[1]>=A[3]))){if((this.FrameSize[0]>0)&&(this.FrameSize[
1]>0))(A=this.H4)?A[1].call(A[0],this):null;this.Co=Cc;}},DetachBitmap:function(
){if(!this.EU)throw new Error(DH);this.bitmap=null;this.EU=false;this.FrameSize=
Ae;this.FrameDelay=0;this.NoOfFrames=1;this.B5=false;return this;},AttachBitmap:
function(aBitmap){if(!!this.bitmap)throw new Error(Di);if(!aBitmap)return this;this.
bitmap=aBitmap;this.EU=true;var noOfFrames=1;var frameSize=Ae;var frameDelay=0;{
noOfFrames=aBitmap.NoOfFrames;frameSize=aBitmap.FrameSize;frameDelay=aBitmap.FrameDelay;
}this.NoOfFrames=noOfFrames;this.FrameSize=frameSize;this.FrameDelay=frameDelay;
this.B5=(this.FrameDelay>0)&&(this.NoOfFrames>1);return this;},HR:function(aClip
,Hh,aString,aOffset,aCount,aDstRect,aSrcPos,aMinWidth,Hj,aColorTL,aColorTR,aColorBR
,aColorBL,aBlend){if(!this.bitmap)this.Update();if(!this.bitmap)return;if(aOffset<
0)aOffset=0;if((!Hh||!Hh.font)||((aOffset>0)&&(aOffset>=aString.length)))return;
var orient=0;if(Hj===1)orient=90;else if(Hj===2)orient=180;else if(Hj===3)orient=
270;var dstFrameNo=this.Dx;var dstBitmap=this.bitmap;var srcFont=Hh.font;{B.nf(dstBitmap
,srcFont,aString,aOffset,aCount,dstFrameNo,aClip,aDstRect,aSrcPos,aMinWidth,orient
,aColorTL,aColorTR,aColorBR,aColorBL,aBlend);}},IR:function(aClip,aBitmap,aFrameNr
,aDstRect,Eb,aColorTL,aColorTR,aColorBR,aColorBL,aBlend){var A;if(!this.bitmap)this.
Update();if(!this.bitmap)return;if((((!aBitmap||!aBitmap.bitmap)||!Eb)||(aFrameNr<
0))||(aFrameNr>=aBitmap.NoOfFrames))return;var dstBitmap=this.bitmap;var srcBitmap=
aBitmap.bitmap;var dstFrameNo=this.Dx;var srcRect=[].concat(Ae,aBitmap.FrameSize
);var left=((Eb&0x1)===0x1);var top=((Eb&0x2)===0x2);var right=((Eb&0x4)===0x4);
var bottom=((Eb&0x8)===0x8);var interior=((Eb&0x10)===0x10);{B.sQ(dstBitmap,srcBitmap
,dstFrameNo,aFrameNr,aClip,aDstRect,srcRect,left,top,right,bottom,interior,aColorTL
,aColorTR,aColorBR,aColorBL,aBlend);}},Hf:function(aClip,aBitmap,aFrameNr,aDstX1
,aDstY1,aDstW1,aDstX2,aDstY2,aDstW2,aDstX3,aDstY3,aDstW3,aDstX4,aDstY4,aDstW4,aSrcRect
,aColor1,aColor2,aColor3,aColor4,aBlend,aFilter){if(!this.bitmap)this.Update();if(
!this.bitmap)return;if(((!aBitmap||!aBitmap.bitmap)||(aFrameNr<0))||(aFrameNr>=aBitmap.
NoOfFrames))return;var O=aDstX1;var Q=aDstX2;var P=aDstY1;var R=aDstY2;if(aDstX2<
O)O=aDstX2;if(aDstX3<O)O=aDstX3;if(aDstX4<O)O=aDstX4;if(aDstX2>Q)Q=aDstX2;if(aDstX3>
Q)Q=aDstX3;if(aDstX4>Q)Q=aDstX4;if(aDstY2<P)P=aDstY2;if(aDstY3<P)P=aDstY3;if(aDstY4<
P)P=aDstY4;if(aDstY2>R)R=aDstY2;if(aDstY3>R)R=aDstY3;if(aDstY4>R)R=aDstY4;if(((((
Q-O)>4096.000000)||((Q-O)<-4096.000000))||((R-P)>4096.000000))||((R-P)<-4096.000000
)){B.uf("%s",DI);return;}var dstBitmap=this.bitmap;var srcBitmap=aBitmap.bitmap;
var dstFrameNr=this.Dx;{B.ug(dstBitmap,srcBitmap,dstFrameNr,aFrameNr,aClip,aDstX1
,aDstY1,aDstW1,aDstX2,aDstY2,aDstW2,aDstX3,aDstY3,aDstW3,aDstX4,aDstY4,aDstW4,aSrcRect
,aColor1,aColor2,aColor3,aColor4,aBlend,aFilter);}},JR:function(aClip,aBitmap,aFrameNr
,aDstRect,aSrcRect,aColorTL,aColorTR,aColorBR,aColorBL,aBlend,aFilter){if(!this.
bitmap)this.Update();if(!this.bitmap)return;if(((!aBitmap||!aBitmap.bitmap)||(aFrameNr<
0))||(aFrameNr>=aBitmap.NoOfFrames))return;var top=aDstRect[1];var left=aDstRect[
0];var right=aDstRect[2];var bottom=aDstRect[3];if(((((right-left)>4096.000000)||((
right-left)<-4096.000000))||((bottom-top)>4096.000000))||((bottom-top)<-4096.000000
)){B.uf("%s",DJ);return;}var dstBitmap=this.bitmap;var srcBitmap=aBitmap.bitmap;
var dstFrameNo=this.Dx;{B.ug(dstBitmap,srcBitmap,dstFrameNo,aFrameNr,aClip,left,
top,1,right,top,1,right,bottom,1,left,bottom,1,aSrcRect,aColorTL,aColorTR,aColorBR
,aColorBL,aBlend,aFilter);}},HN:function(aClip,aBitmap,aFrameNr,aDstRect,aSrcPos
,aColorTL,aColorTR,aColorBR,aColorBL,aBlend){if(!this.bitmap)this.Update();if(!this.
bitmap)return;if(((!aBitmap||!aBitmap.bitmap)||(aFrameNr<0))||(aFrameNr>=aBitmap.
NoOfFrames))return;var dstBitmap=this.bitmap;var srcBitmap=aBitmap.bitmap;var dstFrameNr=
this.Dx;{B.fF(dstBitmap,srcBitmap,dstFrameNr,aFrameNr,aClip,aDstRect,aSrcPos,aColorTL
,aColorTR,aColorBR,aColorBL,aBlend);}},HQ:function(aClip,aDstRect,aEdgeWidth,aColorTL
,aColorTR,aColorBR,aColorBL,aBlend){if(!this.bitmap)this.Update();if(!this.bitmap
)return;var dstBitmap=this.bitmap;var dstFrameNo=this.Dx;{B.sR(dstBitmap,dstFrameNo
,aClip,aDstRect,aEdgeWidth,aColorTL,aColorTR,aColorBR,aColorBL,aBlend);}},Gs:function(
aClip,aDstRect,aColorTL,aColorTR,aColorBR,aColorBL,aBlend){if(!this.bitmap)this.
Update();if(!this.bitmap)return;var dstBitmap=this.bitmap;var dstFrameNo=this.Dx;{
B.hn(dstBitmap,dstFrameNo,aClip,aDstRect,aColorTL,aColorTR,aColorBR,aColorBL,aBlend
);}},_Init:function(aArg){B.ui.W._Init.call(this,aArg);this.__proto__=C.Canvas;this.
BR(aArg);},_Done:function(){this.Cx();this.__proto__=B.ui.W;B.ui.W._Done.call(this
);},_Mark:function(D){var A;B.ui.W._Mark.call(this,D);if((A=this.H4)&&((A=A[0]).
_cycle!=D))A._Mark(A._cycle=D);},_className:"Graphics::Canvas"};C.HS={Left:0x1,Lj:
0x2,Right:0x4,KI:0x8,KT:0x10};
C._Init=function(){C.Canvas.__proto__=B.ui.W;};C.Bd=function(D){};return C;})();

/* Embedded Wizard */