/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var TutorialApplication;if(!TutorialApplication)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(TutorialApplication.uj)throw new Error("The unit file 'Views.js' included twice!"
);TutorialApplication.uj=(function(){var B=TutorialApplication;var C={};
var Ae=[0,0];var AJ=[0,0,0,0];var Cc="\uFEFF";
C.Fz={A$:0xFFFFFFFF,Ba:0xFFFFFFFF,Bc:0xFFFFFFFF,Bb:0xFFFFFFFF,B6:function(At,aClip
,aOffset,Aq,aBlend){var A;aBlend=aBlend&&((this.E&0x2)===0x2);Aq=Aq+1;if(Aq<256){
var AE=this.Bb;var AF=this.Bc;var AC=this.A$;var AD=this.Ba;AE=(AE&0x00FFFFFF)|((((
Aq*((AE>>24)&0xFF))>>8)&0xFF)<<24);AF=(AF&0x00FFFFFF)|((((Aq*((AF>>24)&0xFF))>>8
)&0xFF)<<24);AC=(AC&0x00FFFFFF)|((((Aq*((AC>>24)&0xFF))>>8)&0xFF)<<24);AD=(AD&0x00FFFFFF
)|((((Aq*((AD>>24)&0xFF))>>8)&0xFF)<<24);At.Gs(aClip,B.tz(this.N,aOffset),AE,AF,
AD,AC,aBlend);}else At.Gs(aClip,B.tz(this.N,aOffset),this.Bb,this.Bc,this.Ba,this.
A$,aBlend);},BZ:function(value){var A;if((((value===this.Bb)&&(value===this.Bc))&&(
value===this.A$))&&(value===this.Ba))return;this.Bb=value;this.Bc=value;this.A$=
value;this.Ba=value;if(!!this.F&&((this.E&0x1)===0x1))this.F.Ad(this.N);},_Init:
function(aArg){B.Core.AH._Init.call(this,aArg);this.__proto__=C.Fz;},_className:
"Views::Rectangle"};C.Cl={Width:1,A$:0xFFFFFFFF,Ba:0xFFFFFFFF,Bc:0xFFFFFFFF,Bb:0xFFFFFFFF
,B6:function(At,aClip,aOffset,Aq,aBlend){var A;aBlend=aBlend&&((this.E&0x2)===0x2
);Aq=Aq+1;if(Aq<256){var AE=this.Bb;var AF=this.Bc;var AC=this.A$;var AD=this.Ba;
AE=(AE&0x00FFFFFF)|((((Aq*((AE>>24)&0xFF))>>8)&0xFF)<<24);AF=(AF&0x00FFFFFF)|((((
Aq*((AF>>24)&0xFF))>>8)&0xFF)<<24);AC=(AC&0x00FFFFFF)|((((Aq*((AC>>24)&0xFF))>>8
)&0xFF)<<24);AD=(AD&0x00FFFFFF)|((((Aq*((AD>>24)&0xFF))>>8)&0xFF)<<24);At.HQ(aClip
,B.tz(this.N,aOffset),this.Width,AE,AF,AD,AC,aBlend);}else At.HQ(aClip,B.tz(this.
N,aOffset),this.Width,this.Bb,this.Bc,this.Ba,this.A$,aBlend);},JL:function(value
){var A;if(value<0)value=0;if(value===this.Width)return;this.Width=value;if(!!this.
F&&((this.E&0x1)===0x1))this.F.Ad(this.N);},BZ:function(value){var A;if((((value===
this.Bb)&&(value===this.Bc))&&(value===this.A$))&&(value===this.Ba))return;this.
Bb=value;this.Bc=value;this.A$=value;this.Ba=value;if(!!this.F&&((this.E&0x1)===
0x1))this.F.Ad(this.N);},_Init:function(aArg){B.Core.AH._Init.call(this,aArg);this.
__proto__=C.Cl;},_className:"Views::Border"};C.Gw={timer:null,W:null,Ez:null,Be:-
1,A$:0xFFFFFFFF,Ba:0xFFFFFFFF,Bc:0xFFFFFFFF,Bb:0xFFFFFFFF,HS:0x1F,CV:0,DC:255,D0:
0,GS:B.qx,B5:false,Gn:true,B6:function(At,aClip,aOffset,Aq,aBlend){var A;var AS=
this.CV;if(this.Be>=0)AS=this.Be;if(!this.W||(AS>=this.W.NoOfFrames))return;this.
W.Update();var AE=this.Bb;var AF=this.Bc;var AD=this.Ba;var AC=this.A$;var BG=(((
Aq+1)*this.DC)>>8)+1;var Bl=this.HS;var J=B.tz(this.N,aOffset);var Ge=B.tw([J[2]-
J[0],J[3]-J[1]],this.GS);aBlend=aBlend&&((this.E&0x2)===0x2);if(BG<256){AE=(AE&0x00FFFFFF
)|((((((AE>>24)&0xFF)*BG)>>8)&0xFF)<<24);AF=(AF&0x00FFFFFF)|((((((AF>>24)&0xFF)*
BG)>>8)&0xFF)<<24);AD=(AD&0x00FFFFFF)|((((((AD>>24)&0xFF)*BG)>>8)&0xFF)<<24);AC=(
AC&0x00FFFFFF)|((((((AC>>24)&0xFF)*BG)>>8)&0xFF)<<24);}if(((this.GS[0]>0)&&(Ge[0
]>0))&&!((Bl&0x5)===0x5)){var By=((this.W.FrameSize[0]/3)|0)-Ge[0];if(((Bl&0x1)===
0x1)){if(aClip[2]>J[2])aClip=B.t1(aClip,J[2]);if(By>0)J=B.t1(J,J[2]+By);Bl=Bl|0x4;
}else if(((Bl&0x4)===0x4)){if(aClip[0]<J[0])aClip=[].concat(J[0],aClip.slice(1,4
));if(By>0)J=[].concat(J[0]-By,J.slice(1,4));Bl=Bl|0x1;}else{if(aClip[0]<J[0])aClip=[
].concat(J[0],aClip.slice(1,4));if(aClip[2]>J[2])aClip=B.t1(aClip,J[2]);if(By>0){
J=[].concat(J[0]-((By/2)|0),J.slice(1,4));J=B.t1(J,(J[2]+By)-((By/2)|0));}Bl=Bl|
0x5;}}if(((this.GS[1]>0)&&(Ge[1]>0))&&!((Bl&0xA)===0xA)){var By=((this.W.FrameSize[
1]/3)|0)-Ge[1];if(((Bl&0x2)===0x2)){if(aClip[3]>J[3])aClip=[].concat(aClip.slice(
0,3),J[3]);if(By>0)J=[].concat(J.slice(0,3),J[3]+By);Bl=Bl|0x8;}else if(((Bl&0x8
)===0x8)){if(aClip[1]<J[1])aClip=B.t3(aClip,J[1]);if(By>0)J=B.t3(J,J[1]-By);Bl=Bl|
0x2;}else{if(aClip[1]<J[1])aClip=B.t3(aClip,J[1]);if(aClip[3]>J[3])aClip=[].concat(
aClip.slice(0,3),J[3]);if(By>0){J=B.t3(J,J[1]-((By/2)|0));J=[].concat(J.slice(0,
3),(J[3]+By)-((By/2)|0));}Bl=Bl|0xA;}}At.IR(aClip,this.W,AS,J,Bl,AE,AF,AD,AC,aBlend
);},E4:function(AV){var A;if(!!this.F&&((this.E&0x1)===0x1))this.F.Ad(this.N);},
Dc:function(AV){var A;var AS=this.Be;var BX=0;if(!!this.W)BX=this.W.NoOfFrames*this.
W.FrameDelay;if((!!this.timer&&(this.Be<0))&&(BX>0))this.D0=this.timer.AI-(this.
CV*this.W.FrameDelay);if(!!this.timer&&(BX>0)){var D1=(this.timer.AI-this.D0)|0;
AS=(D1/this.W.FrameDelay)|0;if(D1>=BX){AS=AS%this.W.NoOfFrames;this.D0=this.timer.
AI-(D1%BX);if(!this.Gn){AS=this.W.NoOfFrames-1;BX=0;}}}if(((AS!==this.Be)&&!!this.
F)&&((this.E&0x1)===0x1))this.F.Ad(this.N);this.Be=AS;if(!BX&&!!this.timer){B.sM([
this,this.Dc],this.timer,0);this.timer=null;(A=this.Ez)?A[1].call(A[0],this):null;
}},BZ:function(value){var A;if((((value===this.Bb)&&(value===this.Bc))&&(value===
this.A$))&&(value===this.Ba))return;this.Bb=value;this.Bc=value;this.A$=value;this.
Ba=value;if(!!this.F&&((this.E&0x1)===0x1))this.F.Ad(this.N);},DB:function(value
){var A;if(this.B5===value)return;this.B5=value;this.Be=-1;if(!value&&!!this.timer
){B.sM([this,this.Dc],this.timer,0);this.timer=null;}if(value){this.timer=B._GetAutoObject(
B.um.Fl);B.sz([this,this.Dc],this.timer,0);B.lq([this,this.Dc],this);}if(!!this.
F&&((this.E&0x1)===0x1))this.F.Ad(this.N);},Fu:function(value){var A;if(value<0)
value=0;if((value===this.CV)&&(this.Be===-1))return;this.CV=value;if(!this.timer
)this.Be=-1;if(!!this.F&&((this.E&0x1)===0x1))this.F.Ad(this.N);},Ft:function(value
){var A;if(value===this.W)return;if(!!this.W&&this.W.D5)B.sM([this,this.E4],this.
W,0);this.W=value;this.Be=-1;if(!!value&&value.D5)B.sz([this,this.E4],value,0);if(
this.B5){this.DB(false);this.DB(true);}if(!!this.F&&((this.E&0x1)===0x1))this.F.
Ad(this.N);},_Init:function(aArg){B.Core.AH._Init.call(this,aArg);this.__proto__=
C.Gw;},_Mark:function(D){var A;B.Core.AH._Mark.call(this,D);if((A=this.timer)&&(
A._cycle!=D))A._Mark(A._cycle=D);if((A=this.W)&&(A._cycle!=D))A._Mark(A._cycle=D
);if((A=this.Ez)&&((A=A[0])._cycle!=D))A._Mark(A._cycle=D);},_className:"Views::Frame"
};C.GE={timer:null,W:null,Ez:null,D0:0,Be:0,A$:0xFFFFFFFF,Ba:0xFFFFFFFF,Bc:0xFFFFFFFF
,Bb:0xFFFFFFFF,C1:B.qx,CS:0x12,CV:0,DC:255,CZ:0,B5:false,Gn:true,D4:false,Fy:true
,B6:function(At,aClip,aOffset,Aq,aBlend){var A;var AS=this.CV;if(this.Be>=0)AS=this.
Be;if(!this.W||(AS>=this.W.NoOfFrames))return;this.W.Update();var S=this.Cy();var
AO=this.W.FrameSize;var orient=this.CZ;if((S[0]>=S[2])||(S[1]>=S[3]))return;var AE=
this.Bb;var AF=this.Bc;var AD=this.Ba;var AC=this.A$;var BG=(((Aq+1)*this.DC)>>8
)+1;aBlend=aBlend&&((this.E&0x2)===0x2);if(BG<256){AE=(AE&0x00FFFFFF)|((((((AE>>
24)&0xFF)*BG)>>8)&0xFF)<<24);AF=(AF&0x00FFFFFF)|((((((AF>>24)&0xFF)*BG)>>8)&0xFF
)<<24);AD=(AD&0x00FFFFFF)|((((((AD>>24)&0xFF)*BG)>>8)&0xFF)<<24);AC=(AC&0x00FFFFFF
)|((((((AC>>24)&0xFF)*BG)>>8)&0xFF)<<24);}if(B.tl([S[2]-S[0],S[3]-S[1]],AO)&&!orient
)At.HN(aClip,this.W,AS,B.tz(this.N,aOffset),B.tw(this.N.slice(0,2),S.slice(0,2))
,AE,AF,AD,AC,aBlend);else if(!orient)At.JR(aClip,this.W,AS,B.tz(S,aOffset),[].concat(
Ae,AO),AE,AF,AD,AC,aBlend,this.Fy);else{var left=S[0]+aOffset[0];var top=S[1]+aOffset[
1];var right=S[2]+aOffset[0];var bottom=S[3]+aOffset[1];if(orient===1)At.Hf(aClip
,this.W,AS,left,bottom,1.000000,left,top,1.000000,right,top,1.000000,right,bottom
,1.000000,[].concat(Ae,AO),AC,AE,AF,AD,aBlend,this.Fy);else if(orient===2)At.Hf(
aClip,this.W,AS,right,bottom,1.000000,left,bottom,1.000000,left,top,1.000000,right
,top,1.000000,[].concat(Ae,AO),AD,AC,AE,AF,aBlend,this.Fy);else if(orient===3)At.
Hf(aClip,this.W,AS,right,top,1.000000,right,bottom,1.000000,left,bottom,1.000000
,left,top,1.000000,[].concat(Ae,AO),AF,AD,AC,AE,aBlend,this.Fy);}},E4:function(AV
){var A;if(((this.D4&&!!this.W)&&(this.W.FrameSize[0]>0))&&(this.W.FrameSize[1]>
0))this.Ak(B.ty(this.Cy(),this.C1));if(!!this.F&&((this.E&0x1)===0x1))this.F.Ad(
this.N);},Dc:function(AV){var A;var AS=this.Be;var BX=0;if(!!this.W)BX=this.W.NoOfFrames
*this.W.FrameDelay;if((!!this.timer&&(this.Be<0))&&(BX>0))this.D0=this.timer.AI-(
this.CV*this.W.FrameDelay);if(!!this.timer&&(BX>0)){var D1=(this.timer.AI-this.D0
)|0;AS=(D1/this.W.FrameDelay)|0;if(D1>=BX){AS=AS%this.W.NoOfFrames;this.D0=this.
timer.AI-(D1%BX);if(!this.Gn){AS=this.W.NoOfFrames-1;BX=0;}}}if(((AS!==this.Be)&&
!!this.F)&&((this.E&0x1)===0x1))this.F.Ad(this.N);this.Be=AS;if(!BX&&!!this.timer
){B.sM([this,this.Dc],this.timer,0);this.timer=null;(A=this.Ez)?A[1].call(A[0],this
):null;}},BZ:function(value){var A;if((((value===this.Bb)&&(value===this.Bc))&&(
value===this.A$))&&(value===this.Ba))return;this.Bb=value;this.Bc=value;this.A$=
value;this.Ba=value;if(!!this.F&&((this.E&0x1)===0x1))this.F.Ad(this.N);},DB:function(
value){var A;if(this.B5===value)return;this.B5=value;this.Be=-1;if(!value&&!!this.
timer){B.sM([this,this.Dc],this.timer,0);this.timer=null;}if(value){this.timer=B.
_GetAutoObject(B.um.Fl);B.sz([this,this.Dc],this.timer,0);B.lq([this,this.Dc],this
);}if(!!this.F&&((this.E&0x1)===0x1))this.F.Ad(this.N);},D6:function(value){var A;
if(value===this.CS)return;this.CS=value;if(!!this.F&&((this.E&0x1)===0x1))this.F.
Ad(this.N);},Fu:function(value){var A;if(value<0)value=0;if((value===this.CV)&&(
this.Be===-1))return;this.CV=value;if(!this.timer)this.Be=-1;if(!!this.F&&((this.
E&0x1)===0x1))this.F.Ad(this.N);},Ft:function(value){var A;if(value===this.W)return;
if(!!this.W&&this.W.D5)B.sM([this,this.E4],this.W,0);this.W=value;this.Be=-1;if(
!!value&&value.D5)B.sz([this,this.E4],value,0);if(this.B5){this.DB(false);this.DB(
true);}if(((this.D4&&!!value)&&(value.FrameSize[0]>0))&&(value.FrameSize[1]>0))this.
Ak(B.ty(this.Cy(),this.C1));if(!!this.F&&((this.E&0x1)===0x1))this.F.Ad(this.N);
},Cy:function(){var A;if(!this.W)return AJ;var orient=this.CZ;var Ai=this.CS;var
AO=this.W.FrameSize;var X=this.N;var width=X[2]-X[0];var height=X[3]-X[1];if(!AO[
0]||!AO[1])return AJ;if((orient===1)||(orient===3)){width=height;height=X[2]-X[0
];}var Aa=[0,0,width,height];var M=Aa;if(((Ai&0x40)===0x40)){var HK=((((Aa[2]-Aa[
0])<<16)+((AO[0]/2)|0))/AO[0])|0;var Fa=((((Aa[3]-Aa[1])<<16)+((AO[1]/2)|0))/AO[
1])|0;var Db=HK;if(Fa>Db)Db=Fa;M=B.tZ(M,((AO[0]*Db)+32768)>>16);M=B.tW(M,((AO[1]
*Db)+32768)>>16);}else if(((Ai&0x80)===0x80)){var HK=((((Aa[2]-Aa[0])<<16)+((AO[
0]/2)|0))/AO[0])|0;var Fa=((((Aa[3]-Aa[1])<<16)+((AO[1]/2)|0))/AO[1])|0;var Db=HK;
if(Fa<Db)Db=Fa;M=B.tZ(M,((AO[0]*Db)+32768)>>16);M=B.tW(M,((AO[1]*Db)+32768)>>16);
}else if(!((Ai&0x100)===0x100))M=B.tY(M,AO);if((M[2]-M[0])!==(Aa[2]-Aa[0])){if(((
Ai&0x4)===0x4))M=B.t0(M,Aa[2]-(M[2]-M[0]));else if(((Ai&0x2)===0x2))M=B.t0(M,(Aa[
0]+(((Aa[2]-Aa[0])/2)|0))-(((M[2]-M[0])/2)|0));}if((M[3]-M[1])!==(Aa[3]-Aa[1])){
if(((Ai&0x20)===0x20))M=B.t2(M,Aa[3]-(M[3]-M[1]));else if(((Ai&0x10)===0x10))M=B.
t2(M,(Aa[1]+(((Aa[3]-Aa[1])/2)|0))-(((M[3]-M[1])/2)|0));}if(!orient)M=B.tz(M,X.slice(
0,2));else if(orient===1){var BH=[X[0]+M[1],X[3]-M[2]];M=[].concat(BH,B.tx(BH,[M[
3]-M[1],M[2]-M[0]]));}else if(orient===2){var BH=[X[2]-M[2],X[3]-M[3]];M=[].concat(
BH,B.tx(BH,[M[2]-M[0],M[3]-M[1]]));}else if(orient===3){var BH=[X[2]-M[3],X[1]+M[
0]];M=[].concat(BH,B.tx(BH,[M[3]-M[1],M[2]-M[0]]));}return B.tz(M,this.C1);},_Init:
function(aArg){B.Core.AH._Init.call(this,aArg);this.__proto__=C.GE;},_Mark:function(
D){var A;B.Core.AH._Mark.call(this,D);if((A=this.timer)&&(A._cycle!=D))A._Mark(A.
_cycle=D);if((A=this.W)&&(A._cycle!=D))A._Mark(A._cycle=D);if((A=this.Ez)&&((A=A[
0])._cycle!=D))A._Mark(A._cycle=D);},_className:"Views::Image"};C.Text={A4:null,
CL:null,Ax:B.hm,String:B.hm,BT:null,Ck:B.qx,EE:0,DE:0,A$:0xFFFFFFFF,Ba:0xFFFFFFFF
,Bc:0xFFFFFFFF,Bb:0xFFFFFFFF,Dh:0,C1:B.qx,CS:0x12,DC:255,CZ:0,D$:false,D4:false,
Ep:false,Gl:false,BI:false,B6:function(At,aClip,aOffset,Aq,aBlend){var A;if((this.
Ax===B.hm)||!this.A4)return;var Ai=this.CS;var orient=this.CZ;var font=this.A4;var
Aa=B.tz(this.N,aOffset);var AE=this.Bb;var AF=this.Bc;var AD=this.Ba;var AC=this.
A$;var BG=(((Aq+1)*this.DC)>>8)+1;var CF=this.Ax.charCodeAt(0)||0;var S=B.tz(this.
Cy(),aOffset);var BW=[Aa[0]-S[0],(Aa[1]-S[1])-font.Ascent];if(CF<1)return;if(BG<
256){AE=(AE&0x00FFFFFF)|((((((AE>>24)&0xFF)*BG)>>8)&0xFF)<<24);AF=(AF&0x00FFFFFF
)|((((((AF>>24)&0xFF)*BG)>>8)&0xFF)<<24);AD=(AD&0x00FFFFFF)|((((((AD>>24)&0xFF)*
BG)>>8)&0xFF)<<24);AC=(AC&0x00FFFFFF)|((((((AC>>24)&0xFF)*BG)>>8)&0xFF)<<24);}if(((
Ai&0x80)===0x80)){if(this.GF())Ai=(Ai&~0x80)|0x4;else Ai=(Ai&~0x80)|0x1;}if(((CF===
1)&&!((Ai&0x40)===0x40))&&!orient){At.HR(aClip,font,this.Ax,2,(this.Ax.charCodeAt(
1)||0)-1,Aa,BW,0,orient,AE,AF,AD,AC,true);return;}var leading=font.Leading;if(this.
DE>0)leading=(this.DE-font.Ascent)-font.Descent;var HJ=(font.Ascent+font.Descent
)+leading;var FI=aClip[1]-S[1];var FJ=aClip[3]-S[1];var ET=S[2]-S[0];var D3=0;var
I=1;var Bx=this.Ax.charCodeAt(I)||0;if(orient===1){BW=[S[3]-Aa[3],(Aa[0]-S[0])-font.
Ascent];FI=aClip[0]-S[0];FJ=aClip[2]-S[0];ET=S[3]-S[1];}else if(orient===2){BW=[
S[2]-Aa[2],(S[3]-Aa[3])-font.Ascent];FI=S[3]-aClip[3];FJ=S[3]-aClip[1];}else if(
orient===3){BW=[Aa[1]-S[1],(S[2]-Aa[2])-font.Ascent];FI=S[2]-aClip[2];FJ=S[2]-aClip[
0];ET=S[3]-S[1];}while(((D3+HJ)<FI)&&(Bx>0)){I=I+Bx;D3=D3+HJ;Bx=this.Ax.charCodeAt(
I)||0;}while((D3<FJ)&&(Bx>0)){var DU=B.tw(BW,[0,D3]);var IC=0;var FU=false;if(((((
Ai&0x40)===0x40)&&((this.Ax.charCodeAt((I+Bx)-1)||0)!==0x0A))&&((this.Ax.charCodeAt(
I+1)||0)!==0x0A))&&((this.Ax.charCodeAt(I+Bx)||0)!==0x00))FU=true;if(FU&&!!(Ai&0x6
)){var IB=I+Bx;var Ii=this.Ax.indexOf(String.fromCharCode(0x20),I+1);var Ij=this.
Ax.indexOf(String.fromCharCode(0xA0),I+1);if(((Ii<0)||(Ii>=IB))&&((Ij<0)||(Ij>=IB
)))FU=false;}if(FU)IC=ET;else if(((Ai&0x4)===0x4))DU=[(DU[0]-ET)+font.Ev(this.Ax
,I+1,Bx-1),DU[1]];else if(((Ai&0x2)===0x2))DU=[(DU[0]-((ET/2)|0))+((font.Ev(this.
Ax,I+1,Bx-1)/2)|0),DU[1]];At.HR(aClip,font,this.Ax,I+1,Bx-1,Aa,DU,IC,orient,AE,AF
,AD,AC,true);I=I+Bx;D3=D3+HJ;Bx=this.Ax.charCodeAt(I)||0;}},Ak:function(value){var
A;if(B.tm(value,this.N))return;var HI=false;if(!this.CZ||(this.CZ===2))HI=((A=this.
N)[2]-A[0])!==(value[2]-value[0]);else HI=((A=this.N)[3]-A[1])!==(value[3]-value[
1]);if((((HI&&!this.Dh)&&this.D$)&&this.BI)&&!((this.E&0x2000)===0x2000)){this.Ax=
B.hm;this.BI=false;B.lq([this,this.Ds],this);}if(((this.Ep&&this.BI)&&!B.tl([(A=
this.N)[2]-A[0],A[3]-A[1]],[value[2]-value[0],value[3]-value[1]]))&&!((this.E&0x2000
)===0x2000)){this.Ax=B.hm;this.BI=false;B.lq([this,this.Ds],this);}B.Core.AH.Ak.
call(this,value);B.lq([this,this.HF],this);},Cx:function(){if(!!this.BT){this.Hq(
this.BT);this.BT=null;}},Hq:function(aBidi){if(!aBidi)return;B.ng(aBidi);},Kf:function(
aSize){var bidi=null;bidi=B.qk(aSize);return bidi;},HF:function(AV){B.lq(this.CL
,this);},Ds:function(AV){B.lq([this,this.F_],this);},F_:function(AV){var A;if(this.
BI)return;var orient=this.CZ;var width=(A=this.N)[2]-A[0];var height=(A=this.N)[
3]-A[1];var Ci=-1;if((orient===1)||(orient===3)){width=height;height=(A=this.N)[
2]-A[0];}if(this.D$){if(this.Dh>0)Ci=this.Dh;else if(!this.D4)Ci=width-(this.EE*
2);else Ci=width;if(Ci<0)Ci=1;}if(!!this.BT){this.Hq(this.BT);this.BT=null;}this.
BI=true;if((this.String!==B.hm)&&!!this.A4){var length=this.String.length;if(this.
Gl)this.BT=this.Kf(length);this.Ax=this.A4.JN(this.String,0,Ci,length,this.BT);if(
!!this.BT&&!this.I3()){this.Hq(this.BT);this.BT=null;}}else this.Ax=B.hm;this.Ck=
Ae;if(((this.Ep&&(this.Ax!==B.hm))&&!this.D4)&&!!this.A4){var Ai=this.CS;var font=
this.A4;var leading=font.Leading;var AB=this.Ax;var Gd=this.GF();if(((Ai&0x80)===
0x80)){if(Gd)Ai=(Ai&~0x80)|0x4;else Ai=(Ai&~0x80)|0x1;}if(this.DE>0)leading=(this.
DE-font.Ascent)-font.Descent;var E9=(font.Ascent+font.Descent)+leading;var CF=AB.
charCodeAt(0)||0;var Dp=((height+leading)/E9)|0;var Ho=false;var FH=false;if(Dp<=
0)Dp=1;if(CF>Dp){var Cu=0;var E_=0;var Gc=CF-1;var A3=0;var Bg=AB.length;var tmp=
B.hm;if(((Ai&0x20)===0x20))E_=CF-Dp;else if(((Ai&0x10)===0x10)){E_=((CF-Dp)/2)|0;
Gc=(E_+Dp)-1;}else Gc=Dp-1;Ho=E_>0;FH=Gc<(CF-1);for(A3=1;Cu<E_;Cu=Cu+1)A3=A3+(AB.
charCodeAt(A3)||0);if(FH)for(Bg=A3;Cu<Gc;Cu=Cu+1)Bg=Bg+(AB.charCodeAt(Bg)||0);if(
Ho){var Bt=AB.charCodeAt(A3)||0;tmp=(Cc+B.t9(AB,A3,Bt))+Cc;tmp=B.t4(tmp,0,(Bt+2)&
0xFFFF);A3=A3+Bt;if((tmp.charCodeAt(Bt)||0)===0x0A){tmp=B.t4(tmp,Bt,0xFEFF);tmp=
B.t4(tmp,Bt+1,0x0A);}if((tmp.charCodeAt(2)||0)===0x0A){tmp=B.t4(tmp,2,0xFEFF);tmp=
B.t4(tmp,1,0x0A);}else tmp=B.t4(tmp,1,0xFEFF);}tmp=tmp+B.t9(AB,A3,Bg-A3);if(FH&&(
Bg>=A3)){var Bt=AB.charCodeAt(Bg)||0;var BJ=(Cc+B.t9(AB,Bg,Bt))+Cc;BJ=B.t4(BJ,0,(
Bt+2)&0xFFFF);BJ=B.t4(BJ,1,0xFEFF);if((BJ.charCodeAt(Bt)||0)===0x0A){BJ=B.t4(BJ,
Bt,0xFEFF);BJ=B.t4(BJ,Bt+1,0x0A);}if((BJ.charCodeAt(2)||0)===0x0A){BJ=B.t4(BJ,2,
0xFEFF);BJ=B.t4(BJ,1,0x0A);}else BJ=B.t4(BJ,1,0xFEFF);tmp=tmp+BJ;}AB=String.fromCharCode(
Dp&0xFFFF)+tmp;}var Cu=0;var BD=1;var FY=width-(this.EE*2);if(this.D$&&(this.Dh>
0))FY=this.Dh;CF=AB.charCodeAt(0)||0;for(;Cu<CF;Cu=Cu+1){var Dv=Ho&&!Cu;var Dw=FH&&(
Cu===(CF-1));var Ce=false;var Cf=false;var El=Gd;if((Gd&&Dv)&&!Dw){Dv=false;Dw=true;
}else if((Gd&&Dw)&&!Dv){Dw=false;Dv=true;}var start=BD+1;var Bt=AB.charCodeAt(BD
)||0;var A3=start;var Bg=(start+Bt)-2;var Hw=-1;var Hx=-1;if(!this.D$&&(font.Ev(
AB,start,Bt-1)>FY)){if(((Ai&0x4)===0x4))Ce=true;else if(((Ai&0x2)===0x2)){Ce=true;
Cf=true;}else Cf=true;}if((AB.charCodeAt(A3)||0)===0x0A)A3=A3+1;if((AB.charCodeAt(
Bg)||0)===0x0A)Bg=Bg-1;while(Ce&&((AB.charCodeAt(A3)||0)===0xFEFF))A3=A3+1;while(
Cf&&((AB.charCodeAt(Bg)||0)===0xFEFF))Bg=Bg-1;Ce=Ce&&!Dw;Cf=Cf&&!Dv;while((((Ce||
Cf)||Dv)||Dw)&&(A3<Bg)){if((Ce&&(El||!Cf))||Dv){if(Hw>0)AB=B.t4(AB,Hw,0xFEFF);AB=
B.t4(AB,A3,0x2026);Hw=A3;A3=A3+1;El=!El;Dv=false;if(font.Ev(AB,start,Bt-1)<=FY){
Ce=false;Cf=false;}else Ce=Ce||!Cf;}if((Cf&&(!El||!Ce))||Dw){if(Hx>0)AB=B.t4(AB,
Hx,0xFEFF);AB=B.t4(AB,Bg,0x2026);Hx=Bg;Bg=Bg-1;El=!El;Dw=false;if(font.Ev(AB,start
,Bt-1)<=FY){Ce=false;Cf=false;}else Cf=Cf||!Ce;}}BD=BD+Bt;}this.Ck=[font.HW(AB),((
AB.charCodeAt(0)||0)*E9)-leading];this.Ax=AB;}if(this.D4&&(this.Ax!==B.hm)){var C$=[
this.EE,0];if((orient===1)||(orient===3)){C$=[C$[0],C$[0]];C$=[0,C$[1]];}this.E=
this.E|0x2000;this.Ak(B.ty(B.th(this.Cy(),C$),this.C1));this.E=this.E&~0x2000;}if(
!!this.F&&((this.E&0x1)===0x1))this.F.Ad(this.N);B.lq([this,this.HF],this);},H7:
function(value){if(value===this.Gl)return;this.Gl=value;this.Ax=B.hm;this.BI=false;
B.lq([this,this.Ds],this);},I_:function(value){if(value===this.Ep)return;this.Ep=
value;this.Ax=B.hm;this.BI=false;B.lq([this,this.Ds],this);},Fv:function(value){
if(B.to(value,this.CL))return;this.CL=value;if(!this.Dh||!!value)this.E=this.E&~
0x100;else this.E=this.E|0x100;},JM:function(value){if(value===this.D$)return;this.
D$=value;if(this.BI){this.Ax=B.hm;this.BI=false;B.lq([this,this.Ds],this);}if(value&&
!this.Dh)this.E=this.E&~0x100;else this.E=this.E|0x100;},D6:function(value){var A;
if(value===this.CS)return;this.CS=value;if(!!this.F&&((this.E&0x1)===0x1))this.F.
Ad(this.N);if(this.Ep){this.Ax=B.hm;this.BI=false;B.lq([this,this.Ds],this);}if(
this.BI)B.lq([this,this.HF],this);},D9:function(value){if(value===this.String)return;
this.String=value;this.Ax=B.hm;this.BI=false;B.lq([this,this.Ds],this);},EB:function(
value){if(value===this.A4)return;this.A4=value;this.Ax=B.hm;this.BI=false;B.lq([
this,this.Ds],this);},BZ:function(value){var A;if((((value===this.Bb)&&(value===
this.Bc))&&(value===this.A$))&&(value===this.Ba))return;this.Bb=value;this.Bc=value;
this.A$=value;this.Ba=value;if(!!this.F&&((this.E&0x1)===0x1))this.F.Ad(this.N);
},GF:function(){if(!this.BI)this.F_(this);if(!this.BT)return false;var result=false;
var bidi=this.BT;result=B.qj(bidi);return result;},I3:function(){if(!this.BI)this.
F_(this);if(!this.BT)return false;var result=false;var bidi=this.BT;result=B.sD(
bidi);return result;},Cy:function(){var A;if((this.String===B.hm)||!this.A4)return AJ;
if(!this.BI)this.F_(this);if(this.Ax===B.hm)return AJ;var leading=this.A4.Leading;
var E9=(this.A4.Ascent+this.A4.Descent)+this.A4.Leading;if(this.DE>0){leading=(this.
DE-this.A4.Ascent)-this.A4.Descent;E9=this.DE;}if(B.tl(this.Ck,Ae))this.Ck=[this.
A4.HW(this.Ax),this.Ck[1]];this.Ck=[this.Ck[0],((this.Ax.charCodeAt(0)||0)*E9)-leading
];var Ai=this.CS;var orient=this.CZ;var X=this.N;var C$=this.EE;var width=X[2]-X[
0];var height=X[3]-X[1];if((orient===1)||(orient===3)){width=height;height=X[2]-
X[0];}var Aa=[C$,0,width-C$,height];var M=[].concat(Aa.slice(0,2),B.tx(Aa.slice(
0,2),this.Ck));if(((Ai&0x80)===0x80)){if(this.GF())Ai=(Ai&~0x80)|0x4;else Ai=(Ai&
~0x80)|0x1;}if(((Ai&0x40)===0x40)){var Ci=this.Dh;if(Ci<=0)Ci=width-(this.EE*2);
if(Ci<0)Ci=0;if(Ci>(M[2]-M[0]))M=B.tZ(M,Ci);}if((M[2]-M[0])!==(Aa[2]-Aa[0])){if(((
Ai&0x4)===0x4))M=B.t0(M,Aa[2]-(M[2]-M[0]));else if(((Ai&0x2)===0x2))M=B.t0(M,(Aa[
0]+(((Aa[2]-Aa[0])/2)|0))-(((M[2]-M[0])/2)|0));}if((M[3]-M[1])!==(Aa[3]-Aa[1])){
if(((Ai&0x20)===0x20))M=B.t2(M,Aa[3]-(M[3]-M[1]));else if(((Ai&0x10)===0x10))M=B.
t2(M,(Aa[1]+(((Aa[3]-Aa[1])/2)|0))-(((M[3]-M[1])/2)|0));}if(!orient)M=B.tz(M,X.slice(
0,2));else if(orient===1){var BH=[X[0]+M[1],X[3]-M[2]];M=[].concat(BH,B.tx(BH,[this.
Ck[1],this.Ck[0]]));}else if(orient===2){var BH=[X[2]-M[2],X[3]-M[3]];M=[].concat(
BH,B.tx(BH,this.Ck));}else if(orient===3){var BH=[X[2]-M[3],X[1]+M[0]];M=[].concat(
BH,B.tx(BH,[this.Ck[1],this.Ck[0]]));}return B.tz(M,this.C1);},_Init:function(aArg
){B.Core.AH._Init.call(this,aArg);this.__proto__=C.Text;},_Done:function(){this.
Cx();this.__proto__=B.Core.AH;B.Core.AH._Done.call(this);},_Mark:function(D){var
A;B.Core.AH._Mark.call(this,D);if((A=this.A4)&&(A._cycle!=D))A._Mark(A._cycle=D);
if((A=this.CL)&&((A=A[0])._cycle!=D))A._Mark(A._cycle=D);},_className:"Views::Text"
};C.KT={II:0x1,IH:0x2,IJ:0x4,IM:0x8,IL:0x10,IK:0x20,Lf:0x40,Lg:0x80,Li:0x100};C.
Lj={II:0x1,IH:0x2,IJ:0x4,IM:0x8,IL:0x10,IK:0x20,Kz:0x40,Ky:0x80};C.CZ={K2:0,Ld:1
,Lb:2,Lc:3};
C._Init=function(){C.Fz.__proto__=B.Core.AH;C.Cl.__proto__=B.Core.AH;C.Gw.__proto__=
B.Core.AH;C.GE.__proto__=B.Core.AH;C.Text.__proto__=B.Core.AH;};C.Bd=function(D){
};return C;})();

/* Embedded Wizard */