/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var TutorialApplication;if(!TutorialApplication)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(TutorialApplication.ia)throw new Error("The unit file 'Application.js' included twice!"
);TutorialApplication.ia=(function(){var B=TutorialApplication;var C={};
var Ae=[0,0,480,320];var AJ=[30,122,230,272];var Cc="Ring";var DH="Bell";var Di=[
0,32,480,72];var DI="Tutorial application";var DJ=[254,122,454,272];var EN="Show";
var EO="Forecast";var EP=[0,74,200,106];var J4="Unit";var J5="Header";var Hg=[0,
0,200,150];var J6=[23,76,173,126];var J7="Action";var J8=[0,13,200,53];var J9="Heading";
C.TutorialApplication={BY:null,CT:null,CX:null,C2:null,Timer:null,B0:null,BR:function(
aArg){B._GetAutoObject(B.Device.Device).Fp();},JQ:function(AV){B._GetAutoObject(
B.Device.Device).EI();},IX:function(AV){B._GetAutoObject(B.Device.Device).FA();}
,JS:function(AV){B._GetAutoObject(B.Device.Device).EI();},_Init:function(aArg){B.
Core.Root._Init.call(this,aArg);B.uj.Fz._Init.call(this.BY={Af:this},0);C.Fx._Init.
call(this.CT={Af:this},0);B.uj.Text._Init.call(this.CX={Af:this},0);C.Fx._Init.call(
this.C2={Af:this},0);B.Core.Timer._Init.call(this.Timer={Af:this},0);B.ul.B0._Init.
call(this.B0={Af:this},0);this.__proto__=C.TutorialApplication;var A;this.Ak(Ae);
this.BY.Ak(Ae);this.BY.BZ(0xFFDCDCDC);this.CT.Ak(AJ);this.CT.H9(Cc);this.CT.H_(DH
);this.CX.Ak(Di);this.CX.D9(DI);this.CX.BZ(0xFF000000);this.C2.Ak(DJ);this.C2.H9(
EN);this.C2.H_(EO);this.Timer.Cp(true);this.B0.Ak(EP);this.B0.JB(J4);this.B0.Jz(
1);this.BQ(this.BY,0);this.BQ(this.CT,0);this.BQ(this.CX,0);this.BQ(this.C2,0);this.
BQ(this.B0,0);this.CT.H6([this,this.JQ]);this.CX.EB(B.s$(B.ui.Gt));this.C2.H6([this
,this.IX]);this.Timer.EC=[this,this.JS];this.B0.Jy([A=B._GetAutoObject(B.Device.
Device),A.H5,A.D8]);this.B0.GT(B._GetAutoObject(B.ul.Hd));this.BR(aArg);},_Done:
function(){this.__proto__=B.Core.Root;this.BY._Done();this.CT._Done();this.CX._Done(
);this.C2._Done();this.Timer._Done();this.B0._Done();B.Core.Root._Done.call(this
);},_ReInit:function(){B.Core.Root._ReInit.call(this);this.BY._ReInit();this.CT.
_ReInit();this.CX._ReInit();this.C2._ReInit();this.Timer._ReInit();this.B0._ReInit(
);},_Mark:function(D){var A;B.Core.Root._Mark.call(this,D);if((A=this.BY)._cycle
!=D)A._Mark(A._cycle=D);if((A=this.CT)._cycle!=D)A._Mark(A._cycle=D);if((A=this.
CX)._cycle!=D)A._Mark(A._cycle=D);if((A=this.C2)._cycle!=D)A._Mark(A._cycle=D);if((
A=this.Timer)._cycle!=D)A._Mark(A._cycle=D);if((A=this.B0)._cycle!=D)A._Mark(A._cycle=
D);},_className:"Application::TutorialApplication"};C.Fx={Fe:null,BY:null,Cl:null
,BS:null,CJ:null,FC:J5,JO:function(AV){var A;(A=this.Fe)?A[1].call(A[0],this):null;
},H6:function(value){if(B.to(this.Fe,value))return;this.Fe=value;this.BS.Df=value;
},H9:function(value){if(this.FC===value)return;this.FC=value;this.BS.H8(value);}
,H_:function(value){if(this.FC===value)return;this.FC=value;this.CJ.D9(value);},
_Init:function(aArg){B.Core.Aj._Init.call(this,aArg);B.uj.Fz._Init.call(this.BY={
Af:this},0);B.uj.Cl._Init.call(this.Cl={Af:this},0);B.ul.BS._Init.call(this.BS={
Af:this},0);B.uj.Text._Init.call(this.CJ={Af:this},0);this.__proto__=C.Fx;this.Ak(
Hg);this.BY.Ak(Hg);this.Cl.Ak(Hg);this.Cl.JL(1);this.Cl.BZ(0xFF000000);this.BS.Ak(
J6);this.BS.H8(J7);this.CJ.Ak(J8);this.CJ.D9(J9);this.CJ.BZ(0xFF010101);this.BQ(
this.BY,0);this.BQ(this.Cl,0);this.BQ(this.BS,0);this.BQ(this.CJ,0);this.BS.Df=[
this,this.JO];this.BS.GT(B._GetAutoObject(B.ul.G4));this.CJ.EB(B.s$(B.ui.Eu));},
_Done:function(){this.__proto__=B.Core.Aj;this.BY._Done();this.Cl._Done();this.BS.
_Done();this.CJ._Done();B.Core.Aj._Done.call(this);},_ReInit:function(){B.Core.Aj.
_ReInit.call(this);this.BY._ReInit();this.Cl._ReInit();this.BS._ReInit();this.CJ.
_ReInit();},_Mark:function(D){var A;B.Core.Aj._Mark.call(this,D);if((A=this.Fe)&&((
A=A[0])._cycle!=D))A._Mark(A._cycle=D);if((A=this.BY)._cycle!=D)A._Mark(A._cycle=
D);if((A=this.Cl)._cycle!=D)A._Mark(A._cycle=D);if((A=this.BS)._cycle!=D)A._Mark(
A._cycle=D);if((A=this.CJ)._cycle!=D)A._Mark(A._cycle=D);},_className:"Application::PushButtonComponent"
};
C._Init=function(){C.TutorialApplication.__proto__=B.Core.Root;C.Fx.__proto__=B.Core.
Aj;};C.Bd=function(D){};return C;})();

/* Embedded Wizard */