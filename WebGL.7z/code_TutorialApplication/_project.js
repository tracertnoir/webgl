/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiCompr_9_30;var TutorialApplication;if(!EmWiCompr_9_30)throw new Error("The Embedded Wizard runtime environment file 'emwi_compr_9_30.js' isn't yet loaded!"
);if(TutorialApplication)throw new Error("The application file '_project.js' included twice!"
);TutorialApplication=(function(){var B={__proto__:EmWiCompr_9_30};
B.Default=0;
B.tS=[480,320];B.m7=function(){return B.ia.TutorialApplication;};B.sy="Embedded Wizard sample application";
B.lg=0;B.ue=0;B.hs=[];B._Init=function(){B.Core._Init();B.um._Init();B.Graphics.
_Init();B.ui._Init();B.uj._Init();B.ul._Init();B.uk._Init();B.ia._Init();B.Device.
_Init();B.un._Init();B.uo._Init();this.__proto__._Init.apply(this,arguments);};B.
tQ=function(D){B.Core.Bd(D);B.um.Bd(D);B.Graphics.Bd(D);B.ui.Bd(D);B.uj.Bd(D);B.
ul.Bd(D);B.uk.Bd(D);B.ia.Bd(D);B.Device.Bd(D);B.un.Bd(D);B.uo.Bd(D);};return B;}
)();

/* Embedded Wizard */