/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var TutorialApplication;if(!TutorialApplication)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(TutorialApplication.Device)throw new Error("The unit file 'Device.js' included twice!"
);TutorialApplication.Device=(function(){var B=TutorialApplication;var C={};
var Ae="Sorry, but this device is not able to ring the bell!";var AJ="Sorry, but this device is not able to present a weather forecast!";
C.Cw={EJ:0,EI:function(){if(this.AP&&this.AP.EI)return this.AP.EI.apply(this,arguments
);else return this.Ka.apply(this,arguments);},Ka:function(){B.uf("%s",Ae);},FA:function(
){if(this.AP&&this.AP.FA)return this.AP.FA.apply(this,arguments);else return this.
Kb.apply(this,arguments);},Kb:function(){B.uf("%s",AJ);},Fp:function(){if(this.AP&&
this.AP.Fp)return this.AP.Fp.apply(this,arguments);else return this.J_.apply(this
,arguments);},J_:function(){B.uf("%s",Ae);},D8:function(value){if(this.AP&&this.
AP.D8)return this.AP.D8.apply(this,arguments);else return this.J$.apply(this,arguments
);},J$:function(value){if(this.EJ===value)return;this.EJ=value;},H5:function(){return this.
EJ;},_Init:function(aArg){B.uk.Cw._Init.call(this,aArg);this.__proto__=C.Cw;var Id=
this._variants();if(Id){this.AP={};Id._Init.call(this,aArg);}},_Done:function(){
if(this.AP)this.AP._Done.call(this);this.__proto__=B.uk.Cw;B.uk.Cw._Done.call(this
);},_ReInit:function(){B.uk.Cw._ReInit.call(this);if(this.AP)this.AP._ReInit.call(
this);},_Mark:function(D){B.uk.Cw._Mark.call(this,D);if(this.AP)this.AP._Mark(D);
},_variants:function(){return B.un.HP._variants();},AP:null,_className:"Device::DeviceClass"
};C.Device={_Init:function(){C.Cw._Init.call(this,0);},_variants:function(){return this;
},_this:null};
C._Init=function(){C.Cw.__proto__=B.uk.Cw;};C.Bd=function(D){var A;if((A=C.Device.
_this)&&(A._cycle!=D))A._Done(C.Device._this=null);};return C;})();

/* Embedded Wizard */